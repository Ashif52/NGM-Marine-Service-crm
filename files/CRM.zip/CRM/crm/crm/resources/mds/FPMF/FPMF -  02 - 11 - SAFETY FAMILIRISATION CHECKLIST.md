

Vessel Name:                                         Port:                                                    Date:



Name:                                                     Rank/Rating:



General Emergency Alarm :  Seven or more Short Blasts followed by one Long Blast on the Ship’s Whistle or Siren

and additionally on the Electrically Operated Bell.



Fire Alarm:  Continuous sounding of an Electrically Operated Bell and the Ship's Bell

Abandon Ship Signal:  General Emergency Alarm followed by the Spoken Word "ABANDON SHIP" by the Master of the vessel. Upon hearing any of these alarms, all persons to proceed to their respective muster station.

### Note : Items in this checklist shall be completed, as soon as possible, upon joining the vessel, before assigning duties to the person on board.



Communication means understood:  Important Telephone Nos:    Bridge:           Engine Room:

Safety signs, symbols sighted and understood

Your duty if a man falls overboard:  Raise alarm, throw lifebuoys, stand-by for orders

Your duty if fire or smoke is detected:  Raise alarm, assess fire, report location, and proceed for em. station

Upon hearing abandon ship alarm:  Don lifejacket and proceed to embarkation station

Your Primary Muster Station is located at:

Your Secondary Muster Station is located at:

You are a member of the               Team for Emergency Stations.

Your Emergency Stations Duty is:

Your Lifeboat No is:

Your Lifeboat Station Duty is:

Your SOPEP Duty is:

The nearest extinguisher to your cabin is    and is located at:

Type of extinguishers and operations explained:

Your duty in case of medical emergency: raise alarm, provide first aid, seek for prompt help

Your Life Jacket located in the                                  Donning Instructions known:

The Nearest Fire Hose/Nozzle to Your Cabin is located at:

The Nearest Manual Fire Alarm to Your Cabin is located at:

Closing / Opening of fire, weather tight and water tight doors, emergency escape explained :







Signature of Chief Officer / Chief Engineer :                                                     Date :





Signature of Enjoining  :                                                                                     Date :

