## SEAFARERS APPRAISAL/ CONFIDENTIAL REPORT FORM
(To be prepared when the Crew signs off)

Rate the performance in comparison to the requirements of the position by ticking the appropriate box.

1= POOR : 2=IMPROVEMENT NEEDED : 3=SATISFACTORY : 4= GOOD : 5= EXCEPTIONAL



REMARKS IF ANY :