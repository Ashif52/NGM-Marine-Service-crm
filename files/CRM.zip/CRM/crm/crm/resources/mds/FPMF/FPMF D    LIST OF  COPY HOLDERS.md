





List of controlled copy holders:



















Remarks: As the company takes over any vessel’s under management, running numbers shall be given for the manuals issued to the controlled copy holders. Each Vessel will have one copy  on board once these vessels are taken by management under this code.





Note: All pages of Master copy will be signed by Managing Director. Prior doing any revision in SMS document, the DPA has to take concurrence from Managing Director. The new revision will be filled in master copy with signature of Managing Director and other copy holders will be updated with new revision. Obsolete copy from all SMS manual will be removed and filled for audit reference.





