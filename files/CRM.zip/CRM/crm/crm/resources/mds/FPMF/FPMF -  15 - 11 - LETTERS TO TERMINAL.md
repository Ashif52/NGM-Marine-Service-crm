Letter of Protest for

Non Issuance of Documents







M/T:  						            PORT:

BERTH: 						 DATE:



To: Whom It May Concern.



Dear Sirs,



I, Master of M/T ________________________ do hereby make a formal protest for



not providing CERTIFICATE OF QUANTITY, CERTIFIACTE OF ORIGIN & CARGO MANIFEST.



This Vessel has loaded ___ grade of cargo ……………………………



Your Terminal has not provided CERTIFICATE OF QUANTITY, CERTIFICATE OF ORIGIN  CARGO MANIFEST & BILL OF LADING.



I, Master of the vessel, on behalf of owner & charterers hold you totally responsible for any delay, claims or liabilities that may arise due to the above mentioned fact and absolves self, owner or charterer towards all liabilities and any losses that my owner or charterer may suffer due to this incident.



We also reserve the right to extend this protest at a date and place convenient.



Please acknowledge receipt of this letter.



Yours faithfully,				   Received by:









___________________________     __________________________________

Master / Ch. Off.			             Terminal Representative / Boarding Officer



































Letter of Protest for

Load on Top Line Push Quantity



M/T:  					   	           PORT:

BERTH: 						 DATE:



To: Whom It May Concern.



Dear Sirs,



I, Master of M/T ___________________________do hereby make a formal protest for the



line push quantity loaded on top of …………… in ………… COT:



As per the Programme letter issued by …………………, v/l has to load the Shore line push quantity on top of …………. in ………. COT.

Vessel will not be responsible for any Change in Quantity, Change in Quality or Contamination of ……………. cargo in ………….. COT, due to the above mentioned Load on top operation as instructed by ………………. and the liabilities whatsoever.



I, Master of the vessel, on behalf of owner & charterers hold you totally responsible for any delay, claims or liabilities that may arise due to the above mentioned fact and absolves self, owner or charterer towards all liabilities and any losses that my owner or charterer may suffer due to this incident.



We also reserve the right to extend this protest at a date and place convenient.



Please acknowledge receipt of this letter.



Yours faithfully,				   Received by:













___________________________     __________________________________

Master / Ch. Off.			             Terminal Representative / Boarding Officer

































Letter of Protest for

Delay in Placement of Gangway



M/T:  							 PORT:

BERTH: 						 DATE:



To: Whom It May Concern.



DEAR SIR,



This is to bring to your notice that my good vessel MT ________________ Berthed at __________  Terminal  on ________ and was All Fast  ………….. hrs on _______. Vessel was aligned to Load/Discharge ________  through _________  Manifold. From the time vessel was made  All fast we were trying to lower and place Gangway/MOT Ladder at a location without any obstruction on the jetty. The space constraints were so much that it was impossible to lower the Gangway/MOT Ladder with out damaging the shore side installation.

With a lot of effort and stress/strain, & surgical precision the vessel succeeded in lowering the accommodation ladder/gangway/MOT Ladder safely onto the jetty.



I hereby request you to make required alternate arrangements, e.g. shore gangway, for safe access to vessel for shore  & ship staff in future.



I, Master of the vessel, on behalf of owner & charterers hold you totally responsible for any delay, claims or liabilities that may arise due to the above mentioned fact and absolves self, owner or charterer towards all liabilities and any losses that my owner or charterer may suffer due to this incident.



We also reserve the right to extend this protest at a date and place convenient.



Please acknowledge receipt of this letter.



Yours faithfully,				   Received by:









___________________________                       __________________________________

Master / Ch. Off.			             Terminal Representative / Boarding Officer

































LETTER OF PROTEST







TO: THE SHIPPER/LOADING MASTER

TERMINAL NO.







DEAR SIR,

THIS IS TO BRING TO YOUR NOTICE THAT THE VESSEL HAD REQUESTED FOR LOADING RATE OF____________CUM/HR, WHERE AS THE CARGO WAS LOADED WITH AN AVERAGE RATE OF____________CUM/HR, THIS HAS PROLONGED THE PERIOD OF LOADING FOR WHICH VESSEL CANNOT BE HELD RESPONSIBLE.

I, MASTER OF__________________________________________,ON BEHALF OF MY CHARTERER AND OWNER PROTEST AGAINST THIS DELAY AND HOLD YOU TOTAL RESPONSIBLE FOR THIS DELAY AND ANY LOSSES WHICH MY CHARTERER OR OWNER MAY INCUR DUE TO THIS DELAY. I FURTHER RESERVE THE RIGHT TO EXTEND THIS NOTICE OF PROTEST AT FUTURE DATE AND PLACE CONVENIENT.





ACKNOWLEDGED BY						          CAPT

MASTER

M.T.



DATE :



PLACE:



Cc: Ship 	              				Cc: OFFICE

















LETTER OF PROTEST







TO: THE SHIPPER/LOADING MASTER

TERMINAL NO.



DEAR SIR,



THIS IS TO BRING TO YOUR KIND NOTICE THAT ON COMPLETION OF LOADING, FREE WATER CONTENT AND TRACES OF WATER WERE FOUND/ IN MANY TANKS. HOWEVER DUE TO INSUFFICIENT SETTLING TIME, IT IS NOT POSSIBLE TO ASSESS THE EXACT QUANTITY OF FREE WATER IN THE CARGO.PLEASE NOTE DURING THE PASSAGE THE WATER MAY SETTLE AND QUANTITY OF FREE WATER MAY INCREASE. SINCE THE WATER HAS COME WITH THE CARGO, THE VESSEL WILL NOT BE  RESPONSIBLE FOR SAME.  TOTAL QUANTITY OF FREE WATER FOUND WAS CUM______________________.



I, MASTER OF THE VESSEL, ON BEHALF OF THE OWNER AND CHARTERER, HOLD YOU RESPONSIBLE FOR THE FREE WATER IN THE CARGO AND ABSOLVES SELF OWNER AND CHARTERER TOWARDS ALL LIABILITIES AND OR ANY LOSSES THAT MY OWNER OR CHARTERER MAY SUFFER DUE TO THIS INCIDENT. WE ALSO RESERVE OUR RIGHT TO EXTEND THIS NOTE OF PROTEST AND TAKE UP THE MATTER AT A FUTURE DATE AND PLACE CONVENIENT.









# ACKNOWLEDGE BY					CAPT.

MASTER

M.T.

DATED:

PLACE:







CC  : OFFICE				CC  : Charters







LETTER OF PROTEST FOR QUANTITY





Subject:  Excessive Cargo Difference

Date:

Time:

Year:

To

____________________________________

The cargo quantities as gauged aboard the  M.T. __________________________________ and computed on the basis of ullages taken on completion of loading at _________ _______________________ (Port/ Berth) on ________________( Date)__________ (Time) __________________(Year) calculated using _______________________ _______________________(Tables used).  When compared with cargo quantities based on shore figures (B/L) indicates an apparent excessive cargo difference of ________________M.T.

On completion of discharge, a comparison will be made of the cargo quantities with the B/L issued at __________________ (Port) ___________________ (Date)

If this comparison confirms the indicated excessive cargo differences, we serve notice that we hold you, as cargo suppliers, responsible for all costs and expenses arising from consequence of the discrepancies.



B/L Quantity _________________

Ship’s Fig ___________________

Master   _____________________

M.T.       _____________________

Receipt Acknowledged

Terminal Representative	                              	          Date   _______________________





LETTER OF PROTEST





Place:

Date:



TO:

___________________

___________________

___________________





Sub :	Bill of Lading No.	:

Cargo			:

Weight/ Number	:

Consignee		:





One original Bill of Lading signed by _____________ for the cargo in the title has been presented to me for carriage to the discharge port.  I have requested that all other Original Bills of Lading plus all copies be endorsed as follows:-



“One Original Bill of Lading retained

on board against which bill delivery

of cargo may be properly made on instructions

received from Shippers / Charterers.”





But this request has been refused.



In the circumstances I hereby protest at Shippers refusal to allow me to endorse the Bills of Lading, and Owners will accept no liability for wrongful delivery of the Bills of lading or Cargo to third parties at the Discharge Port.  Should no Original Bill of Lading (in addition to the Original put on board my vessel) be available at Discharge Port.  Owners will require the usual Letter of Indemnity (L.O.I.) in the form ascribed by their P & I Club for delivery or cargo without production of Bills of lading prior to commencing the discharge of the cargo.







Signed:				Signed:



Ship	   				For Shippers/Charterers/ Cargo Interests.







CC: OFFICE   					CC: P & I Club















Letter of Protest for

Insufficient Hose Connection



M/T:  					           	 PORT:

BERTH: 						 DATE:





To: Whom It May Concern.



Dear Sirs,



I, Master of M/T ________________________ do hereby make a formal protest for difference in diameter of cargo hoses connected



The Vessel has offered ________manifold connection of ___ inches diameter for loading / discharging  of …………………..



Your Terminal has presented      loading arm of ….. inches diameter for loading / discharging of …………………….



The reduction in diameter of loading arm presented by you has imposed restriction on the vessel’s normal cargo handling capacity.



I, Master of the vessel, on behalf of owner & charterers hold you totally responsible for

any delay, claims or liabilities that may arise due to the above mentioned fact

and absolves self, owner or charterer towards all liabilities

and any losses that my owner or charterer may suffer due to this incident.



We also reserve the right to extend this protest at a date and place convenient.



Please acknowledge receipt of this letter.



Yours faithfully,				   Received by:





___________________________     __________________________________

Master / Ch. Off.			             Terminal Representative / Boarding Officer

































Letter of Protest for

Same Shore Line for Different Grades







M/T:  						          PORT:

BERTH: 						 DATE:



To: Whom It May Concern.



Dear Sirs,



I, Master of M/T _____________________ do hereby make a formal protest for the



Same Shore Line being used for loading / discharging of …………….



The Same Shore line was used for loading of _______ and ________ into Ships tank # _______



Vessel will not be responsible for any Change in Quantity, Change in Quality or Contamination of ___________ cargo in __________ COT, due to the above mentioned same shore line and the liabilities whatsoever.



I, Master of the vessel, on behalf of owner & charterers hold you totally responsible for

any delay, claims or liabilities that may arise due to the above mentioned fact

and absolves self, owner or charterer towards all liabilities

and any losses that my owner or charterer may suffer due to this incident.



We also reserve the right to extend this protest at a date and place convenient.



Please acknowledge receipt of this letter.



Yours faithfully,				   Received by:









___________________________     __________________________________

Master / Ch. Off.			             Terminal Representative / Boarding Officer



