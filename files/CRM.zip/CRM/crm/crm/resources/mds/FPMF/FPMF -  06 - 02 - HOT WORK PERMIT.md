This permit to work relates to any work involving temperature conditions which are likely to be of sufficient intensity to cause ignition of combustible gases, vapour or liquids in or adjacent to the area involved. Before completing this form, refer to the accompanying guidance notes, and to Section 2.8.



GENERAL

This permit is valid from   …………………hrs     Date ……………………..

…………………hrs     Date …………………….



Location of hot work :



Has an enclosed space entry permit been issued?                               Yes / No

Reason if ‘No’:



Description of hot work :





Personnel carrying out hot work ……………………………………………………….

Person responsible for hot work ……………………………………………………….

Person responsible for safety / risk assessment.……………………………………



SECTION 1

1.1	Has the hot work area been checked with a combustible gas indicator for hydrocarbon vapours?	Time :                                        	       Yes / No

1.2	Has  the surrounding area been made safe ?  Time :           	        Yes / No

Has risk assessment carried out ? Time :		        Yes / No



SECTION 2

2.1	Has the hot work area been checked with a combustible gas indicator for hydrocarbon vapours ?				             	        Yes / No

2.2	Has the equipment or pipeline been gas freed ?	  	                  Yes / No

2.3	Has the equipment or pipeline been blanked ?		         	        Yes / No

2.4	Is the equipment or Pipeline free of liquid ?		                  Yes / No

2.5	Is the equipment isolated electrically ?			                  Yes / No

2.6	Is the surrounding area safe ?				                  Yes / No

2.7	Is additional fire protection available ?		               	        Yes / No

Special conditions/precautions………………………………………………………….

………………………………………………………………………………………………



In the circumstances noted it is considered safe to proceed with this hot work.



Signed ……………………………………………………………………… Master



………………..…………………………………Person Incharge of hot work team















SECTION 3

The work has been completed and all persons under my supervision, materials and equipment have been withdrawn.



Authorised officer in charge……………………………………Time………….



Date…………………



First copy for display at work area

Second copy for ship or terminal records



Guidance Notes for Hot Work Permit

GENERAL

Starting/Finishing time must not exceed the Authorised Signatories’/Responsible Officer’s working hours.



Specific location of hot work to be given.



Description of hot work to include type of equipment to be used.



Risk Assessment form  to be filled up.



SECTION 1 :

Applies to all hazardous work not involving naked flame or continuous spark production, and would include use of electrical, use of air driven rotary equipment, sand or grit blasting, hammering and mechanical chipping and movement of equipment of materials over or near to machinery that is operating. All steps have been Risk Assessed and assigned a specific Risk Factor . Refer Risk Assessment Form.



SECTION 2 :

Applies to all hot work involving high temperatures, open flame, electric arc or continuous source of sparks etc. This type of work includes but is not limited to welding, burning and grinding. All steps have been Risk Assessed and assigned a specific Risk Factor . Refer Risk Assessment Form.





