





(To be completed by Officer of Watch and handed over to boarding Pilot)





VESSEL: ____________________________                    DATE    : ____________________________



PLACE  : ____________________________                   TIME     : ____________________________



## Cargo onboard _______________________ m/ts



Call sign ________________       Deadweight ________________ m/ts      Displacement ______________ m/ts



Draught in m/ft:     Forward __________________     Aft __________________     Mid ___________________

__________________________________________________________________________________________



### SHIP’S PARTICULARS



## LOA:		ANCHOR CHAIN, 	Port:	__________	Shackles

## LBP:			Stbd:	__________	Shackles

## Breadth:			1 Shackle: ______	Mtrs

Depth:

Draught (summer):

Deadweight:

Air draught in: _________ mtrs/______ft_____in

(Please give above dimensions)











## Received by: Pilot’s name: _____________________Signature: ___________________