The Master has to conduct / provide at least one drill / training to all shipboard staff every month in respect of Abandon ship as a requirement of SOLAS.





Other than that master shall perform any of the below mentioned drills in such a way that the cycle of 12 drills is covered within a period of 12 months and follow the plan as closely as possible .







Approved by: ________________________________  			Date:____________________

DPA



