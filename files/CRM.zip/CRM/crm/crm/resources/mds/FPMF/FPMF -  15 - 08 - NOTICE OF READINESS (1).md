

To Messer:…………………………………

………………………………….

………………………………….

………………………………….





Dear Sirs,



Please note that the ship……………………………… Nationality .……………………. Call Sign .…………….



Has arrived at ………………………………………… on ………………….. at …………………….. hours and



Is in every respect ready to commence operations in accordance with the terms and conditions of the Charter



Party dated ………………………….





Time is to count as per the terms and conditions of the above mentioned Charter party.



Please confirm receipt of the Notice of Readiness by signing and returning the copy attached.







N.O.R. tendered on ………………………………… at …………………….. hrs.



N.O.R. accepted on ………………………………… at …………………….. hrs.





























____________________________				________________________________



MASTER							CHARTERER