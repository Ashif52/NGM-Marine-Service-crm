

TRAINING PLAN (SHIPBOARD)



# Training Plan for the year:













Approved by DPA :   					                                                        Date:







Note: 	The Master and Chief Engineer are responsible for providing appropriate training to shipboard personnel as per plan and shall also be responsible for maintaining record of training in the Personal Training Record Form. However Master or C/E may designate his deputy to carry out training on behalf but he/they shall not be relieved from duty/responsibility as a trainer.  Need for any additional training, shall be provided by the Master / Chief Engineer and to inform DPA.

