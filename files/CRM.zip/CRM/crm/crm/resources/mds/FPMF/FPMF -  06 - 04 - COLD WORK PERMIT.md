This permit relates to any work in a hazardous or dangerous area which will not involve generation of temperature conditions likely to be of sufficient intensity to cause ignition of combustible gases, vapours or liquids in or adjacent to the area involved.



General

This permit is valid from             	Hrs.            Date :

To           	Hrs.            Date :



Location of cold work :

Has enclosed space entry permit been issued?						Yes/No/NA

Description of cold work :

Personnel carrying  out work: 1)

2)



Responsible person in attendance :



SECTION 1

Preparation and checks to be carried out by Officer in Charge for cold work to be performed.

1.1	The equipment/pipeline has been prepared as follows:

Vented to atmosphere:  Yes/No	Drained:   Yes/No

Washed:                           Yes/No	  Purged:   Yes/No

Other:

1.2	The equipment/pipeline has been isolated as follows:

Lines Spaded:		Yes/No		Lines Disconnected:  Yes/No

Valves Closed:		Yes/No		Other :

1.3	Is equipment free from:

Oil:  Yes/No	Toxic Gas:  Yes/No	H2S:  Yes/No	Pressure:  Yes/No

1.4	Is surrounding area free from hazards:					Yes/No

1.5	If work is to be performed on electrical equipment has that

equipment been isolated?                                                                                        Yes/No



SECTION 2

Information and instructions to person carrying out work:

2.1	The following personal protection must be worn

.............................................................................................................................................................

2.2	Equipment/Pipeline contained following material in service

.............................................................................................................................................................

2.3	Equipment expected to contain the following hazardous material when opened

.............................................................................................................................................................

2.4	Special Conditions/Precautions

.............................................................................................................................................................



In the circumstances noted it is considered safe to proceed with this work.

Signed .............................................................................................................Master/Responsible Officer

...........................................................................................................Person carrying out work task

or in charge of work team

SECTION 3

The cold work has been completed and all persons under my supervision, materials and equipment have been withdrawn.





Authorised person in charge.........................................................Time...................................Date...................





Note: Please read the Guidance Notes on the back side



(To appear on reverse side of permit)





Guidance Notes for Cold Work Permit



Starting/finishing time must not exceed the Authorised Signatories’/Responsible Officer’s working hours.



Specific location of work to be given.



Description of work to include type of equipment to be used.



This permit should be used for but not limited to the following cold work:



Blanking/deblanking.



Disconnecting and connecting pipe work..



Removing and fitting of valves, blanks, spades or blinds.



Work on pumps, etc.



Clean up (oil spills).