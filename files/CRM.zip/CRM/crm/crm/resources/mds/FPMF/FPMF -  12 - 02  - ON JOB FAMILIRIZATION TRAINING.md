



This checklist is not to be filled for officers undergoing On Job familiarization.









PAGE 1 OF 3



DECK FAMILIARISATION CHECKLIST

Date:



I have undertaken the checks listed above, on joining the vessel.

Signature of newly joined officer in-charge of navigational watch......................................................



I have imparted the checks listed above to..............................................................................



Signature of Master/Officer imparting the familiarisation......................................................



Name of Vessel:









PAGE 2 OF 3

ENGINE ROOM  FAMILIARISATION CHECKLIST



I have undergone machinery familiarisation listed above

Signature of Engineer Officer with date



Name of Engineer Officer :

Rank of Engineer Officer  :

CEO’s Signature with date :

Name of Vessel:



PAGE 3 OF 3

