

LINER CALIBRATION			        PISTON GROVES SIZE



a			A																A						B																		B





C







BUT CLEARNCE				         PISTON GRADE CLEARANCE



