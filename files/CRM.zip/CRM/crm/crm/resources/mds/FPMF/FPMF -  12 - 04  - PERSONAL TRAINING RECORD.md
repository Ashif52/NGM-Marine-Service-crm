NAME :                                                  C.D.C. :                                              VESSEL:



DATE JOINED:                                    PLACE OF JOINING:



DESIGNATION:                                   DEPT.:



QUALIFICATIONS:





Remarks (if any):









Approved by:                                                   Signature:                                        Date:

(Master/Chief Engineer)