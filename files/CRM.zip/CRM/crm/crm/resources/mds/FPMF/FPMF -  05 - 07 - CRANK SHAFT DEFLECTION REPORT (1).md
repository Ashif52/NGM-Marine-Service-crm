



Start with crank at D.B.C.

Move crank to position “A” and fit gauge between the webs, set dial to zero.

Continue turning the engine in direction shown (ahead direction) and read gauge at position “B”, “C”, “D” and “E” of crankpin , without stopping movement of crankshaft.

Opening of webs to be recorded as +.

Closing of webs to be recorded as -.

















