TANK INSPECTION CERTIFICATE





VESSEL			:                                                                    DATE	:

LOCATION                         :                                                                     TIME 	:

CARGO TO BE LOADED	:







Information supplied by the Ship's Officer or Ship's Log cannot be guaranteed as accurate and no liability can be assumed for errors that result from improper supply, of information. The responsibility for such information must rest with the ship and her officers.





Last Cargo                       :

Second Last Cargo         :

Third Last Cargo             :





Method said to be used to clean tanks :







Methods said to be used to clean lines system :









Are any tanks coated                                       :

Which tanks and types of coating                 :



This is to certify that on the above date, we carried out inspection of the following tanks:





TANK NOS      :



Visual inspection from deck level due to ship's tank were not Gas Free and information supplied by the ship's Chief Officer, we consider that the said tanks are :





SUITABLE TO LOAD NOMINATED CARGO

Whilst every effort has been made to comply with Tank Inspection instructions, we cannot be held responsible for those areas beyond visual inspection ( such as pumps, lines etc) and/or the effectiveness of the advised tank cleaning methods.



Valves Sealed and Numbered       :





CHIEF OFFICER							SURVEYOR





## DRY   TANK    CERTIFICATE





M.T.     :

PORT :

DATE :







THIS IS TO CERTIFY THE UNDERSIGNED CHARTERERS/ SHIPPERS REPRESENTATIVES INSPECTED THE VESSELS CARGO TANKS…3P/3S/4C/ & 7C









AFTER THE DISCHARGE OF CARGO   ……….





FOUND WELL DRAINED AND





TANK INSPECTION COMMENCED  -     @	HRS

TANK INSPECTION COMPLETED    -     @	HRS













SURVEYORS SIGN/ STAMP					                   CHIEF OFFICER









REPRESENTING







DATE	:				                            LOCAL TIME :

