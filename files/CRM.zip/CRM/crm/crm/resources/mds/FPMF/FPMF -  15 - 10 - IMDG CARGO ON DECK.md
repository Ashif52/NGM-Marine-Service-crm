CHECK LIST FOR LOADING AND DISCHARGING OF IMDG CARGO



After loading



During Discharging











____________________						______________________

Master						                       Chief Officer





