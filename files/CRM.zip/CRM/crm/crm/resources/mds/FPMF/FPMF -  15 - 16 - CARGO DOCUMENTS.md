RECEIPT FOR SAMPLES









Date		:



M.T 	:



At Port	:









Received from                                                                     the under mentioned  sealed and labelled samples in respect of the cargo[es] loaded into the above named vessel :-

























### MASTER





















CERTIFICATE OF QUALITY



Report No.		:

Sample No.       	:

Vessel   		:

Location          	:

Date          		:

Grade              	:

Sample ref.       	:









Remarks:







Test method deviation:

Test conducted by Emp#:

Report prepared by Emp#:

The above test results are only applicable to the sample(s) referred above



### REPORTED BY











CERTIFICATE OF QUANTITY







VESSEL                                   :



DATE                                       :



LOCATION                              :



PRODUCT                               :





The undersigned, independent Surveyor, herewith observed that the quantity loaded on the above mentioned vessel amounts to:







METRIC TONS (IN AIR)                 :

LONG TONS                                    :

US BARELS @ 60 DEG F                  :









These quantities have been determined by Shore Tank Measurements.













































RECEIPT FOR DOCUMENTS





M/T                   :



AT PORT            :





RECEIVED THE ABOVE MENTIONED DOCUMENTS.







DATE     :                                                                           MASTER :



