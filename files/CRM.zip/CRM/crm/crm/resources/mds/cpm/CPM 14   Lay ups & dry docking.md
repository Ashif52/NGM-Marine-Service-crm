



14. LAY UPS & DRYDOCKING



14.1 OBJECTIVE -To ensure that the dry-docking & repairs of the vessels are carried out in time to

ensure compliance with class & statutory requirements.



14.2 RESPONSIBILITY -The technical superintendent is responsible for ensuring that the dry-docking surveys

are planned, logistical arrangements made and personnel are assigned for attending vessel in dry dock.



14.3 DESCRIPTION



14.3.1 Major repairs and overhauls shall be carried out during the dry-docking of the ships. The specifications

for this work shall be prepared by the technical superintendent in consultation with the vessel.



14.3.2 The dry-docking shall be planned as per the requirement of the classification society and/or

the Administration.



14.3.3 The repair list shall be circulated to various yards and Original Equipment Manufacturers (OEM) and

other equipment repair firms and quotations obtained by the Company.



14.3.4 The dry dock shall be selected based on quality, cost, time, payment terms and their past record.



14.3.5 During dry-docking, the following work shall be among those carried out:

Inspect the hull and other underwater parts and attend as necessary.

Coat the vessel's underwater parts for prevention of corrosion and fouling.

Overhauling of identified equipment.

Inspect rudder, propeller and shaft seals and attend to as warranted.

Lower anchor cables on the dock’s bottom and wash, change end to end and calibrate.

Replace wasted hull anodes.

Inspect cargo and ballast tanks and coat, if required.

Attend to main and auxiliary machineries and overhaul, if required.

Inspect navigation and radio equipment and service, if required.

Carry out planned maintenance and overhaul machinery based on running hours and on survey cycles.

Modify/upgrade where applicable any equipment to meet Charterer’s requirements.

Attend any other items requiring repair.



14.3.6  Once the vessel enters the dry dock (i.e. she is tied up alongside their quay including double banking

or is in the dry dock), the responsibility for the safety of the vessel shall be divided as below:



14.3.6.1 The Technical Superintendent shall ensure that the Master of the vessel is aware of his responsibility

for vessel stability and for ensuring that the ship staff follows the necessary safety norms.



14.3.6.2 All other aspects of safety, such as providing water during a fire etc, shall be the responsibility

of the shipyard. However Technical Superintendent shall ensure that vessel’s staff, especially the Master, is

aware of the shipyards rules and regulations and seek clarifications where applicable before commencing work.



14.3.6.3 The above distribution of responsibilities shall be conveyed in writing to the dry-dock, where ever

feasible.



14.3.7 On completion of the repair work, all machinery that has been overhauled shall be tried out

to the satisfaction of the Chief Engineer, superintendent & classification surveyors as applicable.



14.3.8  Inspection & testing of repairs and modification shall be planned and carried out as under:



14.3.8.1 Wherever applicable, inspection of material at vendor works shall be done as per approved QA/QC

plan and/or inspection and test plan approved by the Technical Superintendent.







14.3.8.2 The qualification and suitability of all manpower including service and welding technicians sent to the

site are reviewed and approved by the Tech Superintendent, wherever required.



14.3.9  Monitoring the performance of repairs/ modification activities: The Technical Superintendent shall

employ measure(s) to determine the quality of services include those specified or implied in contracts or

charter parties, etc, so that the repairs/ modification operations are done within allowable downtime as

far as possible. Wherever practical, back up machinery is maintained in optimum condition through

preventive maintenance.



14.4 RECORDS



14.4.1 Records of the following shall be maintained:

All modifications made including approved sketches and plans shall be maintained on the vessel as a

part of  the vessel’s permanent documentation.

Dry dock specs.

Work done reports.

Survey reports.

Renewed certificates.