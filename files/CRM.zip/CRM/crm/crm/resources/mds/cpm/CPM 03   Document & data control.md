

3. DOCUMENT AND DATA CONTROL



3.1 OBJECTIVE

To control the preparation (review & approval), issue (release & distribution) and maintenance

(retention & disposal) of documents in accordance with the requirements of the ISM code.



3.2 RESPONSIBILITY

DPA: For controlling all the documents in consultation with Managing Director.



3.3 DESCRIPTION



3.3.1 CONTROL OF CONTROLLED DOCUMENTS



A list of controlled documents and its distribution shall be maintained by the DPA, wherein the

recipients holding hard copies of the controlled documents shall be identified.

Copies of documents marked “CONTROLLED COPY” are the only documents that are controlled.

All other documents are uncontrolled.



3.3.2 AMENDMENTS TO CONTROLLED DOCUMENTS



Amendments to controlled documents shall be prepared by the DPA and approved by the Managing

Director.

A revision number and an effective date shall identify each amendment.

Obsolete documents shall be filled and kept for audit purpose only.

Records of changes are reflected in the respective manuals.

The amendments shall be sent to the controlled copy holders along with a Controlled Document

Transmittal Record (Refer manual CPMF 03-01), the acknowledged copy of which is to be maintained at

office for records.



3.3.3 RE-ISSUE OF CONTROLLED DOCUMENTS

Whenever the amendments involve a major part of the manual, the whole manual may be re-issued by

the DPA.



3.3.4 CONTROL OF EXTERNAL DOCUMENTS



The DPA shall maintain a list of external documents (Refer manual CPMF 03-02) and shall monitor

the changes and update them regularly.

The DPA shall ensure that the status of documents are reviewed at least once in a year & confirm that

they have the latest version for reference as applicable.

Superseded documents, shall be marked clearly as ‘For Reference Only’ and retained for reference

as required.



3.4 RECORDS



Following records shall form a part of this procedure:-

CPMF 03-01 – Controlled document transmittal record

CPMF 03-02 – External documents inventory

CPMF 03-03 – Office/Ship- SMS filling structure.



