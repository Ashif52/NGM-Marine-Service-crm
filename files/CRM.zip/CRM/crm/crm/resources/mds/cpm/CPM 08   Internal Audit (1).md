8. INTERNAL AUDIT



8.1 OBJECTIVE



8.1.1 To describe a method of periodical verification for ascertaining:-

If the SMS of the company conforms to the ISM code.

If the day-to-day operations conform to the documented SMS of the company



8.2 RESPONSIBILITY

The DPA shall be responsible for preparing the audit plan (Refer manual CPMF 08-04) and appoint auditor(s)

for carrying out audits in the office and on board vessels.



8.3 DESCRIPTION

8.3.1 Internal audits shall be conducted both in the office and on board the vessels as per the audit plan

(Refer manual CPMF 08-04).



8.3.2 Internal audits shall be carried out at least once a year both ashore and on board the vessel.



8.3.3 The audit plan shall be made taking into consideration the status and importance of the activities

to be audited as well as the results of the previous audits.



8.3.4 The audit team shall be appointed by DPA. He shall ensure that the audit is carried out by a

person independent of the function to be audited.



8.3.5 Auditors shall have undergone necessary training to conduct internal audits.



8.3.6 The audit shall be carried out to assess:

if the SMS of the company conforms to the ISM code.

If the day-to-day operations conform to the documented SMS of the company



8.3.7 The auditor shall use the Internal audit checklist (Refer manual CPMF 08-02) as guidance. While

conducting the audit, non-conformities/ observations shall be noted in the Internal audit non-conformance

report (Refer manual CPMF 06-01).



8.3.8 Auditor shall obtain acceptance from the auditee of the non-conformances and observations.



8.3.9 Auditee shall propose the corrective/ preventive actions with proposed target dates in the same form.

Such proposed actions shall be acceptable to the auditor and they shall meet the requirements of the ISM

code. Every effort shall be made to complete the proposed corrective actions as quickly as possible, after

which they shall be verified and the non-conformities shall be closed by DPA. The date of completion of

the corrective actions shall not be unduly delayed.



8.3.10 The effectiveness of these corrective actions shall be verified during subsequent audits and

safety committee meeting/ management review meeting.



8.3.11 The DPA shall review the audit report and shall verify the closure of non-conformance reports.



8.4 RECORDS

8.4.1 The following records shall form a part of this procedure:-

CPMF 08-01: Internal audit report

CPMF 08-02: Internal audit checklist

CPMF 08-03: Ship Inspection report or Superintendent Inspection report.

CPMF 08-04: Internal audit plan

