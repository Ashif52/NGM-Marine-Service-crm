

7. CORRECTIVE AND PREVENTIVE ACTION



7.1 OBJECTIVE



To describe a method of taking necessary corrective and preventive actions for a non-conformity.



7.2 RESPONSIBILITY



The non-conformity report shall be reviewed by the Master (for onboard NCs) and by the DPA (for office NCs). DPA shall decide on the corrective and preventive actions.



7.3 CORRECTIVE ACTION



7.3.1. The identified non-conformance shall be reviewed and corrected immediately. The Master/ DPA shall investigate the matter, analyze the root cause and take required corrective action to eliminate the non-conformity. Such action may involve one or more of the following:-

Advise vessels/ concerned staff to take necessary corrective action to eliminate the non-conformity and follow-up for the implementation of the corrective action.

Facilitate appropriate training for the employee whose inadequate skill/ knowledge resulted in the non-conformity

Replace the employee, if required, with the one having necessary skill/ knowledge.

Inform other departments/ vessels to take corrective action to avoid similar occurrences.

Repair or replace machinery/ equipment causing the non-conformity.



7.3.2 The non- conformity and the subsequent corrective action shall be analyzed in the subsequent safety committee meeting/ management review meeting.



7.4 PREVENTIVE ACTION



A non-conformity is analyzed in the safety committee meeting/ management review meeting and a preventive action is arrived at in order to prevent recurrence of the non-conformity.

Decide the preventive action from the resources available and monitor its implementation.

If the preventive action requires additional capital investment or involves other departments, the matter may be discussed with the DPA and resolved.

If the preventive action requires an amendment to the SMS, the DPA shall amend the SMS accordingly.



7.5 RECORDS



All records of the corrective actions form part of manual CPMF 06-01 and CPMF 06-02.