

12. INSURANCE



12.1 OBJECTIVE

To ensure that the P&I and H&M insurance claims are dealt with in an efficient manner.



12.2 RESPONSIBILITY



12.2.1 The Technical Superintendent shall be responsible for alerting the vice president regarding any incident

that may result in a claim. He shall also collect the necessary documentary evidences.



12.2.2 The Technical Superintendent shall be responsible for processing the insurance claims with the

relevant authorities and co-ordinating with relevant departments.



12.3 DESCRIPTION



12.3.1 The Vice President shall, wherever applicable, discuss with the owners and decide on whether or

not to make an insurance claim for a particular incident and the Technical Superintendent shall process the

claim with the insurance company.



12.3.2 The Master shall be responsible for reporting any incident that can lead to an insurance claim. He

shall collect all possible evidence to protect the interest of the Owners/ Managers. He shall also collect reports

from the witnesses/ persons on duty as possible. He shall provide all the above information to the

Technical Superintendent.



12.3.3 Below is a sample list of the documents that may be required to be submitted to support insurance

claims:

Deck and engine log books

Photos of the relevant areas, persons etc

Note of protest to be filed by the Master

Detailed report of the Master

Underwriter surveyor’s report and costs, if any.

Owner surveyor’s report and costs, if any.

Receipted accounts for repairs and/ or any spare parts supplied by owners (endorsed by

underwriter’s surveyor an Costs for any dry-docking and general expenses relating to the repairs (endorsed by underwriter’s surveyor

Costs for all incidental expenses at the port of repair, e.g. port charges, watchmen, communications, agency expenses, etc.

Details of fuel and engine room stores consumed during the repair period together with the cost of replacing the fuel used.

If other repairs carried out on the Company’s account concurrently with the damage repairs the costs for the other repairs, where required, also to be provided.

Copies of communications sent and details of long distance calls made in connection with the incident together with their costs.

In case of un-repaired damages, fair cost estimate of cost of such anticipated repairs.



12.3.4 Additional documents that may required to be submitted in case of collision claims:

Details of steps taken to establish the liability for the collision (Eg., Notice to be served on the Owners of the other vessel holding them responsible, etc).

P&I surveyor’s report.

If a recovery has been made from the colliding vessel, detailed copy of the claim put forward and all the items allowed from the claim by the Owners of the colliding vessel.

If a claim is payable to the other vessel then receipts will be required for the amount paid in settlement of the claim including costs and interests. Receipted accounts for solicitor’s costs, bail fees, etc. will also be required.

If the settlement between the vessels results in a recovery for the Company, the Solicitor’s account statement will be required showing how the settlement has been arrived at.





12.3.5 Additional documents required to be submitted where vessel is moved to some other place for repairs:

The reason for movement of vessel to some other place

Whether the vessel was put on hire after the repairs had been completed.

Costs of the inward and outward port charges.

A statement showing the wages of the officers and crew during the movement to the repair port and also

for the return passage if the vessel returns to her original port. The cost of maintenance for the Officers

and crew should also be stated.

Certificate of fuel and stores used during the movement and the cost of their replacement.

Cost of temporary repairs if they were done solely to enable the vessel to move to the repair port.



12.3.6 Documents required to be submitted for GENERAL AVERAGE CLAIMS may vary considerably according

to the nature of the incident. A brief list is as below:

Documents/ information required where there has been recourse to a port of refuge.

Log extracts and reports from the Master or other relevant parties showing the dates and times when

the vessel deviated, arrived at port of refuge, left port of refuge and regained her position.

Any survey reports whether held on behalf of Underwriters, Owners or the Classification Society dealing

with the vessel’s recourse to the port of refuge and/or repairs affected there.

Details of any repairs effected at the port of refuge stating whether they are temporary or

permanent repairs.

Details of any shifting or discharge of cargo at the port of refuge stating whether such shifting or

discharge was necessary either in order to allow repairs to be affected or for the common safety.

Agent’s general account covering the detention period at port of refuge together with supporting vouchers.

A statement giving details of wages and allowances paid to crew of vessel at the time of her recourse to

the port of refuge.

The daily rate of maintenance paid in respect of victualling of the vessel’s crew.

Details of fees and expenses paid to any Company’s Superintendent/ Surveyor employed at the port

of refuge.

Details of fuel and stores consumed in deviating to the port of refuge while there and in regaining position.

Copies and cost of all communications.

All accounts should be marked with the date on which they were paid by the Company.

12.3.7 Documents in respect of damage to vessel due to fire:

Survey report showing separately the damage due to fire and damage due to efforts to extinguish the

fire. (The same division should also be made in surveys of any similar damage to cargo).

Accounts for repairs to the vessel should also be divided in this way.

Accounts for any fire-fighting costs refilling extinguishers CO2 bottles etc

12.3.8 Documents in respect of damage to vessel due to grounding:

Survey report showing separately the damage caused due to grounding and that caused by efforts to

re-float the vessel.

Repair accounts should be similarly divided.

If the vessel has been re-floated with tugs, then the copy of the salvage contract.

Any costs incurred for lightening the vessel.

12.3.9 Documents in respect of cargo:

Manifest of the cargo on board at the time of the incident.

Details of the cargo delivered.

Any reports of survey on the cargo held directly following the incident or at the ports of destination.

General average security documents furnished by cargo interests i.e. average bonds and general

average guarantees.

Counterfoils of any general average deposit receipts issued.

Valuation forms completed by cargo interest if possible accompanied by a copy of the invoice covering

the particular consignment.

12.3.10 Documents in respect of freight:

Charter party

Bills of lading, mates receipt

Details of off-hire, if any.

Other relevant documents