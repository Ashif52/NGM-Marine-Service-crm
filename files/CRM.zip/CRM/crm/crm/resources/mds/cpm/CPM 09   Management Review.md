

9. MANAGEMENT REVIEW



9.1 OBJECTIVE

To provide a procedure for reviewing the effectiveness of the SMS.



9.2 RESPONSIBILITY

The DPA is responsible to plan, prepare the agenda and conduct the management review meeting.



9.3 DESCRIPTION



9.3.1 The continuing suitability and effectiveness of the Management system shall be reviewed once a

year. However the maximum interval between two successive Management Review Meetings shall not

exceed more than twelve months. Also additional reviews may be carried out in case of serious system

failures.

M. Director shall preside over the meeting. The Vice President/DPA, Technical Superintendent/ADPA, Head

Fleet Personnel and other staff shall attend the meeting.

The purpose of a Management Review meeting is to evaluate the efficiency of the SMS and to recommend

any changes intended to enhance efficiency.

Every Management Review meeting shall be minuted and DPA shall take action to implement decisions in

time bound manner without extra-ordinary delay. (Refer manual CPMF-09-01).



9.3.2 The DPA shall prepare the agenda for the meeting. The agenda shall include, as a minimum, the

following:

Review of the minutes of the previous management review meeting

Review of monthly ship safety committee meetings

Review of Master’s SMS review

Internal/External audit findings.

PSC / FSI Inspection reports

Analysis of reports, accidents, hazardous occurrences and non-conformities.

Organizational changes.

Trainings done and the effectiveness of the training methods.

Changes in relevant legislations, conventions etc.

Identification of new plans, procedures or instructions.

The effectiveness of the SMS and any suggested changes.

Review of the performance of sub-contractors and suppliers.

Any other matter



9.3.3 The minutes of the Management Review Meeting shall be circulated to all concerned and those

who attended the meeting.



9.4 RECORDS



The following records shall form a part of this procedure.

CPMF 09-01: Management review meeting