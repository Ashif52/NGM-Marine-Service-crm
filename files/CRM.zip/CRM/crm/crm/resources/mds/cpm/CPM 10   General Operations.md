

10. GENERAL OPERATIONS



10.1 OBJECTIVE



10.1.1 To ensure that the operational guidelines described herein are generally followed for the

following activities:

Appointment of agents

Co-ordinating port calls



10.2 RESPONSIBILITY



The Technical Superintendent shall appoint agents, co-ordinate port calls and communicate with the

charterers, owners and Master of the vessel.



10.3 DESCRIPTION



10.3.1 APPOINTMENT OF AGENTS



10.3.1.1 The Technical Superintendent shall appoint agents at concerned ports whenever a company’s

vessel is fixed to call. If the company’s agency division has offices in the port, he shall appoint them as

agents. While appointing an agent, he shall take into account the agent’s past performance record

and the owner’s/ charterer’s recommendations, if any.



10.3.1.2 Quotations shall be invited from various Agencies by giving vessel’s particulars and program for

the port.



10.3.1.3 The agent shall be appointed on the basis of the following considerations:

Past record/ supplier’s evaluation

Local standing and influence

Agency network

Price element

Nature of agency service required.



10.3.1.4 At times, the agent may be appointed on the recommendation of the Charterer.



10.3.2 CO-ORDINATING PORT CALLS



10.3.2.1 Depending on the requirements of the vessel, the Technical Superintendent shall decide on the

port of call.



10.3.2.2 The Technical Superintendent shall co-ordinate with the Charterer or Owner, as necessary. He

shall advise the appointed agents regarding the proposed call.



10.3.2.3 The Technical Superintendent shall advise the Master the details pertaining to his vessel’s work

-scope in port, name/ contacts of the agents etc. The Agents shall be advised to provide necessary

logistical support to the vessel (e.g. supplies, repair workshop, surveys etc.)