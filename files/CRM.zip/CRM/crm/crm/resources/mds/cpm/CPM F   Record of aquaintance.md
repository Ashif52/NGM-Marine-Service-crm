Record of acquaintance

The following persons have read and understood the contents of this SMS manual:



Note: This sheet is required to be signed by all working in Office . The “Vessel copy”  to be signed

by all officers and crew working onboard, as a proof of their reading and understanding of the contents of this manual.

