

13. SURVEYS AND INSPECTIONS



13.1 OBJECTIVE

To ensure that all surveys and inspections are planned and carried out in a timely manner and vessel is

always maintained in accordance with the rules & requirements.



13.2 RESPONSIBILITY

The technical superintendent is responsible for ensuring that the surveys or inspections are planned and

carried out at the appropriate time and necessary logistical arrangements are made for surveys/ inspections.



13.3 DESCRIPTION



13.3.1 The status of surveys for each vessel shall be maintained and monitored by the Technical

Superintendent with respect to the following:

When a survey was last carried out.

When a survey is next due.

Date on which certificate was issued.

Date of expiry of the certificate

Any recommendations and "conditions of class" pending and

Other relevant details of extension of surveys if any.



13.3.2 Further whenever certificates are endorsed for Annual and/or Intermediate surveys copies of the

endorsed certificates shall be obtained from the vessel and records updated.



13.3.3 Plans shall be made in advance to carry out the surveys falling due and the vessels shall be instructed

to prepare for the same. The Surveyor shall be advised the expected time and port of arrival of the vessel

and agents full style contact details. Where the vessel is on charter and if there is a need to off-hire the vessel

to carry out the survey, appropriate arrangements shall be made with the Charterer for her release. Efforts are

to be made to ensure that the surveys are held in such a way to ensure that the vessel remains off hire for

the minimum time, taking advantage of the window periods permitted for surveys.



13.3.4 The Surveyor's visit on board shall be co-ordinated with the local Agents, ship's staff and the

Charterers. Arrangements shall be made to facilitate prompt attendance of the Surveyor on board with a

view to ensure completion of survey without any delay to the vessel or disruption of her normal operations.



13.3.5 Any recommendations given during the survey shall be conveyed by the vessel to the

technical superintendent and these shall be made good within the stipulated time. On satisfactory completion

of the survey, the vessel’s certificate is endorsed. In case of renewal surveys, surveyors either endorse the

existing certificates or issue fresh certificates with 5 months validity. In such cases, the technical

superintendent shall arrange to follow up & obtain the full term certificates issued in time.



13.3.6 It is Company’s policy that the vessel shall comply with all survey requirements and shall not permit

its vessels to sail out of port with overdue surveys and recommendations.



13.4 RECORDS



13.4.1 The following records shall form a part of this procedure.

FPMF 11-01: Monthly report on certificates.







