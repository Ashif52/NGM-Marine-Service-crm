

4. COMPETENCE, AWARENESS & TRAINING



4.1 OBJECTIVE

To ensure that the shore and floating staff have the required level of competence, the required awareness of

their roles and the necessary training to perform their work in an effective manner.



4.2 RESPONSIBILITY



4.2.1 Vice President: For deciding the desired competency levels of shore staff, issuing service

conditions, providing the necessary training of shore employees and maintaining records.



4.2.2 Technical Superintendent & Head fleet personnel : To provide job familiarization to the staff

reporting to him and to evaluate their training needs.



4.3 COMPETENCE



4.3.1 SHORE STAFF



4.3.1.1 Competence level desired for the shore employees shall be decided by the Vice President.

4.3.1.2 The documents and experience shall be checked .



4.3.2 FLOATING STAFF



4.3.2.1 Competence levels shall be as per safe manning document as specified by DGS guidelines.

4.3.2.2 The documents and certificates of all at the time of joining, be checked and verified for validity

and for authenticity also. The records of verification of authenticity shall be kept along with the application

form of the respective seafarer.



4.4 AWARENESS/ FAMILIARISATION



4.4.1 SHORE STAFF



The vice president shall ensure that the employees reporting to them are familiarized with the company

policies, safety management system and the individual work responsibilities. Record of awareness/

induction training of office staff (Refer manual CPMF 04-01) shall be filled up.



4.4.2 FLOATING STAFF



Before joining the vessels, Master, Chief Officer, Chief Engineer and 2nd Engineer shall be briefed

at the office.(Refer manual FPMF 12-01). If, due to any reason, the briefing cannot be carried out at office

(in person), then it may be done over telephone. Records of such briefing shall be maintained in the office.

Other floating staff shall be familiarized as per procedure. Refer manual FPM 12.



4.5 TRAINING



4.5.1 SHORE STAFF



Performance appraisal of shore staff is done by Vice president once every year. The records of appraisal

are maintained by the Vice President. Refer manual CPMF 01-01. Training needs, if any, shall be identified

during the appraisal. Training needs shall also be identified during management review meeting or during

day-to-day operations. Training shall be arranged based on the needs thus identified at intervals decided

by the Vice President and recorded in CPMF 04-02. DPA shall make the training plan

(Refer manual CPMF 04-03) for every calendar year.









4.5.2 FLOATING STAFF

Performance appraisal of officers and crew onboard are done by the Master/ Chief Engineer. The Vice

president shall do the performance appraisal for Master and Chief Engineer. Refer manual FPMF 01-02.

Training needs, if any, shall be identified during the appraisal. Training needs shall be identified during

safety committee meetings and during day-to-day operations. Training for the officers and crew shall be

arranged on board by the Master. Training for Master and Chief Engineer shall be arranged by the vice

president during their leave ashore.





4.6 RECORDS

4.6.1 The training records for floating staff and shoe staff shall be kept for three years.



Ref forms:

CPMF 04-01: Record of awareness/induction training for office staff

CPMF 04-02: Office staff training record.

CPMF 04-03: Office staff training plan.

CPMF 01-01: Performance and appraisal report

FPMF 01-02: Seafarers’ appraisal/ confidential report form.

