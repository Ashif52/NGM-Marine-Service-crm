



15. RESOURCES TO DPA





15.1 OBJECTIVE

To ensure that adequate resources are made available to the DPA for handling issues relating to the safety

of the vessel and the environment.



15.2 RESPONSIBILITY

The Management is responsible for ensuring that adequate resources are made available to the DPA.



15.3 DESCRIPTION



15.3.1 The Company shall adopt a resolution at the board meeting authorizing the DPA for granting

unlimited financial approvals related to the safe operation and safety of the vessel and the environment.



15.3.2 The Company shall stand by any decision taken or approval issued by the DPA in respect to issues

relating to the safety of the vessel and/or environment.



15.3.3 The Company has the potential to make such finances available. The Company is a part of a group

which is into various businesses like steamer agency, shipping logistics, freight forwarding, ship broking,

ship chartering etc. The Company has, through years of hard work in the shipping industry, created various

assets and goodwill which will come in handy in times of need.



15.3.4 The Managing director of the company have signing authority with the bank:



15.3.5 The DPA shall contact the Managing director through telephone, mobile, email, SMS or by any other

means at any time of the day for the release of funds.



15.4 RECORDS



Records of the board resolution shall be maintained by the DPA.













