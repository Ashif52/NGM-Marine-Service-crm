

6. CONTROL OF NON-CONFORMANCES, ACCIDENTS, INCIDENTS AND NEAR MISSES



6.1 OBJECTIVE

To describe a method of identifying, reviewing and disposing non-conformances noticed during day to day operation.



6.2 RESPONSIBILITY



The DPA shall review the non-conformances reported, plan and monitor suitable disposal, corrective and preventive action, irrespective of the manner in which they are reported.



6.3 NON CONFORMITY



6.3.1 Non-conformity has occurred whenever:-

The documented SMS fails to provide the necessary control to prevent the occurrence of an adverse incident affecting Safety and/or Pollution Prevention;

The documented Safety Management System is not implemented, i.e. actual practice does not conform to the documented system;

A situation is identified that represents a potential hazard;

A deficiency is identified by external organizations i.e. flag state or port state.



6.3.2 Any person observing any non-conformance shall bring it to the notice of Master (on board the vessel) or to the notice of the DPA (if in the shore office).



6.3.3 Master raise a non-conformance report (Refer manual CPMF 06-01) and forward it to the DPA giving the details of the cause for such non-conformance and also immediate corrective action if required.



6.3.4 The DPA shall, on receipt of the non conformance report, review it and decide on the adequacy of the suggested corrective action. The DPA shall also identify the root cause and take preventive action as under:-

Take immediate action in case of non-conformance of any mandatory requirement;

Obtain concurrence from concerned authorities for the acceptance of the situation, with concession, where a full corrective action is not immediately feasible.

Take steps to prevent recurrence of the reported non-conformance in future.



6.4 ACCIDENT/ INCIDENT/ NEAR MISSES



6.4.1 All accidents/ incidents and near misses are a result of some non-conformity and hence all such happenings are also to be treated as non-conformity and appropriate action as explained above are to be taken by the person concerned. All accidents/ incidents/ near misses/ hazardous occurrences shall be recorded in Refer manual CPMF 06-02.



6.4.2 A root cause analysis is done after the immediate action and results of the analysis are used to plan a future strategy to prevent its recurrence.



6.4.3 All such happenings are to be reviewed in the monthly safety committee meetings and at the management review meeting in the office.



6.5 RECORDS



6.5.1 The following forms shall be a part of this procedure.



CPMF 06-01: Non conformance report

CPMF 06-02: Accident/ Incident/ Near miss report.