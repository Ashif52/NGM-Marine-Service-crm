



2. CONTROL OF RECORDS



2.1 OBJECTIVE



To describe the procedure for identification, storage, retention and disposal of records.



2.2 RESPONSIBILITY



Technical superintendents and fleet personnel head are responsible for maintaining the records of

their respective areas of work.



2.3 MAINTENANCE OF RECORDS



2.3.1 Records shall be maintained either as hard or soft copies.



2.3.2 For protection, the records shall be kept in a weather-protected area.



2.3.3 If records are maintained as soft copies only, then arrangements shall be made to back up the records

on a daily basis at a remote location.



2.4 RETENTION



The minimum retention period for each record shall be three years. Records may be maintained for

longer periods at the discretion of the vice president or for meeting any statutory requirements.



2.5 RECORDS



The office/ship filing structure (Refer manual CPMF 03-03) shall be used for record keeping.