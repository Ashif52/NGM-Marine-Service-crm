



5. PURCHASING



5.1 OBJECTIVE: The objective of this procedure is to facilitate the purchase of right quality and quantity of supplies, from the right source at a reasonable price and to ensure that the supplies are made in time.



5.2 RESPONSIBILITY



5.2.1 Technical Superintendent: For evaluation of Vendors and service providers.



5.2.2 Service providers stated above would generally include:

Repair & servicing workshops

Dry-docking and repair establishments

Servicing Agencies for LSA/FFA, Radio Equipments, TM & Diving agencies etc

Ship Chandlers & Spare Part Vendors



5.2.3 The Technical Superintendent shall monitor the activities carried out by the services provider and follow-up as necessary. Such verification may be done at supplier’s premises wherever applicable.



5.3 DESCRIPTION



5.3.1 LIST OF APPROVED VENDORS



OEM Vendors, their authorized stockists and service providers shall be considered as approved Vendors. Other Vendors/service providers shall be included as and when the Company does business with them.

All other service providers are selected & evaluated based on their performance for the services provided by them. Evaluation criteria being measured with respect to technical competence, capability, cost factor & speed of response.

While qualifying Vendors & service providers, due weightage shall be given to their reputation in the area where supply/service is required.

List of qualified Vendors shall be maintained and shall be reviewed/ evaluated every one year.



5.3.2 PROCEDURE FOR PROCUREMENT



Vessel shall send to the Technical department their Material (stores & spares) requirement specifying the technical details in the appropriate indent form (Refer manual CPMF 05-01).

If a long delivery time is required, the Company shall inform vessel  about the approximate lead time.

Indents shall be approved by the Technical Superintendent and then shall forward to the purchase executive. Purchase executive shall send inquiries to approved Vendors and obtain quotations.

The Purchase Executive shall consolidate the quotations and forward them to the Technical Superintendent who shall authorize the purchase after due scrutiny. The Purchase Executive shall then release the orders for the supplies.

In urgent situations, the Technical Superintendent may approve the order based on only one quote also.

The indent is for OEM spares, the order may be placed directly with the OEM or their authorised stockiest.

The purchase executive shall monitor the delivery status of the orders as follows:

Local supplies: Directly follow-up with Vendors for timely delivery on board.

Import supplies: Copy of the order shall be sent to the freight forwarder for information and follow-up with the supplier. On receipt, the freight forwarder shall ship the material to the advised destination.



Once the material is received on board, it shall be checked. The vessel shall confirm receipt of the material to the office, including details of shortages, damages, wrong and/or part supply, where applicable.

The purchase executive shall take up the issue of any short come in quantity and quality with the supplier.

On acceptance of supplies, invoices and other relevant documents shall be forwarded to the Accounts.



5.3.3 BUNKER SUPPLY



On receiving the bunker requirement from vessel, the figures shall be reviewed in the Office.

Enquiries shall be floated by the Technical Superintendent with various bunker brokers and the price ideas shall be obtained. On receiving the price deal, the details of physical supplier with the full style address, method of supply, contact number etc and conveyed to the vessel’s Master and to local agents.

On completion of the bunkers, the Chief Engineer shall keep a sample of the fuel duly signed by the supplier’s personnel. The sample is to be retained on board as per MARPOL requirements.

If required One sample shall be sent to the lab for analysis and the analysis report shall be sent to vessel.

In case of any discrepancy, the Master shall issue a protest letter and make appropriate remarks on the bunker delivery note.



5.3.4 VERIFICATION OF SUPPLIES/ SERVICES



Verification of the service provided such as servicing, testing, supply of labour etc shall be carried out onboard by the Master/ Chief Engineer reported to the Technical Superintendent.

Verification may also involve third party survey/ inspection. The requirements and responsibilities for such inspection shall be specified in the purchase order.



5.4 RECORDS



The following records shall form a part of this procedure :

CPMF 05-01: Stores/ spares requisition

