

1. PERSONNEL MANAGEMENT



OBJECTIVE

The objective is to ensure effective management of floating staff. This includes welfare of the personnel

and interaction with relevant authorities with respect to safe manning of the vessels. The Company shall

also comply with the rules and regulations as adopted in the Maritime Convention, [MLC], 2006.



RESPONSIBILITY

1.2.1 VICE PRESIDENT: REFER SMM 03 SECTION 3.2.2.2.3.

1.2.2 GM (HEAD FLEET PERSONNEL & OPERATION): REFER SMM 03 SECTION 3.2.2.4.



COMPLIANCE WITH MANNING REGULATIONS



The vessels shall be manned as per the Safe manning document issued by Flag administration.

Where it is not possible to man the vessels as per any regulation on account of any reason,

appropriate dispensation shall be obtained from the Flag administration.



The Head- Fleet Personnel and Master to ensure that all company vessels are manned in accordance

with minimum safe manning document issued by the Flag state Authority ensuring that the vessels

are operated safely, efficiently and with due regard to security under all conditions, taking into

account concerns about seafarer fatigue and the particular nature and condition of the voyage and

all operating condition. (Manning Level regulation 2.7 as per MLC 2006)



MANNING AGENCY -

The manning needs for  the vessel will be fulfilled  by the Company or the Owners of the vessel directly.

However, the services of a ship manning agency may be used if required.

Our Fleet Personnel department and DPA shall carry out briefing of Master, Chief Officer, Chief Engineer

and 2nd Engineer prior joining the vessel at Office or through phone.( Refer form- FPMF12-01 shall be filled up).



Monitoring Of Manning Agency when Sub contracted

When the services of a ship manning agency is used. In such circumstances, the company on behalf of the

Owners shall enter into an agreement with the manning agency. Prior Signing the agreement the company

will check that the manning agency has valid RPSL number in Flag Administration website. The details of

License number, its validity, number of Seafarer it can employ and records of annual audits will be verified.

On satisfactory completion of verification an agreement specifically covering key areas of crew qualification

and certification, victualing, replacement of personnel, wages, maintenance of records, responsibilities and

liabilities of the manning agency, general administration and compliance with applicable laws and regulations

and any other directions issued by the Company shall be signed . The responsibility of manning will be with

the Company only.



1.5 RECRUITMENT PROCEDURE

In compliance with the rules & regulations as laid down in MLC 2006, the Company shall not employee any

person under 18 years of age to work, including cook in any of our vessel. (Minimum age regulation 1.1 as

per MLC 2006)



1.5.1 The Head-Fleet Personnel shall arrange with Manning agency for relief of:

those floating staff who have completed their contract

those floating staff who have, though not completed their contract period, have requested for

relief on compassionate grounds.

those floating staff who have been found wanting on grounds of competence, conduct or sobriety and

whose names have been recommended by the Master for termination of contract.



1.5.2 The company shall ensure that the seafarers working onboard are certified as per Flag state requirement.













1.5.2.1 The Head-Fleet personnel shall scrutinize the application form and the validity of the travel

documents, certificates etc. The certificates of competency may be verified through the website of the flag

state and a print out of the result shall be filed along with the valid medical documents. It is the responsibility

of the Fleet Personnel to ensure that the all certificates including medical certificates of the seafarer joining

the vessel remains valid during the period of his sailing on board.





1.5.3 The Head-Fleet Personnel shall check the seafarers previous sailing experience and shall, if he

feels necessary, check the past record of the seafarers with his previous companies. If the seafarers is

an ex-employee of the company, then his confidential reports (Refer manual FPMF 01-02) shall be checked.

If the seafarers past record is unsatisfactory, he shall not be appointed again except in emergency situations

as a stop-gap arrangement.



1.5.4 On completion of all the formalities of joining and having completed the pre-joining checklist

(Refer manual CPMF 02-03). The Head-Fleet personnel shall plan with manning agency for crew change

at appropriate ports taking into account the vessel’s schedule, agents, transportation costs, visa & clearance

issues etc.



1.6 DEATH & DISABILITY

In case of death of a seafarer or permanent disability to a seafarer, the head of fleet personnel department

shall inform the Owner of the vessel, Manning agency  and seamen’s employment office concerned and the

next-of-kin of the seafarer within forty-eight hours of such death or disability. If the period falls during a

weekend or a holiday, then the concerned seamen’s employment office shall be informed of the news on their

next working day. If the Head fleet personnel is not in a position to inform as above, then the Vice President

shall do so.



1.6.1 Death



1.6.1.1 The Company  on receipt of communication from the vessel, ensure that the following are carried out:

Inform Owner, Manning Agent, P & I and Next of Kin.. Submit relevant documents as per their requirements.

Inform local and Indian maritime authorities and dispatch forms required to be filled-up by the authorities

to the vessel. If the death occurs in India the local Shipping Master/ local police shall be informed,

who may     conduct an inquiry into the cause of death.

Advise Master & advise Agent for transportation of the corpse to its home and for which the Agent shall

obtain an embalming certificate and carry out local formalities.

Arrangements to be made to receive the body of the deceased and hand it over to the next of kin.

Deposit documents like Passport CDC etc. with the local maritime authority.



1.6.1.2 Confirm receipt of following documents

Statements of ship's staff

Log entries

Master's Report

Incident report from the vessel (Refer manual CPMF 06-02)

Police report and post-mortem report where applicable.

Port Health Certificate

List of personal belongings - for handing over to the next of kin.

Filled-up forms required by Indian maritime authorities (MMD DGS etc).



1.6.1.3 The Office shall conduct an inquiry where death has occurred due to causes other than natural causes.



1.6.1.4 In an event of death of a crew member, the company shall connect a suitably qualified replacement

to the vessel at the first available opportunity.











1.6.2 Disability



1.6.2.1 The Office on receipt of communication shall ensure that the Owner, Manning Agent and Next of

Kin are informed immediately and following are carried out.

To arrange immediate medical attention for the disabled person.

Inform P&I Club and submit relevant documents as per their requirements.

Confirm receipt of the documents.

Follow-up with agent on the medical treatment provided and the health condition of the disabled person.

Once the patient recovers and is fit to travel arrange for his repatriation to his home town..

On his arrival the seaman shall be examined by the manning agency doctor and a report pertaining to his

fitness/ disability be obtained.

An inquiry shall be conducted by the Company into the cause of disablement/accident/incident.

Arrange for returning the personal effects of the disabled person back to him.

In an event of disability of a crew member the company shall connect a suitably qualified replacement

to the vessel at the first available opportunity.



1.7 ON-BOARD MEDICAL CARE: INJURY AND ILLNESS



1.7.1 On-board Medical Care

All small injuries and illnesses shall be treated on board. The Company is committed to protect the health

of the seafarers and ensure their prompt access to Medical care on board ship and ashore.

Fleet Head Personnel is Responsible:

To Ensure that adequate measures for the protection of Seafarer’s health and access to prompt and

adequate medical care whilst working onboard is available.

Health Protection and medical care service is to be provided at no cost of seafarers under employment

contract.

3) Arranging visit to a qualified medical doctor or dentist without delay in ports of call, where practical.

The Master of the Vessels is responsible to ensure that the medical chest, hospital, medical equipment are

regularly inspected by competent authority. The current edition of Medical Guide should be available

onboard. Medical advice, including specialist advice, will be made available 24 x 7, including onward

transmission of medical message by radio or between ship and those ashore giving the advice.

Seafarers will have access to health promotion and health education programs for treatment of sick and

injured seafarers and also for prevention of occupational health and safety related diseases.

Company will provide material assistance and financial support for sickness, injury or illness while seafarer’s

are serving under an employment agreement or arising from their employment under such agreement.

Masters to note that onboard Hospital accommodation, where provided is to be used exclusively for medical

purpose only.(On-board Medical Care regulation 4.1 as per MLC 2006)



1.7.2 In case of more serious injuries and illnesses the Master shall inform the Company/Manning Agent /

Agents and arrange to send the person to see a doctor ashore (Refer manual CPMF 02-07). The Company

shall, on receipt communication, ensure that the following are carried out.

Inform next of kin, owner &  P & I Club and submit relevant documents as per their requirements.

Confirm receipt of the following:

3.  If abroad, advise Agents to repatriate patient to India on his becoming fit to travel.

4. On arrival India the patient will be examined by the manning agency doctor and a report pertaining

to his injury/illness obtained.

In case of an injury an investigation will be conducted by the Office into the cause of the injury.

Arrange for handing over personal effects to the person .

Office shall connect a suitably qualified replacement to the vessel at the first available opportunity.

1.8  HEALTH,SAFETY AND ACCIDENT PREVENTION

Company has a formalized system for reporting and investigating all occupational accidents including unsafe

acts and unsafe practices (Hazard / Near Miss / Incident Reporting). The above are analyzed and shared

with all fleet vessels. Company has taken into account the general working activities of our seafarers and the

same reflected in the Hazard identification and Risk Assessment, a copy of which is placed onboard each

fleet vessel. (Refer manual FPMF-14-01 & FMPF-14-02).

Safety news / flashes, alerts are sent to all fleets vessels as lessons learnt for the seafarers, towards

Awareness and prevention of Injuries, incidents.



Company has a system where in Safety committees, chaired by the Master are formed onboard all fleet

Vessels to look into onboard Safety matters.

Responsibilities of Master and Ship Safety Officer include implementation of and compliance with Ship’s

occupational safety and health policy requirements. (Health and safety and accident prevention, Regulation

4.3 as per MLC 2006)



2.0 MEASURES TAKEN BY COMPANY FOR SEAFARERS WELFARE

2.1 Hours of rest : Onboard all company vessels Master to ensure working arrangements shall be in

accordance with MLC-2006. The maximum hours of rest for every seafarer onboard shall not be less than

10 hours in any 24 hours period and not less than 77 hours in a 7 day period. The minimum hours of rest

shall be divided not more than two periods, one of which shall be at least 6 hours.

A table of shipboard working arrangement shall be displayed conspicuously in common areas such as mess

room , lounge, etc, accessible to all seafarers. This should be dated to reflect current working arrangement.

Master shall ensure that all seafarers receive a copy of records pertaining to daily rest, which shall

be duly endorsed by the master or a person authorized by the master.

When a seafarer is on call, such as when a machinery space unattended, the seafarers shall have an

adequate compensatory rest period if the normal period of rest is disturbed by the call-outs to work.



Master of a ship has the right to require a seafarer to perform any hours of work necessary for the immediate

safety of the ship, persons on board or cargo, or for the purpose of giving assistance to other ships or

person in distress at sea. Once the normal situation is restored, the master shall ensure that the seafarers who

have performed work in the scheduled period of rest are provided with adequate period of rest. (Refer manual

FPMF 01-01) Master shall ensure that Drills prescribed by National Laws and regulations shall be conducted

in a manner that minimizes the disturbance of rest period and does not induce fatigue. (Hours of Work or

Rest (Regulation 2.3) as per MLC 2006).



2.2 Accommodation : Company will ensure that standards of crew accommodation are in compliance

with the Maritime Labour Convention 2006 requirements, which are as follows:

For New Ships – MLC 2006 and For Existing Ships – Crew accommodation Rules of Flag state

incorporating Accommodation of crews Convention (Revised) 1949 (No.92), and the Accommodation of the

Crews (Supplementary Provisions) Convention, 1970 (No.133).

The Master, along with the vessel Technical Superintendent will be responsible to ensure that accommodation

of seafarers, living and working condition onboard is clean, decently habitable and maintained as per MLC

2006. Master shall carry out weekly inspections of crew accommodation giving due importance to

heating, ventilation sanitary facilities, lighting. The inspections will be duly recorded. (Accommodation,

Regulation 3.1 as per MLC 2006).



2.3 Onboard recreational facilities : Considering welfare of seafarers onboard, Company is committed to

provide adequate facilities onboard all vessels managed with regard to recreation & welfare of the crew.

Recreation facilities including but not limited to television, showing of films, magazine, sports equipments,

internet & e-mail facilities, library etc., may be provided at no cost to seafarers. The seafarer shall be

provided reasonable access to ship to shore telephone communications, where available with reasonable in

amount. A welfare club would be constituted onboard with contributions from the Company for

recreational facilities.(Onboard recreational facilities, Regulation 3.1 as per MLC 2006)



2.4 Food and catering: Fleet Head Personnel and Master to ensure the following on board: Food and

drinking water of approximate quality, nutritional value and quantity that adequately covers the requirement

of the ship and takes into account the differing culture and religious backgrounds is provided. Water to be

tested periodically using shipboard test kit and annually by an accredited lab ashore. Food will be provided

free of charge while on employment. Ship’s cooks has the responsibility of food preparation.

Documented weekly inspections are to be carried out under the authority of the master, with respect

to the following:

Supplies of food and drinking water

All spaces and equipment used for the storage and handling of food and drinking water.

Galley and other equipment used for the preparation and service of meals

Maintenance of Proper Hygiene standards. ( Food and catering -Regulation3.2 as per MLC 2006).





2.5 On-board Complaint Procedures : Onboard procedure for resolution of any grievance has been

implemented in our SMS as directed by Flag Administration. Refer M.S. Notice No. 04 of 2013 dated 30th Jan

2013 which has stipulated complaint / grievance redressal mechanism to be adopted for Indian Flag vessels

in accordance with Guidelines provided by Maritime Labour Convention 2006.

A copy of the onboard complaint procedure along with the details of complaint redressal mechanism is

made available on board to all seafarers (Refer manual CPMF 02-06).

Seafarers shall have the right to file a complaint directly to an appropriate external authority, such as, but

not limited to

A Flag Administration Official.

A Port State Control Official.

A Local Seafarer labour Organization representative; or

Other Seafarer welfare assistance service.

Any other legal entity that the seafarer may consider appropriate.

(On-board Complaint Procedures -Regulation 5.1.5 as per MLC 2006)



2.6 Payment of Wages : The Company ensures payment of wages to the seafarer’s engaged on board

in accordance with the seafarer employment agreement for their work at no greater than monthly interval.



3.1 SEAFARER’S EMPLOYMENT AGREEMENT



3.1.1. All seafarers working on board ships shall have an agreement ( Contract agreement) signed between

the Owners/ Manning agency and the seafarer for the said contractual period which gives a decent

working condition to the seafarer.



3.1.2 The Article of Agreement (AOA) may be entered into as per the latest DGS order. All joining seafarers

are given the opportunity to examine their contract of employment and (AOA) before signing. Copies of

all agreement signed shall be available on board the relevant vessel, with the master for verification by

the authorities in any port visited by the vessel.



4.0 RECORDS

4.1.1 Following records form a part of the personnel management procedure:

CPMF 01-01: Performance and appraisal report of shore staff

CPMF 02-01: Seafarer’s application form (Owner or Manning Agency)

CPMF 02-02: Drug and alcohol declaration

CPMF 02-03: Pre-joining checklist

CPMF 02-04: Next of kin declaration

CPMF 02-05: Acknowledgement of application

CPMF 02-06: Grievances reporting form

CPMF 02-07: Application to see doctor

CPMF 02-08: Crew list

CPMF 02-09: Monthly Random Alcohol Breathing test.

FPMF 01-01: STCW Rest Hours ( As per MLC form).

FPMF 01-02: Seafarers Appraisal/ Confidential Report Form

FPMF 12-01: Records of Briefing at Office for Master, C/Engineer, C/Officer and 2nd Engineer.

FPMF 14-01: Risk Assessment Form

FPMF 14-02: Hazard Identification Form

FPMF 13-02: Monthly Safety Committee Meeting Report



