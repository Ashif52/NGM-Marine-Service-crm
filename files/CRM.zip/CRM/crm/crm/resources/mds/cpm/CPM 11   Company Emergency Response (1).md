



11. COMPANY EMERGENCY RESPONSE



11.1 OBJECTIVE :To ensure that any contingency related to vessel can be dealt with in a proper and

effective manner.



11.2 RESPONSIBILITY : The DPA shall be responsible for the coordination of the emergency response

ashore.



11.3 DESCRIPTION



11.3.1 Upon notification of a contingency by a vessel, the DPA shall call for a meeting of the Emergency

Response Team. If the emergency occurs outside working hours, the DPA shall inform the other members

and they shall proceed to office immediately.



11.3.2 The emergency response team shall comprise of:

Managing Director

Designated Person Ashore

Technical Superintendent

GM - Head of Fleet Personnel

Fleet Personnel executive

Technical executive

Purchase executive



11.3.2.1 The emergency response team shall all assemble in the Company’s board room.



11.3.3 If one or more persons of the emergency response team is out of station, the DPA may involve the

person in the team activity through voice conferencing. He may delegate the duties of that person to other

team members.



11.3.4 The emergency response team shall refer to the vessel's plans, technical manuals etc and shall advise

the most appropriate measures to be taken in order to deal with the situation. They shall also co-ordinate will

all external parties such as classification society for advice on the ships damage stability calculations.



11.3.5 The emergency response team shall notify the flag state, concerned agents, owners  and other

concerned parties and shall advise the Master accordingly about the actions to be taken with regard to the

safety of life and the cargo as well as possible action for safeguarding the vessel and environment.



11.3.6 Where necessary, the Coast Guard and the Coastal State Authorities shall be informed.



11.3.7 Prompt travel arrangements shall also be made for shore personnel to reach the scene of contingency.

If the company’s representative is dispatched to the location, he shall coordinate between the vessel and

the emergency response team.



11.3.8 Neither the vessel nor any person from the company shall directly deal with the press without the

explicit orders from Managing Director.



11.3.9 To test the efficiency of the emergency response team, mock drills shall be initiated with the vessels

at least once a year, on the instructions of the Vice President/DPA.



11.3.10 In case of prolonged emergency, the DPA shall rest the team members in rotation in such a way that

at any time, adequate members are available to handle the emergency.



11.3.11 After the Master calls off the emergency, the backup arrangements shall be on standby for some

more time as there may be a possibility that the emergency may rise again. This extra time shall be as decided

by DPA.







11.3.13 Every emergency or incident which required the use of emergency plans shall be reviewed after

the event to ascertain whether the situation could have been avoided, and to take whatever corrective

action considered necessary to avoid re-occurrence. The review shall also be used to improve the

contingency plan on board and ashore.



11.4 NOTIFICATION



11.4.1 Depending on the type of contingency, one or more of the following agencies may need to be notified.

The list includes, but is not limited to:

Flag State Administration

Oil Spillage Contractors

Repairers/ Divers /Services

Flag State Oil Spill coordinators

Classification Society

Vessel’s owners

Vessel’s Agent

Coast Guard , Tug/ Salvage Operations

Coastal State Authorities

Port Authorities

Shipping Master

Personnel families (next of kin)

Medical Facilities

H & M underwriters, P & I Club





11.5 RESPONSIBILITY



























11.6 EMERGENCY RESPONSE FLOW CHART



























































