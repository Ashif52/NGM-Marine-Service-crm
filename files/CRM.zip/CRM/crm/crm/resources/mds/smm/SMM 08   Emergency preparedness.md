8. EMERGENCY PREPAREDNESS



The Company has prepared contingency plans to deal with potential shipboard emergencies. These

plans have been developed for both ship and shore response to any incident and further ensure that

the Company responds to an emergency in a prompt, coordinated and effective manner (Refer manual

FPM 07).



8.1 EMERGENCY SHIPBOARD SITUATIONS

8.1.1 The Company has identified potential emergency shipboard situations and listed in (Refer manual

FPM 07) and has established procedures to respond to them.



8.1.2 The need for additional situations or amending existing situations is identified through ship’s

safety committee meetings, management review meetings, non-conformities or through accident/ incident/ near miss reports & marine safety circulars.



8.1.3 The company has also established procedures for responding to and reporting about potential emergency shipboard situations (Refer manual FPM 08).



8.2 EMERGENCY DRILLS & EXERCISES PROGRAM



8.2.1 The company has established a program for emergency drills & exercises that are conducted on board ships and ashore (Refer manual CPM 11 & FPM 07). It is the Master’s responsibility to ensure that drills & exercises are held as per the plan. Ashore, the Vice President is responsible for ensuring that the drills are carried out as per the plan.



8.2.2 Contingency plan exercises shall be carried out at least once every TWELVE months.



8.2.2 Shipboard contingency plans include (Refer manual FPM 07).

The allocation of duties and responsibilities of crewmembers

Actions to be taken to gain control in the emergency situations

Guidelines for communications to office and to third parties

To recover persons from the water, ship may follow the manual “Plans and Procedures for Recovery of

Persons from the Water” that are specific to their vessel.



8.3 COMPANY RESPONSE MEASURES

8.3.1 The company’s safety management system has established measures to ensure that the company

can respond at any time to emergency situations involving its ships (Refer manual CPM–11).



8.3.2 Shore based contingency plans include

Delegation of personnel to the emergency response teams and assignment of duties to each person.

Guidelines for immediate action to be taken in response to an emergency call.

Guidelines for dissemination of information within the department, within the Company and to outsiders.

Guidelines for maintaining communication with ships.

Actions to be taken to support the vessel in gaining control of the emergency.

A list of 24-hour contact points within the Company and other Rescue Agencies



8.3.3 Whenever there is an accident, illness or an emergency situation connected with a floating staff,

the shore office shall liaise with the next of kin of the floating staff concerned.



8.3.4 All communication with media shall be handled by the Managing Director or his

authorized representative only.



8.3.5 In case of a protracted emergency, the company has established a backup arrangement

(Refer manual CPM 11).

