

9. REPORTS AND ANALYSIS OF NON-CONFORMITIES, ACCIDENTS AND HAZARDOUS OCCURRENCES



9.1 PROCEDURE FOR REPORTING, INVESTIGATION AND ANALYSIS

The SMS of the company includes procedures ensuring that NC, accidents and hazardous situations are

reported to the company, investigated and analyzed with the objective of improving safety and pollution

prevention. Circulars are sent to all the fleet vessels so as to prevent recurrence. (Ref. manual CPM 06)



9.1.1 RESPONSIBILITY



9.1.1.1 The Master shall be responsible for reporting to office about any accident, incident, near miss or

hazardous occurrences. He shall encourage the crew members to report NC to him. The Master shall be

responsible for investigation and analysis of the said occurrences (root cause).



9.1.1.2 At shore the DPA shall be responsible for reporting, investigating and analyzing the occurrences.

All corrective and preventive actions will be aimed at ensuring that recurrence of incidents, accidents or

deficiencies in the SMS is avoided.  He shall encourage other staff to report any such occurrences to him.



9.1.2 REPORTING



9.1.2.1 The Master shall report the following to the company/ DPA.

Accidents & near misses

Hazardous situations

Non-conformities

Findings of the shipboard safety committee

FSI/ PSC or audit recommendation or deficiencies noted



9.1.2.2 Officers and crew members are responsible for identifying and reporting non-conformities to the

deck

watch officer or the duty engineer. Appropriate action will be taken as dictated by the circumstances.



9.1.2.3 Non-conformity has occurred whenever:

The documented Safety Management System fails to provide the necessary control to prevent the

occurrence of an adverse incident affecting Safety or Pollution Prevention;

The documented SMS is not implemented, i.e. actual practice does not conform to the documented

system;

A situation is identified that represents a potential hazard;

A deficiency is identified by external organizations i.e. flag state or port state.



9.1.2.4 NC are reported to the DPA with a view towards improving safety and protection of the

environment. Documented procedures are provided for reporting NC. Refer CPM 06 and FPM 14.



9.2 PROCEDURE FOR – CORRECTIVE ACTION (INVESTIGATION AND ANALYSIS)

Master shall investigate the incident or occurrence and arrive at its root cause and possible correction.

This shall be recorded in the CPMF 06-01 or CPMF 06-02. The report shall be discussed in the subsequent

shipboard safety committee meeting and the report of same shall be sent to office. The non-conformity

report and the safety committee meeting report shall be discussed in the management review meeting.

A root cause analysis shall be done again.











9.3 SAFETY COMMITTEE MEETING



SCM are held onboard at least once every month chaired by the Master. These meetings provide a forum to

discuss all safety issues and to recommend improvements in procedures and practices to the company. The

issues discussed during the safety committee meetings is recorded in the “Safety Committee Meeting Report

”which is forwarded to the company every month. Refer manual FPMF 13-02. During the meeting, the master

shall also discuss the results of his inspections and the results of inspections carried out by flag state/ port

state/ class/ superintendent on board. The meeting shall be attended by all officer and crew as possible.



9.4 PROCEDURE FOR CORRECTIVE ACTION AND PREVENTIVE ACTION



The Master together with senior officers shall do the root cause analysis and possible correction. Such

reports are reviewed by the DPA with relevant senior management and corrective action agreed with the

Master within the target date for closure. DPA to ensure that all corrective and preventive actions will be

aimed at ensuring that recurrence of incidents, accidents or deficiencies in the SMS is avoided.

(Refer manual CPM 07). All reports and non-conformities, accidents or incidents and near-misses are

analyzed by the DPA and senior management. The results of such analysis may be used to:

Initiate general corrective and preventive action through mails or circular letters to other fleet

vessels. Initiate amendments to the SMS to prevent recurrence.

