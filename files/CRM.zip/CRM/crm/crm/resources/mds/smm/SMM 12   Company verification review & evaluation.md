



12. COMPANY VERIFICATION, REVIEW AND EVALUATION



12.1 INTERNAL SAFETY AUDITS



12.1.1 The Company maintains a program of yearly internal safety audits designed to verify the

compliance of safety and pollution prevention activities with the documented requirements of the SMS.



12.1.2 The Company shall carry out internal safety audits at intervals of not more than 12 months to

verify whether safety and pollution prevention activities comply with the SMS. The DPA shall be

responsible for establishing and implementing the internal audit schedule for office and for the company’s ships.

In exceptional circumstances such as vessel is laid up for repairs/dry-dock/surveys, this interval may

be exceeded by not more than 2 months after the vessel is brought in operation.



12.1.3 On completion of audit, the results of the audits are brought to the attention of all personnel

having responsibility in the area involved.  Audit reports are submitted to DPA, giving details



of the departments/ area audited and non conformities & observations recorded during the audit. These

reports are to be made in the prescribed format, as per internal audit procedure (Refer manual CPM 08).



12.2 COMPANY'S RESPONSIBILITIES UNDER THE CODE



The Company shall periodically verify whether all those undertaking delegated ISM-related tasks are

acting in conformity with the Company's responsibilities under the Code."



12.3 PROCEDURES FOR EVALUATION AND REVIEW OF SMS



12.3.1 The company has established a system to evaluate the effectiveness of the SMS during its normal

day to day operation. This shall be discussed during the management review meeting which is conducted

once during every calendar year or more frequently in case of serious system failures. However

the maximum interval between two successive Management Review Meetings shall not exceed more

than twelve months. Based on the evaluation, the SMS shall be revised if necessary

(Refer manual CPM 09).



12.3.2 Each master performs an SMS review once in six months. This Master’s SMS review is discussed

in the management review meeting and the SMS is amended accordingly (Refer manual FPM 13).



12.3.3 The management review meeting covers the following (Refer manual CPM 09):

Review of the minutes of the previous management review meeting

Review of monthly ship safety committee meetings

Review of Master’s SMS review

Internal/External audit findings.

PSC / FSI Inspection reports.

Analysis of reports, accidents, hazardous occurrences and non-conformities.

Organizational changes.

Trainings done and the effectiveness of the training methods.

Changes in relevant legislations, conventions etc.

Identification of new plans, procedures or instructions.

The effectiveness of the SMS and any suggested changes.

Review of the performance of sub-contractors and suppliers.

Any other matter











12.3.4 The Master’s SMS review covers the following (Refer manual FPM 13):

Accident, incident, near miss report/ investigation.

Recommendations/ memos following class/ statutory surveys.

Charterer’s claims/ complaints.

Vessel performance.

Suggestions for improving the SMS.

Status of implementation onboard.

Non-conformities and corrective action taken.

Any other matter.





12.4 AUDIT PROCEDURES - CORRECTIVE ACTION AND INDEPENDENCE OF AUDITORS

The company has established procedures to carry out audits and to implement the possible corrective and preventive actions. Audits are conducted by duly qualified auditors, external to the area being audited but having knowledge of the functions under audit (Refer manual CPM 08).



12.5 COMMUNICATION OF AUDITS RESULTS

Audit results shall be communicated to the auditee as well as to the DPA (Refer manual CPM 08).



12.6 IMPLEMENTATION OF CORRECTIVE ACTION

If any non conformity or observation is recorded during the audit, a root cause analysis shall be carried out to establish the cause. The corrective & preventive action shall be decided and implemented at the earliest. The implementation of the corrective action shall be verified by DPA or his representative, if necessary, by visiting the vessel (Refer manual CPM 08).