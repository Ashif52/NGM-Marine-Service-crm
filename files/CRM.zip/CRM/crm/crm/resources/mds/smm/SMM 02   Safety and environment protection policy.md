

2.0   SAFETY AND ENVIRONMENTAL PROTECTION POLICY



NMG Marine Services Private Limited has established a safety and environmental protection policy which describes how the objectives of the ISM Code are achieved.



2.1 SAFETY AND ENVIRONMENTAL PROTECTION POLICY

THE COMPANY IS COMMITTED TO:

## Comply at all times with rules and regulation applicable for ship operations and its management.

Comply with all applicable codes, guidelines, amendments and standards recommended by the Organization, Administrations, and classification societies.

Ensure safe working practices and prevention of pollution by oil, gases and noxious substances in particular to marine environment and to property.

Ensure safety of life/ persons on board.

Provide Healthy work Environment on vessels to prevent human injury or loss of   life.

Ensure that none of it’s operations and activities are detrimental to the environment.

Establish safeguards against all identified risks

Do Risk Assessment of all standard ship board operations and assist in developing a culture of Risk Evaluation on board.

Continuously monitor and review the safety Management system in order to work towards improvement of the effectiveness of the system.



MR. MADESH GANESHAMOORTHY

MANAGING DIRECTOR

28TH MARCH 2023



2.2 POLICY IMPLEMENTATION:

2.2.1 ACCESSIBILITY

Copies of the above Policy are posted at conspicuous locations at the office and onboard ships. At office, the policy shall be posted at the display board and onboard ships, it shall be posted at the wheel house, engine room (or ECR) and officer/crew mess rooms.



2.2.2 UNDERSTANDING



The policy is a part of the apex manual which shall be read and understood by all employees as soon as they join the ship/company. Kindly refer the NOTE given in the “Record of acquaintance” sheet (Refer manual SMM F) as an acknowledgement of understanding.



2.2.3 IMPLEMENTATION

The above policy and objectives will be implemented by the shore and shipboard organizations. The DPA will be responsible for the implementation ashore while the Master will be responsible for the implementation onboard. The DPA and the technical superintendent who visit the vessels for inspection & internal audits would verify such implementation. To implement the policy, the company has incorporated in its safety management system, procedures for the following:

Safe procedures and standards – Refer manual FPM 10

Pollution prevention - Refer manual FPM 9

Compliance with rules, regulations, codes and classification/ flag state requirements. Refer manual

FPM 11





2.3 IMPLEMENTATION ASSURANCE SHIP/SHORE



The company shall assure that the safety and environmental protection policy is read, understood, implemented and maintained at all levels in the organization. Adequate resources and shore-based support shall be provided to achieve the above (Refer manual   SMM 03 & CPM 15).



2.4 DRUG AND ALCOHOL POLICY



THE COMPANY’S DRUG AND ALCOHOL POLICY APPLIES TO ALL SHIP AND SHORE STAFF, INCLUDING VISITORS TO THE VESSEL.



DRUGS

THE MISUSE OF LEGITIMATE DRUGS OR THE USE, POSSESSION, DISTRIBUTION OR SALE OF ILLICIT OR UNPRESCRIBED CONTROLLED DRUGS BY SHIP/SHORE STAFF IS PROHIBITED.



THE COMPANY WILL NOT EMPLOY ANY PERSONS WHO ARE USERS OF OR HAVE A RECENT RECORD OF THE USE OF ILLEGAL DRUGS OR HAVE ABUSED THE USE OF PRESCRIBED DRUGS. ANY EMPLOYEE FOUND IN CONTRAVENTION OF THIS POLICY WILL BE INSTANTLY DISMISSED.



THE COMPANY WILL FOLLOW NATIONAL DRUG LAW & PROVIDES AUTHORITY TO THE PORT HEALTH FOR RANDOM CHECKING OF DRUGS IN CASE OF ANY SUSPICION.



ALCOHOL

THE USE, POSSESSION, DISTRIBUTION OR SALE OF ALCOHOL ON BOARD SHIP IS PROHIBITED. ANY EMPLOYEE FOUND IN CONTRAVENTION OF THE COMPANY’S ALCOHOL POLICY WILL BE LIABLE FOR DISMISSAL.



MR. MADESH GANESHAMOORTHY

MANAGING DIRECTOR

28TH MARCH 2023



2.4.1 ACCESSIBILITY



The Copies of Drug and Alcohol Policy are posted at office and onboard ships. At office, the policy shall be posted at appropriate location and onboard ships, it shall be posted at the wheel house, engine room and mess rooms.



2.4.2 UNDERSTANDING



The Drug and Alcohol Policy is a part of the apex manual which shall be read, understood and signed by all employees as soon as they join the ship/ company.



2.4.3 IMPLEMENTATION



The above policy will be implemented by the shore and shipboard organizations. The DPA will be responsible for the implementation ashore while the Master will be responsible for the implementation onboard. The DPA and the technical Superintendent who visit the vessels for inspection & internal audits would verify such implementation. In accordance with this policy, screening of floating staff shall be done along with the pre-joining medicals (Refer manual CPM 01). Onboard screening shall be done through random tests.







2.5   CYBER SECURITY POLICY



The company cyber security policy is to ensure the application of measures on board the ship designed to protect persons on board, cargo, cargo transport units, ship’s stores or the ship from the risks of a security incident.

The vessel management office is responsible for providing cyber security policy for the Master to follow to ensure vessel safety.

The ship’s Master has overall responsibility for the safety of the vessel. As Cyber security can directly affect vessel safety, the responsibility includes cyber security.

The vessel management team is responsible for ensuring timely notification of any incident, which may be viewed as a ‘cyber incident’.

The vessel support team are responsible for providing support and escalations.





MR. MADESH GANESHAMOORTHY

MANAGING DIRECTOR

28TH MARCH 2023



