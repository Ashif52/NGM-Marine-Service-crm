



16. FORMS OF CERTIFICATES



16.1 The Document of Compliance, the Safety Management Certificate, the Interim Document of Compliance

and the Interim Safety Management Certificate should be drawn up in a form corresponding to the models

given in the appendix to this Code. If the language used is neither English nor French, the text should include a translation into one of these languages.

16.2 In addition to the requirements of paragraph 13.3, the ship types indicated on the Document of

Compliance and the Interim Document of Compliance may be endorsed to reflect any limitations in the

operations of the ships described in the safety management system.



