



ABBREVIATIONS:



