

5.0 MASTER’S RESPONSIBILITY AND AUTHORITY



5.1 DEFINITION OF TASKS



The Master is the overall in-charge & administrative head of the vessel. The master’s responsibilities

shall include the following:

To conduct training and contingency drills as per the drill planner.

To convene safety committee meetings every month and encourage all staff to actively participate

in them.

To ensure all ship’s personnel communicate in the common working language English and in Hindi.

To implement the company’s safety and environmental protection policy.

To implement company’s drug and alcohol policy.

To issue standing orders and supplement them with night orders.

To ensure that all accidents/ incidents/ near-misses are properly documented, analyzed and reported

to the company.

To ensure that all non-conformities and hazardous occurrences are documented, and their closure reported. on with supporting documents.

To encourage crew to report any near misses or any lapse in safety systems on board.

To ensure that all the important documents (e.g. official log book, deck and engine log books, bridge

and    engine movement book, statement of facts, note of protest, bill of lading, etc) are neatly written and duly signed/ initialed.

To take care of crew welfare. To promote healthy inter-action amongst crew and to maintain harmony on

board to enable vessel’s safe operation.

To maintain the vessel’s sea-worthiness at all times.

To liaise with the company regarding the vessel’s needs

Ensuring all records relevant to the SMS and as defined in procedures are available on board.

Ensuring all documentation that is designated as ‘controlled’ are maintained up to date and as per

Company’s procedures.

Advising C/E and Ch. Officer of the relevant details of the intended voyage.

Monitoring all cargo operation, vessel stress and stability with the help of Chief Officer

Verifying all documents before signing it.



5.1.1 & 5.1.2 IMPLEMENTATION, MOTIVATION



The Master is responsible for implementation of the SMS and the Safety and Environmental Protection Policy of the Company. He is also responsible for motivating the crew to act in accordance with the SMS through discussions, briefings trainings and drills (Refer manual   FPM-07).



5.1.3 & 5.1.4 ORDERS AND VERIFICATION



The Master is also responsible for issuing appropriate orders and instructions in a clear and simple language and verifying that the specified requirements of the SMS, supplemented by any orders and instructions given by him, are met.



5.1.5 REVIEWS AND REPORTS ON SMS



Periodically the Master shall review the SMS once every six months and shall report any deficiencies and/or suggestions for improvement to the Designated Person Ashore (Refer manual   FPM 13).



5.2 MASTER’S AUTHORITY AND OVERRIDING AUTHORITY



5.2.1 The Master has overriding authority and responsibility to make decisions with respect to safety of

the crew, ship and its cargo, pollution prevention and to request the company’s assistance as may

be necessary.







5.2.2 NMG Marine Service Private Limited grants the Master of a ship full and complete authority on board for the safe operation of the ship and for preventing pollution from ship.



5.2.3 The Master has the ultimate authority to sign Lloyds Open Form subject to the following:

That in his considered opinion, the ship is in peril or the safety of the crew is in imminent danger or the

environment will be affected.

He does not have sufficient time to contact the ship’s Owners/managers for their advise/ instructions on this matter Under extreme conditions, if the salvor insists on signing a contract before acting, master shall sign the same on “No-cure No-pay" terms using Lloyd's Salvage Agreement Form.



5.2.4 The Master is not constrained by the ship owner, charterer or any other person from taking in this respect any decision which, in the professional judgement of the Master, is necessary for maritime safety or for the protection of the marine environment. (IMO Res A.443 (XI)).

Master” discretion for Ships safety & security has been incorporated in SOLAS Chapter XI- 2 Regulation 8 and same shall be used by Master when required.



5.2.5 The Master also has the overriding authority to:

To refuse to load any cargo if he is of the opinion that carriage of cargo is in violation of applicable.

international regulations, thereby affecting the safety of the crew, the ship and the environment.

To stop cargo and prevent any further loading/ stowage/ discharging if in his opinion the said operational.

pattern will affect the ship’s stability and thus the safety of the crew, the ship and the environment.











