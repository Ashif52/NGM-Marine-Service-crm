# 13. CERTIFICATION AND PERIODICAL VERIFICATION



13.1 COMPANY CERTIFICATION

The company shall have a valid DOC/Interim DOC and a copy of same shall be placed on board all the

vessels operated by the company.



13.2 DOCUMENT OF COMPLIANCE

The company’s DOC/Interim DOC is issued by the DIRECTORATE GENERAL OF SHIPPING, the validity

of which shall be subject to initial, annual, renewal audits.



13.3 DOC FOR SHIP TYPES

The DOC shall be valid for the type of vessel for which audit has been carried out. In case there is some

other type of vessel taken over by the Company, another DOC audit shall be carried out and accordingly

the DOC will be suitably amended.



13.4 VALIDITY OF DOC

The validity of an Interim DOC shall be one year within which period, the company shall implement the

SMS and submit the system for an initial audit. On successful completion of initial audit, a full term DOC is

issued valid for five years, subject to annual verification by the Directorate General of Shipping.



13.5 REVOCATION OF DOC

The DOC would be withdrawn by the Administration if the company fails to request for an annual verification

or if there is evidence of major non-conformities with the ISM code.



13.5.1 REVOCATION OF SMC

All associated SMC or interim SMC issued to vessels would also be withdrawn if the DOC is withdrawn.



13.6 DOC COPY ON SHIP

The company shall place on board a copy of the DOC so that the master of the ship, if so requested,

may produce it for verification by the Administration or during port state inspection.



13.7 SAFETY MANAGEMENT CERTIFICATE

The company shall maintain a SMC on all its vessels. Copies of these certificates are maintained ashore

at the office so that same can be produced for verification if required during audits.



13.8 VALIDITY OF SMC

The validity of an interim SMC shall be six months within which the company shall implement the SMS

and submit the vessel for an initial audit. On successful completion of initial audit, a full term SMC is issued

to the vessel. This certificate shall be valid for five years from the date of issuance subject to the validity

of the DOC. There shall be one intermediate audit during these 5 years which could be undertaken

anytime between 2nd and 3rd year of the validity of the SMC.



13.9 REVOCATION OF SMC

In addition to the paragraph 13.5.1, the SMC should be withdrawn by DGS if the intermediate

verification required in paragraph 13.8 is not requested or if there is evidence of Major NC with the

ISM code.



13.10 VALIDITY OF RENEWED CERTIFICATES – CASE I

When the renewal verification is completed within three months before the expiry date of the existing

DOC or SMC, the new DOC or SMC would be valid from the date of completion of the renewal verification

for a period not exceeding five years from the date of expiry of the existing DOC or SMC.







13.11 VALIDITY OF RENEWED CERTIFICATES – CASE II

When the renewal verification is completed more than three months before the expiry

date of the existing DOC or SMC, the new DOC or SMC should be valid from the date of completion of

the renewal verification for a period not exceeding five years.



13.12 VALIDITY OF RENEWED CERTIFICATES – CASE III

When the renewal verification is completed after the expiry date of the existing SMC, the new SMC should

be valid from the date of completion of verification to a date not exceeding five years of the existing SMC.



13.13 VALIDITY OF RENEWED CERTIFICATES – CASE IV

If a renewal verification has been completed and a new SMC cannot be issued or placed on board the

ship before the expiry date of the existing certificate, the Administration or organization recognized by

the Administration may endorse the existing certificate and such a certificate should be accepted as valid

for a further period which should not exceed five months from the expiry date.



13.14 VALIDITY OF RENEWED CERTIFICATES – CASE V

If a ship at the time when SMC expires is not in a port in which it is to be verified, the Administration

may extend the period of validity of the SMC but this extension should be granted only for the purpose

of allowing the ship to complete its voyage to the port. No SMC should be extended for a period more

than three months, and the ship to which an extension is granted should not leave that port without

having a new SMC. When the renewal verification is completed, the new SMC should be valid to a

date not exceeding five years from the expiry date of the existing SMC before the extension was granted.























