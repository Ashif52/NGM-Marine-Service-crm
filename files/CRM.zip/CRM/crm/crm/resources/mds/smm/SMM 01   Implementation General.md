# 1. GENERAL

Regulations governing the operation of ships are becoming increasingly complex and comprehensive

due to national and international efforts to prevent maritime catastrophes, while at the same time

requirements of efficiency are becoming very high. Rules and regulations do not, however, in

themselves guarantee safety, and the actual operational safety depends on:

-     The degree of our compliance with the rules and regulations,

-     Pro-active management,

-     The exercise of prudent seamanship.



Therefore, the Company has developed and implemented a Safety Management System (SMS) to

ensure that the Company’s shipping operations are planned, executed and documented properly

to achieve high standards of safety and environment protection.



1.0.1 The Company’s SMS is documented in the following five manuals:

SAFETY MANAGEMENT MANUAL – SMM (CONTROLLED COPY)

COMPANY PROCEDURE MANUAL – CPM (CONTROLLED COPY)

FLEET PROCEDURES MANUAL – FPM (CONTROLLED COPY)

COMPANY PROCEDURE FORMS MANUAL - CPMF (CONTROLLED COPY)

FLEET PROCEDURES FORMS MANUAL – FPMF (CONTROLLED COPY)



1.0.2 This manual serves as the Safety Management Manual of the SMS implemented by the Company.

It identifies and illustrates the systematic approach to safety and pollution prevention that the

Company follows and provides references to supporting documentation.



1.1 DEFINITIONS:

The following definitions apply to parts A and B of this Code.



International Safety Management (ISM) Code means the International

Management Code for the Safe Operation of Ships and for Pollution Prevention as adopted by the

Assembly, as may be amended by the Organization.



1.1.2 Company means the owner of the ship or any other organization or person such as the manager,

or the bareboat charterer, who has assumed the responsibility for operation of the ship from the ship

owner and who, on assuming such responsibility, has agreed to take over all the duties and

responsibility imposed by the Code.



1.1.3 Administration means the Government of the State whose flag the ship is entitled to fly.



1.1.4 Safety Management System means a structured and documented system enabling

Company personnel to implement effectively the Company safety and environmental protection policy.



1.1.5 Document of Compliance means a document issued to a Company which complies with

the requirements of this Code.



1.1.6 Safety Management Certificate means a document issued to a ship which signifies that the

Company and its shipboard management operate in accordance with the approved safety management

system.



1.1.7 Objective evidence means quantitative or qualitative information, records or statements of

fact pertaining of safety or to the existence and implementation of a safety management system

element, which is based on observation, measurement or test and which can be verified.

1.1.8 Observation means a statement of fact made during a safety management audit and

substantiated by objective evidence.



1.1.9 Non-conformity means an observed situation where objective evidence indicates the

non-fulfillment of a specified requirement.



1.1.10 Major non-conformity means an identifiable deviation that poses a serious threat to the

safety of personnel or the ship or a serious risk to the environment that requires immediate corrective

action

or the lack of effective and systematic implementation of a requirement of this Code.



1.1.11 Anniversary date means the day and month of each year that corresponds to the date of expiry

of the relevant document or certificate.



1.1.12 Convention means the International Convention for the Safety of Life at Sea, 1974 as amended.



1.1.13 Passenger Ship – is a ship which carries more than twelve (12) passengers.



1.2 OBJECTIVES



1.2.1 OBJECTIVES OF THE CODE:

The Objectives of the Code are to ensure safety at sea, prevention of human injury or loss of life,

and avoidance of damage to the environment, in particular to the marine environment and to property.



1.2.2 OBJECTIVES OF THE COMPANY:

The safety management objectives of the company are:



1.2.2.1 To provide for safe practices in ship operation and a safe working environment

(Ref. manual FPM 10).



1.2.2.2 Assess all identified risks to its ships, personnel and the environment and

establish appropriate safeguards; and (Refer manual CPM 06 and FPM 14).



1.2.2.3 To continuously improve safety management skills of personnel ashore and aboard ships,

including preparing for emergencies related both to safety and environmental protection (Refer manual

CPM 11 & FPM 12).



1.2.3 SMS COMPLIANCE WITH RULES AND CODES



1.2.3.1 The company has developed a safety management system for ensuring compliance with

mandatory rules and regulations. This SMS has in place procedures and instructions defining the

processes for ensuring this at all times, including maintaining the condition of ship and equipment

between surveys.



1.2.3.2 The company’s safety management system has documented procedures to ensure that

applicable codes, guidelines and standards recommended by the Organization, Administration,

Classification Societies and maritime industry organizations are taken into account. "Refer to the List

of codes, recommendations, guidelines and other safety and security-related non-mandatory

instruments (MSC.1/Circ.1371)."



1.3 APPLICATION OF THE ISM CODE

The requirement of this Code will be applicable to NMG Marine Services Private Limited and to all

vessels managed or operated by it. The company has applied for a document of compliance for the

ship type:

Other Cargo Ship.

Oil Tanker.

BULK CARRIER







1.4 FUNCTIONAL REQUIREMENT



NMG MARINE SERVICE PRIVATE LIMITED has developed a safety management system covering

the functional requirement of the ISM Code which includes:



1.4.1 A Safety and Environmental protection policy (Refer manual SMM 02).



1.4.2 Instructions and procedures to ensure safe operations of ships and protection of the environment

in compliance with relevant international and Flag State legislation, such as IMO, Administration,

Classification Society and other Maritime Organizations (Refer manual FPM 11).



1.4.3 Defined levels of authority and lines of communication between, and amongst, shore and

shipboard personnel (Refer manual SMM 03 & FPM 01).



1.4.4 Procedures for reporting accidents and non–conformities within the provisions of this code

(Refer manual CPM 06).



1.4.5 Procedures to prepare to respond emergency situations. (Ref. manual FPM 07, FPM 08 & CPM 11).



1.4.6 Procedures for internal audits and management reviews (Refer manual CPM 08).