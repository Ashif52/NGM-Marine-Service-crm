



6.0 RESOURCES AND PERSONNEL



6.0.1 The company shall continually provide the resources and personnel needed to implement, maintain

and evolve the safety management system. The company shall also ensure that shore/ floating staff are

competent on the basis of education, training and experience (Refer manual CPM 04 and FPM 12).



6.0.2 The company shall also determine and provide the work environment on board ships in order to

motivate employees to perform their operations effectively to meet the requirements of the safety

management system.



6.0.3 The company employs seafarers, including cook of age 18 years and above only

(Refer manual CPM 01).



6.1 MASTER’S QUALIFICATION

Appointing a Master to take over command of a vessel, the company shall ensure that:



6.1.1 He is properly qualified for command.

Competency certificate as per the safe manning requirements of the vessel.

Certificate courses as per STCW requirement.



6.1.2 He is fully conversant with the company’s SMS (Refer manual CPM 04).



6.1.3 Given the necessary support so that the Master’s duties can be safely performed :-

The Company shall ensure that adequate resources are available both ashore and afloat to support the Master

in the safe and efficient operation of his vessel. This is achieved by providing adequate competent manning and defect-free functioning of equipment’s. (Refer manual  FPM 05).



6.2 CREW QUALIFICATION AND NUMBERS



6.2.1 The Company shall establish and maintain procedures to ensure that each ship is manned with

qualified, certificated and medically fit seafarers in accordance with applicable national and

international requirements including MLC 2006 regulation 1.3 and appropriately manned in order to

encompass all respects of maintaining safe operations on board. As per Safe Manning Document.



6.2.2 It is ensured that the floating staff is:

Certified as per Flag State requirements.

Possession of valid certificates for their rank prior to posting – as per flag state requirements.

Possession of a valid Medical fitness certificate as per flag requirement.



6.2.3 All Officers assigned to ships managed by the company shall have appropriate licenses or

endorsements issued by the flag administration. Licenses and endorsements are required to be current and

valid for the duration of their tenure on the ship. The authenticity of the seafarer’s certificate of competencyis verified through the DG Shipping website before the seafarer is placed on the vessel. All floating staff must hold a valid medical fitness report issued by the DGS approved medical practitioner prior to assignment aboard ship.



6.2.4 The criteria for qualification shall be as per the flag state requirements. The recruitment procedures

are defined in procedure (Refer manual CPM 01).









6.3 TRAINING OF NEW PERSONNEL/ ASSIGNMENT

The Company has established procedures to ensure that new personnel and personnel transferred

to new assignments are given proper familiarization with their duties (Refer manual CPM 04 & FPM 12).



6.4 UNDERSTANDING OF THE RULES



6.4.1 The company shall, through familiarization and training program, ensure that all personnel involved

in the Company’s SMS have an adequate understanding of relevant rules, regulations, codes and guidelines.



6.4.2 The details of various relevant rules as applicable to the industry have been incorporated in

(Refer manual  FPM 11). The master shall ensure that all floating staff have read and understood this

section. he company shall, through periodical audits and inspections, verify that all floating staffs have an

adequate understanding of relevant rules, regulations, codes and guidelines. Furthermore, the company

shall, from time to time, send fleet circulars containing recent changes in regulations and anyother relevant information.



6.5 PROCEDURE FOR TRAINING

6.5.1 General



6.5.1.1 In order to achieve excellence in its activities, the Company lays prime importance to the training

of its ship and shore staff. The company shall promote awareness & knowledge related to Safety, Security and

Protection of Environment amongst its employees.



6.5.1.2 The Company has established procedures for identifying the training needs of personnel required in

support of the SMS. Procedures for identifying and providing such training concerned are established

(Refer manual CPM 04 & FPM 12).



6.5.2 The objectives of training are:

Assist the employees to function more effectively in their present positions.

Increase awareness among floating staff about issues pertaining to pollution prevention and safety.

To build a second line of competent floating staff and prepare them to occupy more responsible positions.



6.5.3 Objectives of the training are achieved through the following:

To Familiarize the new staff with their job responsibilities.

To Familiarize the new staff and personnel transferred to new assignments with the company’s policies

and the safety management system.

Ensure Periodical performance appraisal carried out.

Ensuring that personnel are aware of the relevance and importance of their role in the system.

The training needs of staff shall be periodically reviewed during drills, safety committee meetings

and management review meetings.



6.5.4 Training – (Shore based Personnel)

The Vice President is responsible for identifying the training needs and organizing necessary training. Records for training shall be maintained (Refer manual CPM 04).



6.5.5 Training – (Shipboard Personnel)

It is the responsibility of Master to identify the training needs of all floating staff and ensure that necessary

training is provided on board by way of discussions, training and drills (Refer manual FPM 12).







6.5.6 The Company has made provision for onboard training by:

Providing Initial familiarization immediately on joining the vessel and On Job familiarization with

machinery, equipment and systems where they are going work (With in 7 Days).

Conducting regular drills and exercises to prepare for emergency actions.

Encouraging crew members to update their knowledge regarding safety procedures and shipboard

operations.



6.6 PROCEDURE FOR WORKING LANGUAGE



6.6.1 The Master of the vessel is responsible for passing orders in a clear and simple manner and for

ensuring that all personnel can communicate effectively in order to carry out their duties having due regard

to the Company’s Safety and Environmental Policy.



6.6.2 The Company has established procedures to ensure that ship’s personnel receive relevant information on the safety management system in ENGLISH language.



6.6.3 The Company’s procedures ensure that the ships personnel are able to communicate effectively

(English or Hindi) in the execution of their duties.



6.7 EFFECTIVE COMMUNICATION (LANGUAGE)

The command language on board vessels and the language understood by the crew shall be English or Hindi.

The Master shall ensure that when a seafarer joins a vessel he has an adequate understanding of both the

written and verbal key instructions, suitable for execution of their duties related to the safety management

system.







