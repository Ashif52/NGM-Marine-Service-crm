

4. DESIGNATED PERSON ASHORE(DPA) AND ADPA



4.0.1 The VICE PRESIDENT has been appointed as the Company’s DPA to ensure overall compliance

with the SMS. The Company will appoint an ADPA, when the total number of vessels being managed

exceeds Three, which may be reviewed as per Flag requirement. These appointments are

made & communicated through office orders from the office of Managing Director, meeting the qualification

and experience requirements given in the guidelines issued by DG shipping from time to time.



4.0.2 DPA is the link between the company & the personnel on board the ship and has direct and

independent access to the top most management for matters concerning safety & pollution prevention

The company shall ensure that adequate resources and shore based support are provided to the

DPA for carrying out his responsibilities.



4.0.3 The DPA is responsible to ensure that SMS procedures are established, implemented and

maintained as per the requirements of ISM Code. He will monitor & report the performance of SMS to

company management for review, as a basis for improvement. He will liaise with regulatory authorities

in matters related to SMS, in order to ensure that the company DOC & SMC are always in order.



4.0.4 The DPA has the full responsibility and authority for unlimited financial approvals with regard to

safe operation and safety of the vessels. (Refer manual   CPM-15)



4.1 IDENTIFICATION OF TASKS INCLUDING OPERATION OF SMS :-



The responsibilities and authority of the DPA shall include the following:

To Monitoring the safety and pollution prevention aspect of the operation of the company’s ships.

To Ensure that adequate resources and shore based support are applied as required.

To Implementing the safety management system

To Providing a link between the ship and shore in matters of safety and pollution prevention.

To Monitoring of various nonconformities and hazardous occurrences reports. To ensure follow-up

of corrective action with respect to safety committee meeting minutes/ master’s review/ drill reports

etc  and presents the same during Management Review Meetings.

To Co-ordinate during emergencies.

To Prepare annual audit plan for office and ships.

To Review requirements and amend company manuals as required.

To Ensure and implement the policy both ashore and onboard ships and verify its implementation.

To Ensure and Implement the Drug and Alcohol policy both ashore and onboard ships and

verify its implementation.



4.2      CONTACT DETAILS:    DESIGNATED PERSON ASHORE(DPA)



NAME & DESIGNATION	   :  CAPT. REYNALD FERNADO– VICE PRESIDENT

OFFICE DIRECT TELEPHONE	       :  91 044 48530742

MOBILE NUMBER		       : +91 9486471072

E- MAIL			                  :  tech@ nmgmarineservice.com

4.2.1   ALTERNATE DESIGNATED PERSON ASHORE(ADPA)

CONTACT DETAILS:    ALTERNATE DESIGNATED PERSON ASHORE(ADPA)

NAME & DESIGNATION	                  : 	 MR. V. ADIMULAM (TECH. SUPERITENDENT)

OFFICE DIRECT TELEPHONE            : 	+91 044  48530742

MOBILE NUMBER		       : 	+91 700004117

EMAIL				       : 	 technical@nmgmarineservice.com