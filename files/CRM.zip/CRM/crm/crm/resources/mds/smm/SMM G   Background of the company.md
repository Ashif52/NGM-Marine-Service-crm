

G. BACKGROUND ABOUT THE COMPANY



Overview: NMG MARINE SERVICE PVT.LTD is a global ship management company that provides comprehensive management services for a wide range of vessels, including container ships, bulk carriers, tankers, and offshore vessels. Our services include technical management, crew management, commercial management, and   newbuilding supervision.



History: NMG MARINE SERVICE PVTR.LTD was established in 2020 by a team of experienced shipping professionals with a passion for providing world-class ship management services. Since then, we have expanded our operations and currently manage a fleet of over 30 vessels for clients around the world.



Services:

Technical management: We provide technical management services that ensure the safe and efficient operation of vessels, including maintenance and repair, drydock planning, and vessel performance monitoring.

Crew management: We provide crew management services that ensure the recruitment, training, and welfare of seafarers, including crew scheduling, payroll management, and certification management.

Commercial management: We provide commercial management services that ensure the optimal commercial performance of vessels, including chartering, voyage planning, and market analysis.

Newbuilding supervision: We provide newbuilding supervision services that ensure the successful construction and delivery of new vessels, including contract negotiation, design review, and sea trial supervision.

Certifications: NMG MARINE SERVICE is certified to the highest industry standards, including:

RPSL LICENCES HOLDER RPSL NO. CHN058/CHN/RPSL

ISO 14001:2015 Environmental Management System

MLC 2006 And Quality Service

Mission: At NMG MARINE SERVICE PRIVATE LTD, our mission is to provide safe, efficient, and cost-effective ship management services that exceed our clients' expectations. We strive to be a leader in the industry by continuously improving our services, investing in technology and innovation, and attracting and retaining the best talent in the business.

