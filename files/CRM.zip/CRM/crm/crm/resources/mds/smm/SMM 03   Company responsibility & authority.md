

# 3. COMPANY RESPONSIBILITIES AND AUTHORITY



3.1 IDENTIFICATION OF RESPONSIBLE OPERATOR



The Company are responsible for and should report to the administration, the name and full address of NMG Marine Service Private Limited, as the entity responsible for the operation of their ships. The company shall provide all necessary assistance to the owners in this regard. The company shall be in full control of all SMS

related activities, including the sub-contracted activities.



3.2 RESPONSIBILITY, AUTHORITY & INTERRELATION



The Vice President is responsible for the efficient operation of the company. He has executive powers to take decisions pertaining to safety & environmental protection. In day to day activities, he is assisted by senior executives in technical, operation and fleet personnel. The organization chart depicted below reflects the

personnel responsible for the implementation & verification of safety management system. They are provided

with adequate resources and authority to discharge their responsibilities effectively. The Managing Director has overall responsibility for the ship management operations of the company.



### 3.2.1 ORGANIZATION STRUCTURE OF SHORE SIDE MANAGEMENT



s















3.2.2 RESPONSIBILITIES AND AUTHORITY OF SHORE STAFF

3.2.2.1 MANAGING DIRECTOR

3.2.2.1.1 AUTHORITY



Overall and full power for allocating and approving financial resources for implementation of company’s

plans  policies and operation.

For approving the safety management system of the company.



3.2.2.1.2 RESPONSIBILITY

-  Managing Director has the full power and overall responsibility for ship management operations of the company.



3.2.2.2 VICE PRESIDENT

3.2.2.2.1 REPORTING - To the Managing Director

3.2.2.2.2 AUTHORITY



For issuing unlimited financial approvals with regard to safe operation of the vessels and protection of

the marine environment.

To interview, appoint, promote, demote and remove shore staff with due regard to the company’s need

for human resources.

For approving expenses related to routine activities of the office.

To approve expenses like fees to flag state, classification societies, P&I club etc.



3.2.2.2.3 RESPONSIBILITY



To Identify and provide infra-structural resources.

To Handle all legal matters.

To Pursue disciplinary procedures of senior fleet officers and shore staff.

To Correspond with the principals as directed by the Director Marine.

To Review vessels’ month end papers, as applicable.

To Prepare and implement the safety management system of the company.

To Perform appraisal and evaluate training needs of the staff reporting to him.

To Review and update the safety management system of the company.

To Perform appraisal of floating staff.

To interview, appoint, promote, demote and remove floating staff with due regard to the vessels’ need

for human resources.

To Organize periodical inspection of vessels.



He is also appointed as Designated Person Ashore and his responsibilities as DPA is described in SMM-04 of this manual. In his absence, the GM (Head Fleet Personnel & OPS) takes the charge of him.



3.2.2.3 TECHNICAL SUPERINTENDENT:

3.2.2.3.1 REPORTING -To the Vice President.

3.2.2.3.2 AUTHORITY



To approve procurement of stores, spares and various other supplies to vessels

To approve workshops, technicians, service engineers etc as required.

To approve appointment of agents at vessels’ ports of call.

To approve procurement of bunkers to the vessels, as required.

To approve procurement of stores, spares and various other supplies to vessels.

To approve expenses like fees to flag state, classification societies, PNI club etc.













3.2.2.3.3 RESPONSIBILITY



To Handle routine technical issues of the company’s fleet.

To ensure that the vessels possess valid trading and other certificates as required.

To Monitor and implement the planned maintenance system on board vessels.

To Maintain & monitor the record of surveys and certificates.

To Plan and prepare vessels for dry docking.

To ensure Vessels are adequately stocked with necessary stores and supplies at all times.

To Co-ordinate with the Administration, Classification Societies for certification/surveys and validation

of certificates required for particular trade.

To Liaison with agents for the vessels at ports of call, as required.

To Organize workshops, repair technicians etc as required for the vessels.

To Co-ordinate with co-staffs for connecting the workshops, repair technicians, supplies, surveyors etc

to the vessels.

To Review vessels’ month end papers.

To Perform appraisal and evaluate training needs of the staff reporting to him.

To Provide job familiarization to staff reporting to him.

To Assist the Vice President in technical issues as required.



He is also appointed as Alternate Designated Person Ashore and his responsibilities

as ADPA is described separately in SMM -04 of this manual.



3.2.2.4 GM (HEAD FLEET PERSONNEL & OPERATIONS):



3.2.2.4.1 REPORTING -To the Managing director in the absence of DPA and to Vice President.



3.2.2.4.2 AUTHORITY



To bind the company into agreements with various unions and organizations for the smooth ship

management operations.

To fix or change wage scales for floating staff.

To approve expenses related to joining and repatriation.



3.2.2.4.3 RESPONSIBILITY



To Handle routine personnel issues of the company’s fleet.

To ensure vessels are adequately manned at all times as per Flag state requirements.

To Liaison with various unions, including the local unions - MUI, NUSI & ITF.

To Assist in the interview and recruitment of floating staff.

To Verify certificates of the floating staff prior joining the vessel.

To Liaison with next of kin of floating staff as required.

To Arrange joining and repatriation of floating staff.

To Arrange pre joining medicals of crew through approved medical practitioner.

To Co-ordinate with Technical Superintendent for the joining and repatriation crew.

To Review vessels’ month end papers, as applicable.

To Perform appraisal and evaluation of training needs of the staff reporting to him.

To Provide job familiarization to staff reporting to him.

To update higher authority about vessel’s status and position in day to day basis.



3.2.2.5 TECHNICAL EXCECUTIVE:



3.2.2.5.1 REPORTING - To the Technical Superintendent.

3.2.2.5.2 RESPONSIBILITY –To Assist Technical Superintendent as directed by him.













3.2.2.6 PURCHASE EXECUTIVE:

3.2.2.6.1 REPORTING - To Technical Superintendent



3.2.2.6.2 RESPONSIBILITY



To Procure stores, spares and other supplies as directed.

To Maintain documentation related to purchase and vendors.



3.2.2.7 FLEET PERSONNEL EXECUTIVE:



3.2.2.7.1 REPORTING -To Head Fleet Personnel



3.2.2.7.2 RESPONSIBILITY -



To Organize travel arrangements of floating staff as directed by Head fleet personnel.

To Assist the Head fleet personnel as directed by him.





3.2.3 REQUIRED LEVEL OF COMPETENCY FOR SHORE STAFF.



3.3 RESOURCES FOR DESIGNATED PERSON



The company shall be responsible for ensuring that adequate resources, hardware, human resources and

shore based support are provided to enable the designated person or persons to carry out their functions.

(Refer Manual CPM 15).