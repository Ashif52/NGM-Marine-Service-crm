



14. INTERIM CERTIFICATION



14.1 INTERIM DOCUMENT OF COMPLIANCE



When the company takes over a new type of vessel, it shall apply for an interim DOC from DGS. An

interim DOC may be issued following verification that the company has a SMS that meets the objectives

of the ISM code, provided the company demonstrates plans to implement a SMS meeting the full

requirements of the ISM code within the period of validity of the Interim DOC. A copy of the Interim

DOC should be placed on board in order that the master of the ship, may produce it for verification by

DGS/ MMD/RO. In this regard, the company shall be guided by the ISM circulars and other guidelines

issued by DGS from time to time.



14.2 INTERIM SAFETY MANAGEMENT CERTIFICATE



When the company takes new delivery from yard, or a ship new to the company or whenever the

company’s ship changes its flag, the company shall apply for interim SMC from DGS. An interim SMC

may be issued following verification that the ship has a SMS that meets the objectives of the ISM code.

The original Interim SMC should be placed on board in order that the master may produce it for

verification by DGS/ MMD/ IRS.



14.3 EXTENSION OF VALIDITY OF SMC



In extreme cases where the validity of the interim SMC needs to be extended, the company may request

DGS for extension.



14.4 ISSUANCE OF INTERIM SAFETY MANAGEMENT CERTIFICATE



An Interim Safety Management Certificate may be issued following verification that:

the DOC, or the Interim DOC, is relevant to the ship concerned;

the SMS provided by the Company for the ship concerned includes key elements of this Code and

has been assessed during the audit for issuance of the DOC or demonstrated for issuance of the

Interim DOC;

the Company has planned the internal audit of the ship within three months;

the master and officers are familiar with the SMS and the planned arrangements for its

implementation;

instructions, which have been identified as being essential, are provided prior to sailing;

and relevant information on the SMS has been given in a working language or languages understood

by the ship’s personnel.