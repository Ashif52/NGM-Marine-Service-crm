



10. MAINTENANCE OF THE SHIP AND EQUIPMENT



10.1 PROCEDURE FOR MAINTENANCE



10.1.1 The Company has developed procedures (Refer manual FPM 05 and 11) to ensure that the

vessel is maintained in accordance with relevant rules and regulations. The company has also

developed a Planned Maintenance System that will ensure that vessels are maintained in ship shape

and in compliance with all relevant rules, regulations, codes and guidelines. The PMS shall integrate

the regulatory requirements and the manufacturers’ operational instructions/ maintenance guidelines.

Officers are designated for ensuring that scheduled maintenance and repairs are performed according

to the Planned Maintenance Schedules provided by the Company. Procedures for implementing the

PMS are documented in manual FPM 05.



10.1.2 Machinery and equipment shall be maintained on a routine basis and in accordance

with OEM recommendations. Where such data is not available, the Company has developed procedure

to ensure that the machinery or equipment is maintained to highest standards, in accordance with

a ship specific Planned Maintenance System.



10.1.3 In carrying the maintenance and developing the PMS, the following is taken into consideration:

The maintenance recommendations and specifications of the equipment manufacturer;

The results of third party inspections

The age of the ship;

Identified critical equipment or systems.

The history of the equipment including failures, defects and damage and the corresponding

remedial   action.

The consequences of the failure of the equipment on the safe operation of the ship.



10.1.4 The Planned maintenance would cover and consider the following:

The Maintenance Intervals including lubricating Oil renewal as OEM or analysis every 6 months.

The Definition of The Methods and Frequency Of Inspection.

The Specification Of the type Of Inspection and Measuring Equipment to be used and the

Accuracy required Of it;

The Establishment of Appropriate Acceptance Criteria (Pass/Fail);

The Assignment of Responsibility for Inspection Activities To Appropriately Qualified Personnel:

The Assignment of Responsibility for Maintenance Activities To Appropriately Qualified Personnel;

The Clear Definition of Reporting Requirements and Mechanisms.



10.1.5 As a part of the maintenance structure, the following records shall be maintained onboard.



10.1.5.1 INTERNALLY GENERATED RECORDS:



Records of routine inspection and maintenance work carried out (Refer manual FPMF 05-10)

Records of the testing of standby and other critical equipments (DECK/ ENG LOGBOOK)

Records of testing of alarms and emergency shut-downs (DECK/ ENG LOG BOOK)

Superintendent’s visit and ship inspection report (Refer manual CPMF 08-03)

Internal audit report and third party audit report (Refer manual CPMF 08-01)

Records of non conformities and hazardous occurrences/ accidents (Refer manual CPMF 06-01 & 08-02)

Records of the corrective action taken and preventive action, if any (Refer manual CPMF 06-01 & 08-02)

Records of stores/ spares requested and received (Refer manual CPMF 05-01).







10.1.5.2 EXTERNAL GENERATED RECORDS:



Class generated records, reports and certificates.

Statutory survey records, reports and certificates

Flag state/ port state control inspection reports

Report of vetting organizations.



10.2 INSPECTIONS AT APPROPRIATE INTERVALS, REPORTS OF NC & CA RECORDS



10.2.1 The Company has established procedures to ensure that the superintendent perform inspections

in order to monitor the condition of ships for compliance with rules and regulations and ensure

maintenance of the condition of the vessel in between surveys. Technical Superintendent reviews the

monthly PMS

reports from the vessels. They will also visit on board the vessel at once in six months and will review to

verify if all the maintenance systems are being followed and report to the Company management,

on the condition of the vessel & improvements required. (Refer manual FPM 05.)



10.2.2 Non-conformity/ deficiency noted during inspections and found during the course of

normal maintenance are also documented and reported to the DPA. ( Refer manual FPM 05 and CPM 06.)



10.2.3 For the non-conformities noted as above, appropriate corrective action shall be taken within the

target date and the non-conformities shall be closed. This shall be reported to the DPA. In case an

immediate action cannot be taken, the DPA is informed about the same and the target date shall be

noted accordingly. Refer manual CPM 07.



10.2.4 Appropriate records shall be maintained for the above mentioned inspection, non-conformity,

corrective actions etc.



10.3 PROCEDURES FOR EQUIPMENT AND SYSTEMS, MEASURES TO PROMOTE RELIABILITY



10.3.1 The company has identified equipment and technical systems, the sudden operational failure of which may result in a hazardous situation. The Company has taken specific measures to promote the reliability of such equipment and technical systems by a program of planned maintenance and,

where appropriate, regular operational testing of stand-by arrangements. (Refer manual FPM 05 for the list of critical equipment & technical systems which are tested as part of Saturday routines).



10.3.2 Breakdown of critical vessel’s machinery, unplanned machinery failure or replacement of

machinery parts prior to projected maintenance frequency are considered as non-conformities. These

failures and associated repairs are reported to the company along with the possible causes, if known.

Where appropriate, analysis of such unplanned events may result in changes to the vessel’s

planned maintenance system in order to preclude re-occurrence of similar failures.



10.3.3 In the event of the breakdown of equipment or a system, the chief engineer may recommend a change in the maintenance and inspection requirements of the Planned Maintenance System to the

Company. Appropriate corrective action is then taken in order to prevent a reoccurrence of the

breakdown. Refer manual FPM 05.











10.4 MAINTENANCE ROUTINE FOR CRITICAL EQUIPMENT



10.4.1 Breakdowns of Vessel’s critical machinery are considered non-conformities and are reported

to the company. The repairs are carried out at the earliest. Procedures have been prepared for weekly

testing of critical systems and the recording of results. Breakdowns of machinery where appropriate,

may result in changes to the Vessel’s Preventive Maintenance System in order to prevent reoccurrence

of similar breakdowns. Refer manual FPM 05.