

11. DOCUMENTATION



11.1 PROCEDURES FOR SMS DOCUMENT CONTROL



11.1.1 The Company has established procedures regarding control of records and document

(Ref. manual CPM 02), data control (Ref. manual CPM 03) that relate to the SMS both ashore and

afloat. All pages of Master copy will be signed by Managing Director. Prior doing any revision in SMS

document, the DPA has to take concurrence from Managing Director. The new revision will be filled in

master copy with signature of Managing Director and obsolete copy will be removed and filled for any

future records or for audit inspection. Changes made to the controlled documents shall be informed to

all copy holders by DTN and their acknowledgement for changes noted are filled in DTN file.

Records of all SMS related activities shall be kept on vessels or ashore as defined in each of the

relevant procedures.



11.1.2 Control of Internally generated documentation ensures that:

Documentation is reviewed for adequacy prior to issue;

Documentation is approved by a proper authority prior to issue;

Documentation is uniquely identified and user friendly.

Documents are capable of being revised/ updated in an orderly manner;

Initial issues and revisions to documentation are issued to assigned document holders;

Document holders are assigned in such a way that documents are available at locations where they

are required and used;

Obsolete documents are removed from points of use when  or deleted from the system;

Revisions to documents are subject to the same review and approval procedures as the original

version.  Review and approval of revised documents is performed by the same persons or functions

as the original document.



11.1.3 Externally generated documents like navigation charts, mandatory statutory rules and

conventions, ship’s plans, maintenance and operation manuals of equipments, industry guidelines are

updated and maintained by the Master. The publications containing the rules and regulations shall be

tracked by the Vice President/ DPA. He shall ensure that the updated publications are available at office

and on board vessels.



11.1.4 A master list of both internal and external documents will be maintained ashore as well as on

board the vessel.



11.2 VALID DOCUMENTS AVAILABLE AT LOCATION



11.2.1 The DPA shall issue the SMS Manuals to the Controlled Copy Holders, who shall be responsible

for the updating of same and for making the manuals available at their appropriate locations.



11.2.2 The Vice President is responsible for the distribution of externally controlled documents to the

Master. The Master shall be responsible for making the documents available at their appropriate locations.



11.3 SHIP SPECIFIC DOCUMENTATION



The documents used to describe and implement the SMS are referred to as the Safety Management

Manual. The manuals are issued and maintained as controlled hard copies. All the controlled documents

and the Forms and checklists issued shall not be allowed for any modification except done by DPA. The

Forms and Checklists are allowed for photocopying and for preparing records. The forms and checklists

shall also be available as soft copies on board with latest revision. Each ship shall carry on board

all documentation relevant to the ships specific.