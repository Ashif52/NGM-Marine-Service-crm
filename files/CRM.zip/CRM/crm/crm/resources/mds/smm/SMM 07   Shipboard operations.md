



7.   SHIPBOARD OPERATIONS



7.1 KEY SHIPBOARD OPERATIONS



The Company has established procedures, plans and instructions, including checklists as appropriate,

for key shipboard operations concerning the safety of the personnel, ship and protection of the

environment. The various tasks are defined and assigned to qualified personnel.



7.1.1 Key shipboard operations are listed in manual (Refer manual FPM 06) which are common to most

of the type vessels. Some of the issues not common but specific to the type vessel are detailed in the

section of Fleet Procedure manual.



7.2 PROCEDURES FOR PREPARING PLANS, INSTRUCTIONS & CHECKLISTS



7.2.1 The plans and instructions for key shipboard operations have been developed based on the

traditional requirements of the type of vessel taking into consideration the relevant rules and regulations.



7.2.2 The need for additional instructions or the need for amending existing instructions is formally

identified through ship’s safety meetings and by management review, or by the identification of

non-conformities.



7.2.3 These plans and instructions shall be updated based on regulatory changes and operational

experience.



7.3 QUALIFICATION REQUIREMENTS FOR DEVELOPING PLANS



7.3.1 Procedures are best developed by the personnel who are involved in the operations and those

who have a reasonably good knowledge of the operations for the type of vessel. Among floating staff, it

shall be the Master or Chief Engineer and among shore staff, it shall be the Technical Superintendent or

the Vice President who may develop the plans and instructions.



7.3.2 The procedures are then reviewed by the DPA. He shall issue the procedure after approval

by the Managing Director as per manual (Refer manual CPM 03).



7.4 TASK IDENTIFIED AND ASSIGNED



While developing the plans and instructions, the tasks involved shall be identified and assigned to

qualified personnel. For the key shipboard operations that have been identified, the tasks have been

defined and assigned in manual (Refer manual FPM06).









