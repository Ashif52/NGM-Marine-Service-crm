



15. VERIFICATION



15.1 VERIFICATION AND CONTROL



The Company has established procedures to ensure that all verifications required by the provisions of ISM

Codes are carried out in accordance with procedures acceptable to DGS.



15.2 AUDITS AT SHORE OFFICE:



15.2.1 Verification audits at shore office are carried out by DG Shipping as under:

Renewal audit on completion of the full five years validity of the DOC. These audits are carried out with

in 3 months of the expiry of the certificate.  Audit needs to be completed before the expiry date of the

certificate.



15.2.2 The anniversary date for the annual verification is the expiry date of the certificate each year and

the annual audits have a window of +/- 3 months.



15.3 AUDITS ON BOARD SHIPS



15.3.1 The verification audits for SMC are carried out by the RO as per DGS and the renewal audits

are carried out before the expiry of the certificate. Audits can be carried out within 3 months of the

expiry date.



15.3.2 An Intermediate verification needs to be carried out between the second & third anniversary

date of the certificate.



15.4 ADDITIONAL AUDITS:



In addition to the above mandatory audits, additional audits are carried out at the instruction of the

flag state, in case of suspected failure of the SMS during the inspection of vessel by FSI/ PSC inspectors.



