

14. RISK ASSESSMENT AND HAZARD IDENTIFICATION



14.1 PURPOSE :The purpose of the procedure is to ensure that before carrying out operations on board,

the proposed relevant activities are subjected to a risk assessment. The risk assessment will identify the hazards

and detail the controls required to reduce the risks to a level which is as low as reasonably practicable.



14.2 SCOPE : The procedure defines the actions which will be taken to carry out a risk assessment for all

operational and task activities undertaken by personnel working on the vessels.



14.3 PRINCIPLES OF RISK ASSESSMENT



14.3.1 Risk assessment is intended to be a careful examination of what in the nature of operations that could

cause harm, so that decisions can be made as to whether enough precautions have been taken. The aim is

to minimize accidents and ill health on board.



14.3.2 The assessment should first establish the hazards that are present at the place of work and then identify

the significant risks arising out of the work activity. The assessment should include consideration of the

existing precautions to control the risks such as permit to work, restricted access, warning signs.



14.3.3 Any risk assessment must address risk to the health and safety of personnel and harm to vessel,

property, process and environment.



14.4 MAIN ELEMENTS OF RISK ASSESSMENT

14.4.1 A risk assessment process must involve the following:

Classifying different work activities associated with a task;

Identifying hazards for each work activity and the personnel at work;

Correctly determining the risk;

Deciding if risk is tolerable;

Preparing action plan (putting in place appropriate risk control measures);

Reviewing adequacy of action plan.



14.5 DEFINITIONS



14.6 RESPONSIBILITIES



14.6.1 MASTER :The Master shall ensure that appropriate risk management arrangements are implemented by

chief officer and chief engineer under their department.



14.6.2 CHIEF ENGINEER : The Chief Engineer shall ensure that appropriate risk management arrangements

are in place by the implementation of these procedures for all activities in the machinery spaces.



14.6.3 CHIEF OFFICER : The Chief Officer shall ensure that appropriate risk management arrangements are in

place by the implementation of these procedures for all activities in the deck and accommodation.



14.6.4 OTHER OFFICERS : The Chief Officer and Chief Engineer may delegate responsibility to other officers

and engineers; however they will be overall responsible for their respective Departments.







14.7 FORMAL RISK ASSESSMENT



14.7.1 The “Risk Assessment” Form has been developed to ensure a consistent approach to risk assessment.

The form shall be used for all activities .



14.7.2 The purpose of a risk assessment is to ensure that hazards are identified and controls put in place so that

the task is performed with risks which are tolerable.



14.7.3 At the end of a risk assessment it may be decided that the risk cannot be brought down to tolerable limits.

In this case the task must be abandoned or modified.



14.7.4 If the task is modified then a second risk assessment must be performed.

A fresh risk assessment will not be required to be made out for the same operation, provided the parameters taken

in the initial risk assessment have remained unchanged. In case of change (involving risk of a higher order) a

fresh risk assessment will have to be made.



14.7.5 As a general rule, the risk assessment process should involve as many relevant people as possible, to

ensure that all available expertise is used to identify the hazards and to decide the controls to be put in place.



14.7.6 “RISK ASSESSMENT INITIATED BY”

The signature and name of the person initiating the Risk Assessment should be recorded in the risk assessment

form. The person initiating the risk assessment should have a sound knowledge of:

controls in place and controls available;

task to be carried out;

hazards which may be present;

Conditions under which the activity will be performed.



14.7.7 Involvement of the staff when carrying out the risk assessment is of importance. When the staff realizes

and understands the hazards and the importance of taking appropriate risk control measures, the assessment will

be certainly meaningful.



14.8 HAZARD IDENTIFICATION



14.8.1 PURPOSE

The purpose of the procedure is to ensure that all observed hazards on board are reported as soon as they

are detected. Appropriate action can then be taken to mitigate the observed hazard.



14.8.2 SCOPE

The procedure defines the actions to be taken by personnel on the vessel after an observed hazard has been

reported



14.8.3 TYPE OF HAZARDS TO BE REPORTED



14.8.3.1Various types of hazards may be encountered on board. A hazard can be reported by any staff member

who observes:

an unsafe work practice being followed on board;

an unsafe work condition [e.g. a leaky hydraulic line on deck];

Anything that could lead to a hazardous occurrence.

Each observed hazard shall be reported on the standard Company form provided for the purpose.

14.8.3.2 RESPONSIBILITIES OF REPORTNG HAZARDS

Any staff member on board can initiate a report on observing a hazard. Each observed hazard shall be reported

On the standard Company form provided for the purpose.

14.8.3.3 ROLE OF VESSEL’S SAFETY OFFICER

The Chief Officer on board is the appointed vessel’s Safety Officer. The staff member reporting the hazard shall

hand-over the report to him. Chief Officer shall maintain complete confidentiality with respect to the originator

of the report.



14.8.3.4 ROLE OF THE MASTER

The Master shall verify the appropriateness of the corrective action before filing the Report.



14.9 THE PROCESS

STEP 1

Any staff member on board can initiate a report on observing a hazard and also suggest necessary corrective

action. The report shall be handed-over to the vessel’s Safety Officer.

STEP 2

The Safety Officer shall hand-over the report to the concerned Department, discuss and agree on the

proposed corrective action and obtain the time scale within which it will be completed. He will enter the time scale

on the report before handing it over to the concerned Department. (When the hazard pertains to his Department,

the Chief Officer shall enter the time scale and take the corrective action within that period). Once the

corrective action has been taken it shall be duly entered and the completed form shall be returned to the

Safety Officer.

STEP 3

Once the form has been returned to the Safety Officer he shall check that the corrective action has been taken

as envisaged and the report shall be signed by the Safety Officer and shown to the Master. Thereafter the Master

shall verify the appropriateness of the corrective action before signing and filing the report on board. In case

the corrective action is not to the satisfaction of the Master, he may order the concerned Department to take

further corrective action within a reasonable time frame and make an appropriate entry on the report. On

completion of the corrective action to the satisfaction of the Master, the report shall be signed by him and filed.



14.10 GENERAL



14.10.1 Sufficient stock of the Company’s Hazard Reporting form shall be maintained in the vessel’s mess

room(s) so that any individual on board, desirous of reporting a hazard, can do so. He shall hand-over the report

to the vessel’s Safety Officer. The success of this system to a large extent depends on the Safety Officer

maintaining the confidentiality of the person reporting the hazard.



14.10.2 No copies of the Hazard Reporting form are to be dispatched to the Office, except in case of those

forms where the time scale for closing out the hazard have expired. During Safety meetings the Master

shall encourage staff to report all observed hazards. The Superintendents and Internal Auditors shall routinely

sight the records to check that the Hazard Reporting System is functioning effectively on board.

14.11 IDENTIFICATION OF WORK ACTIVITIES

14.11.1 Following shipboard activities shall be assessed for risk

Entering enclosed space.

Working over side, working aloft.

Cold work- e.g. blanking / de-blanking, connecting & disconnecting pipe work etc….

Work on pumps.

Working on electric equipment and circuits.

Entering in cargo hold loaded with cargo.

Hot work outside engine room workshop.

Shut down or malfunctioning of critical equipment.

Use of critical equipment for which maintenance is overdue as per PMS.

Risk assessment for any management of change.

Before performing any activity which may result in deviating from procedure laid in SMS.

Anchoring within area of strong winds and current.

Significant Safety deficiencies that cannot be rectified by vessel staff shall be assessed for risk in detail.



14.12 EXISTING CONTROLS AND SAFEGUARDS



14.12.1 Existing control measure is a part of risk mitigation. Each of identified hazards shall now be linked with

the control measures and safeguards presently available on board.  The decision of existing control measures

is implemented on a job to job basis by the management, heads of department and operations.

14.12.2 For example, in case of enclosed space entry, existing control measure for hazard against lack of oxygen

is as follows:

To follow the enclosed space entry procedure as described in SMS.

To fill up Enclosed Space Entry Permit, so that all parameters are in the safe limits as prescribed by law.

The Tools for existing control measures during any operation include:

Company procedures, charterers instructions, port regulations, industry regulations and guidelines.

Use of checklists, permit to work system etc.

Minimum level of training of personnel.

Adequate number of personnel involved.

Appropriate design and construction.

Weather envelopes, i.e. maximum wind speed, requirement of good visibility or dry day.

Protection and detection control system ( e.g. Inert gas system, Fixed gas detection system etc. )

Planned maintenance.

Communication and language requirements.

Use of proper equipments.

Additional Control Measures

Based on the outcome of a risk assessment of existing control measures, an additional control measures

may be required to mitigate the risk further.

Work Activity- Enclosed space entry to ballast tank,

Hazard associated with activity (one of the hazard) - Sudden break down of illumination in tank which may

result in panic among crew inside a tank.

Consequence- Personal injury

Existing Control Measures and safeguard

To carry hand held torch by the persons entering in enclosed space.

To have illumination in tank.

The additional control measure to further mitigate the risk associated with panic caused due to break down of illumination in ballast tank could be as follows

. Installing more lights in tank to mitigate the hazard arising due to failure of illumination.

. To make entry in tank during day light

. To keep all the manhole open to have more light in tank.

. To carry out briefing to crew-members regarding the lay out of tank structure.

.  Additional training and briefing on enclosed space entry.

.  Sending those crew members who have previous experience of entering into ballast tank.

As guidance on selecting appropriate additional controls, the following shall be considered for minimizing

the harmful effects of exposure to a hazard:

. Remove or eliminate the hazard, i.e., combat the risk at source. This generally applies to environmental

hazards such as noise, heat, cold, dust, smoke etc.

. Contain the hazard, i.e. erect guard or barriers. Dedicated locations for harmful or dangerous substances.

. Use technology to monitor the hazard i.e. gas detector, oxygen analyzer.

. Adapt the individual to work, i.e. train on the use of equipment or control system. Language

and communication requirements, physical and mental suitability.

Personal protective equipment: This is often viewed as a last resort,

Accepting the hazard as all other control options have been considered.

Emergency response: Should controls fail and the hazard manifest itself into an accident the only way

to minimize the consequences is the speed and efficiency of emergency response.

Re-design and re-equip: In many instances, controls are put in place to protect the individual from the risks

in bad design or bad and faulty equipment or machinery.

Duplication of equipment

Providing additional crew and officers on board.

Health and safety

These two topics are inseparable. The OOW must not only look after his own health and safety, but also of all

those working on board. High standards of personal cleanliness and hygiene should be maintained. Those handling

oil-based products should wash all parts of their skin thoroughly with soap or approved cleansers after

completing work.  Paint remover, other chemicals must NEVER be used as skin cleansers.  Cargo spills should

be washed off skin and clothing. Cuts and abrasions should be cleaned at once, and first aid treatment given

to protect against infection.  Water and salt intake should be increased if the temperature and humidity in port

are high. Any infestation of rats, rodents and insects should be reported to the Master, and remedial action

instigated. All ship’s personnel should keep up to date with all relevant vaccinations.







14.13.1  Safe access

IT IS OF PARAMOUNT IMPORTANCE THAT A SAFE MEANS OF ACCESS BETWEEN THE SHIP AND THE SHORE

IS MAINTAINED AT ALL TIMES. This is a legal requirement in all ports of the world.

Ship’s gangway

The gangway must be clean and undamaged with no missing stanchions.

Safety rails, or ropes, must be taught at all times.

The bottom platform must be level, and fitted with stanchions and the safety ropes.

The safety net must extend from one meter on board the ship from the top of the gangway to the

extremity of the bottom platform on the quay, and encircle the entire gangway from the top of the

outboard rail rope to the ship’s side.  DO NOT make any part of the net fast to the quay.

There must be a lifebuoy with a heaving line, floating quiet, and self-igniting light positioned at the top of

the gangway.

The gangway must be fully illuminated at night.

A ship’s watchman should be in attendance at all times - even if shore security are employed.

The MAXIMUM number of persons permitted on the gangway at any one time must never be exceeded.

The OOW needs to pay extra attention to this requirement at the change of shift or stevedores.  This

number should be prominently displayed on the gangway, as an indication of its Safe working load.

Special attention should be paid when large shore cargo-handling equipment, such as gantries, are

moving along the quay close to the gangway, and may damage it if there is a collision. Continuous

supervision is necessary if the gangway cannot be landed on the quay, and has to be left suspended

on its wires.

It is useful to display a notice at the foot of the gangway warning that, it is liable to sudden movement.

Other notices often displayed at the gangway include `No Unauthorized Visitors’,  `No Smoking’, the times

of high and low water, and the times of sailing and expiry of shore leave.

It is recommended that the means of access should be situated clear of the cargo working area, and that

no suspended load passes over it.



Shore gangway : If a shore gangway is provided, the OOW must ensure that the safety points are fully

complied with. This includes cases when the means of access is part of the shore cargo-handling equipments.

The stevedores must NOT be allowed to lower this ladder only upon demand, just because it makes his job

easier when he continually moves the ladder along the quay.  The OOW must stress to him that a safe means

of access must be CONTINUOUSLY available.

Safe access around the ship : The requirement to provide a safe means of access is not limited to the gangway.

All decks, walkways, ladder, and other accesses around the decks and within the cargo compartments must be

in a safe condition, which means

Clearly marked

Unobstructed (cargo, dunnage, leads from lashings, etc.)

Undamaged

Clean (free from oil and grease),

Fitted with safety rails / ropes where appropriate

Illuminated at night

Any hazards must be highlighted.

The OOW must be constantly on the lookout for unsafe accesses as he patrols  the decks.  Ice, dust on top of

dew, and any spills of oil, grease and cargo can be very slippery and could lead to trips and slips.  They must

be removed as soon as they are noticed.  Hardened ice may be melted with rock-salt, or its surface made safe

with a coating of sand or grit.  If the hazard cannot be removed, access to the area should be prevented by roping

off and erecting appropriate warning signs.



The doors or lids of accesses to the holds must be either closed or secured open with toggle pins, and an adequate handrail must be located adjacent to assist people between the hold ladder and the deck.





FORMSIN USE

FPMF – 14 – 01 RISK ASSESSMENT FORM

FPMF – 14 – 02 HARZARD IDENTIFICATION FORM

