

5.   PREVENTIVE MAINTENANCE



5.1 INTRODUCTION - GENERAL REQUIREMENT



5.1.1 Vessels are exposed to tough and demanding marine environmental conditions. In order to remain

seaworthy, safe and efficient throughout operational life, they must be properly maintained.



5.1.2 This chapter contains guidelines and information to Masters, Chief Engineer and other vessel crew and

officers involved in maintenance of hull, systems and equipment onboard.



5.1.3 It is company’s policy to maintain all vessels in best operational condition. In order to implement this

policy, preventive maintenance guidelines must be followed and all information recorded and reported for follow

up purposes.



5.2 GOOD MAINTENANCE REQUIREMENTS: Good maintenance requires:-

Owners must be prepared to pay reasonable, justified costs and provide support of ship-based

management of resources (means and manpower).

Planning and Competent and reliable suppliers (services, spare parts and stores).



5.3 MAINTENANCE PLANNING (PMS):- Maintenance planning requires:-

Master and C/Engineer must indicate lists of maintenance to be carried out to the Deck Officers/

Engineer Officers. Setting priorities (most important must be taken care first).

Confirming requirements (all necessary tools, spares and consumable are onboard) and making

requirements realistic (estimates of stores and spare parts required).

Setting realistic goals and planning task (have a clear idea of how work is to be done)

Confirming readiness of equipment to be used

A PMS is developed by each vessel based on the specific machinery requirements including the following

factors which are to be considered. Then the PMS for the specific vessel is approved by the company

for the ships staff to be followed

The Maintenance Recommendations and Specifications of the Equipment Manufacturer

The Results of Third-Party Inspections

The Age of the Ship

Identified Critical Equipment or Systems

History of Equipment Including Failures, Defects and Damage, and its Remedial Action.

The Consequences of the failure of the equipment on the safe operation of the ship

Maintenance which requires generic maintenance plan is developed by the office.

Routine Maintenance of LSA/FFA items

All maintenance schedule/plan has to be followed by the Chief engineer and the chief officer and reported

to the office about the status of the implementation of the plan.



5.4	CRITICAL SYSTEMS

The Company's maintenance objective is to protect the asset value whilst trading the vessel in a manner

consistent with the declared intentions of the Company Policy on Safety and Environmental Protection.



5.4.1	PLANNING

Plans are formulated for shipboard maintenance as per the OEM recommendations, time elapsed since last

overhaul basis, or periodic with information referred to Head Office on a monthly basis through the “Monthly

Reports, generated from the PMS and other company forms”. The Company has identified equipment

and technical systems, the sudden operational failure of which may result in hazardous situations.



5.4.2	Equipment and systems identified (As Applicable on board) for programmed testing is as follows: -

Main Engine

Emergency Generator

Emergency Fire Pump

Emergency Air Compressor

Lifeboat  / Rescue Boat

Navigational Lights



The testing, checks and maintenance of the above mentioned equipment and systems are covered under the

Planned Maintenance System (PMS), in the Monthly Work done Reports.

he Company shall keep minimum spares required for the critical equipments as specified in form number

FPMF 05-14 as applicable and also endeavor to source as required when consumed.



5.4.3 Results are recorded in deck & engine log books respectively. In the event of the breakdown of equipment

or a system, the Master/chief engineer may recommend a change in the maintenance and inspection

requirements of the Planned Maintenance System to the Company. Appropriate corrective action is then

taken in order to prevent a reoccurrence of the breakdown.



5.5 MANAGEMENT OF SPARE PARTS : -Spare parts management requires:-

Maintaining adequate stocks of spare parts onboard, as soon as spares are used replacements

must be requested. All spares maintained/stored with the 2nd engineer

Requesting for spare parts - Requisitions should include, information of part number, name of item,

machinery details, number of items required and other details

Proper identification, receipt inspection, segregation (if required) and storage

Record keeping (inventory control) (FPMF - 05-15)

Re-conditioning of spare parts : Some items is suitable for re-conditioning.



5.6 RESPONSIBILITIES

This section contains departmental responsibilities relevant to shipboard maintenance. Vessel’s management

is expected to ensure that all shipboard maintenance is conducted and completed in a safe, timely and cost

effective fashion.



5.6.1 MASTER’S RESPONSIBILITIES

Master must ensure following that the Condition and overall appearance of vessel and her systems/equipment

must be kept as high as practically possible. This can be achieved through careful planning proper and

safe maintenance. He is also responsible for maintenance of spaces and equipment assigned to Deck Department

are properly planned and carried out which he may delegate to any of the Mates.



5.6.1.1 DECK DEPARTMENT: GENERAL

a.  Emergency equipment except that which is specifically assigned to Chief Engineer

b.  Life-saving and fire fighting equipment

c.  Deck house interiors

d. Gangways Passageways and accommodation spaces

e.  Master is responsible for intimating the quantity of Paints required for the vessel to the Technical

Superintendent

f.  Under the direction of Master and Chief Officer, the Deck hands ensure that all mechanical and

operational deficiencies, including those relevant to propulsion, ballast handling, cargo operation and

auxiliary equipment are promptly reported to Chief Engineer. Furthermore, work required in Deck

Department spaces is to be performed under direction of the Master or Chief Officer, who works closely

with Chief Engineer to carry out required vessel maintenance



5.6.1.2 DECK DEPARTMENT - HULL MAINTENANCE/PAINT WORK

5.6.1.2.1 When vessel is in port or at anchorage, every opportunity must be taken to carry out

preventive maintenance and paintwork of hull (accessible areas). Scaling should be carried out where necessary

and only where allowed by safety and harbor regulation

5.6.1.2.2 Painting is considered as an integral part of maintenance, serving purposes of appearance and

protection of steel surfaces. Under no circumstances shall colors or finish of painted surfaces be altered without

prior justification to and permission from company.

5.6.1.3 DECK DEPARTMENT - WINDLASSES-ANCHOR AND ANCHOR CHAIN INSPECTIONS

Anchor, shackles and swivels are regularly inspected to check for possible damage and ensure that all pins

are properly in place.

Chain should be checked whenever possible to ensure that lead and spile pin are in place on joining

shackles and cable studs are secure.

All identified defects are brought to immediate attention of the Technical Department.





5.6.2 ENGINEERING DEPARTMENT: RESPONSIBILITIES OF CHIEF ENGINEER:-



5.6.2.1 Under direction of Chief Engineer, Engine Department has overall responsibility for sound

mechanical condition and safe operation of deck and engine machinery, including, but not limited to, following:

Propulsion system

Power generating system

Deck equipment e.g. winches, windlasses, cargo gears and cargo pumps etc.

C/Engineer ensures all plant operating data is regularly and properly recorded in Engine Log Books.



5.6.2.2 MAINTENANCE AND INSPECTION

The Chief Engineer with the second engineer carries out maintenance and inspection of the

vessel periodically. The Technical Superintendent monitors the operation.



5.6.2.3 The Engine room staff shall monitor the performance of the Engine machinery and shall use the

following formats:

FPMF – 05 - 01 - monthly consumption and machinery running hours

FPMF – 05 - 02 – main engine cylinder liner calibration

FPMF – 05 - 03 - main engine de carb report

FPMF – 05 - 04 - aux engines de carb reports

FPMF - 05 - 05 – main engine bearing inspection report

FPMF – 05 - 06 – Machinery overhaul report

FPMF – 05 - 07 – crank shaft deflection report

FPMF – 05 - 08 – class survey report

FPMF – 05 - 09 – Megger test report

FPMF – 05 - 10 – work done report by deck, engine and electrical

FPMF – 05 - 11 – Lube oil and bunker sample report

FPMF – 05 - 12 – Engine log Abstract

FPMF – 05 - 13 – Deck, Electrical and Engine Room Defect list

FPMF – 05 - 14 – Monthly Critical Spares Report

FPMF – 05 - 15 – Quarterly Stores / Spares Report



5.7 The Technical superintendent shall inspect the vessel once in Six Months and shall record the results in

CPMF 08-03. In case of non-conformities, same to be reported in the non-conformity report CPMF 06-02.



5.8 PREVENTIVE PLANNED MAINTENANCE OF THE COMPANY

The Master and the Chief Engineer of each vessel have been designated for carrying out the preventive

maintenance schedules as indicated by the Vice President who keeps a track of the PMS of the company

and is monitored by them from time to time in the office in their computers. They are assisted by the ship’s

staff and wherever required by additional resources, manpower from shore. They are also responsible for

carrying out regular inspections to confirm that the preventive maintenance schedules are being followed as

planned. The requirement of spares to carry out the maintenance is to be forwarded to the office well in advance

by the ship’s staff and well coordinated by the Shore staff (office).

The respective officer should ensure that the quarterly inventory control of stores and spares are maintained

and recorded as per FPMF–05-15. The departmental head should verify the records to ensure that the consumed

and received stores and spares are updated as required. The Master and Chief Engineer should ensure

the effectiveness of quarterly inventory control and its transmission to office every quarter.



5.9 RECORDS

FPMF – 05-10 – WORK DONE REPORT BY DECK, ENGINE & ELECTRICAL

FPMF – 05-13 – DECK DEFECT LIST OF DECK, ENGINE & ELECTRICAL

FPMF – 05-15 - QUARTERLY STORES / SPARES REPORT