

9. POLLUTION PREVENTION PROCEDURES



9.1 GENERAL REQUIREMENT

All vessels are required to comply with all pollution prevention rules and regulations



9.2 RESPONSIBILITY

Master is responsible for operating vessel with due regard to environmental protection.



9.3 TRAINING OF CREW



9.3.1 Master ensures that all crew members involved in the following operations are familiar with

MARPOL regulations. Master shall ensure that the persons receive proper training as required.

Ballast or bunker operations

Bilge, garbage disposal

Cargo operation



9.4 OIL RECORD BOOK



9.4.1 All Cargo operation, bunker and bilge handling operations are recorded in the oil record Book.

Particular attention is paid to ensuring that times; quantities and vessel positions are accurately entered

where required.

9.4.2 Chief Engineer is responsible for Engine Room Oil Record Book (Part I) and Chief Officer is responsible

for Cargo Oil Record Book ( Part II). MARPOL 73/78 provides details concerning the type of entries to be

recorded in this book Refer Appendix I to Annex III (Form of Oil Record Book).



9.5 ABSORBANT MATERIAL AND TOOLS:  Refer  SOPEP Manual and SMPEP for details.



9.6 GARBAGE AND WASTE-GARBAGE DISPOSAL MANAGEMENT



9.6.1 To comply with the requirements of Regulation 9 of Annex V of MARPOL 73/78, the following

Garbage Management Plan has been prepared for the Company vessels.

9.6.2 All the company’s vessels shall display placards, which notify the crew requirements of Regulations

3 and 5 as applicable to the vessel.

9.6.3 Although discharge at sea, (except in special areas) of a wide range of ship-generated garbage is

permitted outside specified distances from the nearest land, it is recommended that whenever practicable

ships use as a primary means, port reception facilities.



9.6.4 RESPONSIBILITY



9.6.4.1 The chief officer shall be responsible for implementing the garbage management plan. He is shall

ensure that the procedures within the plan are implemented.



9.6.4.2 He shall make the prescribed entries for each discharge operation in the Garbage Record Book. The

Chief Engineer other Crew are responsible for providing support to him. Such support is necessary for

collection, separation and processing of the garbage. Representatives from each department may be appointed

for this purpose.



9.6.5 PROCEDURE



9.6.5.1 The Company’s policy for its vessels disposal is possible consistent with Marpol Annex requirement.



9.6.5.2 Following guidelines shall be used for the procedures to be followed:

Collection: Receptacle shall be provided for galley and Engine room. These receptacles shall be

marked accordingly. Crew shall be advised of appropriate use of these receptacles. Responsibilities shall

be assigned for their collection or emptying and taking the garbage to the appropriate processing or

collection location.





9.6.5.3 Guidance for separate receptacles: Processing: If there is no compactor, commixture or incinerator

on board, no garbage processing is done on board other than segregation and packing in the garbage

bags provided to each vessel.



9.6.6 DISPOSAL

Although disposal is possible consistent with Annex, discharge of garbage to port reception facilities should

be given first priority.



9.6.7 TRAINING

Training should be provided to all crew members that are involved in handling and disposing of garbage as

part of their operational responsibilities



9.6.8 RECORDS



9.6.8.1 Company vessels are provided with a Garbage Record Book ( Part I & II) in the specified format

which shall be duly filled by chief officer.



9.6.8.2 Each garbage discharge operation shall be recorded in the Garbage Record Book and signed for on

the date of the discharge by the Chief Officer.



9.6.8.3 The Master of the ship shall sign each completed page. The Garbage Record Book shall be kept on

board ready for inspection for a period of two years after the last entry is made on the record. A copy will be

send to Head of operation to upload in website informing the approved agent for collection in respective port.



9.7 NOXIOUS LIQUID SUBSTANCES : Every ship to which Annex II applies is required to maintain a

Cargo Record Book where entries are to be made on tank to tank basis for all operation involving Noxious

liquid substances as P & A manual. The cargo record book, Oil record book and ODME print outs shall

be maintained for at least 3 years. All Officers in charge of the cleaning of cargo tanks and discharge of

residues and mixtures from these operations are to consult MARPOL 73/78 and its Amendments.



9.8 SEWAGE : The discharge of sewage into the sea is covered by Annex IV of MARPOL. To control pollution

from this source, vessel shall ensure that discharge of sewage are through approved treatment plant or stored

in holding tanks and discharged through in an approved manner in compliance with MARPOL Regulation.



9.9  DANGEROUS GOODS : Annex III of MARPOL 73/78 covers pollution by harmful substances carried

in packaged form and Chapter VI of SOLAS contains requirement for carriage of dangerous goods by sea.

Certain chemicals and other substances used in the operation of ships including paints, detergents, cleaning

fluids and additives are harmful to the environment. Master shall ensure that these harmful chemicals used

on board are stowed, handled and disposed of in an environmentally responsible manner.



9.10  BALLAST WATER :  The Control and management of ballast water is an effective method to minimize

the transfer of harmful aquatic micro organism and pathogen. The Master shall follow the procedures

and guidelines contained in approved Ballast Water Management Plan ( As applicable).



9.11  CARGO VAPOUR EMISSIONS : Emission of volatile organic compound will lead to the formation

of photochemical oxidants which causes damage to crops and forest. Measures to limit VOC emissions from Oil

and Chemical tankers are set out in Annex VI of MARPOL 73/78. The Master shall ensure that the release of

cargo vapour and inert gas into atmosphere is minimized.



9.12    ENGINE EXHAUST EMISSIONS : The main exhaust emission pollutants are nitrogen oxide,

carbon dioxide and un burnt hydrocarbon particles which are potentially damaging the environment. Annex

VI of MARPOL 73/78 covers emissions of Nox, Sox, ODS, VOC, shipboard incineration and associated

discharge of waste.