

11.COMPLIANCE WITH RULES REGULATIONS CODES AND CLASSIFICATION/FLAG STATE

REQUIREMENTS



11.1 UNDERSTANDING OF AND COMPLIANCE



11.1.1 SOLAS

SOLAS covers a wide range of measures designed to improve the safety of shipping. It covers regulations

involving ship construction, fire protection, fire detection and fire extinction, life saving appliances and

arrangements, radio communications, safety of navigation, carriage of cargoes & dangerous goods, nuclear

ships, management for the safe operation of ships etc.



11.1.2 MARPOL

The International convention for the prevention of pollution from ships, widely known as the MARPOL Convention,

was adopted in 1973. These cover pollution of the sea by oil, by noxious liquid substances in bulk, by

harmful substances carried by sea in packaged form, by sewage from ships, by ballast water and by garbage

from ships. Annex VI was adopted by a further protocol in 1997; it covers air pollution from ships.



11.1.3 LOADLINE CONVENTION

The international convention on Load Lines, 1966 was adopted by the International conference on Loadlines on

5th April 1966 and entered into force on 21st July 1968. It has since been amended by means of various

assembly resolutions. It establishes uniform principles and rules with respect to the limits to which ships

on international voyages may be loaded having regard to the need for safeguarding life and property at sea.



11.1.4 STCW

The international convention on the Standards of Training, Certification and watch keeping for seafarers, 1978,

as amended in 1995, 1997 and 2010 (Manila Amendments). This code also provides guidance to assist those

involved in educating, training or assessing the competence of seafarers or who are otherwise involved in

applying STCW convention provisions. The intent of the convention is to give full and complete effect to the

minimum global standards of knowledge, understanding, experience and professional competence.



11.2 SURVEY AND INSPECTION PREPARATIONS:

11.2.1 GENERAL

11.2.1.1 It is the responsibility of the Master and Officers alike to keep the vessel in seaworthy and well-

maintained state for carrying out inspection at all times.



11.2.1.2 The following basic guidelines are suggested while a survey/inspection is underway:

Never leave the Inspector/Surveyor unattended.  He needs guidance in conducting his inspection.

Be courteous and refrain from getting into an argument over any particular finding where views differ.



11.2.2 PREPARATIONS

11.2.2.1 A request for survey by the ship should be sent sufficiently in advance to the Technical

Superintendent, listing the items/certificates being offered for inspection, with the proposed port of inspection.



11.2.2.2 All equipment and records must be in order and appropriate checks completed beforehand.



11.2.2.3 If deficiencies/defects noted cannot be immediately rectified, the Technical Superintendent is

to be immediately informed. The viability of the inspection/survey will then be decided.



11.2.2.4 All statutory surveys are carried by the DG shipping or by RO nominated by DGS. At all times the

certificates should be valid and in case of any deficiency noted should be intimated to the office.

11.2.3 DEFECTS: All defects found must be promptly rectified to prevent the Flag State Authority from

invalidating the Certificate.



11.3 CERTIFICATE OF CLASS (HULL & MACHINERY) CLASSIFICATION:

Classification societies are agencies that provide a specified standard of ship construction and equipment.

Their standards allow insurers to set premiums based on the ship being classed.



11.3.1 REQUIREMENTS

To be placed on a society register as Classed, a new building must have the classification society present at the

design and construction stage.  They will monitor every stage of the new building to ensure that materials used

and methods of construction and design features, etc., meet the society rules. This process is known as “ Built

under Special Survey.”



11.3.2 REQUIREMENTS TO CONTINUE IN CLASS

Once placed on the register of classed ships, there are periodic inspections required for a ship to remain in class.

The frequency of these inspections depends on the requirements of Classed Society.



11.3.3 OUT OF CLASS

In much the same way as a ship’s statutory certificates can be withdrawn or invalidated, so can a ship’s

Certificate of Class, whenever the ship fails to comply with society rules.



11.3.4 INTERIM CERTIFICATE OF CLASS

If a ship suffers damage that cannot immediately be permanently repaired, the classification society may,

after inspection of the damaged area, permit a temporary repair to be effected and issue an Interim Certificate

of Class. This interim certificate will state any limitation, e.g. “Retained in Class until next Port” or “Retained in

Class until next Dry-dock.”



11.3.5 CONDITION(S) OF CLASS - If a ship suffers damage that does not affect the safety or

operational procedures of the vessel, the Classification society may impose certain Conditions of Class.

These conditions will need to be cleared within the time frame and method specified by the society surveyor, if

the ship is to remain in class.



11.4 ARRANGEMENTS FOR SURVEYS

11.4.1 DATES FOR SURVEYS:

The office will make the necessary arrangements to have the surveys carried out at the interval specified on

the particular Certificate. The Master will be advised as to when and where the survey will take place.



11.4.2 RESPONSIBILITY OF THE MASTER:

11.4.2.1 The Master must be aware of the due date for surveys and also ensure that necessary measures are

taken to prepare the vessel for survey. If any item is found to require repair or renewal, a repair requisition must

be sent immediately to office.



11.4.2.2 If any item fails the survey, every effort must be made to correct this situation as soon as possible, and

if possible have the surveyor record that the item is to his satisfaction.  However, if an item remains outstanding,

or a survey incomplete, the Master must inform office of the reasons for the same and measures taken to clear

the outstanding item(s) or to complete the survey at the earliest.  Once the surveyor clears the outstanding

item(s), or completes the survey, office must be informed as soon as possible.



11.4.2.3 Whenever a survey has been passed, the type of survey with the new expiration date must be provided

to office and a copy of the certificate with endorsement must be forwarding to the Vice President.

11.4.2.4 When items have been offered for Survey, the vessel should fill in a “Report of Class Surveys” and mail

this to Company as soon as possible.



11.5 PORT/ FLAG STATE CONTROL INSPECTION

Each authority will maintain an effective system of port state control with a view to ensuring that without

discrimination as to flag, foreign merchant ships visiting the ports of its state comply with the standards lay

down in the instruments above. The vessels staff and the master should always be in a state of readiness that at

any given time the Flag / Port state control could effectively conduct the inspections and deficiencies if noted to

be immediately informed to this office.

11.6 RECORDS:

Request for stores / spares requisition Form CPMF-05-01

Request for repairs from ship through defect list form FPMF-05-13

Recommendations of the Surveyors from Administration and Classification Society.

