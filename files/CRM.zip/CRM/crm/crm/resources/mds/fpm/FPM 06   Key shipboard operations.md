

6. KEY SHIPBOARD OPERATIONS



6.1 DEFINITION : Key shipboard operations are those that fall under any of the below categories:

Operations that affect the structural integrity of the ship

Operations related to the safe operation of the ship

Operations related to the protection of the marine environment

Operations pertaining to cargo/passenger handling and care

Permit to work system



6.2 IDENTIFIED KEY SHIPBOARD OPERATIONS

The company has identified the following key shipboard operations and has developed procedures for them:

Entry into enclosed spaces

Hot work

Working aloft and overboard

Mooring operations

Navigation in heavy traffic density waters

Navigation in heavy weather or in tropical storm areas

Navigation in restricted visibility

Ballasting and de-ballasting operations

Bunkering

Pumping out of engine room bilges

Cargo Operation



6.2.1 ENTRY INTO ENCLOSED SPACES



6.2.1.1 ENCLOSED SPACES AND HAZARDS



6.2.1.1.1 Any tank or other space that has been isolated from the surrounding atmosphere for a period of time

must considered as an enclosed space and as dangerous for man entry.



6.2.1.1.2 Enclosed spaces include cargo holds, pump rooms, ballast tanks, void spaces, peak tanks,

cofferdams, bunker tanks, fresh water tanks, pipe tunnels, duct keels and any other spaces which are normally

kept closed.



6.2.1.1.3 The above spaces should never be entered without explicit instructions from the Master or a

senior responsible officer. Before giving permission to enter, the Master or the senior responsible officer must

ensure all precautionary measures have been taken. No entry must be made until tests have shown that the

area inside the atmosphere is breathable - contains 21% oxygen and no noxious hydrocarbon or other toxic

gases.



6.2.1.2 Ventilation: Ventilation must be carried out before entry into any enclosed spaced.

Forced ventilation - at least two air changes must take place before entry is made.

Natural ventilation - the space should be allowed to breath for at least 24 hours.



6.2.1.3 Gas Testing:



6.2.1.3.1 The first test for all ships should be to ensure the atmosphere throughout the space contains 21%

of oxygen by volume. (Note: 19% oxygen may be breathable but it is not "Safe".)



6.2.1.3.2 The second test, when necessary, should be to ensure that no hydrocarbon gases are present and

zero readings on explosive meters are obtained.



6.2.1.4 ENTRY PROCEDURES

No-one shall enter an enclosed space without the Master’s signed consent on a Company approved checklist.

Further, individuals should never enter enclosed spaces alone unless a watchman stationed at the entrance of

the compartment. The "linkman", is in continuous communication with the man in the tank and the

emergency support coordinator (officer on the bridge at sea or the officer on watch in the engine room).



6.2.1.5 ENCLOSED SPACE ENTRY CHECKLIST (FPMF 06-01)



6.2.1.5.1 This checklist must be completed by the Responsible Officer in charge and must always be approved

and countersigned by the Master.



6.2.1.5.2 Note: Entry into a space that is not gas freed or does not contain 21% oxygen must never be

undertaken by a crew member – except in an emergency to save life in which case, he shall use a

breathing apparatus and shall have a full back up/ support party.



6.2.1.6 DUTY OF THE MASTER

The Master is personally responsible for the safety of every man entering an enclosed space. As this is a

potentially dangerous act, he must ensure before signing the entry into enclosed space form that he is satisfied

that it has been properly ventilated, that the atmosphere in the space has been properly tested (with

the appropriate instruments at different levels for oxygen and/ or other gases) and that the people carrying out

the tests are competent to do the job. He must also ensure that a "Responsible Officer" is in charge of the

operation.



6.2.1.7 RESPONSIBILITIES OF THE OFFICER IN CHARGE



6.2.1.7.1 He must ensure that the space has been found safe, that the necessary lines of communication

and equipment are in place so that in the event of trouble inside the space, the emergency party is able to

respond quickly and safely to evacuate the people inside.



6.2.1.7.2 He must ensure communications between the people inside the tank and those on stand-by outside

the tank have been established and that a coordinator is monitoring the situation from a place where alarms

can be raised to send in the emergency team.



6.2.1.8 RESCUE

On no account should the linkman attempt to enter the space before additional help has arrived, and no one

should enter the space or attempt to effect the rescue without wearing a breathing apparatus set and a

rescue harness. The Master or the responsible officer should make sure that people who have been given

rescue duties and responsibilities are competent in the use of breathing apparatus sets and have been trained

in enclosed space entry. Regular drills should be undertaken simulating rescue of incapacitated people

from dangerous spaces and details recorded in the official log book.



6.2.1.9 DRILLS

Whilst a statutory duty to practice emergency drills simulating the rescue of a crew member from a dangerous

space may not apply to all ships and all flags, such drills are certainly in the interests of shipboard safety.

Drills should be held at regular intervals (as per the drill plan) and shall be recorded. These drills can range

from "table top drills" in which the procedures are enacted and discussed, to a full-scale emergency drill to

retrieve a dummy from a tank or compartment.



6.2.1.10 DOCUMENTATION



The completed checklist identifies details regarding each enclosed space entry by ship’s crew.  All

completed checklists are filed and retained on board for a period of three years. Ref.  FPMF 06-01.



6.2.2 HOT WORK



6.2.2.1 HOTWORK AND HAZARDS



6.2.2.1.1 Hot work is defined as the use of open fires and flames, power tools, hot rivets, grinding,

soldering, burning, cutting, welding or any repair work involving heat or creating sparks, which may lead to a

hazard because of the presence or proximity to combustible material or gases.



6.2.2.1.2 This procedure is established to secure the safety of personnel during operations that require hot

work and to ensure compliance with regulations and recommendations in force.





6.2.2.2 GENERAL



6.2.2.2.1 Operators should be competent in the process, familiar with the areas and equipment to be

used. Instructed where special precautions need to be taken. Personal protective equipment must be worn by

the operator and those assisting him.



6.2.2.2.2 Adequate ventilation and adequate illumination to be provided. The areas to be cleaned and

the effectiveness of the ventilation should be checked at intervals. In confined spaces, breathing apparatus

may be required.



6.2.2.3 CHECK EQUIPMENTS PRIOR USE



Welding and flame-cutting equipment should be inspected before use by a competent person.



6.2.2.4 PRECAUTIONS AGAINST FIRE AND EXPLOSION



6.2.2.4.1 Before the hot work is begun, a check should be made that there are no combustible materials or

gases, at, below or adjacent to the area of work, which might be ignited by heat or sparks from the work.



6.2.2.4.2 Cargo tanks, fuel tanks, cargo holds, pipelines, pumps and other spaces that have contained

flammable substances should be certified as being free of flammable gases before any repair work is

commenced. The testing should include, as appropriate, the testing of adjacent spaces, double bottoms,

cofferdams etc.



6.2.2.4.3 Welding and flame-cutting operations should be properly supervised and kept under regular

observation. Suitable fire extinguishers should be kept at hand ready for use during the operation. A person

with a suitable extinguisher should also be stationed to keep watch on areas not visible to the welder which

may be affected.



6.2.2.4.4 The Hot work permit FPMF 06-02 shall be used whenever hot work is carried out on board.



6.2.3 WORKING ALOFT AND OVERBOARD



6.2.3.1 WORKING ALOFT AND ITS HAZARDS



6.2.3.1.1 Working aloft can be defined as carrying out work on any mast, kingpost or other structure

where the potential for a fall exists. Probably the greatest hazard associated with working aloft is the danger

of a fall. Other hazards include electrical shock, radiation burns, asphyxiation from stack gases, and the

dropping of objects.



6.2.3.1.2 Working aloft or overboard shall be carried out only under explicit instructions from the Master or a

senior responsible officer. Before giving such permission, the Master or the senior responsible officer must

ensure that all precautionary measures have been taken.



6.2.3.2 GENERAL PRECAUTIONS



All nearby electrical/ electronic equipment shall be turned off to avoid the hazard of an electric shock.

If the work is on the main mast, the radar(s) must be switched off and appropriate notices shall be posted

near the radar controls so that it is not turned on.

If the GMDSS transmitting aerials are located nearby, then the equipments shall be turned off and

appropriate notices shall be posted near the units also.

Inmarsat antennae usually have a warning sign posted on them stating the minimum safe distance. If the

work is to be carried out within that distance, then the Inmarsat equipment must be turned off.

Adequate notices shall be posted near the power controls of the equipment.

Safety harness shall be worn and it shall be attached to a strong point at all times.



Tools should never be carried up and down the ladders. All tools shall be put in container which shall be

raised and lowered whenever necessary.

A safety lanyard shall be tied to each tool and the lanyard shall be attached to the user’s wrist to prevent

the tool from falling down due to a slip.

Clear all unnecessary personnel from the area of work.

Additionally, when working overboard, the persons shall wear a lifejacket.

Keep a person with a walkie-talkie standby near the place of work for raising alarm in case of an accident.

Notify the bridge about which persons are working aloft/ overboard.

No work shall be done aloft or overboard if Master/ responsible officer considers it unsafe.



6.2.3.3 WORKING ALOFT/ OVERBOARD CHECKLIST (FPMF 06-03)

Before commencing a work aloft or overboard, this checklist must be completed by a responsible officer in

charge and must always be approved and countersigned by the Master. A separate checklist shall be completed

for each operation.



6.2.3.4 DUTY OF THE MASTER

The Master is responsible for the safety of every man working aloft or overboard. He must ensure before

Signing the checklist FPMF 06-03 that proper safety precautions have been taken and the staff understand

the hazards of working aloft/overboard.



6.2.3.5 RESPONSIBILITY OF THE OFFICER IN CHARGE



He must ensure that all staff engaged in a work aloft/ overboard is fully aware of the hazards involved in such

work and has taken suitable precautions. He must also notify the bridge, establish necessary lines of

communication and ensure that the work is carried out in a safe and efficient manner.



6.2.3.6 DOCUMENTATION



The completed checklist identifies details regarding the work aloft/overboard. All completed checklists are filed

and retained on board for a period of three years. Ref FPMF 06-03.



6.2.4 MOORING STATIONS



6.2.4.1 HAZARDS

Mooring and unmooring operations provide the circumstances for potentially serious accidents. Enormous forces

are generated while heaving on a rope and during unexpected surges on the rope. The ropes can part under

tension and the backlash can be so fast and unexpected for people to react or evade the rope.



6.2.4.2 GENERAL PRECAUTIONS

Appropriate personal protective gear (PPE) shall be worn by all persons as appropriate.

The signals for heaving and lowering ropes shall be explained and agreed in advance.

The communication with the navigating bridge and alternate lines of communication shall be tested prior.

The winches, drums, rollers etc shall be checked for their smooth functioning.

The ropes, heaving lines, stoppers etc shall be checked for their condition.

The Officer-in-charge shall always stand in a position where he can see the winch operator and the other

end of the rope.

Ropes shall be heaved on only when all persons have moved away from the rope.

If there is any excessive load on any rope, all persons shall immediately let the rope go and shall move to

safer areas.

The area below (on the water) shall be checked prior lowering the mooring ropes.

The propeller area shall be continuously monitored for clearance and if any obstruction, the navigation

bridge shall be informed immediately.

The ends of runners and falls shall be secured to the barrel by clamps, U-bolts or some equally effective method.

All foot operated controls shall have suitable anti-slip surfaces.

All controls and locking devices shall be maintained in proper working condition.

The direction of operation of controls shall be conspicuously marked.







6.2.4.3 RESPONSIBILITY OF THE MASTER



The Master shall co-ordinate with the Pilot and shall plan the mooring/ unmooring operation in advance.

While planning, he shall take the prevailing weather conditions, the peculiarities associated with the port,

the limitations of the on board machinery, the shore equipment etc. He shall brief the officers-in-charge about

the total number of ropes that would be passed and their sequence, the number of tugs and their position,

the approach and final position of the vessel, the number of shore gangs, mooring boats etc. The Master shall

ensure that the persons engaged in the operation are well aware of the hazards connected with the operation

and the safety precautions that need to be taken. He shall also ensure that appropriate safety precautions are

being taken.



6.2.4.4 DUTY OF THE OFFICER-IN-CHARGE



The officer-in-charge shall brief his men about the procedure that is to be followed, the hazards associated with

the operation and the safety precautions that would be necessary. He shall also ensure that all appropriate

safety precautions are taken. He shall delegate duties to each individual. He shall plan the position and method

of securing the ropes. He shall co-ordinate with his men, the bridge, the shore gang, the tugs etc in an

efficient manner.



6.2.5 NAVIGATION IN CONFINED OR HEAVY TRAFFIC DENSITY WATERS.



Confined or heavy traffic density waters shall include coastal waters, traffic separation schemes, approaches

to port, anchorages and fishing zone where navigation has to be carried out with particular caution.



6.2.5.1 PROCEDURES



Entry into confined or heavy traffic density waters shall be avoided if practicable, but, when unavoidable, the

largest scale chart shall be used for the planned passage. The officer of the watch shall positively identify all

relevant traffic/ navigational marks. Position fixes shall be taken at regular intervals, the frequency of which

shall depend on factors such as distance from the nearest hazards, speed of the vessel, set experienced etc.,

but in any case, the interval between fixes shall not be more than 15 minutes.



6.2.5.2 RESPONSIBILITIES



6.2.5.2.1 Before approaching heavy traffic density waters, the officer of the watch must call the Master and

take whatever action is required to ensure the safety of the ship in compliance with the COLREGS.



6.2.5.2.2 Upon receiving call from OOW master shall proceed to wheel house . On his arrival on the bridge,

the Master will appraise the situation and if he considers it necessary, he shall take charge of the bridge watch

and OOW shall comply with master’s steering and manoeuvring orders.



6.2.5.3 DOCUMENTATION- Form FPMF 02-05 shall be complied with.



6.2.6. NAVIGATION IN HEAVY WEATHER OR IN TROPICAL STORM AREAS



6.2.6.1 PROCEDURE



6.2.6.1.1 Whenever the vessel is to go through heavy weather or tropical storm is anticipated, the master

shall obtain weather reports. Accordingly passage plan should be amended to ensure safety of vessel at all

times. The master must inform all departmental heads to prepare for heavy weather. All loose objects,

watertight doors, hatch covers must be secured/ closed to avoid ingress of water. Cargo lashing must be

checked and re-tightened as necessary.



6.2.6.1.2 The departmental heads are responsible to the master for checking and ensuring that all movable

objects are secured and all stores are well stowed. The master shall take whatever action is required to ensure

the safety of the ship, lives and cargo.



6.2.6.1.3 Although it is difficult to address all the various stresses which may occur due to heavy weather,

the following factors should be born in mind:

The tendency to slam is closely related to the draught and the impact increases with the vessel's speed.

For heavy weather stresses, a reduction of the vessel's motion is the first step to reduce the stress.

It is necessary to avoid synchronization between the vessel's motion and the period of the waves.

The period of encounter with waves is related to three factors - wave length, vessel speed and angle

of encounter.

Generally vessel's motion is most violent when the length of the wave is close to the length of the vessel.

The vessel's motion becomes more violent with an increasing wave height to wave length rates.

The maximum wave height tends to be more important than the average wave height, as it is the former

which incurs the high stress and damage.



6.2.6.2 DOCUMENTATION - Form FPMF 02-09 shall be complied with.



6.2.7 RESTRICTED VISIBILITY



The definition of "restricted visibility" in Rule 3(l) of COLREGS is "any condition in which visibility is restricted

by fog, mist, falling snow, heavy rainstorms, sandstorms or any other similar causes



6.2.7.1 RESPONSIBILITIES



6.2.7.1.1 If the visibility deteriorates the OOW must call the master and take whatever action is required to

ensure the safety of the ship in compliance with the COLREGS. Further OOW shall be guided by master’s

standing orders on restricted visibility.



6.2.7.1.2 Upon receiving call from OOW master shall proceed to wheel house as soon possible. On his arrival

on the bridge, the Master shall appraise the situation and if he considers it necessary, will take charge of the

bridge watch and OOW shall comply with master steering and manoeuvring orders.



6.2.7.2 DOCUMENTATION - Form FPMF 02-08 shall be complied with.



6.2.8 BALLASTING AND DEBALASTING OPERATIONS



6.2.8.1 PURPOSE

The purpose of the procedure is to ensure that ballasting/ de-ballasting operations is done in a safe and

efficient manner.



6.2.8.2 PROCEDURE & RESPONSIBILITY



6.2.8.2.1 The overall responsibility of the ballasting/ de-ballasting operation lies with the chief officer. He

shall be assisted by the duty officer. Tank valves may have to be manually operated from the deck, whilst

valves in the pipelines may have to be operated from engine room. Pumps may have to be set up locally or

from the engine control room.



6.2.8.2.2 Where the duty officer is delegated the access to directly control the ballast operation, he will be

required to operate the pumps and the valves. He must have a basic understanding of the principles involved,

to operate safely and efficiently, without causing damage to the ballast system.



6.2.8.3 HAZARDS



6.2.8.3.1 Ballasting and de-ballasting operations has to be managed carefully and the consequences of

not controlling the operation effectively can be catastrophic, causing both damage and delay to the ship.













6.2.8.4 PRECAUTIONS



6.2.8.4.1 It is important to check all ballast lines and valve settings before every operation and to have an

agreed safe setting for all valves to which they must be restored on completion of every ballast operation.

It is essential for the duty officer to monitor closely the actual movement of ballast at all times, so that he

always knows the quantity of ballast remaining in each tank. This goes hand-in-hand with his monitoring of the

cargo operation, and his checking the ship’s draft regularly.



6.2.8.4.2 If the duty officer finds that the ballast and cargo are out of step from the plan, he must call the

chief officer immediately.



6.2.8.4.3 The duty officers shall strictly adhere to the ballast plan throughout the ballast operation to

avoid excessive stresses on the ship’s structure.



6.2.8.5 INTERNATIONAL REGULATIONS



6.2.8.5.1 All ships will have to carry a Ballast Water Record Book and will be required to carry out ballast

water management procedures to a given standard. Existing ships will be required to do the same, but after a

phase-in period.



6.2.8.5.2 But various coastal states have already in place rules and regulations towards ballast water

management for vessel entering their port and mandatory compliance. For example USCG, AQIS

(Australian quarantine and inspection service) which will require ballast water management procedures as per

their guidelines to be adhered by vessel calling their port.

Vessel master shall obtain coastal state guidelines with regards to ballast water management prior arrival from

local agents for compliance.



6.2.9 BUNKERING OPERATIONS



6.2.9.1 PURPOSE -To provide guidance to the floating staff for carrying out bunkering operations.



6.2.9.2 VESSEL PRE-BUNKERING PLAN



Before taking in bunkers, the chief engineer shall prepare the bunkering plan. He shall brief the staffs regarding

the bunkering operations. The plan shall include identification of the bunker tanks, their location and capacity of

the bunker tanks. The plan shall also mention the final level  and percentage of the total capacity  of the

bunkers upon completion. Ref FPMF 09-02



6.2.9.3 TRAINING



6.2.9.3.1 The chief engineer must conduct training all crew members who are likely to assist in the

bunkering operation. The training must include a review of the pre-bunkering plan, oil spill

contingency, communications, watch requirements at the point of transfer and deck patrol, emergency

shutdown procedures etc.



6.2.9.3.2 The chief engineer must make an entry in the vessel’s engine log book noting that the training

was conducted.



6.2.9.4 PRE-BUNKERING



Before commencing the bunkering, the chief engineer shall meet the bunker barge in-charge and discuss

with him regarding the line of communication, point of transfer, emergency shutdown procedures.

Communication shall be established VHF/ UHF channel shall agreed.

A pilot ladder shall be rigged for access between the vessel and the bunker barge.

6.2.9.5 DURING BUNKERING

Those persons required during the bunkering operation must have no other tasks, and must remain at

their work stations during topping off.



The bunker barge must be informed by duty engineer before topping off tanks or changing over tanks

begins, in order to adjust the flow rate.

The duty engineer in charge must inform the duty officer when topping off or changing tanks so that they

may monitor the deck and water adjacent to the ship for spills.



6.2.9.6 BUNKER DELIVERY NOTE AND OIL SAMPLING



6.2.9.6.1 MARPOL Annex VI, regulations places requirements on ship owners and fuel oil suppliers in respect

of bunker delivery notes and representative samples of the fuel oil received.



6.2.9.6.2 Declaration signed and certified by the fuel oil supplier’s representative that the fuel oil supplied

is in conformity with regulation of MARPOL Annex VI.



6.2.9.6.3 Fuel oil suppliers have the responsibility of providing ships with bunker delivery notes and fuel oil

samples as required by MARPOL Annex VI. Bunkering delivery note shall be retained onboard for at least three

years and fuel oil sample for twelve months.



6.2.9.6.4 Vessel shall collect drip sample during bunkering operation which shall be forwarded to company

for analysis. Vessel fuel oil samples shall be retained for twelve months.



6.2.10 Waste oil and bilge water



Oil or oily mixtures from machinery space bilges shall be collected in the vessel’s oily water tank or sludge tanks.

The oily water tanks shall be used to contain oily mixtures and sludge tank shall be used to contain sludge from

the purifiers of fuel / lube oils. In order to minimize pollution, the following measures are recommended:The

contents of the oily water tank should be discharged ashore to reception facilities.

If the vessel is equipped, contents of the oil residue tank may be treated in the oily water separator, and

then burned in the vessel’s sludge incinerator.

Any discharge from the vessel’s oil water separator must comply with  the relevant requirements of

MARPOL 73/78 with its amendments.

It is a MARPOL requirements that oil record book should be maintained on board and correct entries made

in the record book of all engine room bilge operations.

Therefore, it is imperative that all engine room bilges are pumped through the 15 ppm bilge oil separator

And the operation recorded in the oil record book.



6.2.10.1   Guidelines for maintenance of oily water separator



Oily Water Separators on board will be maintained as per OEM instruction manual. For on  site calibration, some

makers provide a definite fluid (formaz in water solution with specified turbidity) and a suitable calibration set which

may be separately ordered from makers.

Alternately the OWS can be actually run simulating practical conditions and the discharged sample may be sent for testing

to a laboratory ashore (many scientific laboratories can do this  testing. This may be done during every dry-dock and

the certificate kept on board along with the ORB as records With actual testing records and intermediate cleaning as per

PMS, the calibration can be easily explainable to FSC / PSC authorities. Alternatively the OWS can be calibrated

by approved/authorized firm of the flag/class and or the Dry Dock which has such facility and accepted by the flag/class.



6.2.10.2	Marpol Annex VI



MARPOL Annex VI applies to all ships of 400 gross tons and above engaged in international voyages, constructed

on or after 19 May 2005, are required to be surveyed and issued with an IAPP (International Air Pollution

Prevention Certificate) certificate on delivery of the ship. This certificate will be valid for five years.

Whenever vessel trades/operates in SECA Zone vessel will burn fuel < 1.5 % Sulfur.

MARPOL Annex VI, controls the following six sources of air pollution from ships:

Emissions of Ozone Depleting Substances.

Nitrogen Oxide Emissions from Diesel Engines.

Sulphur Oxide Emissions.



Emissions of Volatile Organic Compounds.

The Incineration of Shipboard Wastes.

Fuel Oil quality.



6.2.11    CARGO OPERATION

The cargo operation, handling and care is detailed in FPM (REFER MANUAL FPM – 15).



6.2.12     VDR/ SDVR  - The company has decided that during survey the data retrieval from VDR/ SDVR

will be carried out annually by OEM representative. Unless required by Flag, the data may be retrieve earlier.

The  Data retrieval will be kept in soft format for inspection at all times.

6.3 . Electronic Chart Display & Information System (ECDIS) :

It is an electronic navigational chart with information on position fixing and additional information on

navigation towards assisting in safe navigation. Although ECDIS reduces navigational workload, simplifies

chart correcting procedures, simplifies voyage planning, track monitoring and position fixing etc. Back

up arrangement: A second Type approved ECDIS powered from the main and emergency power supply

and operating independently of the main ECDIS and connected to the ship’s main power supply and

to an independent GPS input. This secondary ECDIS must have the ENC chart database and voyage plan

loaded before commencement of the voyage and must be operational at all times.

ECDIS Back up Arrangements: General requirement and information : The principal requirement is to

enable a timely transfer to the back-up system during the critical navigation situations and to allow the vessel

to be navigated safety until the end of the intended voyage. Both the primary and secondary ECDIS shall be

fully independent and both supplied from ship’s main and emergency source of power. In addition reserve

power source (UPS Mode) with a capacity of at least 30 minutes is to be provided. When paper charts serve

as the only back-up arrangements, the charts shall include the planned route and, when navigating within

restricted waters, the ship’s position is to be regularly updated to ensure a safe take-over of ECDIS functions,

should the need arise.



ENC Procurement & Corrections



. Master to contact the empanelled service provider and obtain permit for the trading area.

. Corrections are supplied in CD regularly to vessel through agent. Vessel to update the data on regular basis.

. Ships using ECDIS for navigation must carry Electronic Navigational Charts (ENC), the Official Vector Charts

and should be corrected by obtaining current weekly Notices to Mariners.

. T&P notices correction and management are to be done as per maker and service provider. A clear system

must be in place to ensure TNP notices are incorporated.

. Navigational warnings are to be incorporated manually as and when required.

. The Hydrographic offices of various countries process official charts and take on the responsibility of

maintaining their accuracy.  However, corrections made by these offices might only be available at certain

fixed intervals and reliability/margin of error of a position-fix must be borne in mind.









Use of ECDIS for Passage Planning

Planning using electronic chart display systems

Passage planning can be undertaken either on paper charts or using an electronic chart display and

information system (ECDIS) displaying electronic navigational charts (ENC). While planning passage using

ECDIS, the navigating officer should be aware that a safety contour can be established around the ship.

The crossing of a safety contour, by attempting to enter water which is too shallow or attempting to

cross the boundary of a prohibited or specially defined area such as a traffic separation zone, will be

automatically indicated by the ECDIS while the route is both being planned and executed.



When passage planning, using a combination of electronic and paper charts, particular care needs to be

taken at transition points between areas of electronic and paper chart coverage. The passage reflects

distinct pilotage, coastal and ocean water phases. Planning within any one phase of the voyage should be

undertaken using either all electronic or all paper charts rather than a mix of chart types. Where a passage

is planned using paper charts, care should be taken when transferring the details of the plan to an electronic

chart display system. In particular, the navigating officer should ensure that:



Positions are transferred to, and are verified on, electronic charts of   an equivalent scale to that of the paper

chart on which the position was originally plotted;Any known difference in chart datum between that used

by the paper chart and that used by the electronic chart display system is applied to the transferred positions;



The complete passage plan as displayed on the electronic chart display system is checked for accuracy

and completeness before it is used. Secondary ECDIS must have the ENC chart database and voyage plan

loaded before commencement of the voyage and must be operational at all times when the ship is in

coastal waters. When paper charts serve as the only back-up arrangements, the charts shall include the

planned route and, when navigating within restricted waters, the ship’s position is to be regularly updated to

ensure a safe take-over of ECDIS functions, should the need arise.



Checks prior using ECDIS for Appraisal and Passage planning

The following checks shall be carried out by the Navigating Officer: The vessel's controlling operational

parameters (maximum draft, air draft, turning data, minimum under keel clearance required, 'look ahead'

distance etc.) should be entered. The GPS position system should be set to WGS 84 datum. The alarm functions

of the ECDIS should be fully operational; they will alert the operator of any danger exposed in good time during

the voyage.The electronic chart coverage for the voyage must be adequate and all relevant charts must be

fully corrected.

Checks during passage planning

Marking and highlighting of electronic charts should be carried out in a similar way to paper charts. Suchmarking should identify radar conspicuous targets, no-go areas, parallel index lines, transit marks,

clearing bearings, etc.is prudent for a simulated passage to be run prior to the vessel's departure to ensure that

the route does not enter any alarm preset danger areas that may have been overlooked;

Estimated positions should be marked on the chart for each watch, in advance





List of safety alarms to be set and monitored on ECDIS

Safety depths and safety contours

Depth/UKC alarms

Dangerous targets alarms

Cross track distance alarms

Ahead sector (distance/time)

Bridge alarms (alarm from other navigational equipments)

Gyro , GPS, Log error alarms



Checks during watch



Following to be checked:

Data input from the gyro compass, speed log, echo sounder and other electronic equipment to the

ECDIS should be periodically monitored to ensure accuracy.

Secondary ECDIS must be operational at all times when the ship is in coastal waters.

Check back up ECDIS.

Check safety alarms settings and their functioning.

Checks to be made of the ECDIS position fixing system (normally GPS) by the use of other means.

Such checks should include:

Parallel indexing and use of clearing bearings

Visual cross bearing

Use of radar to check the accuracy of the charted position

Limitations of Electronic Charts



ENC charts do not cover all sea areas.

Caution should be exercised whenever information layers are removed or information level is reduced

From an ENC and must be reviewed by the Master.  All Officer of the Bridge must be advised whenever

such changes are carried out.

The Hydro graphic offices of various countries process official charts and take on the responsibility

of maintaining their accuracy.  However, corrections made by these offices might only be available at

certain fixed intervals and reliability/margin of error of a position-fix must be borne in mind.

Positions are primarily derived from the GPS.  Therefore any GPS alarms must be immediately investigated

in order to avoid error in position and the possibility of the vessel running into danger.

There is a risk of running too close to danger with a zoomed-in chart scale.  The Navigating Officer

should alternatively switch smaller chart scale to appraise of the situation.

Positions of other vessels and targets displayed on the ECDIS might be obscured because of improperly

tuned radars or improperly set anti-clutter on either the radar or ECDIS.

AIS displays target course and speed over ground as well as heading.  However, AIS does not calculate

target course/speed based on 'Speed over Ground'.

An ECDIS equipped with a radar overlay shall only be used as a situational awareness tool during anti-

collision manoeuvres and not for primary anti-collision purposes.  The ship's ARPA radars will be used for

this purpose.

A notice must be placed on the ECDIS indicating the depth units in use (meters, feet or fathoms).

The Navigating officers must also inform the same to the relieving Officer at the time of handing over

the watch.

Navigating officers must not become over-reliant on ECDIS. Frequent checks should be made of the

ECDIS position fixing system (normally GPS) by the use of some other means like parallel indexing, radar

fix, visual cross bearings.

Data input from the gyro compass, speed log, echo sounder and other electronic equipment should

be periodically monitored to ensure accuracy.

Using ECDIS should never lull the mariner into a false sense of security. ECDIS is not a substitute of

good seamanship or for maintaining an effective look out.

If display is zoomed beyond intended scale accuracy, the chartered information could be erroneous.

The accuracy is dependent on the limitation of other linked devices i.e. GPS and Radar etc.



Information overload can create cluttered screen degrading navigational safety and could result in

technology assisted incident’

Independent position fixing system input and must be in operational mode in confined water.

Initial phase of changing over from paper chart to ECDIS is crucial to navigational safety. This

must be managed safely and properly under watchful eyes of Master.

Ship’s officers should prepare themselves to deal with situation where primary means has failed.

Servicing, Maintenance and Repairs shall be carried out as per manufacturer’s guidelines, preferably

through manufacturer’s authorised agents.



Actions in the Event of Complete ECDIS Failure



The Officer of the Navigations Watch shall immediately

Inform the Master.

Follow ship specific ECDIS failure procedure.

Report to Technical Superintendent.



6.4 RECORDS



6.4.1 FORMS IN USE:

FPMF - 06 - 01 - ENTRY INTO ENCLOSED SPACES

FPMF - 06 - 02 - HOT WORK PERMIT

FPMF - 06 - 03 - WORKING ALOFT AND ELEVATED SPACES

FPMF - 02 - 05 - NAVIGATION IN COASTAL WATERS

FPMF - 02 - 09 - NAVIGATION IN HEAVY WEATHER OR TROPICAL STORM AREAS

FPMF - 02 - 08 - NAVIGATION IN RESTRICTED VISIBILITY

FPMF - 09 - 01 - BUNKERING CHECKLIST

FPMF - 09 - 02 - BUNKER PLAN