

3. COMMUNICATIONS



This section provides the Master with procedures for communicating with office.



3.1  GENERAL

This system has been established to ensure that company shore based management is adequately aware

and informed of vessel’s position and status.



3.2 ARRIVAL REPORT

Upon berthing at a port, the master shall send the arrival report to confirm safe arrival at a port containing

at least the following information. (If the vessel is calling an anchor port, then this report shall be sent

upon anchoring).

Vessel name / Date

Position / Port

Total dist covered during the voyage

Total steaming time

Average speed during the voyage

FO/DO/LO/FW cons during the voyage

FO/DO/LO/FW ROB on arrival

Cargo – Quantity on board

Anchoring period (Let go & anchor aweigh time), if applicable

POB/ Pilot away time.

First line ashore/ All fast time

EOP/ SBE/ FWE

ETC/D if known

Expected work at port (Loading, discharging, bunkering etc)



3.3  DEPARTURE REPORT

Upon departing from a port, the master shall send the departure report to summarise all activities during

port stay (If the vessel is leaving an anchor port, then this report shall be sent when underway). This report

shall contain at least the following information.

Vessel name / Date

Position / Port

Details of cargo - Cargo – Quantity on board

Time of commencing/ completion loading/ discharging

FO/DO/LO/FW ROB

POB/ Pilot away time.

SBE/ All cast off / RFA

Next port/ ETA

Crew sign on/ sign off particulars

Requisitions received

Repairs/ service/ workshops visited

Inspections/ surveys/ audits carried out.

3.4 NOON REPORT

During sailing, the master shall send the noon report everyday. This report shall contain at least the following:

Vessel name / Date

Noon position

Dist covered/ steaming time/ Avg speed (LAST ONE DAY)

Avg RPM/ Slip

FO/DO/LO/FW consumption (LAST ONE DAY)

FO/DO/LO/FW ROB

Wind direction/force. Sea condition.

Next port/ ETA