





REGISTERED OFFICE:



NMG MARINE SERVICE PVT. LTD

SR TOWERS, NO.14, 4TH FLOOR, 4TH LINE,

NORTH BEACH ROAD, CHENNAI - 600001.

INDIA



TEL: 044- 48530742

Email: info@nmgmarineservice.in

Web : www.nmgmarineservice.com







General alert personnel:







