

7. SHIPBOARD EMERGENCY RESPONSE PLAN



7.1 PURPOSE



7.1.1 To provide guidance to the Master for dealing with accidents or emergency situations. While it is not

possible to cover every hypothetical eventuality, this document tries to cover as wide a list of emergencies

as possible. This procedure is intended to provide a framework on which the Master can build to cope with

the situation at hand.



7.1.2 Where an Oil Pollution incident has occurred or is imminent, reference should be made to the SOPEP

Manual.



7.2 SCOPE

The Scope of this procedure applies to all shipboard emergencies operations and include the following but

not limited to:

Abandon Ship

Oil pollution – during bunkering

Fire

Search & rescue/Salvage of other vessel

Flooding

Shifting of Cargo

Personal injury / illness

Man overboard

Critical plant failure

Collision

Grounding

Emergency steering

Enclosed space entry



7.3 RESPONSIBILITY

The master is responsible for ensuring that on board emergencies are dealt with as per this procedure. He is

also responsible for ensuring that the emergency drills are held as per the drill plan and  reports send to office.



7.4 GENERAL PRINCIPLES



7.4.1 If a ship is involved in an accident or emergency situation whereby the safety of life, ship, cargo or

the environment is threatened, the Master shall immediately inform the DPA.



7.4.2 If a ship is involved in an accident or emergency situation as mentioned above, the Master has the

authority to take whatever action he deems fit to minimize the risks and to save life.



7.4.3 In deciding if assistance is required, the Master should assume that the conditions would worsen and

take whatever action is necessary as soon as possible.



7.4.4 If in danger, the Master must summon assistance well in time. The Coast Guard or rescue authorities

and other ships can be alerted using the “safety” or “urgency” signal depending upon the seriousness of

the situation.



7.4.5 If the Master is unable to contact the company or the owners and, if in the professional judgement of

the master, immediate tug or towing assistance is required, the master has the right to make his own terms

with whoever is able to assist him. There is no need to sign anything initially but merely to make a

verbal agreement. The fact that an agreement has been made – alongwith the name of the party – shall

be recorded in the deck log book and in the official log book. The company should be informed at the first

available opportunity.











7.4.6 If tug assistance is required when the ship is in no immediate danger, the Master should contact

the company. The company shall endeavor to arrange for the tow assistance on the best terms available.

The Master must keep the situation under review and if it deteriorates he must take any action necessary

to maintain the safety of life and of the ship.



7.4.7 Whatever be the emergency, the company should be informed as soon as is practicable. It is generally

in the best interests of the company and the master if the first report of any accident or incident comes to

the company directly from the master and not from a third party. This however, does not reduce the authority

of the master to take whatever steps he deems necessary to ensure safety and to prevent pollution.



7.4.8 A master should, at all times, be guided by his main responsibilities of ensuring safety of life, vessel &

cargo and of preventing pollution.



7.4.9 In a salvage situation, the Master remains in command even when salvors are appointed.  While the

Master and his crew should make all efforts to assist and co-operate with the salvors, the Master may override

their advice if he deems it necessary. A detailed record of any salvage services should be kept.



7.4.10 In any casualty situation, it is probable that the ship may be contacted in one way or other by

radio, television or press representatives to answer questions or make statements. The master and all crew

must refer all press contact to shore office. The Managing Director (or his authorized representative) shall be

the only voice that answers the press.



7.4.11 In emergency situations like Man-Overboard, Master and his Crew may please be guided by the

Manual issued to them on “Plans and Procedures for Recovery of Persons from the Water” which is specific to

their vessel. However the master of the vessel may use his discretion and professional experience during

the recovery operation.



7.5 REPORTING

If a vessel is involved in an accident or in an emergency situation, the master must report the matter to the

local coast guard or local port authority and to the Company as soon as possible. In order to save valuable time

and to transmit the maximum information, the standard form of initial report which follows the IMO

Guidelines should be made as follows:-

Name of vessel

Vessels position (lat/long, bearing, port/berth)

Ports to and from

Nature of casualty (collision, grounding, fire oil spill, etc…)

Nature and extent of damage

Name of charterers or agent with any contact names and emergency phone numbers

Name, nationality, type and situation of any other vessel involved

Any casualties or fatalities

Nature of any services required (towage, helicopter, lifeboat, medical, fire fighting, etc.)

Services already summoned

National, local or any other authorities or agencies already informed

State of weather and sea, present and forecast and other relevant comments

Date and time of report

In the event of bunkers refer to SOPEP (if applicable).



7.6 DRILLS



7.6.1 The purpose of carrying out emergency drills on board is to:-

To increase awareness among the staff about the potential hazards facing them.

To familiarize the staff about the action to be taken by them during real emergencies.

To improve the standard and speed of response to identified potential emergency situations.









7.6.2 The Master ensure that drills are carried out for the identified emergencies as per the drill plan in

FPMF 07-01.



7.6.3 The drills and exercises (Refer 7.2) shall be periodically carried out on all company vessels so as to

cover the cycle of all the drills carried out at least once during a period of 12 months with a mandatory

requirement of a fire / abandon ship/ SOPEP drill once a month and rescue boat lowering / steering gear failure

once every 3 months.



7.6.4 The effectiveness of these drills shall be reviewed at the SCM. Training needs that are identified during

the drills shall also be discussed in SCM. Any inference drawn from these reviews and any suggestions

for improvement shall be recorded in the SCM. The company shall discuss these safety meeting reports at

the management review meeting and any amendments to the drills/ safety management system may be

brought into force by the DPA.



7.7 RECORDS



7.7.1 The following drill checklists detail the action to be taken during each identified emergency situation.



7.7.2 FORMS IN USE:

FPMF 07–01: EMERGENCY RESPONSE AND POLLUTION PREVENTION DRILL PLAN

FPMF 07–02: EMERGENCY DRILL REPORT

FPMF 07–03: RECORD OF DRILLS

FPMF 07- 04 : MUSTER CARD (SAMPEL)

EMERGENCY DRILL CHECK LISTS – 01 TO 13





















































