



17. OPERATION OF BULK CARRIERS



This Section of  FPM 17 to be read in Co-relation with FPM Section 15.





