

8. EMERGENCY RESPONSE CONTACTS



8.1 PURPOSE

To provide guidance to the master regarding the emergency response and the necessary contact details of the Administration and third parties.



8.2 TWENTY FOUR HOUR CONTACT DETAILS

The Company has established contact points approachable by Master as listed below:

8.3 AGENCIES FOR RESCUE ASSISTANCE.

8.4 OWNERS’ CONTACTS



8.5 NATIONAL REQUIREMENTS :

8.5.1 The Owner/ Master of the vessel shall report any emergency to the Administration without any delay and by the quickest possible means as contained in Merchant Shipping Act.

8.5.2 Contact Numbers as follows:

DG COMM CENTRE

Tel No: 91 22 22614646 / 22610606

Fax No: 91 22 22613636

Email: dgcommcentre-dgs@nic.in / dgcommcentre-dgs@vsnl.in

8.5.3  Full Style Address:

Director General of Shipping,

9th Floor Beta Building,

i-Think Techno Campus, Kanjurmarg (East),

Mumbai - 400 042. India.

Tel No: 91-22-25752040/41/42/43/45

Fax No: 91-22-25752029/35

Email: dgship-dgs@nic.in



8.6     LIST OF CONTACTS FOR DGS AND MMD





8.7  LIST OF COASTAL STATES

REFER TO APPENDIX 1 OF SOPEP



8.9  RECORDS

A. Communication logs (brief texts)

B. Call log

C. Copy of Tx/Rx msgs