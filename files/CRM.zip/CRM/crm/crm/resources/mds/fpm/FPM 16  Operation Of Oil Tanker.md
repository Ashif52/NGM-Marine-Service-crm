# 16. OPERATION OF OIL TANKER



1.   INTRODUCTION

1.1  General



1.1.1 These instructions are issued to guide the Master and the ship officers when performing their services on board the ship operated by NMG MARINE SERVICE PVT LTD. as a minimum requirement.



1.1.2 Nothing printed in these instructions should relieve the Master and his officers from their duty, which is always to act according to the best of their judgment. Neither should the instructions exempt from any responsibility as laid down in valid laws, regulations etc.



1.2   Voyage Orders



1.2.1  These instructions to the vessel shall be sent by Charterers or Owners and will normally contain the following information;

1.2.2      Ports of loading and discharge

1.2.3	Volume, grade and Density / S.G.

1.2.4	Special requirements of the charge i.e. heating, IG pressure

1.2.5	Special properties of the cargo i.e. H2S

1.2.6	Limiting drafts at the discharge port / loading port

1.2.7	Stemming details

1.2.8	Lay days  / Canceling days

1.2.9	Rate of loading discharge.



1.3 The Master is responsible for loading under these orders. Maximum amount of cargo is to be taken as stipulated in the voyage orders, limited to the load line restrictions of each zone. There may be instances, however, when a vessel is unable to load full cargo or unable to comply with the Voyage Orders, in which case the Master shall contact Charterers and Owners as soon as possible.



2.     PLANNING CARGO STOWAGE



2.1  Factors To Be Considered

### 2.1.1    The limiting zone of the loaded passage taking into account zones encountered and Bunker, water consumption on intended passage.

### 2.1.2    Freeboard should be always in compliance with the applicable load line zone.

### 2.1.3    The sailing condition should be within the maximum permissible limits of sea going.

### 2.1.4    Sufficient volume should be left in the tanks for possible expansion of cargo.

2.1.5    Sailing trim should be such that the vessel arrives at the discharge port on even keel draft.

2.1.6   Allocation of tanks to different grades should enable the vessel to trim sufficiently for efficient discharge and draining of tanks and efficient scheduling of discharge and stripping.



2.2    The Loading Plan



2.2.1  The loading plan should be recorded in the “Cargo Register and should show following details at least.

Names and quantities of the products to be loaded. The total cargo quantity in each tank (vol. And full ullage). The sequence in which  products are to be received and discharged.

Forward, mid-ship and aft drafts sailing.  Any special instructions.





2.2.2  The chief officer shall be responsible for preparing the plan and shall ensure that the master is in informed and all officers are familiar with the same.



# 3           PLANNING CARGO OPERATIONS



## 3.1      Equipment

3.1.1    All equipment used for loading should be checked prior to loading, tank cleaning and ballasting/ de-ballasting operations. All defects in equipment should be noted and repaired if there is sufficient time.  This includes pressure test of ballast line passing through cargo tanks.

3.1.2    All defects in lines and valves should be noted in the loading plan together with any special operating instructions.

3.1.3    Oil spill clean up equipment should be checked and made readily available, i.e at main deck storeroom.

3.1.4    Fire-fighting equipment should be made ready and available for instant use.

3.1.5    The walkie-talkies should be tested beforehand and be fully charged.

3.2     Personnel

3.2.1   A certified deck officer must be on watch at all times and will be responsible to the Master for the safety and security of the ship and personnel on board. When in doubt, he shall seek instruction from the master or in his absence from the chief officer.

3.2.2    The loading operation is to be constantly monitored by the watch officer.

3.2.3    All personnel should be briefed before commencement of cargo operations on the contingency plans for port emergencies including tank overflows and fires. They should have instructions on emergency communications with the shore terminal.



# 4.   SAFETY AND POLLUTION PREVENTION WHILST AT TERMINAL

# Following to be carried out whilst the ship is at an oil terminal.



4.1    Safety

4.1.1 Readiness - Fire Fighting Equipment

4.1.2 Immediately on arrival at the terminal, the ship’s fire hoses should be connected to the fire main, one forward and one aft of the ship’s manifold. If practicable a pump should maintain pressure on ship’s fire main. If this is not possible the fire pump should be in a stand-by condition.

4.1.3 Portable fire extinguishers should be placed near the ship’s manifold.

4.1.4  A check should be made to confirm that both ship and shore have an International Shore Connection for the transfer of water for fire fighting.

4.1.5 Readiness to Move Under Own Power.



4.2   Communications

4.2.1  There should be adequate means of communication between ship and shore.



4.3  Smoking:

### 4.3.1  Controlled Smoking: The designated smoking areas on a tanker or on shore should be agreed in writing between the Master and the terminal representative before operations start. In the designated smoking places all portholes should be kept closed and sealed. Doors leading to passageways should be kept closed except when in use.



4.4       Galley Stoves and Cooking Appliances.

4.4.1    While the tanker is at berth the use of galley stoves and cooking appliances with non-immersed elements, such as electric hot-plates and toaster, may be permitted in galleys, pantries and accommodation provided that the Master and terminal representative jointly agree that hazard exists.  Any doors or portholes opening directly onto or overlooking the tank deck must be kept shut. Cookers other equipment heated by steam may be used at all times.









4.5       Communication equipment

4.5.1    When a tanker is at berth, its main transmitting aerials should be earthed.



4.6       Radar Scanners

### 4.6.1    The radiation of radar waves from a properly sited radar scanner presents no ignition hazard.  However, the operation of a vessel’s radar will involve running non-approved electrical equipment.



### 4.7       Satellite Communications Terminals

### 4.7.1     These terminals normally radiate at 6 GHz and the power levels contemplated are not considered to present an ignition hazard.  However, the pointing of the antenna may involve the running of non-approved electrical equipment. Consultation between the tanker and the terminal is advised before the satellite terminal is operated.



### 5.      WORK ON A JETTY OR BERTH OR ON A TANKER AT BERTH



### 5.1         Use of Tools

### No hammering & chipping should take place. No  power tool be used outside the boiler or engine rooms on a tanker or on a jetty which a tanker is berthed without joint agreement being reached between the terminal representative and the officer responsible.

5.2     Approval for Cold Work

Where such work is to be done outside the boiler or engine rooms on a tanker at berth, the Master should first request such permission from the terminal representative.  Agreement should be reached upon the details of the work to be done and the safety precautions to be taken (see permit forms used).

5.3     Hot work

No hot work should be carried out on board the ship without permission from DPA/ Tech. super.

At sea the designated area for carrying out hot work is in Engine room workshop.

In Port : Permission from Port Authority to be taken after concurrence from Office. Refer FPM 06, Section 6.2.2.



6.      Access between Ship and Shore.



### 6.1     Personnel should use only the designated access.

### 6.2   Gangways or other means of access should be provided with a safety net where appropriate and life buoys with lifelines should be available in the vicinity of the gangway.  A copy of the FFA plan should also be available.

6.3 Particular attention to safe access should be given when the difference in the level of tanker’s deck and jetty becomes large, especially where the level of the tanker’s deck can fall considerably below that of the jetty.



7.     Moorings



## 7.1 The vessel should be kept safely alongside the jetty at all times.  Moorings should be frequently monitored and tended to.  Any adjustments in moorings should be made only with the approval of the watch officer.

## 7.2  Fire wires shall be run out both forward and aft and shall be of sufficient length for fastening at all stages of loading discharging and ballasting.



## 8.    Pollution Prevention : Refer SOPEP PLAN.



9.   Pre-transfer conference

Prior to cargo operations, following items are to be discussed by Master and the Terminal representative:





9.1.     Type of product

The cargoes to be loaded should be reviewed, including their particular hazards, if any, and the precautions which must be taken and exercised. Same to be displayed on NOTICE BOARD or should be available with Master.



9.2      Sequence of Operation

The order in which the products will be loaded/discharged and the identity of those, which will be handled simultaneously, must be agreed upon, together with changes in the cargo system line-up when changing grades.

9.3      Transfer Rate

The maximum/minimum loading/discharging rate for each grade of cargo should be agreed upon and this should be within safe limits.

9.4      Critical Stages

Depending on the grades and loading/discharging systems there must be an  agreement, as to what the critical stages would be  and the required manpower for the purpose .  At periods of start-up and completing cargo, terminal Staff must be in attendance at the jetty.

9.5       Local Rules and communication

The local Port Rules, especially with regard to safety and pollution, should be discussed by the Master and Terminal Representative and the mode of communication should be agreed.

9.6       Emergency Stop Procedure

Discussions must take place on the procedures to be followed in case of a spill or hose rupture, fire on the vessel, the terminal or in the vicinity; electrical storms; mooring failure; vessels approaching or passing at excessive speed or similar situations.

9.7       Watch and Shift Arrangement

The manning of the jetty and the officers in charge of loading on the vessel shall be agreed. Both Terminal and Ship should be aware of contact persons in case of need.



10.    PRE-LOADING OPERATIONS

10.1     De-ballasting

Unless otherwise specified in the Voyage Orders, the vessel should arrive in the load port with segregated ballast and decanted slops in accordance with Load on Top procedures.

When alongside unless Terminal, local or international regulations require otherwise, the vessel will discharge her segregated ballast to sea simultaneously while loading. During de-ballasting, continuous watch be maintained on the ballast tanks and  overboard discharges to be checked for signs of pollution. (if any). Ballast Management Plan to be refer prior De ballasting.



10.2     Tank Inspection

Prior to loading, the vessel’s tanks should be inspected by the terminal’s Inspector, who should sign on (On board Quantity) O.B.Q. Certificate.



10.3     Lining Up Pipelines and Valves

Prior to loading, deck and pump room lines should be lined up. In accordance with the loading plan such as the cargo flows through loading drop valves and bypassing the pump room (where applicable).Unused pump room cargo-line valves should be firmly shut, sea chest, overboard discharge valve must be secured and shut.

Deck valves that are going to be used should be shut.  The offshore manifold valves should be tightly closed and blanks should be secured firmly in place with bolts in all holes and flanges.

Check if manifold air cocks, pressure gauge cocks, drain valves are all tightly secured. The position of all-main, stripping and tank valves must be specifically checked to ensure that those which should be closed, are in fact, closed..



10.4      Operational checks

Before cargo operations, the chief officer and chief engineer shall confirm that all Safety equipment are in order.  The cargo pumps, Inert gas system, machinery alarms, hydraulic systems, trips, high-level alarm, gauge, sensors etc. are in operational condition as per company policy.



11. LOADING OPERATIONS



11.1      Start of Loading

Start of loading should initially be at reduced rate into one or two tanks. Once satisfied that the vessel is receiving the cargo, the terminal should be asked to slowly increase the rate as agreed upon after ensuring the following:

Confirming that the cargo is not leaking into any tanks other than those open.

Checking over-side for any possible escape of oil through sea valves.

The loading manifold/s should be inspected to see if there are any leaks from loading arm connection or from any blanks at both sides of the manifold and on the outboard manifold.

11.2      Monitoring Cargo Tanks

The ullages of the tanks being loaded should be frequently and regularly monitored along with IG pressure, especially when tanks are approaching the topping off range.

11.3      Changing Tanks

From the point of view of oil pollution and safety, filling the tanks up to the predetermined ullage, securing them and changing over to other tanks at the same time is a most critical operation.  There must be sufficient manpower to handle valves and check ullages.  These men should understand the operation  and must pay full attention to their duties.	Extra precaution should be taken to avoid over-pressurizing the ship’s lines and shorelines by closing too many valves against the shore pressure.

## 11.4   Topping Up

### The flow of cargo to tank involved must be reduced such that ullages can be monitored and at the same time watch has to be maintained on tanks to where the flow has been diverted.

### Following points should be considered during topping off tanks:

### Closing off one tank increases the rate of flow to other open tanks on the same line.  As the vessel trims by the stern, the rate of flow into after tanks, which are open, will increase. Open the valve to an empty tank on the same line and the rate of flow into  any tank, when it is nearly full shall be quickly reduced.  This procedure, in conjunction with closing the valve on the full tank, permits precise control of  the rate of loading of individual tanks. he man in charge of topping off tanks must give the operation his undivided  attention, which means he cannot perform other duties simultaneously such  as reading the vessels draft.

### The ullages in the tanks that have been topped up should be frequently checked to make certain that there are no leaks and subsequent overflow.

## 11.5    Final Tank

## Adequate notice should be given to the Terminal when completing cargo operation.  The last part of the loading operation should be done at a reduced rate when loading into the last tank only.  The Chief Officer should satisfy himself that there are terminal staff on the jetty ready to shut down, prior to completion of cargo.

## When ordering the stop of cargo, time should be allowed for the terminal to shut down.  Space should be allowed in the tank for this, and also for draining loading arms.

## 11.6    Check After Loading

As soon as the loading arms have been drained, the Chief Officer should ensure that all valves in the cargo system are closed and that pressure/ vacuum relief valves are appropriately set with I.G. Pressure as applicable.



12.     OPERATIONAL CHECKS



12.1    Moorings

The Duty officer is responsible for frequent and careful tending of moorings. When tending to moorings an  overall view of the mooring system should be taken, so that the tightening or slackening of individual moorings do not allow the vessel to move or lay undue stress into other moorings.











Following should be considered when tending moorings;

-     Significant increase in wind speed or change in wind direction, particularly if the tanker is lightly laden;

Swell conditions;

Period of maximum tidal flow;

Low under-keel clearance;

The close passing of other ships;

Position of gangway relative to shore bits etc.



12.2   All precautions taken during berthing and cargo handling operations alongside jetty.



# 13.   PLANNING DISCHARGE

### 13.1    Stress

The vessel must not exceed maximum still water stress limits at any time during cargo operations.



13.2    The Discharge Plan



13.2.1 Operation

The pumping program is to be pre-planned before discharge, and the chief officer is to inform the chief engineer of all pumping requirements prior to discharge with IG requirement.  Any special requirements or limitations are to be discussed.



13.2.2 Equipment

All necessary equipment for cargo operations, firefighting and pollution avoidance should be inspected and placed ready prior discharge.



13.2.3 Personnel

Port watches are to be set.  Any special manning requirements, such as storing or crew absences for medical treatment, will need to be taken into account. All operation personnel are to be briefed of the Emergency Plan prior to discharge.



13.2.4 Discharge Plans

This has to be completed prior to vessel’s arrival at the discharge port.  The discharge plan is in the Preplanning Cargo Book duly attested by Master/Chief Officer and kept in Cargo Office for use by all concerned officers.

Instructions should be kept for ballasting after discharge.



14.    FORMS IN USE

FPMF-15-01 CARGO PRE LOADING CHECKLIST

FPMF-15-02 CARGO WATCH CHECKLIST

FPMF-15-03 CARGO POST LOADING CHECKLIST

FPMF-15-04 CARGO PRE DISCHARGING CHECKLIST

FPMF-15-05 CARGO POST DISCHARGING CHECKLIST

FPMF-15-07 SHIP TO SHORE CARGO CHECKLIST

FPMF-15-08 NOTE OF READINESS.

FPMF-15-09 CARGO DAMAGE REPORT.





