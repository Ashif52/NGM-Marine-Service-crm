15. OPERATION OF GENERAL CARGO SHIP



CARGO PROCEDURES:

1.  CARGO HOLDS MAINTENANCE & CONDITION

It is of the utmost importance that the vessel's cargo holds are maintained in good condition and clean so that the vessel is always in a condition to carry any commodity.



1.1.  Although it is the Chief Officer's duty to ensure that work is carried out in the cargo holds whenever possible to maintain and improve their condition, it is the Master's overall responsibility to inspect the cargo holds on a regular basis, to report to office their condition and defects, if any, that cannot be attended by ship staff.



1.2 Due regard must be given at all times to personal safety when carrying out cleaning, maintenance and inspection work within the holds.



2. HATCH COVERS

2.1 Hatch covers form a major part of the vessel's watertight integrity and therefore, require a lot of attention. The following notes apply to most types of hatch covers, and are to be used in conjunction with manufacturer's instructions and any additional information held on board specific to the type of hatch covers fitted.

2.2 Hatch covers are to be inspected prior loading. Particular attention is to be given to the underside of hatch covers, with consideration to the type of hatch covers fitted in the vessel. Sealing rubbers are to be inspected for damage, distortion, cracking and over compression. Compression bars must always be kept smooth, free from rust and paint, and any damages must be repaired immediately. The areas immediately surrounding the compression bars are to be swept clean of any cargo residues after loading/discharging.

2.3 Securing dogs must always be used while the vessel is at sea. They must be well maintained and greased, and are to be checked on a regular basis.

2.4 Drain Channels are normally inaccessible after the hatch cover has been closed, and are therefore to be attended and checked immediately after loading/discharging operations have been completed. The channels must be swept clean of any cargo residues, and are always to be free of rust, scale and flaking paint.

2.5 The non-return drain facilities on the hatch coamings must always be kept clear. They are most susceptible to blockage during loading/discharging operations, and must be checked and cleared after completion of such operations. The condition of the non-return facility must be checked frequently to ensure optimum operation and prevention of water ingress during heavy weather.

2.6 Miscellaneous openings & inspection hatches, if provided on hatch covers, must be checked for proper sealing & securing.



3.  HATCH COVER OPERATION AND TESTING

The machinery and equipment required for the opening and closing of hatch covers, must be kept in good working order. Where the hydraulic systems are employed, care must be taken to avoid leakage of hydraulic fluid which would cause hazardous conditions on the vessel's deck and possible injury to ship and shore personnel. It has also been the cause of fines for pollution when such fluid has escaped over the ship's side. In order to ensure that there are no claims for cargo damage by water ingress through hatch covers owing to poor seals, all hatch seals are to  be tested  by chalk test/ hose test  at regular intervals.

4.  CARGO HOLD CLEANING

4.1 There are various types of cargoes which are commonly carried in today's market, and they all require different methods of hold cleaning. Hence the basic rule that always applies, is that the vessel's cargo holds must always be cleaned to the highest standards possible, regardless of the next commodity to be carried.

4.2 The hold washing activities shall include following:

Extent of washing required for removal of cargo residues

Cleaning of cargo hold bilge wells

Identity of blanks to be opened/ closed



4.3 After carriage of any bulk cargo, the holds must always be swept before any attempt is made to wash.

4.4 Old dunnage is not to be retained on board unless specifically requested for by the Charterers.

4.5 When disposing of waste materials, attention must be drawn to the International Regulations concerning the disposal of garbage at sea. It must be stressed that on no account are plastics to be thrown overboard into the sea at any time.

Consideration must also be given to the type of residues involved and the possibility of damage to pumps, valves and valve seals. Washing after carriage of this type of cargo should involve the use of a portable salvage pump to remove washing water rather than using the hold bilge pump. For cement cargoes, the bilge pumping system must not be used as any water left lying in the pipeline will hold cement in suspension and will eventually harden in the pipelines, valves and pumps. On completion of sea water washing of holds, a fresh water rinse must always be carried out  to prevent Salt deposits which may  contaminate  next  cargo, and or will  damage coating, fittings and steelwork.

4.6 The Chief Officer must always carry out a full and final inspection of all cargo holds before presenting them for shipper's final approval and acceptance, to ensure that all cleaning work has been carried out as per his instructions and to his satisfaction, and that he is satisfied that the cargo holds are in a suitable condition for the carriage of the next commodity and presentation to the shippers.



5.  FUMIGATION

For the carriage of grain cargoes, it is sometimes a requirement that cargo holds be fumigated before loading to irradiate any insects which may have been present. When selecting the type of fumigation to be used, the local Authority regulations are to be taken into account and also all applicable safety measures are to be complied with.



6.   LOADING & DISCHARGING



6.1 CARGO LOADING



6.1.1 The Master must ensure that the standard of cleanliness in the cargo holds for the carriage of the proposed cargo before presenting the vessel for loading.



6.1.2 The Master must ensure that he has as much information as possible concerning the nominated cargoes. All appropriate publications are to be consulted in this respect. The Master must also aware of dangers, precautions, ventilation & instrumentation requirements associated with the cargoes to monitor temperatures, gas and oxygen levels, moisture content etc. Where there is any doubt, the master is to contact the Office for advice.



6.1.3 When declaring the amount of cargo the vessel can load, due attention must be paid to limitations and draft restrictions at the ports of discharge, bunkers to be taken and trim required for adequate manoeuvrability of the vessel during the voyage.

A Pre-Loading Meeting with the Shore facility is to be held to discuss the Chief Officer’s Cargo/Ballast Load Plan, communications and any relevant Port Regulations applicable to the vessel.

It is of the utmost importance that Loading Operations are carried out with careful regard to the ship’s stability, as well as bending moments and shear force limitations.

The OOW is fully aware of the times of high and low water at the berth.

The ship’s moorings are to be closely monitored and adjusted as necessary to ensure that they have the correct tension.

The OOW must closely monitor the condition of the cargoes being loaded and report any defect immediately.



6.2 CARGO DISCHARGING



6.2.1 As with loading, the discharge of cargo must be carefully planned, taking into account all the previously mentioned factors, and a discharge plan made out well before operations commence.







6.2.2 During the discharge operation, the condition of the cargo is to be closely monitored and any cargo damage, must be noted. The Company should be informed immediately with as much information in the circumstances as possible and request for a P& I representative to attend if appropriate. In the event that it is not possible to get in contact with the Company the Master is to call in local P & I representative and, if necessary , discharging must be stopped. A full report must be sent to the company as soon as possible.



6.2.3 It is of the utmost importance that both loading and discharging operations are carried out with careful regard to the ship’s stability, as well as bending moments and sheer force limitations.



7.   DRAFT SURVEY

A draft Survey is to be carried out before and after Loading and Discharging and must be properly documented. Draft readings are to be taken from the Draft Marks on the vessel’s Hull and in case of difference between the cargo figures obtained from draft survey & shore facility meters, the differences in Cargo quantity is to be correctly documented and a letter of protest issued to the charterers and/or shippers.



8.   STEVEDORE DAMAGES

8.1 It is essential that during Cargo Operations a careful watch is kept for any damage caused to the vessel and her equipment by stevedoring operations i.e. damage to Cargo Holds by grabs and bulldozers or damage caused by the nature of the cargo itself such as steel.

8.2 Notice of any damage must be brought to the attention of the stevedore representative as soon as possible after any incident involving damage.

8.3 In the event stevedores representative refuses to sign, same must be stated on the report and brought to the attention of the charterers and/ or charterers agent as per the relevant clause in the charter party.

8.4 If possible photographs of the damage are to be taken and appended to the notice.



9.   CONDITION OF CARGO



9.1 The condition of the cargo to be loaded must be noted and if the Master suspects that the actual condition of the cargo is not as described by the Shippers/Charterers or their Agents he must instruct the Chief Officer to endorse the Mate’s receipts accordingly and ensure that Bills of Lading are similarly endorsed.



9.2 If the Master suspects that the condition of the cargo has changed during the voyage, for whatever reason, he must advise the Office immediately providing as much information as possible on the affected cargo and reasons for the change in condition. He must also seek advice from the P & I representative.



9.3 It must be ensured that entries are made correctly in the Deck Log Book concerning items which may affect the condition of the cargo and will later assist the Owners in documenting their case in the event of a claim, e.g. the weather conditions during Loading/Discharging and on passage. Deck Log Book Entries must also include information on wet or otherwise contaminated/damaged cargo being placed on board, or rough handling by stevedores.



10.   BALLASTING AND DEBALLASTING



10.1 When the ship is not carrying cargo or is lightly loaded, sufficient ballast must be carried to ensure that the ship’s stress, stability, draft, trim and propeller immersion is within permissible limits to guarantee the safe handling of the vessel in the prevailing or expected conditions.



10.2 In meeting these parameters the vessel must comply, at least, with the requirements of the IMO, Class and Port State Authorities.

When planning & carrying out ballasting & de ballasting operations the following factors must be taken into account:

Shear Force and Bending Moment



Stability and Free Surface Effect

Torsion Loads

Draft and Trim of the Vessel

Pumping Limitations.

Ballasting must always be carried out at a safe rate, determined by the vessels design as per ballast Water Management Plan( As applicable).



11.   CARGO GEAR



11.1 GENERAL



11.1.1 The Master has the overall responsibility for ensuring that the vessel's cargo cranes are being adequately maintained and that he receives regular updates from the Chief Engineer and Chief Officer on their condition.



11.1.2 The Chief Engineer is directly responsible for all crane maintenance and under his supervision and assistance, the Electrical Officer and other ship's Engineer Officers are to carry out all necessary repairs and maintenance to ensure that the vessel's cranes are always in good working order during the loading and discharging operations with due regard to safety.



11.1.3 It is the joint responsibility of the Chief Engineer and the Chief Officer to ensure that all moving parts are adequately greased. General maintenance of the crane exteriors and fittings is the responsibility of the Chief Officer.



11.1.4 The S.W.L. of the cranes must be clearly marked in a conspicuous position on the crane jib, and it must be ascertained by the Chief Officer that all parties concerned with the load/discharge operation are aware of the maximum capacity of cranes, and that this is not exceeded. The weight of grabs, spotters, or other cargo handling equipment attached to the hook must always be taken into account.



11.2 TEST AND STATUTORY INSPECTIONS OF LIFTING GEAR



11.2.1 The Master must ensure that the test & statutory inspections are always carried out as required by notifying the Office well in advance of when such an inspection, test or survey is required to be carried out.



11.2.2 When reviewing survey status on cargo lifting gear, due attention must be paid to the local government regulations of the vessel's destination; many countries require the cranes to have been tested during a certain time limit prior to arrival in their ports. The age of the vessel is often a factor in determining whether the cranes require such extra tests and the agent and or Charterers representative should always be consulted to determine if any special regulations are in existence. An example is the regulations imposed by the Saudi Arabian authorities which require all cranes to be inspected by a class surveyor within the previous six months prior to the vessel's arrival at a Saudi Arabian port, if the vessel is over ten years old. If such an inspection is required, the Master must inform the Office in ample time to arrange this.



11.2.3 All statutory inspections, tests and surveys of cargo handling equipment must be entered in the chain register and duly stamped and signed by the attending surveyor.



11.2.4 All crane wires are supplied along with a test certificate which pertains only to that wire. The certificate must be kept on file, and ready for inspection by the appropriate authorities at all times. The certificates must be marked with the position of the wire, i.e. on which crane the wire is situated and its use, e.g. luffing or hoist wire. If the wire is held on board as a spare, the certificate must be marked along with the stowage position of the wire. The wire itself is to be tagged and marked with the applicable certificate number. A certificate must be held on board for every wire on board whether in use or as a spare.









11.3 LIFTING GEAR PLAN

It is an International requirement that the location of each piece of equipment used for lifting is indicated on a plan which must be available for inspection by a competent authority at any time. It is the responsibility of the Chief Officer to ensure that these are kept up-to-date and are accurate. The plan must contain details of the location, safe working load and certificate numbers of each crane, grab, wire, hook and swivel on the vessel.



11.4 CHECKS ON LIFTING GEAR PRIOR USE



11.4.1 In addition to maintaining the cargo gear to the highest standards, the following items must be specifically checked on each occasion on which the vessel arrives from sea and when cargo is to be discharged or loaded. Limits - The hoisting and luffing limits are to be tested and, if necessary, must be set in strict accordance with the manufacturer’s instructions.



Crane Oil Levels - Check the oil levels in all the relevant header tanks, servo tanks, etc.

Crane Floodlights - These must be tested, as are the interior lights in the driver's cabin and in the machinery space.

Crane Windows - These are to be washed clean and cracked or broken windows must be replaced, and the seals  checked. Hinges and locking clamps are also to be checked that they are free.

Machinery Spaces - Must be kept clean, tidy and free from oil and water on the deck plates, and the drains must be proven clean and clear.

Cooling Fans - These must be tested and proven in good working order. All ventilator flaps/cowlings which require to be open during crane operation, together with associated locking devices are to be free.

Ladder ways and Platforms - These must be inspected and kept clear of any oil, grease or water on the foot treads, and the handrails must be intact and safe.

Crane and Machinery Space Watertight Doors - Sealing rubbers to be intact and all hinges and closing handles must be oiled and kept free.

Chain, Hook and Ponder Ball - This assembly is to be kept painted with a highly visible or fluorescent paint, most commonly dayglow orange, and must be maintained in this condition. Ponder ball swivels are to be maintained free and must be marked with the safe working load of the rig. With continual slight movement taking place between the mating faces of the chain links, it is inevitable that some wear will occur, and these areas are to be periodically checked.

Oil Cooling Ducts and Grills - Make sure watertight access doors are open, and all trunking/cooling fins/grills are clear of residual cargo dust and obstructions.

Slip Rings - Electrician to megger test prior to operation.

Electric Cable Lead Pulleys - Must be checked and maintained free. Failure to maintain these in a free condition will result in the electric cable abrading/chaffing with consequent damage. Before commencement of cargo operations, the electric cable is to be manually pulled to check the free operation of the cable guide pulleys. If the guide pulleys do not move then they may be adjusted too tightly or may be seized, and steps must be taken to ensure free turning.

Electric Power Cable/Plug and Socket - Electrician carry out a megger test prior to them being connected. On taking off the watertight covers, any residual water/moisture must be completely dried out.



11.4.2 CHECKS ON LIFTING GEAR PRIOR PROCEEDING TO SEA

It is mandatory that, on every occasion, and without exception, crane jibs are lowered into the jib crutches and secured before putting to sea. The electric plugs and sockets are to be covered against entry of water, and the electric cable is to be hove sufficiently tight to prevent chaffing when the vessel is working in a seaway. All crane windows, doors and ventilation hatches are to be closed and any portable guardrails and/or chains to be replaced. If the vessel carried grabs or other cargo handling equipment, they shall be well secured on every occasion before the vessel proceeds to sea.













12.   STABILITY & CARGO DISTRIBUTION



12.1 GENERAL

Different types of cargoes require a wide variety of care and attention. This section does not attempt to cover individual cases but will cover general rules which apply to most cases. Master is to ensure that sufficient information is obtained from the relevant publications/sources   concerning the cargo  to  be  loaded and if any doubt exists as to the requirements for the carriage of any commodity then  Office is to  be contacted.



12.2 STABILITY AND STRESS



12.2.1 Priority must always be to ensure that the proposed cargo can be safely loaded, always ensuring that the  vessel has adequate stability for all stages of the intended voyage This is particularly important  in the event of multiple port discharging, to ensure that  moments are within acceptable limits when proceeding between ports with partially filled cargo compartments.



12.2.2 The distribution of the cargo must always be such that the vessel's stress or bending limits are never exceeded as defined in the loading manual. It must be ensured that this is the case for all stages of intended voyage. The most critical times are during loading and discharging operations when it must be ensured that the shore installation personnel are adhering to the predetermined loading or discharging program to ensure that stress and bending limits are not exceeded. Caution must also be exercised when loading or discharging in such a manner which requires any compartment to remain empty for any stage of the voyage, such as multiple port loading/discharging or carriage of heavy cargoes which require one or more of the vessel's holds to be empty. If there is any doubt that the vessel may be over stressed during loading or discharging, operations must be ceased immediately. Operations must not be recommenced until such time as the situation has been re-checked, and it is satisfied that operations can continue without danger to the vessel.



12.2.3 It is the Chief Officer's responsibility to carry out the necessary calculations to ascertain the vessel's stability and stress/bending moments. It is the responsibility of the Master to check and approve or amend these as he sees fit.



13.   STEEL CARGO



13.1 Whenever the vessel is scheduled to load finished steel products (e.g. coils, slabs etc), the Master is to contact the office with regards to the appointment of a P&I surveyor. The Master is to ensure that a pr-loading survey is carried out of the cargo by the P&I surveyor. This is done to establish the condition of the steel at the time of loading to ensure that the Owner’s position is protected in case there are any claims at the discharge port or after discharge.



13.2 Particular attention is to be paid to the following:

Ensure that hatch covers, packing, compression bars, ventilators, access hatches etc are all checked for watertight integrity. Tests carried out (e.g. hose or chalk) are to be recorded in the deck log book.

Silver nitrate tests are to be conducted at loading, especially on steel which appears rusty and/or wet or where there is any suspicion that the cargo may have been in contact with salt water. If this test is not done, then there is a risk that any test carried out later at the discharge port will be used against the ship for salt water contamination.

The Master to monitor the progress of the surveyor and will report any adverse finding back to the office.

Mate’s Receipts and Bills of Lading must be claused with remarks that accurately reflect the cargo’s condition, including any rusty appearance or positive result from a silver nitrate test. The surveyor may assist the Master in the clausing of these documents, however this does not release the Master of his responsibility. If the Master is in any doubt he is to contact the office for further guidance and advice.







13.3 If the above precautions are carried out, this will assist the ship owner to reject any claims should they arise at a later stage. Accurate records greatly assist the Owner to defend claims and photography plays a vital role in supporting documentary evidence. Photographs are to be taken of any damage or rusting of the cargo at both the loading and discharge ports.



13.4 Seawater has a devastating effect on steel products. It is therefore essential that hatch covers and other openings are absolutely water-tight and that holds are cleaned in advance of loading with fresh water.



13.5 Good ventilation is essential and a record of air and hold temperatures along with dew points are to be recorded as well as times of ventilation and by what method.



13.6 Finally, steel cargo can be potentially a dangerous cargo in relation to the ship’s structure with cargo shift and handling during loading and discharging operations. Also it is important that tank tops are not over-loaded in order to avoid the buckling and damage to plates. Should any mishandling or damage by stevedores be noted by ship’s staff then a note of protest is to be issued or a stevedore damage report as applicable. Extra securing points may be required to be welded to the hold. Where this is carried out it is important that the correct hot work procedures are followed as well as the need to recoat the space (e.g. ballast tank) on the opposite side of where the securing point has been welded. The vessel must not proceed to sea until the Master is satisfied that the securing arrangements are suitable for the voyage.



14.   VESSEL PERFORMANCE AND SAFETY REQUIREMENTS



14.1 CHARTER PARTY REQUIREMENTS

A copy of the charter party applicable to the vessel will be put on board as soon as possible, by Managers, Charterers or their agents. If it is not immediately available, all the necessary information will be sent in brief by telex or tele-fax to enable the vessel commence the voyage. If vessel require clarification or advice on any aspect of the charter party, vessel must contact the Office. The Master is responsible for ensuring that the vessel performs as described in the charter party at all times. If there is any inability to comply with any requirements under the charter party, the Company will advise the Owners and enter into discussions with the charterers. Similarly, the Master must ensure that any instruction or requests from the charterers come within the requirements of the vessel, Master and crew as defined in the charter party, otherwise advice must be obtained from the Company before complying with such instructions or requests.



14.2 CARRIAGE OF DECK CARGO



14.2.1 Deck cargo, if carried, are to be stowed in such a way, providing safe access to and from working areas.



14.2.2 If access to working areas is necessary over a deck load, as with lumber, a catwalk will normally be required, unless a level, continuous surface free of encumbrances such as lashings is already provided. When catwalks are required they are to be at least one meter in width and provided with adequate guard rails. Where the deck cargo is sufficiently level for gangway purposes without a catwalk, guard rails, or life lines, spaced not more than 300mm apart vertically, must be provided on each side of the deck cargo to a height of at least 1.2 meters above the cargo.



14.2.3 If deck access is provided on deck adjacent to the deck cargo a level continuous passage at least 1 meter in width must be provided. This access is to be unencumbered by shoring, lashings or other obstacles deemed hazardous to normal passage.



14.2.4 When personnel are require d to traverse over deck cargo, ladders adequate for safe access must be provided between the top of deck cargo and the deck. Such ladders must be provided with guard rails or safety lines as previously described for catwalks. An adequate bulwark or railing is to be provided between the deck cargo and the ship's side.



14.2.5 All sharp edges and projections on deck cargo adjacent to normal accesses must be adequately protected to prevent injury to personnel.



14.2.6 Sufficient lighting must be provided by the vessel to illuminate deck access and working spaces during the hours of darkness.



14.3   CARRIAGE OF COAL



14.3.1 The carriage at sea of coal of all types can produce potential flammability hazards.

All grades of coal emit methane, which is odourless, lighter than air, and has a flammability range of approximately 5% to 15% by volume. It can be detected with an explosimeter. Particular attention must be paid to providing effective surface ventilation to circumvent the build up of methane gas, especially during times of following wind and in the period immediately subsequent to an enforced shut-down of surface ventilation due to adverse weather.



14.3.2 Some types of coal are susceptible to spontaneous combustion, where the presence of oxygen assists the temperature of the coal to rise to a point at which self-ignition occurs.



14.3.3 The following precautions must be observed when carrying any coal cargo:

Cargo temperatures in any hold containing coal are to be monitored and recorded daily.

A sustained increase in cargo temperature is to be reported to the Company.

The methane content of any hold containing coal is to be monitored and recorded daily.

Any recordings of methane content in excess of 10% of the lower explosive limit (LEL) are to be reported

immediately to the Company.

Surface ventilation is to be effected at all times when carrying coal, weather permitting, unless heating is

detected, when the vessel  should be guided by the provisions of the IMO code for Category C cargoes.

Strict attention must be paid to ensuring that methane build-up does not take place during period of following wind, when surface ventilation may prove ineffectual. If methane emission has been detected, the monitoring frequency is to be increased during such periods. Under no circumstances is ventilation to be attempted within the bulk of the cargo.

Particular care is to be exercised in respect of any work being conducted on deck when methane concentrations have been detected in any hold. Following periods of enforced suspension of surface ventilation due to adverse  weather, no work whatsoever is to take place adjacent to hatches save that strictly necessary to reopen the vents until the methane concentrations in all holds has been established and, where necessary, reduced below 10% of the lower explosive limit.

Entries are to be made in the Deck Log when any change in surface ventilation procedures is effected and the reasons for such changes.

No sources of ignition must be present outside the accommodation when coal is being carried or handled.

Smoking Regulations are to be complied with, and the use of naked lights are forbidden forward of the

accommodation.

Electrical leads and non gas-tight lighting and torches are not permitted in or near coal holds during passage.

Care must be taken to see that methane is not allowed to enter accommodation or store spaces



14.4 CARRIAGE OF DANGEROUS CARGO



14.4.1 The Master must ensure that the vessel has all the relevant IMDG Certificate and Reference Publications onboard and that these are kept corrected and up-to-date by a competent Deck Officer. These publications must be readily available, and all officers aware of them, and of their importance.







14.4.2 The Master is to ensure that he receives the details of all hazardous cargo to be loaded and that a pre-stowage plan is presented, and agreed before any hazardous containers are loaded. Care must be taken that any hazardous containers being loaded do not broach the segregation limits of other hazardous containers.



14.4.3 Copies of all hazardous cargo manifests and plans are to be kept up-to-date and readily available .

14.4.4 All relevant personnel must be kept well aware of all hazardous containers/cargoes to be loaded in deck or holds, the pre-stowage plan, segregation and any special requirements. All special requirements such as fire hoses being rigged, fire extinguishers in attendance, no smoking boards, fire wires being in place at bow and stern, B flag etc must be fully observed.



14.4.5 All IMO Rules and Regulations for the carriage of Dangerous Goods must be strictly complied with.



14.4.6 Special attention must be paid to the position of hazardous cargoes when planning for deck repairs.



14.4.7 The Master must be satisfied that adequate safety equipment and protective clothing is on board for use in the event of leakage, spillage or other mishap of any hazardous commodity.



14.4.8 The OOW must check the labels of all hazardous containers against the hazardous cargo manifest and ensure the correct labels are displayed.



15.    EMERGENCY PROCEDURES RELATING TO CARGO



15.1 FIRE IN CARGO HOLD



15.1.1 The initial action for dealing with a fire in a cargo hold will be the same regardless of whether a ship is at sea or in port. Upon discovering such a fire, either visually or through the smoke detector, the Emergency Alarm must be sounded at once and the Emergency Party mustered. The Chief Officer or the Senior Deck Officer on board is to direct the Emergency Party. His actions are to be governed by circumstances, but initially he must investigate the situation and assess the gravity of the fire. If personnel are, or have been, working in the affected hold a search must be made whilst commencing remedial action. The investigation is to determine if the fire can be dealt with using hoses, or if the fixed fire extinguishing system , where provided,  will be required. Whatever the outcome the Emergency Party must rig fire hoses around the affected hold and cool the deck.



15.1.2 The following are further guidelines should the fixed fire extinguishing system be required:

The hold must be sealed and ventilation stopped and sealed.

When preparing the fixed fire extinguishing system for use, it is vital for all members of the Emergency Organisation to follow the instructions of the Chief Officer (or his deputy) to avoid the danger of CO2 being released before personnel are clear and the hatch is sealed.

Whenever possible, a check must be made of the temperature in the hold on fire and the surrounding spaces.



Hatches must only be reopened when the Local Fire Service is in attendance, and never at sea. When such a fire occurs in port the local Fire Service must be called without delay and upon arrival the Senior Fire Service Officer will normally assume control of the operation

It must be remembered that the concentration of CO2 in the hold must be maintained to compensate for leakage.



15.1.3 Re-ignition is likely to occur if the hatch is opened too soon and this may well be uncontrollable. Should entry be essential, every precaution must be taken to prevent re-ignition and the temperature of the hold carefully monitored.







15.2 FIRE IN DECK CARGO



15.2.1 In the event of a fire occurring in a deck cargo, it may be necessary for the Master to take the way of the vessel or alter course to put the wind astern in order to reduce the airflow over the deck. Whilst it is impossible to lay down specific guidelines for dealing with such a fire, the Chief Officer should direct the Emergency Party to bring as many hoses as possible into action from an upwind position.



15.2.2 With fires involving chemical cargoes, it is important for the Emergency Party to remain well upwind. The same applies to a spillage (not resulting in a fire) of a chemical cargo on deck.



15.2.3 In port, the Oil Spill Contingency Plan must be put into action and the Port Authorities informed. Action here will depend on firstly, the danger to life on board and secondly, environmental considerations. If it is to be washed overboard, the spillage is to be washed overboard using copious quantities of water applied in the form of a spray only. Breathing apparatus and protective clothing must be worn.



15.2.4 Special instructions to deal with a leakage, or fire in, dangerous chemicals carried, as deck cargo must always be available before sailing from the loading port. In special cases, additional protective clothing will also be required.



All above operations are to be carried out safely keeping in mind the prevailing weather conditions and under sole discretion of Master.



16.    FORMS IN USE

FPMF-15-01 CARGO PRE LOADING CHECKLIST

FPMF-15-02 CARGO WATCH CHECKLIST

FPMF-15-03 CARGO POST LOADING CHECKLIST

FPMF-15-04 CARGO PRE DISCHARGING CHECKLIST

FPMF-15-05 CARGO POST DISCHARGING CHECKLIST

FPMF-15-06 CONTAINER CARGO CHECKLIST

FPMF-15-08 NOTE OF READINESS.

FPMF-15-10 IMDG CARGO ON DECK





















































