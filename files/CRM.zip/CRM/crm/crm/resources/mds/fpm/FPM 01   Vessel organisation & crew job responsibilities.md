



1. VESSEL ORGANISATION AND CREW JOB DESCRIPTIONS



1.1 SHIPBOARD ORGANISATION CHART





1.2 JOB DESCRIPTION OF SHIPBOARD PERSONNEL:

The responsibilities defined in the job description are non-exclusive and therefore do not exempt any officer/

rating from performing tasks assigned to him other than those given below or from acting prudently in

situations when action is required.



1.2.1 MASTER



1.2.1.1 REPORTING TO:  The Vice President



1.2.1.2 AUTHORITY: Owner’s representative has complete authority on all aspects of the ship (operations,

safety, pollution prevention & cargo care).



1.2.1.3 RESPONSIBILITY:

The Master has the overriding responsibility for the safe operation of the ship.

In order to ensure the safety of life, environment and material values - including ship, cargo, equipment

etc…the Master shall ensure that the following functions are conducted safely and professionally,

in accordance with approved work procedures

The ship is fully equipped, well maintained and in all respects seaworthy.

The ship’s crew is competent and well informed of appropriate levels of safety and environmental

protection.

He shall evaluate the performance of the Staff under him and fill up the confidential report on Format

FPMF-01-02

Navigation and machinery operation.

Port entry, stay and departure, readiness for sea.

Cargo operations, Passenger- embarkation/ Dis-embarkation.



Ballasting/De- ballasting

Bunkering.

Further he shall ensure that sufficient time and resources are allocated to execute the following

activities effectively:

- Maintenance of ship, machinery and equipment

- Maintenance of classification status and certificates

Safety training and drills

Maintenance and control of hygienic and safe conditions in the accommodation, galley and provision-

stores

Procurement of safe stocks & provisions

Assignment of the Safety Officer function to a qualified officer

The Master is responsible for the implementation follow up and improvement of the SMS.

The Master delegates responsibilities to the Chief Engineer and the Chief Officer including the supervision

of Junior Officers but retains direct command of Officers responsible for bridge watches when underway.

The Master shall fill in the form no. FPMF-01-03 for his CHANGE OF COMMAND



1.2.2 CHIEF OFFICER



1.2.2.1 REPORTING TO: The Master



1.2.2.2 AUTHORITY:

The Chief Officer is delegated authority by the Master to execute his responsibilities and in the Master’s absence,

to act as his deputy.



1.2.2.3 RESPONSIBILITY:

The Chief Officer supervises the deck crew and all activities executed by the deck department

and responsible for the safety of cargo/passenger at sea, handling of ballast and for proper

deck maintenance. He is responsible for all matters related to vessel cargo and stability.

He shall assist the Master in all matters related to the safe and efficient operation of the ship, and

in emergencies is the leader of all deck department emergency efforts.

The Chief Officer shall ensure that the following requirements are met, and that  activities are

executed safely and professionally, in accordance with approved work procedures:-

To issue standing instruction concerning the cargo/ ballast operation which are understood clearly and

signed by all deck Officers.

That each individual is given the opportunity of improvement through selective on-the-job training.

That deck equipment, safety equipment are well maintained and are in good order.

•	Chart index register as applicable

•	Medical locker

In case third Officer is not there as per safe manning, he takes over the responsibilities of Navigational

Equipments and records.



1.2.4 THIRD OFFICER



1.2.4.1 REPORTING TO: The Chief Officer on cargo, LSA/FFA etc and to master on navigation

and communication.



1.2.4.2 AUTHORITY: Delegated authority by the Master/Chief officer to execute assigned responsibilities.



1.2.4.3 RESPONSIBILITY:

The Third Officer is responsible to the Master for the proper performance of his assigned bridge

watch standing and navigational duties.

He is responsible to the Master through the Chief Officer for watch duties pertaining to handling

cargo, ballasting and de-ballasting and various maintenance functions on the safety equipment.

The Third Officer must become completely familiar with deck equipment/systems, and any gear if

fitted for cargo operations and learn to plan the operations and carry out as per instructions.

In the event that a vessel carries two Third Officers, the Chief Officer shall divide the duties of a Third

Officer between the two officers.  Each Third Officer may be assigned duties to assist the Second Officer.





Upon joining a vessel, the Third Officer must report to the Master.  He must discuss with the officer

being relieved the areas of responsibilities and inspect them promptly, preferably in the company of

the officer being relieved.  Anything found to be unsatisfactory must be reported to the Master.

In general the Third Officer is responsible to the Chief Officer for cargo / deck watches in port and

shall report to the chief officer of any deviations from the planned activities.

The Third Officer must observe the vessel’s draft and enter it in the deck log before departure and on

arrival after reporting it to the Master.

The Third Officer is responsible for the care of the ship’s signaling and searchlights.  He is responsible for

the vessel’s International Code Signal flags and national ensigns and must ensure that the proper sets

are on board and available for immediate use.

The Third Officer is responsible to the Master for maintaining and accounting for all training publications

and training aids, including films and other audio visual equipment.

The Third Officer is responsible for maintaining the port log and submitting it to the Master for signature.

If there is no third officer on board as per Safe Manning, the above responsibilities shall be shared by

Chief Officer (LSA & FFA) and Second officer (Navigational equipments and records).



1.2.5 DECK RATINGS



1.2.5.1 REPORTING TO: Chief officer and duty officer



1.2.5.2 RESPONSIBILITY:

To perform sea watch and deck watch duties including assisting in cargo operations as instructed and to

carry out maintenance work and other operational tasks as required.

To familiarize himself with work procedures pertaining to tasks to be executed.

To execute assigned tasks in conformance with work procedures as instructed by the Duty Officer

or Ch/Officer

To execute assigned tasks safely, to the best of his ability, and to report hazardous conditions without

delay to the Duty Officer or the Chief Officer.

Work such as entry into enclosed spaces, hot work and work aloft shall not be undertaken without

prior approval by the Chief Officer or Master.

Familiarize him self with all safety equipment and safety procedures onboard.



1.2.6 CHIEF ENGINEER



1.2.6.1 REPORTING TO: The Master



1.2.6.2 AUTHORITY: Delegated authority by the Master to execute assigned responsibilities.



1.2.6.3 RESPONSIBILITY:

The Chief Engineer shall ensure:

That propulsion and auxiliary machinery, including electrical installations, and deck machinery is

maintained in good condition.

That all machinery is operated with good seamanship and in accordance with the applicable

regulations, maker’s instructions, Company directives and the Company Quality Management System.

During maneuvering in restricted waters and under abnormal conditions, the Chief engineer shall be

present in the engine-room or on the bridge and shall at all times maintain communication with engine

-room and bridge.

That Engineers and Engine-ratings are well informed of their duties and applicable work procedures,

and of safety and pollution prevention measures.

He shall evaluate the performance of the Staff under him and fill up the confidential report on Format No. Refer manual FPMF 01 – 02.

Further he shall ensure that the following functions are conducted safely and professionally in

accordance with approved work procedures:  Machinery operation, maintenance and repair work

Classification status for machinery

Record of technical certificates, including documentation of spare parts.

Maintenance as per PMS system and record keeping

Calculation of safe stocks of fuel oils and lubrication-oils for each sea-passage

Adherence to safe procedures during bunkering to prevent overflow and pollution

Separation and proper discharging of oily-water mixtures, from the engine room



Maintenance and testing of:

•	Alarm systems

•	Emergency alarm systems

•	Fire extinguishing installations

•	Emergency fire pump/Emergency generator.

•	Technical/engine systems for the rescue boat.

Monitoring the Ship Energy Efficiency Management onboard as described in the Ship Energy

Efficient Management Plan (SEEMP). He shall fill in the form FPMF-04-03: SEEMP-CALCULATION OF

ENERGY EFFICIENCY OPERATIONAL INDICATOR (EEOI) monthly in order to access the energy efficiency

on-board.

He shall fill in the form FPMF-01-04 for his handing over to the next chief engineer.



1.2.7 SECOND ENGINEER



1.2.7.1 REPORTING TO: The chief engineer



1.2.7.2 AUTHORITY:

Delegated authority by the chief engineer to execute assigned responsibilities, and in the chief engineer’s

absence, to act as his deputy.



1.2.7.3 RESPONSIBILITY:

The 2nd Engineer is the Supervisor of all work performed by subordinate engineers and engine crew.

He shall assist the Chief Engineer in all matters related to safe and efficient operation of all machinery.

He shall ensure that the engine room with all facilities and equipment is maintained with proper

cleanliness, and that machinery is maintained in good working condition.

He shall be familiar with all systems in the Engine Room.

He should be familiar with all safety equipment and fire drills, including personal responsibilities during

fire.

Further, he shall ensure that the following requirements are met and that the following activities

are executed safely and professionally, in accordance with approved work procedure:

That each individual is given the opportunity of improvement through selective on-the-job training

That Personnel executing hazardous work are well informed of the work procedures to be adhered to.

That machinery is maintained, in accordance with maintenance plans as approved by the Chief Engineer,

to function as designed.

That modification of the safe work procedures is initiated if proved to be insufficient or faulty.

That spare parts and engine-stores are received, checked and safely stored and that replenishments

are ordered through the Chief Engineer.

Prepare short term working plans & execute engine watches at sea and in port as assigned by the C/E



1.2.8 THIRD ENGINEER / FOURTH ENGINEER / TME (IF ONBOARD AS PER SMD)



1.2.8.1 REPORTING TO: Chief engineer with regard to watch-keeping & Second engineer with respect

to maintenance routines.



1.2.8.2 AUTHORITY: Delegated authority by the Engineer to execute assigned responsibilities.



1.2.8.3 RESPONSIBILITY:

To execute engine watches at sea and in port as assigned by the Chief Engineer and to assist the

2nd Engineer with all tasks related to machinery operation and maintenance.

To familiarize himself with regulations and work procedures pertaining to tasks assigned to him or

to be executed under his responsibility.

Routine surveillance of equipment and installations specifically assigned to him.

He is responsible for operating the rescue boat engines during drills and their regular testing





1.2.9 ELECTRICAL OFFICER. (C/E TAKES THE RESPOSIBILITY IN HIS ABSENCE)



1.2.9.1 REPORTING TO: The chief engineer



1.2.9.2 AUTHORITY: Delegated authority by the chief engineer to execute assigned responsibilities



1.2.9.3 RESPONSIBILITY:

He is responsible for the maintenance and efficient working of all electrical and electronic equipment on

board. His duties include preventative maintenance and daily checks of all alarms.

He is responsible for making out timely defect list, stores and spares indents and submitting same to the

Chief Engineer for approval.

Maintain up to date stores and spares inventory and submit maintenance on time.

Apart from his normal duties, he shall pay special attention to routine inspection and maintenance of

electrical hydraulic cranes and grabs and shall assist other Engineers in breakdowns so as to keep the

down time to a minimum.

He shall assist Chief Engineer in Air-Conditioning Plant and Provision Refrigeration maintenance and shall

also assist with galley equipments.

Carrying out Electrical Motor Overhauling and maintaining records.

Assist navigating officers with repair work on all navigational equipment.



1.2.10 ENGINE RATING



1.2.10.1 REPORTING TO:  The Duty Engineer during watch duties and the 2nd Engineer during other

operational or maintenance work



1.2.10.2 RESPONSIBILITIES:

To perform Engine Room watches as instructed by the Duty Engineer and carry out operational

and maintenance work within his capabilities.

To familiarize him with regulations and work procedures pertaining to tasks to be done.

To execute assigned tasks under the supervision of the Duty Engineer

To execute other assigned tasks safely, to the best of his ability, and to report hazardous conditions

without delay to the proper supervisory authority.



1.2.11 COOK



1.2.11.1 AUTHORITY: Delegated authority by the Master to execute assigned responsibilities.



1.2.11.2 REPORTING TO:  The Master



1.2.11.3 RESPONSIBILITIES:

The Cook is responsible for the catering function on board.

He shall order provisions, maintain the required stock levels at all times.

He receives controls and arranges for preservation of food and all the supplies in dry and cold storage.

Responsible for the maintenance of cleanliness and hygiene in stores and galley.

He shall provide sufficient and healthy diets with a reasonable degree of variety.

Responsible for all preparation of food and shall ensure that it is prepared under hygienic conditions.

To prepare and present to the Master, consumption reports regarding provisions.

To dispose galley garbage / wastes under the Chief Officer’s directions



1.2.12 GENERAL STEWARD (GS) (IF ONBOARD)



1.2.12.1 REPORTING TO: Chief officer.



1.2.12.2 RESPONSIBILITIES:

To prepare mess room for serving breakfast, lunch & dinner.

To clean all officers’s cabin daily.



To dispose off garbage from cabins, pantry and galley daily.

To clean officer’s mess room, recreation room & pantry daily.

To prepare tea/coffee/lime juice/snacks as required for all officer’s during short breaks in mornings/

evenings.

To assists cook in preparing.

To assist cook in arranging & cleaning meat/fish/vegetable rooms & dry provision stores.

To clean all officer’s linen on weekly basis and replace same.

In his absence Chief officer will allocate the responsibility to deck rating .





1.2.13 RECORDS:



1.2.13.1 Following records shall be maintained as per the procedure.

FPMF-01-01 - STCW REST/WORK HOURS

FPMF-01-02 – PERFORMANCE APPRAISAL REPORT

FPMF-01-03 – MASTERS HANDING OVER REPORT

FPMF 01-04 – CHIEF ENGINEERS HANDING OVER REPORT

FPMF 01-05 – DECK LOG ABSTARCT



