



10.1 SAFETY PROCEDURES AND STANDARDS



10.2 INTRODUCTION

10.2.1 Safety is the state in which the risk of harm to persons or damage is limited to an acceptable level.



10.2.2 Effort of Masters and crew members must be preventive/proactive versus reactive for following

reasons: Preventive or proactive focus is always less risky and less expensive than being reactive.



10.2.3 Proactive approach reduces following:

Incidents and associated costs

Legal liabilities

Insurance costs.

Proactive approach improves

Safety, health and work environment

Employees’ morale

Effectiveness of continuous improvement process



10.2.4 Public relations

Reactive is always riskier and more expensive than proactive.

Reactive approach increases:

Potential for incidents

Cost of compliance.

Legal liability

Insurance costs.

Masters, Officers and crewmembers should keep in mind following company beliefs that guide conduct

of company fleet operations.

Accidents and injuries are preventable.

Each company employee has personal responsibility for his own safety and safety of others.

No business relevant objective is of such importance that it will be pursued at safety’s sacrifice.

A job is considered well done if it is safely done.



10.3 OFFICER RESPONSIBILITIES



10.3.1 Officers are responsible for: Familiarizing themselves and enforcing relevant safety requirements for every

job undertaken onboard vessel.



10.3.2 Ensuring:

Personnel onboard obey applicable safety and health rules and standards outlined in this chapter.

Personal safety and health related equipment to be ordered to meet appropriate standards and is approved

by Company.

Safety of subordinates and vessel, to achieve that instruct, train, hold safety sessions and direct all work

carried out.

Before commencing assigned job:

Hold briefing to review safety standards.

Give working party opportunity to ask questions and make suggestions.

In areas where risk potential exists and cannot be eliminated:

Familiarize working party with situation.

Develop means to prevent accident or harmful situation.

Nothing in following rules or practices should be interpreted as relieving any officer from responsibility

for undertaking most effective action which, in accordance with his judgment, may be necessary to

prevent accidents to personnel, vessel and transported cargo etc….













10.4 RESPONSIBILITIES OF CREW MEMBERS



10.4.1 Each crew member onboard company vessel must be prepared to:

Contribute in prevention of accidents involving personnel, vessel or transported cargo.

Familiarize him and comply with safety standards and rules before undertaking any job.

Before commencing assigned job answer following questions:

. Is there anything new/special about job that may create potential danger or risk?

. Are rules and procedures involved known?

. What types of hazards are involved?

. Has officer in charge of assigned job discussed it with crew (expectations and potential hazards)?

. How can hazards be avoided or eliminated?

. Are correct tools/equipment in place and operable?

. Is proper personal protective gear being worn?

. Will assistance be required (especially crucial when lifting is involved)?

. Have applicable safety/health standards been reviewed and understood?

10.5 VISITORS ON BOARD:



10.5.1 Company policy allows only those visitors who have Master’s permission to board.



10.5.2 Crew member or company employee who requests permission to bring guests onboard is responsible

for ensuring that guests are properly supervised and in compliance with company’s rules and regulations, as well

as with ones of facility where vessel is docked.



10.5.3 Before granting permission for guest to board vessel following must be taken into consideration:

Prevailing weather conditions

How easy it will be for guest(s) to board and leave vessel.

Age and physical condition of individuals boarding

Whether guests have been informed about proper clothing to board vessel.

Whether guests are informed of company’s drug and alcohol policy



10.6 PORT FACILITY REGULATIONS



10.6.1 Upon boarding vessel guests report to Deck OOW who arranges for safety orientation.



10.6.2 When visitors are leaving vessel, Deck OOW is properly notified.



10.6.3 Company policy is not to permit any spouses of Officers or crew to sail on board the ships.



