





FLEET PROCEDURES MANUAL







NMG MARINE SERVICE PVT. LTD

SR TOWERS, NO.14, 4TH FLOOR, 4TH LINE,

NORTH BEACH ROAD, CHENNAI - 600001.

INDIA



TEL: 044- 48530742

Email: info@nmgmarineservice.in

Web : www.nmgmarineservice.com









This manual is the property of NMG MARINE SERVICE PVT LTD and shall be returned to the DPA when the controlled copyholder ceases to be an authorized recipient of this manual. No part of this manual shall be reproduced in any form whatsoever without the prior written permission of the DPA.















This manual is approved by:   Managing Director



