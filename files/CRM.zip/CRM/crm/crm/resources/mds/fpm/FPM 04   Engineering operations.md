

4. ENGINEERING OPERATIONS



4.1.1 INTRODUCTION



4.1.1.1 Chief Engineer is responsible for safe, efficient and cost effective operation of Engine Department.



4.1.1.2 He is key figure for establishing and maintaining high standards of professional conduct and

integrity amongst Officers, including compliance with pertinent international and national laws and regulations

as well as with Company policies.



4.1.1.3 He has responsibility of providing guidance and leadership to subordinates and assisting Engineer’s to

full fill his responsibilities.



4.1.1.4 He shall detail his Standing Orders and shall have his Night Orders written.



4.1.2 GENERAL OPERATIONS

Engine Department operations and maintenance must be conducted safely, efficiently, cost effectively and in

strict compliance with laws, regulations, and good engineering practices.



4.1.3 Chief Engineer or 2nd Engineer shall be onboard during:-

Cargo work, ballast or bunkering operations, Major Engine Room maintenance operations.

Severe weather that may lead to actions that requires operation of main engines or vessel to be

moved from current position (e.g. when at anchor)

Safety is always of top priority and must never be compromised.

It is responsibility of each Engineer to ensure that tasks undertaken by them can be efficiently

accomplished without risk for personnel, vessel cargo. Unsafe acts, practices are not tolerated.

Manufacturers' instructions are followed during operation, inspection, maintenance and repair of

machinery, systems and equipment.



4.1.4 DUTY ENGINEER:



4.1.4.1 To ensure safe and efficient operation of propulsion plant machinery and auxiliary equipment



4.1.4.2 Comply with Chief Engineers Standing Orders.

4.1.4.3 Responsibilities of the Duty Engineer



4.1.4.3.1 Engine Room must never be left unattended while Navigation



4.1.4.3.2 Duty Engineer is responsible for safe and efficient operation in Engine department .



4.1.4.3.3 He must be fully aware and informed of consumption of:-

Fresh water

Fuel oil for main engines / auxiliary engines and boilers

Lubricating oil



4.1.4.3.4 He must ensure that:

There is a careful inspection of machinery spaces at least once a watch or more frequently. During

these inspections, particular attention is given to Gauge readings, bearing temperatures etc… of:

Auxiliary machinery

Propelling machinery

Cargo machinery if in engine room

Lubricating oil levels and pressures

Tank tops and drip pans in Engine Room are clean and oil free.

Machinery space bilge is kept as dry and clean as possible.





Guard against Personnel injuries, Immediately report to Chief Engineer for any doubts or concerns

relevant to status or condition of plant or machinery.

Note defects and take appropriate action as necessary to correct. Operate machinery in a cost

effective fashion. Safety precautions to be taken like

Fire fighting apparatus in readiness

Use of personnel protective gear

Perform and follow as per Chief Engineer standing instructions

Respond to requirements for machinery or emergency equipment/services as dictated by

prevailing circumstances.

Complete entries in Engine Room Log Book /Cargo Log Book  as required, keeping in mind following:

Entries must be clear and legible.

All errors detected must be corrected by single line striking through text to be corrected.

In case of unusually high consumption Engineer on Duty makes effort to:  Detect cause of

high consumption. Initiate appropriate corrective action(s) and inform Chief Engineer in due time



4.1.4.4 RELIEVING DUTY ENGINEER



4.1.4.4.1 Reports to Engine Room at least  15 minutes before assuming relevant duty

Ascertains, from previous watch keeper, details of plant status including:

Bilge, fuel, lubricating oil and water tank levels

Last speed request from Bridge (designated RPMs)

Machinery in operation

Plant machinery defects or unusual indications

Watch personnel in machinery spaces

Work in progress and work to commence during relieving watch keeper’s watch.

Relieving Duty Engineer does not assume watch until:

He has received all information required

He is ready, in all respects, to assume all relevant duties

On taking over watch Duty Engineer makes a complete round of Machinery spaces, noting or being notified of defects (actual or potential) and taking appropriate action. Steering gear and other machinery in operation outside machinery spaces, they must be inspected prior to entry into the Engine room.



4.1.4.5 OUTGOING DUTY ENGINEER:



4.1.4.5.1 He does not stand down until:

Assured that relieving Officer is physically capable to relieve and stand Engine Room watch.

Identified defect(s) has been corrected or additional assistance called.



4.1.5 INFORMING THE MASTER



4.1.5.1 Master must be immediately informed of:-

Machinery damage

Failure affecting seaworthiness of vessel or operating capability of vessel .



4.1.6 VESSEL OPERATING CONDITIONS ( DEPARTURE/ARRIVALS /RESTRICTED PASSAGES ETC…)

4.1.6.1 Chief Engineer:

Ensures Engineering personnel are adequate for safe operation of machinery.

Is notified on receipt of notice of “standby engines”

Engine telegraph is tested and entry made in Log Book.

Main engine should be prepared in accordance with plant operating instructions.

Steering gear is tested and results recorded in Engine Room Log Book.

Duty Engineer makes visual inspection, where required, of:

Oil and Grease level

Operating pressure and temperature

Abnormal sound, Condition of Links and pins



Electrical current of motors

Electrical load on generators if more than one is running in parallel.

Any abnormality is reported to both Chief Engineer and Master as soon as possible.



Power required for deck machinery should be available.

If conditions permit main engine should be tested ahead and astern in consultation   with Master.

When Chief Engineer is satisfied that all Engine preparations have been successfully carried out, Master

is notified that Engine Room is ready to accept “Stand by Engines” order.



4.1.7 RECORDS:

FPMF-04-01 ARRIVAL /DEPARTURE CHECK LIST

FPMF-04-02 MAIN ENGINE PERFORMANCE DATA

FPMF-04-03 SEEMP-CALCULATION OF ENERGY EFFICIENCY OPERATIONAL INDICATOR (EEOI)

