

13. MASTERS SMS REVIEW



13.1 SCOPE

This procedure enables the master to review the safety management system.



13.2 RESPONSIBILITIES:

The master shall be responsible for doing a review of the SMS once in six months.



13.3 DETAILS:

The following shall be the contents of the review:

External audit findings

Internal audit findings

Review of monthly safety committee meetings

Analysis of NCs, OBS, Corrective and preventive action.

Review of accidents, near misses, risks, hazardous occurrences etc…

Status of SMS implementation onboard including its effectiveness

Effectiveness of training and drills

Any other matter/Remarks.



13.4 SAFETY COMMITTEE MEETING



Safety Committee Meetings have to be conducted onboard at least once every calendar month. These

meetings provide a forum to discuss all safety issues and to recommend improvements in procedures and

practices to the company. The issues discussed during the safety committee meetings is recorded in the

“Safety Committee Meeting Report” which is forwarded to the company every month. Refer FPMF 13-02. During

the meeting, the master shall also discuss the results of his inspections and the results of inspections carried out

by flag state/ port state/ class/ superintendent on board. The Master shall chair the meeting. The meeting shall

be attended by chief officer, chief engineer, second engineer, crew and the cook. The crew on watch keeping

duties will be briefed by Chief officer and Chief engineer later regarding matter discussed in SCM.



13.5 RECORDS



FPMF 13-02 Monthly Safety Committee Meeting Report

FPMF 13-03 Master’s SMS review