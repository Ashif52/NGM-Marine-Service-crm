

12. SHIPBOARD TRAINING



12.1 OBJECTIVE

To ensure appropriate training needs are identified and provided to floating staff in order to improve their safety operation skills and their awareness in emergency preparedness through planned drills and exercises.



12.2 SCOPE

This procedure covers the identification of the training requirements, providing training of all floating staff and maintaining all training records.



12.3 RESPONSIBILITY

12.3.1 The Master shall be responsible for identifying the training requirements of all floating staff and shall provide the identified training on board. The training needs shall be based on the experience and feedback from the officers and as discussed in the safety committee meetings.

12.3.2 The Master shall record all shipboard training activities provided to floating staff in the register maintained on board the vessel.



12.4 PROCEDURES



12.4.1 FAMILIARISATION TRAINING – AT OFFICE

A) Master, Chief Officer, Chief Engineer and 2nd  Engineer briefing will be carried out by Office .

B) The Vice President/ GM (Head Fleet Personnel) / Technical Super will arrange above joining to receive familiarization training in the office prior to joining the assigned vessels.

C) The DPA will brief the company’s policies and its objectives, induction training for familiar with the SMS.

D) The GM (Head Fleet Personnel) will brief on crew affairs and the company’s policy on crewing and the working conditions.

E) The vice president shall brief on the ship’s operations, safety and pollution prevention awareness, machinery condition, maintenance, repairs, surveys, certification, any deficiency for rectification etc.

F) After all the briefing is done, it shall be documented in the briefing form FPMF12-01.



12.4.2 ON BOARD FAMILARIZATION TRAINING:

A)Safety Familiarization will be carried out for all immediately on joining the vessel and should be completed prior to departure of the vessel by chief officer. On job familiarization for deck/ engine will be carried out by chief officer and chief engineer and shall be completed within 7 days of joining. The briefing shall be documented on form No.FPMF–12-02.

B) The company expects officers to acquire a thorough understanding of the duties of their immediate superiors. Officers are also expected to prepare themselves for the next higher license. The company encourages its officers to improve their professional knowledge and skills.

C) Every officer being relieved is expected to allow sufficient time before departing the vessel to ensure the replacement officer is aware of any special features of duty assignments.  The Master or Chief Engineer should be notified prior to the relieved officer departing the vessel.  Under no circumstances, other than an emergency, should an officer depart the vessel until his relief comes on board.

D) The Chief Officer is responsible for training all junior deck officers to be proficient in all aspects of cargo and ballast operations, fire and boat drills and other duties and procedures related to these operations. Records of training shall be made on Form No. FPMF-12-04

E) The Chief Officer is also responsible for the training of all cadets and unlicensed personnel assigned to performing deck work, ensuring that they are properly instructed in safe work practices.  Each Watch Officer is responsible to the Master to ensure seamen assigned to his watch are properly trained in watch standing duties.

F) The Chief Engineer is responsible for training all junior engineer officers to be proficient in all aspects of Engine room operations and procedures. Records of training shall be made on Form No. FPMF-12-04

G) The Second Officer is responsible to the Master for maintaining and accounting for all training publications and training aids, including the CD films and other audiovisual equipment. The Vessel has to maintain such training records.

12.4.3 RECORDS

FPMF-12-01 – FAMALIARISATION AT OFFICE - MASTER,CHIEF OFFICER, CHIEF ENGINEER and 2nd  ENGINEER

FPMF-12-02 - SAFETY FAMILIRISATION TRAINING AND ON JOB FAMILIRISATION

FPMF-12-03 - TRAINING PLAN -SHIPBOARD

FPMF-12-04 - PERSONAL TRAINING RECORD



