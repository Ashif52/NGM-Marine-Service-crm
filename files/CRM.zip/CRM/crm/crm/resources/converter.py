import os
import subprocess
from docx import Document

# ================= CONFIG =================
SOURCE_ROOT = r"docs"
TARGET_ROOT = r"mds"

LIBREOFFICE_PATH = r"C:\Program Files\LibreOffice\program\soffice.exe"
# =========================================


def doc_to_docx(doc_path, output_dir):
    subprocess.run(
        [
            LIBREOFFICE_PATH,
            "--headless",
            "--convert-to",
            "docx",
            "--outdir",
            output_dir,
            doc_path,
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        check=True,
    )


def docx_to_md(docx_path):
    document = Document(docx_path)
    md = []

    for p in document.paragraphs:
        text = p.text.strip()
        if not text:
            md.append("")
            continue

        style = p.style.name.lower()
        if "heading 1" in style:
            md.append(f"# {text}")
        elif "heading 2" in style:
            md.append(f"## {text}")
        elif "heading 3" in style:
            md.append(f"### {text}")
        else:
            md.append(text)

    return "\n\n".join(md)


def convert_docs():
    for subfolder in os.listdir(SOURCE_ROOT):
        source_sub = os.path.join(SOURCE_ROOT, subfolder)

        if not os.path.isdir(source_sub):
            continue

        target_sub = os.path.join(TARGET_ROOT, subfolder)
        os.makedirs(target_sub, exist_ok=True)

        for root, _, files in os.walk(source_sub):
            for file in files:
                if file.lower().endswith(".doc"):
                    source_doc = os.path.join(root, file)

                    try:
                        # Convert DOC → DOCX (inside target subfolder)
                        doc_to_docx(source_doc, target_sub)

                        docx_file = os.path.join(
                            target_sub, os.path.splitext(file)[0] + ".docx"
                        )

                        # Convert DOCX → MD
                        md_content = docx_to_md(docx_file)

                        md_file = os.path.join(
                            target_sub, os.path.splitext(file)[0] + ".md"
                        )

                        with open(md_file, "w", encoding="utf-8") as f:
                            f.write(md_content)

                        os.remove(docx_file)

                        print(f"Converted: {source_doc} → {md_file}")

                    except Exception as e:
                        print(f"Failed: {source_doc} | {e}")


if __name__ == "__main__":
    convert_docs()
    print("All conversions completed.")
