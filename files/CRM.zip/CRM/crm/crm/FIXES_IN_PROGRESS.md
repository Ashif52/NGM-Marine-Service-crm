# Comprehensive System Fixes - In Progress

## Issues to Fix

### 1. ✅ FIXED - Certificate API Error
- **Issue**: `/certificates/expiring/60` returning error about column expression
- **Fix**: Fixed name collision in `app/routers/certificates.py` by using aliases for model vs schema
- **Status**: COMPLETED

### 2. ✅ FIXED - Added Missing APIs
- **Issue**: Missing PMS tasks, work logs (updated), recruitment APIs
- **Fix**: Added to `frontend/src/services/api.ts`
- **Status**: COMPLETED

### 3. 🔄 IN PROGRESS - Dashboard Statistics
- **Issue**: Showing 0 for all stats, should show 2 ships (1 active), 1 crew member
- **Root Cause**: Data not being loaded properly or no data in database
- **Action**: Need to verify data exists in database first, then check API responses
- **Status**: INVESTIGATING

### 4. ⏳ TODO - PMS Page Real Data
- **Issue**: PMS page using mock data for tasks
- **Required**: Connect to `/pms/tasks` endpoint
- **Files**: `frontend/src/pages/PMS.tsx`
- **Status**: PENDING

### 5. ⏳ TODO - PMS Stats (Spare Parts, Equipment, Maintenance)
- **Issue**: Stats showing fake values
- **Required**: Actually call the APIs and show real counts
- **Files**: `frontend/src/pages/PMS.tsx`
- **Status**: PENDING

### 6. ⏳ TODO - Work Logs Page
- **Issue**: Not using real backend data
- **Required**: Connect to `/work-logs` endpoint
- **Files**: `frontend/src/pages/WorkLogs.tsx`
- **Status**: PENDING

### 7. ⏳ TODO - Crew Add Member
- **Issue**: Not working
- **Root Cause**: TBD - need to check what error occurs
- **Files**: `frontend/src/pages/Crew.tsx`
- **Status**: PENDING

### 8. ⏳ TODO - Recruitment Page
- **Issue**: Not using real backend data
- **Required**: Connect to `/recruitment` endpoint  
- **Files**: `frontend/src/pages/Recruitment.tsx`
- **Status**: PENDING

### 9. ⏳ TODO - Remove Unused Pages
- **Issue**: Pages that should be removed completely
- **Pages to Remove**:
  - Documents
  - DG Communication
  - Invoices
  - Finance
  - Reports
  - Access Control
- **Files**: 
  - `frontend/src/components/Sidebar.tsx` (remove menu items)
  - `frontend/src/App.tsx` (remove routes)
  - Delete page files
- **Status**: PENDING

### 10. ⏳ TODO - Settings Page
- **Issue**: Create user not working, remove unused tabs
- **Required**: 
  - Fix create user functionality
  - Remove: Templates, Notifications, Masters tabs
  - Keep: User Management, Terms & Conditions, Privacy Policy
- **Files**: `frontend/src/pages/Settings.tsx`
- **Status**: PENDING

### 11. ⏳ TODO - Profile Dropdown
- **Issue**: Should show current user profile with update option
- **Required**: Show logged-in user's info, add profile update dialog
- **Files**: `frontend/src/components/TopBar.tsx`
- **Status**: PENDING

## Next Actions

Priority order:
1. Verify database has data (run SQL script to add crew)
2. Fix dashboard statistics 
3. Fix crew add member
4. Update PMS page with real data
5. Update work logs page
6. Update recruitment page
7. Remove unused pages
8. Fix settings
9. Fix profile dropdown
