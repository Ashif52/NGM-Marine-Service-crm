
  # NMG MODEL

  This is a code bundle for NMG MODEL. The original project is available at https://www.figma.com/design/LSH8vBtJpqs1YIkDu6ZpK5/NMG-MODEL.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  