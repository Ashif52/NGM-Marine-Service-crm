import { useState } from "react";
import { useAuth } from "../../contexts/AuthContext";
import { Card } from "../ui/card";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import {
  Ship,
  ClipboardList,
  Wrench,
  AlertTriangle,
  FileText,
  CheckCircle2,
  Clock,
  Camera,
  ChevronRight,
  Upload,
  Bell,
  Home,
  Settings,
  BarChart3,
} from "lucide-react";

export function CrewDashboard() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("tasks");

  // Mock data - replace with API data
  const currentShip = {
    name: "MV Pacific Star",
    type: "Bulk Carrier",
    status: "active",
  };

  const tasks = [
    {
      id: 1,
      type: "pms",
      title: "Main Engine Oil Check",
      due: "Today",
      status: "pending",
      priority: "high",
    },
    {
      id: 2,
      type: "daily",
      title: "Deck Cleaning & Inspection",
      due: "Today",
      status: "in_progress",
      priority: "medium",
    },
    {
      id: 3,
      type: "safety",
      title: "Fire Equipment Check",
      due: "Tomorrow",
      status: "pending",
      priority: "high",
    },
  ];

  const recentLogs = [
    {
      id: 1,
      type: "PMS",
      title: "Auxiliary Engine Maintenance",
      time: "2 hours ago",
      status: "approved",
    },
    {
      id: 2,
      type: "Daily",
      title: "Bridge Equipment Check",
      time: "5 hours ago",
      status: "pending",
    },
  ];

  return (
    <div className="pb-16 md:pb-0">
      {/* Ship Info Header */}
      <Card className="p-6 mb-6">
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Ship className="w-5 h-5 text-primary" />
              <h2 className="text-xl font-semibold">{currentShip.name}</h2>
            </div>
            <p className="text-sm text-muted-foreground">{currentShip.type}</p>
          </div>
          <Badge
            variant={currentShip.status === "active" ? "default" : "secondary"}
            className="capitalize"
          >
            {currentShip.status}
          </Badge>
        </div>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <Button
          variant="outline"
          className="h-auto py-4 flex-col items-center justify-center gap-2"
          onClick={() => setActiveTab("logs")}
        >
          <ClipboardList className="w-6 h-6" />
          <span className="text-sm">Add Work Log</span>
        </Button>
        <Button
          variant="outline"
          className="h-auto py-4 flex-col items-center justify-center gap-2"
          onClick={() => setActiveTab("tasks")}
        >
          <Wrench className="w-6 h-6" />
          <span className="text-sm">View Tasks</span>
        </Button>
      </div>

      {/* Main Content */}
      <Tabs
        value={activeTab}
        onValueChange={setActiveTab}
        className="space-y-6"
      >
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="tasks">My Tasks</TabsTrigger>
          <TabsTrigger value="logs">Work Logs</TabsTrigger>
        </TabsList>

        <TabsContent value="tasks" className="space-y-4">
          {tasks.map((task) => (
            <Card key={task.id} className="p-4">
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3">
                  <div
                    className={`p-2 rounded-lg ${
                      task.type === "pms"
                        ? "bg-blue-500/10"
                        : task.type === "daily"
                        ? "bg-green-500/10"
                        : "bg-yellow-500/10"
                    }`}
                  >
                    {task.type === "pms" ? (
                      <Wrench
                        className={`w-4 h-4 ${
                          task.type === "pms"
                            ? "text-blue-500"
                            : task.type === "daily"
                            ? "text-green-500"
                            : "text-yellow-500"
                        }`}
                      />
                    ) : task.type === "daily" ? (
                      <ClipboardList className="w-4 h-4 text-green-500" />
                    ) : (
                      <AlertTriangle className="w-4 h-4 text-yellow-500" />
                    )}
                  </div>
                  <div>
                    <h3 className="font-medium">{task.title}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge
                        variant={
                          task.priority === "high" ? "destructive" : "secondary"
                        }
                      >
                        {task.priority}
                      </Badge>
                      <span className="text-sm text-muted-foreground">
                        Due: {task.due}
                      </span>
                    </div>
                  </div>
                </div>
                <Button
                  size="sm"
                  variant={
                    task.status === "in_progress" ? "secondary" : "default"
                  }
                >
                  {task.status === "pending" ? "Start" : "Continue"}
                </Button>
              </div>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="logs" className="space-y-6">
          {/* Add New Log */}
          <Card className="p-6">
            <h3 className="font-medium mb-4">Add Work Log</h3>
            <div className="grid gap-4">
              <div className="grid grid-cols-2 gap-4">
                <Button variant="outline" className="h-auto py-3 justify-start">
                  <Clock className="w-4 h-4 mr-2" />
                  Set Hours
                </Button>
                <Button variant="outline" className="h-auto py-3 justify-start">
                  <Camera className="w-4 h-4 mr-2" />
                  Add Photo
                </Button>
              </div>
              <Button className="w-full">
                <Upload className="w-4 h-4 mr-2" />
                Submit Work Log
              </Button>
            </div>
          </Card>

          {/* Recent Logs */}
          <div className="space-y-4">
            <h3 className="font-medium">Recent Logs</h3>
            {recentLogs.map((log) => (
              <Card key={log.id} className="p-4">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">{log.type}</Badge>
                      <span className="text-sm text-muted-foreground">
                        {log.time}
                      </span>
                    </div>
                    <h4 className="font-medium mt-1">{log.title}</h4>
                  </div>
                  <Badge
                    variant={
                      log.status === "approved" ? "default" : "secondary"
                    }
                  >
                    {log.status}
                  </Badge>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* Mobile Navigation Bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-background border-t p-2 flex justify-around md:hidden">
        <Button
          variant="ghost"
          size="sm"
          className="flex-col items-center gap-1"
        >
          <Home className="w-5 h-5" />
          <span className="text-xs">Home</span>
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className="flex-col items-center gap-1"
        >
          <ClipboardList className="w-5 h-5" />
          <span className="text-xs">Tasks</span>
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className="flex-col items-center gap-1"
        >
          <BarChart3 className="w-5 h-5" />
          <span className="text-xs">Reports</span>
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className="flex-col items-center gap-1"
        >
          <Settings className="w-5 h-5" />
          <span className="text-xs">Settings</span>
        </Button>
      </div>
    </div>
  );
}
