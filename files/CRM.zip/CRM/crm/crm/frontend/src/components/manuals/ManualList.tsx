import { useState } from "react";
import { Search, Upload, Eye, FileText, CheckCircle2 } from "lucide-react";
import { Input } from "../ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../ui/table";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { useAuth } from "../../contexts/AuthContext";

import { Manual, MANUAL_TYPES, ManualTypeKey } from "../../types/manuals";

interface ManualListProps {
  onSelect: (manual: Manual) => void;
}

export function ManualList({ onSelect }: ManualListProps) {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [manuals, setManuals] = useState<Manual[]>([]);

  const isCrew = user?.role === "CREW";
  const isMaster = user?.role === "MASTER";

  const filteredManuals = manuals.filter((manual) => {
    const matchesSearch = manual.title
      .toLowerCase()
      .includes(searchTerm.toLowerCase());
    const matchesType =
      typeFilter === "all" || manual.manual_type === typeFilter;
    return matchesSearch && matchesType;
  });

  const handleUpload = () => {
    // Upload logic
  };

  const handleAcknowledge = (manualId: string) => {
    // Acknowledge logic
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-foreground">Manuals & Procedures</h2>
          <p className="text-sm text-muted-foreground">
            {isCrew
              ? "View and acknowledge manuals"
              : "Manage company and fleet manuals"}
          </p>
        </div>
        {!isCrew && (
          <Button onClick={handleUpload}>
            <Upload className="w-4 h-4 mr-2" />
            Upload Manual
          </Button>
        )}
      </div>

      {/* Filters */}
      <div className="bg-card p-4 rounded-lg border border-border">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search manuals..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Manual Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              {Object.entries(MANUAL_TYPES).map(([key, { label }]) => (
                <SelectItem key={key} value={key}>
                  {label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Manuals Table */}
      <div className="bg-card rounded-lg border border-border overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Title</TableHead>
              <TableHead>Type</TableHead>
              {!isCrew && <TableHead>Ship</TableHead>}
              <TableHead>Version</TableHead>
              <TableHead>Last Updated</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredManuals.map((manual) => (
              <TableRow key={manual.id}>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4 text-muted-foreground" />
                    {manual.title}
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="outline">
                    {MANUAL_TYPES[manual.manual_type as ManualTypeKey].label}
                  </Badge>
                </TableCell>
                {!isCrew && (
                  <TableCell>{manual.ship_name || "All Ships"}</TableCell>
                )}
                <TableCell>v{manual.current_version.version_number}</TableCell>
                <TableCell className="text-sm">
                  {new Date(manual.updated_at).toLocaleDateString()}
                </TableCell>
                <TableCell>
                  {isCrew ? (
                    <Badge
                      className={
                        manual.acknowledgements.some(
                          (ack) => ack.user_id === user?.id
                        )
                          ? "bg-accent"
                          : "bg-warning"
                      }
                    >
                      {manual.acknowledgements.some(
                        (ack) => ack.user_id === user?.id
                      )
                        ? "Acknowledged"
                        : "Pending"}
                    </Badge>
                  ) : (
                    <Badge
                      className={manual.approved ? "bg-accent" : "bg-warning"}
                    >
                      {manual.approved ? "Approved" : "Draft"}
                    </Badge>
                  )}
                </TableCell>
                <TableCell>
                  <div className="flex justify-end gap-2">
                    <Button variant="ghost" size="sm" title="View">
                      <Eye className="w-4 h-4" />
                    </Button>
                    {isCrew &&
                      !manual.acknowledgements.some(
                        (ack) => ack.user_id === user?.id
                      ) && (
                        <Button
                          variant="ghost"
                          size="sm"
                          title="Acknowledge"
                          onClick={() => handleAcknowledge(manual.id)}
                        >
                          <CheckCircle2 className="w-4 h-4" />
                        </Button>
                      )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
