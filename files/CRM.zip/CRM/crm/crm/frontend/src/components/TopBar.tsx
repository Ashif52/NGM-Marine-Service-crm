import {
  Bell,
  HelpCircle,
  Menu,
  ChevronDown,
  Ship,
  LogOut,
} from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import { Badge } from "./ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { useAuth } from "../contexts/AuthContext";

interface TopBarProps {
  currentPage: string;
  onMenuClick: () => void;
}

const pageNames: Record<string, string> = {
  dashboard: "Dashboard",
  pms: "Planned Maintenance System",
  "crew-logs": "Daily Work Logs",
  invoices: "Invoice Management",
  "access-control": "Role & Access Control",
  masters: "Masters",
  clients: "Clients",
  vessels: "Vessels",
  crew: "Crew",
  recruitment: "Recruitment",
  documents: "Documents",
  "dg-communication": "DG Communication",
  finance: "Finance",
  reports: "Reports",
  settings: "Settings",
  login: "Login",
};

export function TopBar({ currentPage, onMenuClick }: TopBarProps) {
  const { user, logout, selectedShip, setSelectedShip, ships } = useAuth();

  const handleLogout = () => {
    logout();
  };

  const currentShip = ships.find((s) => s.id === selectedShip);
  const roleDisplay =
    user?.role?.toLowerCase() === "master"
      ? "Master"
      : user?.role?.toLowerCase() === "crew"
      ? "Crew"
      : "Staff";
  const userInitials =
    user?.name
      ?.split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase() || "U";

  return (
    <header className="h-16 bg-card border-b border-border flex items-center justify-between px-6 shadow-sm">
      {/* Left: Menu + Page Title + Ship Selector */}
      <div className="flex items-center gap-4">
        <button
          onClick={onMenuClick}
          className="lg:hidden text-foreground hover:bg-muted p-2 rounded-lg transition-colors"
        >
          <Menu className="w-6 h-6" />
        </button>
        <h1 className="text-foreground text-xl font-semibold">
          {pageNames[currentPage] || "NMG Marine CRM"}
        </h1>

        {/* Ship Selector - Only for Master */}
        {user?.role?.toLowerCase() === "master" && (
          <div className="ml-4 hidden md:block">
            <Select value={selectedShip || ""} onValueChange={setSelectedShip}>
              <SelectTrigger className="w-[220px] h-9 border-accent/30">
                <div className="flex items-center gap-2">
                  <Ship className="w-4 h-4 text-accent" />
                  <SelectValue />
                </div>
              </SelectTrigger>
              <SelectContent>
                {ships.map((ship) => (
                  <SelectItem key={ship.id} value={ship.id}>
                    <div className="flex items-center justify-between gap-3 w-full">
                      <span>{ship.name}</span>
                      <Badge
                        variant="outline"
                        className={
                          ship.status === "active"
                            ? "bg-green-50 text-green-700 border-green-200"
                            : ship.status === "maintenance"
                            ? "bg-yellow-50 text-yellow-700 border-yellow-200"
                            : "bg-gray-50 text-gray-700 border-gray-200"
                        }
                      >
                        {ship.status}
                      </Badge>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        {/* Crew - Show assigned ship */}
        {user?.role?.toLowerCase() === "crew" && currentShip && (
          <div className="ml-4 hidden md:flex items-center gap-2 px-3 py-1.5 bg-accent/10 rounded-lg">
            <Ship className="w-4 h-4 text-accent" />
            <span className="text-sm text-foreground">{currentShip.name}</span>
          </div>
        )}
      </div>

      {/* Right: Notifications, Help, User */}
      <div className="flex items-center gap-3">
        {/* Notifications */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="relative p-2 hover:bg-muted rounded-lg transition-colors">
              <Bell className="w-5 h-5 text-foreground" />
              <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 bg-destructive text-destructive-foreground text-xs border-2 border-card">
                3
              </Badge>
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-80">
            <DropdownMenuLabel className="text-base font-semibold">
              Notifications
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem>
              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-destructive rounded-full" />
                  <span>John Smith - Passport expiring in 15 days</span>
                </div>
                <span className="text-xs text-muted-foreground ml-4">
                  2 hours ago
                </span>
              </div>
            </DropdownMenuItem>
            <DropdownMenuItem>
              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-warning rounded-full" />
                  <span>DG Compliance - STCW Training deadline in 5 days</span>
                </div>
                <span className="text-xs text-muted-foreground ml-4">
                  3 hours ago
                </span>
              </div>
            </DropdownMenuItem>
            <DropdownMenuItem>
              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-warning rounded-full" />
                  <span>
                    MV Ocean Star - Medical certificates expiring soon
                  </span>
                </div>
                <span className="text-xs text-muted-foreground ml-4">
                  5 hours ago
                </span>
              </div>
            </DropdownMenuItem>
            <DropdownMenuItem>
              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-accent rounded-full" />
                  <span>New DG circular received - Manning Scale Update</span>
                </div>
                <span className="text-xs text-muted-foreground ml-4">
                  6 hours ago
                </span>
              </div>
            </DropdownMenuItem>
            <DropdownMenuItem>
              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-accent rounded-full" />
                  <span>New candidate application received</span>
                </div>
                <span className="text-xs text-muted-foreground ml-4">
                  1 day ago
                </span>
              </div>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Help */}
        <button className="p-2 hover:bg-accent/10 rounded-full transition-colors">
          <HelpCircle className="w-5 h-5 text-foreground" />
        </button>

        {/* User Menu */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="flex items-center gap-2 hover:bg-accent/10 px-3 py-2 rounded transition-colors">
              <Avatar className="w-8 h-8">
                <AvatarImage src="" />
                <AvatarFallback className="bg-primary text-primary-foreground">
                  {userInitials}
                </AvatarFallback>
              </Avatar>
              <div className="hidden md:flex flex-col items-start">
                <span className="text-sm text-foreground">{user?.name}</span>
                <span className="text-xs text-muted-foreground">
                  {roleDisplay}
                </span>
              </div>
              <ChevronDown className="w-4 h-4 text-foreground" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>
              <div className="flex flex-col">
                <span>My Account</span>
                <span className="text-xs font-normal text-muted-foreground">
                  {user?.email}
                </span>
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem>Profile</DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => (window.location.hash = "settings")}
            >
              Settings
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              className="text-destructive"
              onClick={handleLogout}
            >
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
