import { useState } from 'react';
import { Search, Eye, CheckSquare, Upload, Calendar } from 'lucide-react';
import { Card, CardContent } from '../ui/card';
import { Input } from '../ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Progress } from '../ui/progress';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '../ui/dialog';
import { Label } from '../ui/label';
import { Checkbox } from '../ui/checkbox';

const complianceItems = [
  {
    id: 1,
    title: 'STCW Training Compliance - MV Ocean Star',
    circularNo: 'DGS/MSD/01/2024',
    deadline: '2024-12-10',
    daysRemaining: 5,
    actionRequired: 'Submit training completion certificates',
    responsiblePerson: 'Sarah Johnson',
    status: 'In Progress',
    progress: 65,
    vessel: 'MV Ocean Star',
    crew: 'All Officers',
  },
  {
    id: 2,
    title: 'Manning Scale Implementation',
    circularNo: 'DGS/MSD/02/2024',
    deadline: '2024-12-20',
    daysRemaining: 15,
    actionRequired: 'Update manning documents and submit to DG',
    responsiblePerson: 'Mike Brown',
    status: 'Not Started',
    progress: 0,
    vessel: 'MT Pacific Wave',
    crew: '-',
  },
  {
    id: 3,
    title: 'Safety Equipment Inspection',
    circularNo: 'DGS/SAF/03/2024',
    deadline: '2024-12-25',
    daysRemaining: 20,
    actionRequired: 'Complete inspection and upload reports',
    responsiblePerson: 'John Doe',
    status: 'In Progress',
    progress: 40,
    vessel: 'MV Atlantic Trader',
    crew: '-',
  },
  {
    id: 4,
    title: 'Medical Fitness Audit',
    circularNo: 'DGS/MED/04/2024',
    deadline: '2024-12-08',
    daysRemaining: 3,
    actionRequired: 'Submit updated medical certificates',
    responsiblePerson: 'Sarah Johnson',
    status: 'Overdue',
    progress: 85,
    vessel: '-',
    crew: 'Maria Garcia, Ahmed Hassan',
  },
  {
    id: 5,
    title: 'Fire Drill Documentation',
    circularNo: 'DGS/SAF/05/2024',
    deadline: '2024-11-30',
    daysRemaining: -5,
    actionRequired: 'Upload fire drill reports',
    responsiblePerson: 'Mike Brown',
    status: 'Overdue',
    progress: 100,
    vessel: 'MT Indian Star',
    crew: '-',
  },
  {
    id: 6,
    title: 'STCW Certificate Renewal Tracking',
    circularNo: 'DGS/STCW/06/2024',
    deadline: '2024-12-15',
    daysRemaining: 10,
    actionRequired: 'Track and renew expiring certificates',
    responsiblePerson: 'John Doe',
    status: 'Completed',
    progress: 100,
    vessel: '-',
    crew: 'Multiple Crew',
  },
];

const statusColors: Record<string, string> = {
  'Not Started': 'bg-muted text-muted-foreground',
  'In Progress': 'bg-warning text-warning-foreground',
  'Completed': 'bg-accent text-accent-foreground',
  'Overdue': 'bg-destructive text-destructive-foreground',
};

export function DGComplianceTracker() {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const filteredItems = complianceItems.filter(item => {
    const matchesSearch = item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.circularNo.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || item.status.toLowerCase().replace(' ', '-') === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getDaysColor = (days: number) => {
    if (days < 0) return 'text-destructive';
    if (days <= 7) return 'text-destructive';
    if (days <= 15) return 'text-warning';
    return 'text-accent';
  };

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="text-sm text-muted-foreground mb-1">Total Items</div>
            <div className="text-foreground">{complianceItems.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="text-sm text-muted-foreground mb-1">In Progress</div>
            <div className="text-warning">
              {complianceItems.filter(i => i.status === 'In Progress').length}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="text-sm text-muted-foreground mb-1">Completed</div>
            <div className="text-accent">
              {complianceItems.filter(i => i.status === 'Completed').length}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="text-sm text-muted-foreground mb-1">Overdue</div>
            <div className="text-destructive">
              {complianceItems.filter(i => i.status === 'Overdue').length}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative md:col-span-2">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search by title or circular no..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="not-started">Not Started</SelectItem>
                <SelectItem value="in-progress">In Progress</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="overdue">Overdue</SelectItem>
              </SelectContent>
            </Select>
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="Responsible Person" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Personnel</SelectItem>
                <SelectItem value="john">John Doe</SelectItem>
                <SelectItem value="sarah">Sarah Johnson</SelectItem>
                <SelectItem value="mike">Mike Brown</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Compliance Table */}
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Compliance Title</TableHead>
                <TableHead>Circular No.</TableHead>
                <TableHead>Deadline</TableHead>
                <TableHead>Days Left</TableHead>
                <TableHead>Action Required</TableHead>
                <TableHead>Responsible</TableHead>
                <TableHead>Progress</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredItems.map((item) => (
                <TableRow key={item.id}>
                  <TableCell>{item.title}</TableCell>
                  <TableCell className="text-primary text-sm">
                    {item.circularNo}
                  </TableCell>
                  <TableCell className="text-sm">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-muted-foreground" />
                      {item.deadline}
                    </div>
                  </TableCell>
                  <TableCell>
                    <span className={getDaysColor(item.daysRemaining)}>
                      {item.daysRemaining >= 0 
                        ? `${item.daysRemaining} days` 
                        : `${Math.abs(item.daysRemaining)} days overdue`}
                    </span>
                  </TableCell>
                  <TableCell className="max-w-xs text-sm text-muted-foreground">
                    {item.actionRequired}
                  </TableCell>
                  <TableCell className="text-sm">{item.responsiblePerson}</TableCell>
                  <TableCell>
                    <div className="w-24">
                      <Progress value={item.progress} className="h-2" />
                      <div className="text-xs text-muted-foreground mt-1">
                        {item.progress}%
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge className={statusColors[item.status]}>
                      {item.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex justify-end gap-2">
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <Eye className="w-4 h-4" />
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
                          <DialogHeader>
                            <DialogTitle>{item.title}</DialogTitle>
                            <DialogDescription>
                              {item.circularNo} • Deadline: {item.deadline}
                            </DialogDescription>
                          </DialogHeader>
                          
                          <div className="space-y-6 py-4">
                            {/* Metadata */}
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <Label className="text-sm text-muted-foreground">DG Circular Reference</Label>
                                <div className="text-foreground">{item.circularNo}</div>
                              </div>
                              <div>
                                <Label className="text-sm text-muted-foreground">Deadline</Label>
                                <div className={getDaysColor(item.daysRemaining)}>
                                  {item.deadline} ({item.daysRemaining >= 0 
                                    ? `${item.daysRemaining} days remaining` 
                                    : `${Math.abs(item.daysRemaining)} days overdue`})
                                </div>
                              </div>
                              <div>
                                <Label className="text-sm text-muted-foreground">Vessel</Label>
                                <div className="text-foreground">{item.vessel}</div>
                              </div>
                              <div>
                                <Label className="text-sm text-muted-foreground">Crew</Label>
                                <div className="text-foreground">{item.crew}</div>
                              </div>
                              <div>
                                <Label className="text-sm text-muted-foreground">Responsible Person</Label>
                                <div className="text-foreground">{item.responsiblePerson}</div>
                              </div>
                              <div>
                                <Label className="text-sm text-muted-foreground">Status</Label>
                                <Badge className={statusColors[item.status]}>
                                  {item.status}
                                </Badge>
                              </div>
                            </div>

                            {/* Checklist */}
                            <div>
                              <Label>Compliance Checklist</Label>
                              <div className="mt-2 space-y-2 bg-muted p-4 rounded-lg">
                                <div className="flex items-center space-x-2">
                                  <Checkbox id="check1" defaultChecked />
                                  <label htmlFor="check1" className="text-sm cursor-pointer">
                                    Review DG circular requirements
                                  </label>
                                </div>
                                <div className="flex items-center space-x-2">
                                  <Checkbox id="check2" defaultChecked />
                                  <label htmlFor="check2" className="text-sm cursor-pointer">
                                    Gather required documents
                                  </label>
                                </div>
                                <div className="flex items-center space-x-2">
                                  <Checkbox id="check3" />
                                  <label htmlFor="check3" className="text-sm cursor-pointer">
                                    Complete necessary training/updates
                                  </label>
                                </div>
                                <div className="flex items-center space-x-2">
                                  <Checkbox id="check4" />
                                  <label htmlFor="check4" className="text-sm cursor-pointer">
                                    Upload proof documents
                                  </label>
                                </div>
                                <div className="flex items-center space-x-2">
                                  <Checkbox id="check5" />
                                  <label htmlFor="check5" className="text-sm cursor-pointer">
                                    Submit to DG Shipping
                                  </label>
                                </div>
                              </div>
                            </div>

                            {/* Upload Proof */}
                            <div>
                              <Label>Upload Proof Documents</Label>
                              <Button variant="outline" className="w-full mt-2 gap-2">
                                <Upload className="w-4 h-4" />
                                Upload Files
                              </Button>
                            </div>

                            {/* Timeline */}
                            <div>
                              <Label>Timeline of Actions</Label>
                              <div className="mt-2 space-y-2">
                                <div className="text-sm p-2 bg-muted rounded flex items-center gap-2">
                                  <div className="w-2 h-2 bg-accent rounded-full"></div>
                                  <span className="text-muted-foreground">
                                    2024-11-15 - Compliance task created
                                  </span>
                                </div>
                                <div className="text-sm p-2 bg-muted rounded flex items-center gap-2">
                                  <div className="w-2 h-2 bg-accent rounded-full"></div>
                                  <span className="text-muted-foreground">
                                    2024-11-20 - Documents gathered
                                  </span>
                                </div>
                              </div>
                            </div>

                            <div className="flex gap-2 pt-4">
                              <Button className="bg-accent text-accent-foreground hover:bg-accent/90 gap-2">
                                <CheckSquare className="w-4 h-4" />
                                Mark as Completed
                              </Button>
                              <Button variant="outline">
                                Update Progress
                              </Button>
                            </div>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
