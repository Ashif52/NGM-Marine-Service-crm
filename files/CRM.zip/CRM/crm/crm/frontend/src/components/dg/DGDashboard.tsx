import { Send, CheckCircle, Clock, AlertTriangle, Eye, Download } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { Button } from '../ui/button';

const kpiData = [
  { 
    title: 'Total Communications Sent', 
    value: '156', 
    icon: Send, 
    color: 'text-primary',
    bgColor: 'bg-primary/10'
  },
  { 
    title: 'Received Acknowledgements', 
    value: '142', 
    icon: CheckCircle, 
    color: 'text-accent',
    bgColor: 'bg-accent/10'
  },
  { 
    title: 'Pending Compliances', 
    value: '8', 
    icon: Clock, 
    color: 'text-warning',
    bgColor: 'bg-warning/10'
  },
  { 
    title: 'Urgent Deadlines', 
    value: '3', 
    icon: AlertTriangle, 
    color: 'text-destructive',
    bgColor: 'bg-destructive/10'
  },
];

const circulars = [
  {
    id: 1,
    circularNo: 'DGS/MSD/01/2024',
    subject: 'Updated STCW Training Requirements',
    issueDate: '2024-11-15',
    category: 'Training',
    status: 'Pending',
    priority: 'High',
  },
  {
    id: 2,
    circularNo: 'DGS/MSD/02/2024',
    subject: 'Manning Scale Revision for Container Vessels',
    issueDate: '2024-11-20',
    category: 'Manning',
    status: 'Acknowledged',
    priority: 'Medium',
  },
  {
    id: 3,
    circularNo: 'DGS/SAF/03/2024',
    subject: 'Safety Equipment Inspection Guidelines',
    issueDate: '2024-11-25',
    category: 'Safety',
    status: 'Closed',
    priority: 'Low',
  },
  {
    id: 4,
    circularNo: 'DGS/STCW/04/2024',
    subject: 'New STCW Certification Procedures',
    issueDate: '2024-11-28',
    category: 'STCW',
    status: 'Pending',
    priority: 'High',
  },
  {
    id: 5,
    circularNo: 'DGS/MSD/05/2024',
    subject: 'Medical Fitness Standards Update',
    issueDate: '2024-12-01',
    category: 'Training',
    status: 'Acknowledged',
    priority: 'Medium',
  },
];

const categoryColors: Record<string, string> = {
  'Training': 'bg-blue-100 text-blue-700 border-blue-200',
  'Manning': 'bg-purple-100 text-purple-700 border-purple-200',
  'STCW': 'bg-green-100 text-green-700 border-green-200',
  'Safety': 'bg-orange-100 text-orange-700 border-orange-200',
};

const statusColors: Record<string, string> = {
  'Pending': 'bg-warning text-warning-foreground',
  'Acknowledged': 'bg-accent text-accent-foreground',
  'Closed': 'bg-muted text-muted-foreground',
};

const priorityColors: Record<string, string> = {
  'High': 'bg-destructive text-destructive-foreground',
  'Medium': 'bg-warning text-warning-foreground',
  'Low': 'bg-muted text-muted-foreground',
};

export function DGDashboard() {
  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {kpiData.map((kpi, index) => {
          const Icon = kpi.icon;
          
          return (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <p className="text-sm text-muted-foreground mb-1">{kpi.title}</p>
                    <div className="text-foreground">{kpi.value}</div>
                  </div>
                  <div className={`w-12 h-12 rounded-lg ${kpi.bgColor} flex items-center justify-center`}>
                    <Icon className={`w-6 h-6 ${kpi.color}`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* DG Circulars */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>DG Circulars</CardTitle>
            <Button variant="outline" size="sm">
              Upload Circular
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Circular No.</TableHead>
                <TableHead>Subject</TableHead>
                <TableHead>Issue Date</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Priority</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {circulars.map((circular) => (
                <TableRow key={circular.id}>
                  <TableCell className="text-primary">
                    {circular.circularNo}
                  </TableCell>
                  <TableCell>{circular.subject}</TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {circular.issueDate}
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className={categoryColors[circular.category]}>
                      {circular.category}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge className={priorityColors[circular.priority]}>
                      {circular.priority}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge className={statusColors[circular.status]}>
                      {circular.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex justify-end gap-2">
                      <Button variant="ghost" size="sm" title="View">
                        <Eye className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="sm" title="Download">
                        <Download className="w-4 h-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Urgent Deadlines</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-3 pb-4 border-b border-border">
                <div className="w-2 h-2 bg-destructive rounded-full mt-2"></div>
                <div className="flex-1">
                  <div className="text-foreground">STCW Training Compliance</div>
                  <div className="text-sm text-muted-foreground">Deadline: 2024-12-10</div>
                  <Badge className="mt-2 bg-destructive text-destructive-foreground">
                    5 days remaining
                  </Badge>
                </div>
              </div>
              <div className="flex items-start gap-3 pb-4 border-b border-border">
                <div className="w-2 h-2 bg-warning rounded-full mt-2"></div>
                <div className="flex-1">
                  <div className="text-foreground">Manning Scale Implementation</div>
                  <div className="text-sm text-muted-foreground">Deadline: 2024-12-20</div>
                  <Badge className="mt-2 bg-warning text-warning-foreground">
                    15 days remaining
                  </Badge>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 bg-warning rounded-full mt-2"></div>
                <div className="flex-1">
                  <div className="text-foreground">Medical Fitness Audit</div>
                  <div className="text-sm text-muted-foreground">Deadline: 2024-12-25</div>
                  <Badge className="mt-2 bg-warning text-warning-foreground">
                    20 days remaining
                  </Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Communications</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-3 pb-4 border-b border-border">
                <div className="w-2 h-2 bg-accent rounded-full mt-2"></div>
                <div className="flex-1">
                  <div className="text-foreground">Pre-Joining Letter - MV Ocean Star</div>
                  <div className="text-sm text-muted-foreground">Sent to DG Mumbai • 2 hours ago</div>
                </div>
              </div>
              <div className="flex items-start gap-3 pb-4 border-b border-border">
                <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                <div className="flex-1">
                  <div className="text-foreground">Manning Approval Request</div>
                  <div className="text-sm text-muted-foreground">Received from DG Delhi • 5 hours ago</div>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 bg-accent rounded-full mt-2"></div>
                <div className="flex-1">
                  <div className="text-foreground">Incident Report - MT Pacific Wave</div>
                  <div className="text-sm text-muted-foreground">Sent to DG Chennai • 1 day ago</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
