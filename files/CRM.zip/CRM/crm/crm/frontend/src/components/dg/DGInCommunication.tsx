import { useState } from 'react';
import { Search, Calendar, Eye, CheckCircle, Paperclip, Plus } from 'lucide-react';
import { Card, CardContent } from '../ui/card';
import { Input } from '../ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '../ui/dialog';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';

const inCommunications = [
  {
    id: 1,
    refNo: 'DGS-IN-2024-001',
    subject: 'Acknowledgement Request - STCW Training',
    receivedDate: '2024-12-01',
    relatedVessel: 'MV Ocean Star',
    relatedCrew: 'John Smith',
    hasAttachment: true,
    status: 'Pending',
    dgOffice: 'DG Mumbai',
    category: 'Training',
  },
  {
    id: 2,
    refNo: 'DGS-IN-2024-002',
    subject: 'Manning Scale Inspection Notice',
    receivedDate: '2024-11-28',
    relatedVessel: 'MT Pacific Wave',
    relatedCrew: '-',
    hasAttachment: true,
    status: 'Action Required',
    dgOffice: 'DG Delhi',
    category: 'Manning',
  },
  {
    id: 3,
    refNo: 'DGS-IN-2024-003',
    subject: 'Medical Certificate Verification',
    receivedDate: '2024-11-25',
    relatedVessel: '-',
    relatedCrew: 'Maria Garcia',
    hasAttachment: false,
    status: 'Completed',
    dgOffice: 'DG Chennai',
    category: 'Medical',
  },
  {
    id: 4,
    refNo: 'DGS-IN-2024-004',
    subject: 'Crew Dispute Resolution Notice',
    receivedDate: '2024-11-20',
    relatedVessel: 'MV Atlantic Trader',
    relatedCrew: 'Ahmed Hassan',
    hasAttachment: true,
    status: 'Action Required',
    dgOffice: 'DG Kolkata',
    category: 'Dispute',
  },
  {
    id: 5,
    refNo: 'DGS-IN-2024-005',
    subject: 'Safety Drill Compliance Check',
    receivedDate: '2024-11-15',
    relatedVessel: 'MT Indian Star',
    relatedCrew: '-',
    hasAttachment: true,
    status: 'Completed',
    dgOffice: 'DG Mumbai',
    category: 'Safety',
  },
];

const statusColors: Record<string, string> = {
  'Pending': 'bg-warning text-warning-foreground',
  'Action Required': 'bg-destructive text-destructive-foreground',
  'Completed': 'bg-accent text-accent-foreground',
};

export function DGInCommunication() {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedComm, setSelectedComm] = useState<typeof inCommunications[0] | null>(null);

  const filteredComms = inCommunications.filter(comm => {
    const matchesSearch = comm.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         comm.refNo.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || comm.status.toLowerCase().replace(' ', '-') === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div className="relative md:col-span-2">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search by subject or ref no..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="Date Range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7days">Last 7 Days</SelectItem>
                <SelectItem value="30days">Last 30 Days</SelectItem>
                <SelectItem value="90days">Last 90 Days</SelectItem>
                <SelectItem value="all">All Time</SelectItem>
              </SelectContent>
            </Select>
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="Communication Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="training">Training</SelectItem>
                <SelectItem value="manning">Manning</SelectItem>
                <SelectItem value="safety">Safety</SelectItem>
                <SelectItem value="medical">Medical</SelectItem>
                <SelectItem value="dispute">Dispute</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="action-required">Action Required</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Communications Table */}
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Ref No.</TableHead>
                <TableHead>Subject</TableHead>
                <TableHead>Received Date</TableHead>
                <TableHead>Related Vessel / Crew</TableHead>
                <TableHead>DG Office</TableHead>
                <TableHead className="text-center">Attachment</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredComms.map((comm) => (
                <TableRow key={comm.id}>
                  <TableCell className="text-primary">{comm.refNo}</TableCell>
                  <TableCell>{comm.subject}</TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {comm.receivedDate}
                  </TableCell>
                  <TableCell>
                    <div className="text-sm">
                      {comm.relatedVessel !== '-' && (
                        <div className="text-foreground">{comm.relatedVessel}</div>
                      )}
                      {comm.relatedCrew !== '-' && (
                        <div className="text-muted-foreground">{comm.relatedCrew}</div>
                      )}
                      {comm.relatedVessel === '-' && comm.relatedCrew === '-' && (
                        <span className="text-muted-foreground">-</span>
                      )}
                    </div>
                  </TableCell>
                  <TableCell className="text-sm">{comm.dgOffice}</TableCell>
                  <TableCell className="text-center">
                    {comm.hasAttachment && (
                      <Paperclip className="w-4 h-4 text-muted-foreground inline-block" />
                    )}
                  </TableCell>
                  <TableCell>
                    <Badge className={statusColors[comm.status]}>
                      {comm.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex justify-end gap-2">
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => setSelectedComm(comm)}
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                          <DialogHeader>
                            <DialogTitle>{comm.subject}</DialogTitle>
                            <DialogDescription>
                              {comm.refNo} • Received on {comm.receivedDate}
                            </DialogDescription>
                          </DialogHeader>
                          
                          <div className="grid grid-cols-3 gap-6 py-4">
                            {/* Left Panel - Metadata */}
                            <div className="col-span-1 space-y-4">
                              <div>
                                <Label className="text-sm text-muted-foreground">DG Office</Label>
                                <div className="text-foreground">{comm.dgOffice}</div>
                              </div>
                              <div>
                                <Label className="text-sm text-muted-foreground">Category</Label>
                                <div className="text-foreground">{comm.category}</div>
                              </div>
                              <div>
                                <Label className="text-sm text-muted-foreground">Related Vessel</Label>
                                <div className="text-foreground">{comm.relatedVessel}</div>
                              </div>
                              <div>
                                <Label className="text-sm text-muted-foreground">Related Crew</Label>
                                <div className="text-foreground">{comm.relatedCrew}</div>
                              </div>
                              <div>
                                <Label className="text-sm text-muted-foreground">Status</Label>
                                <Badge className={statusColors[comm.status]}>
                                  {comm.status}
                                </Badge>
                              </div>
                              {comm.hasAttachment && (
                                <div>
                                  <Label className="text-sm text-muted-foreground">Attachments</Label>
                                  <Button variant="outline" size="sm" className="w-full mt-1">
                                    View PDF
                                  </Button>
                                </div>
                              )}
                            </div>

                            {/* Right Panel - Content */}
                            <div className="col-span-2 space-y-4">
                              <div>
                                <Label>Communication Content</Label>
                                <div className="mt-2 p-4 bg-muted rounded-lg text-sm text-foreground">
                                  <p className="mb-2">Dear Sir/Madam,</p>
                                  <p className="mb-2">
                                    This is regarding the {comm.category.toLowerCase()} matter 
                                    for {comm.relatedVessel !== '-' ? comm.relatedVessel : comm.relatedCrew}.
                                  </p>
                                  <p className="mb-2">
                                    We request your prompt attention to this matter and compliance 
                                    with the requirements outlined in our circular.
                                  </p>
                                  <p>Regards,<br/>DG Shipping</p>
                                </div>
                              </div>

                              <div>
                                <Label>Add Response</Label>
                                <Textarea 
                                  placeholder="Type your response here..." 
                                  className="mt-2"
                                  rows={4}
                                />
                              </div>

                              <div>
                                <Label>Action Log</Label>
                                <div className="mt-2 space-y-2">
                                  <div className="text-sm p-2 bg-muted rounded">
                                    <span className="text-muted-foreground">
                                      {comm.receivedDate} - Communication received
                                    </span>
                                  </div>
                                </div>
                              </div>

                              <div className="flex gap-2 pt-4">
                                <Button className="bg-accent text-accent-foreground hover:bg-accent/90">
                                  Add Response
                                </Button>
                                <Button variant="outline">
                                  Mark as Completed
                                </Button>
                              </div>
                            </div>
                          </div>
                        </DialogContent>
                      </Dialog>
                      
                      <Button variant="ghost" size="sm" title="Add Response">
                        <Plus className="w-4 h-4" />
                      </Button>
                      
                      {comm.status !== 'Completed' && (
                        <Button variant="ghost" size="sm" title="Close" className="text-accent">
                          <CheckCircle className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
