import { useState } from "react";
import {
  ChevronLeft,
  ChevronRight,
  Download,
  CheckCircle2,
} from "lucide-react";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { useAuth } from "../../contexts/AuthContext";

import {
  Manual,
  ManualSection,
  ManualTypeKey,
  ManualVersion,
  MANUAL_TYPES,
} from "../../types/manuals";

interface ManualViewerProps {
  manual: Manual;
  onClose: () => void;
  onAcknowledge: () => void;
}

export function ManualViewer({
  manual,
  onClose,
  onAcknowledge,
}: ManualViewerProps) {
  const { user } = useAuth();
  const [showVersions, setShowVersions] = useState(false);

  const isCrew = user?.role === "CREW";
  const currentIndex = manual.versions.findIndex(
    (v: ManualVersion) => v.id === manual.current_version.id
  );

  const handlePrevious = () => {
    if (currentIndex > 0) {
      // TODO: Implement version change
      // onVersionChange(manual.versions[currentIndex - 1]);
    }
  };

  const handleNext = () => {
    if (currentIndex < manual.versions.length - 1) {
      // TODO: Implement version change
      // onVersionChange(manual.versions[currentIndex + 1]);
    }
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="border-b p-4">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h2 className="text-xl font-semibold">{manual.title}</h2>
            <div className="flex items-center gap-2 mt-1">
              <Badge variant="outline">
                {MANUAL_TYPES[manual.manual_type as ManualTypeKey].label}
              </Badge>
              {manual.ship_name && (
                <Badge variant="outline" className="bg-blue-50">
                  {manual.ship_name}
                </Badge>
              )}
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm">
              <Download className="w-4 h-4 mr-2" />
              Download
            </Button>
            {isCrew &&
              !manual.acknowledgements.some(
                (ack) => ack.user_id === user?.id
              ) && (
                <Button size="sm" onClick={onAcknowledge}>
                  <CheckCircle2 className="w-4 h-4 mr-2" />
                  Acknowledge
                </Button>
              )}
          </div>
        </div>

        {/* Version Navigation */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              disabled={manual.versions[0].id === manual.current_version.id}
              onClick={handlePrevious}
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowVersions(!showVersions)}
            >
              Version {manual.current_version.version_number}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              disabled={
                manual.versions[manual.versions.length - 1].id ===
                manual.current_version.id
              }
              onClick={handleNext}
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
          <div className="text-sm text-muted-foreground">
            Last updated:{" "}
            {new Date(
              manual.current_version.revision_date
            ).toLocaleDateString()}
          </div>
        </div>

        {/* Version List */}
        {showVersions && (
          <div className="absolute top-full left-0 w-64 mt-2 bg-card rounded-lg border shadow-lg z-10">
            <div className="p-2">
              {manual.versions.map((version: ManualVersion) => (
                <button
                  key={version.id}
                  className={`w-full text-left px-3 py-2 rounded-md text-sm ${
                    version.id === manual.current_version.id
                      ? "bg-accent text-accent-foreground"
                      : "hover:bg-muted"
                  }`}
                  onClick={() => {
                    // TODO: Implement version change
                    // onVersionChange(version);
                    setShowVersions(false);
                  }}
                >
                  <div className="font-medium">
                    Version {version.version_number}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {new Date(version.revision_date).toLocaleDateString()}
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Document Viewer */}
      <div className="flex-1 bg-muted p-4 overflow-auto">
        {/* PDF Viewer or Document Content */}
      </div>

      {/* Change Summary */}
      {manual.current_version.change_summary && (
        <div className="border-t p-4">
          <h3 className="text-sm font-medium mb-2">Change Summary</h3>
          <p className="text-sm text-muted-foreground">
            {manual.current_version.change_summary}
          </p>
        </div>
      )}
    </div>
  );
}
