import { useState } from "react";
import { useAuth } from "../../contexts/AuthContext";
import { Card } from "../ui/card";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import {
  Ship,
  Users,
  FileText,
  DollarSign,
  Search,
  Filter,
  ChevronRight,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Wrench,
} from "lucide-react";

export function StaffDashboard() {
  const { ships } = useAuth();
  const [activeTab, setActiveTab] = useState("operations");

  // Mock data - replace with API data
  const stats = {
    totalCrew: 156,
    activeCrew: 124,
    pendingApprovals: 15,
    pendingInvoices: 8,
  };

  const pendingApprovals = [
    {
      id: 1,
      type: "pms",
      title: "Main Engine Maintenance",
      ship: "MV Pacific Star",
      submitted: "2 hours ago",
      submittedBy: "John Chen",
    },
    {
      id: 2,
      type: "daily",
      title: "Bridge Equipment Check",
      ship: "MV Atlantic Wave",
      submitted: "5 hours ago",
      submittedBy: "Mike Wilson",
    },
    {
      id: 3,
      type: "invoice",
      title: "Spare Parts Purchase",
      ship: "MV Pacific Star",
      submitted: "1 day ago",
      amount: "$12,450",
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header with Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="p-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm text-muted-foreground">Total Crew</p>
              <h3 className="text-2xl font-semibold mt-1">{stats.totalCrew}</h3>
            </div>
            <div className="p-3 bg-blue-500/10 rounded-xl">
              <Users className="w-5 h-5 text-blue-500" />
            </div>
          </div>
          <div className="mt-4 flex items-center text-sm text-muted-foreground">
            <Clock className="w-4 h-4 mr-1" />
            <span>{stats.activeCrew} active now</span>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm text-muted-foreground">Pending Reviews</p>
              <h3 className="text-2xl font-semibold mt-1">
                {stats.pendingApprovals}
              </h3>
            </div>
            <div className="p-3 bg-yellow-500/10 rounded-xl">
              <CheckCircle2 className="w-5 h-5 text-yellow-500" />
            </div>
          </div>
          <div className="mt-4 flex items-center text-sm text-muted-foreground">
            <Clock className="w-4 h-4 mr-1" />
            <span>5 high priority</span>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm text-muted-foreground">Active Ships</p>
              <h3 className="text-2xl font-semibold mt-1">{ships.length}</h3>
            </div>
            <div className="p-3 bg-green-500/10 rounded-xl">
              <Ship className="w-5 h-5 text-green-500" />
            </div>
          </div>
          <div className="mt-4 flex items-center text-sm text-muted-foreground">
            <Clock className="w-4 h-4 mr-1" />
            <span>All operational</span>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm text-muted-foreground">Pending Invoices</p>
              <h3 className="text-2xl font-semibold mt-1">
                {stats.pendingInvoices}
              </h3>
            </div>
            <div className="p-3 bg-purple-500/10 rounded-xl">
              <DollarSign className="w-5 h-5 text-purple-500" />
            </div>
          </div>
          <div className="mt-4 flex items-center text-sm text-muted-foreground">
            <Clock className="w-4 h-4 mr-1" />
            <span>3 require attention</span>
          </div>
        </Card>
      </div>

      {/* Main Content */}
      <Card className="p-6">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <div className="flex items-center justify-between mb-6">
            <TabsList>
              <TabsTrigger value="operations">Operations</TabsTrigger>
              <TabsTrigger value="crew">Crew Management</TabsTrigger>
              <TabsTrigger value="invoices">Invoices</TabsTrigger>
            </TabsList>

            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input className="pl-9 w-[200px]" placeholder="Search..." />
              </div>
              <Button variant="outline" size="icon">
                <Filter className="w-4 h-4" />
              </Button>
            </div>
          </div>

          <TabsContent value="operations" className="space-y-4">
            <div className="space-y-4">
              {pendingApprovals.map((item) => (
                <div
                  key={item.id}
                  className="flex items-start justify-between p-4 bg-muted rounded-lg"
                >
                  <div className="flex items-start gap-3">
                    <div
                      className={`p-2 rounded-lg ${
                        item.type === "pms"
                          ? "bg-blue-500/10"
                          : item.type === "daily"
                          ? "bg-green-500/10"
                          : "bg-purple-500/10"
                      }`}
                    >
                      {item.type === "pms" ? (
                        <Wrench className="w-4 h-4 text-blue-500" />
                      ) : item.type === "daily" ? (
                        <FileText className="w-4 h-4 text-green-500" />
                      ) : (
                        <DollarSign className="w-4 h-4 text-purple-500" />
                      )}
                    </div>
                    <div>
                      <h3 className="font-medium">{item.title}</h3>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="outline">{item.ship}</Badge>
                        {item.amount ? (
                          <span className="text-sm font-medium">
                            {item.amount}
                          </span>
                        ) : (
                          <span className="text-sm text-muted-foreground">
                            By {item.submittedBy}
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">
                        Submitted {item.submitted}
                      </p>
                    </div>
                  </div>
                  <Button>Review</Button>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="crew">
            <div className="text-center text-muted-foreground py-8">
              Crew management content
            </div>
          </TabsContent>

          <TabsContent value="invoices">
            <div className="text-center text-muted-foreground py-8">
              Invoices content
            </div>
          </TabsContent>
        </Tabs>
      </Card>

      {/* Quick Links */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Button
          variant="outline"
          className="justify-between h-auto py-4 px-4"
          onClick={() => (window.location.hash = "crew")}
        >
          <div className="flex items-center">
            <div className="p-2 bg-blue-500/10 rounded-lg mr-3">
              <Users className="w-5 h-5 text-blue-500" />
            </div>
            <div className="text-left">
              <p className="font-medium">Crew Management</p>
              <p className="text-sm text-muted-foreground">
                Manage crew assignments
              </p>
            </div>
          </div>
          <ChevronRight className="w-5 h-5" />
        </Button>

        <Button
          variant="outline"
          className="justify-between h-auto py-4 px-4"
          onClick={() => (window.location.hash = "pms")}
        >
          <div className="flex items-center">
            <div className="p-2 bg-yellow-500/10 rounded-lg mr-3">
              <Wrench className="w-5 h-5 text-yellow-500" />
            </div>
            <div className="text-left">
              <p className="font-medium">PMS Overview</p>
              <p className="text-sm text-muted-foreground">
                Track maintenance status
              </p>
            </div>
          </div>
          <ChevronRight className="w-5 h-5" />
        </Button>

        <Button
          variant="outline"
          className="justify-between h-auto py-4 px-4"
          onClick={() => (window.location.hash = "documents")}
        >
          <div className="flex items-center">
            <div className="p-2 bg-green-500/10 rounded-lg mr-3">
              <FileText className="w-5 h-5 text-green-500" />
            </div>
            <div className="text-left">
              <p className="font-medium">Documents</p>
              <p className="text-sm text-muted-foreground">
                Manage ship documents
              </p>
            </div>
          </div>
          <ChevronRight className="w-5 h-5" />
        </Button>
      </div>
    </div>
  );
}
