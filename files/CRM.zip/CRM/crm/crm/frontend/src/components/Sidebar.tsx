import {
  LayoutDashboard,
  Users,
  Ship,
  UsersRound,
  UserPlus,
  FileText,
  DollarSign,
  BarChart3,
  Settings,
  X,
  Radio,
  Database,
  Wrench,
  ClipboardList,
  Receipt,
  ShieldCheck,
} from "lucide-react";
import { useAuth } from "../contexts/AuthContext";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  currentPage: string;
}

const menuItems = [
  {
    id: "dashboard",
    label: "Dashboard",
    icon: LayoutDashboard,
    roles: ["master", "crew", "staff"],
  },
  { id: "vessels", label: "Vessels", icon: Ship, roles: ["master", "staff"] },
  { id: "crew", label: "Crew", icon: UsersRound, roles: ["master", "staff"] },
  {
    id: "recruitment",
    label: "Recruitment",
    icon: UserPlus,
    roles: ["master", "staff"],
  },
  { id: "pms", label: "PMS", icon: Wrench, roles: ["master", "crew", "staff"] },
  {
    id: "crew-logs",
    label: "Work Logs",
    icon: ClipboardList,
    roles: ["master", "crew", "staff"],
  },
  {
    id: "manuals",
    label: "Manuals",
    icon: FileText,
    roles: ["master", "crew", "staff"],
  },
  {
    id: "incidents",
    label: "Incidents",
    icon: ShieldCheck,
    roles: ["master", "crew", "staff"],
  },
  {
    id: "settings",
    label: "Settings",
    icon: Settings,
    roles: ["master", "crew", "staff"],
  },
];

export function Sidebar({ isOpen, onClose, currentPage }: SidebarProps) {
  const { user } = useAuth();

  // Filter menu items based on user role (convert to lowercase for comparison)
  const visibleMenuItems = menuItems.filter((item) =>
    item.roles.includes(user?.role?.toLowerCase() || "staff")
  );

  return (
    <>
      {/* Sidebar */}
      <aside
        className={`
          fixed lg:static inset-y-0 left-0 z-30
          w-64 bg-sidebar text-sidebar-foreground
          transform transition-transform duration-300 ease-in-out
          ${isOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}
          flex flex-col
        `}
      >
        {/* Logo */}
        <div className="h-16 flex items-center justify-between px-6 border-b border-sidebar-border">
          <div className="flex items-center gap-2">
            <Ship className="w-8 h-8 text-accent" />
            <div className="flex flex-col">
              <span className="text-lg">NMG Marine</span>
              <span className="text-[10px] text-sidebar-foreground/60 -mt-1">
                {user?.role?.toLowerCase() === "master"
                  ? "Master Control"
                  : user?.role?.toLowerCase() === "crew"
                  ? "Crew Portal"
                  : "Staff Portal"}
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="lg:hidden text-sidebar-foreground hover:bg-sidebar-accent rounded p-1"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto py-4">
          {visibleMenuItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;

            return (
              <a
                key={item.id}
                href={`#${item.id}`}
                className={`
                  flex items-center gap-3 px-6 py-3 
                  transition-colors duration-150
                  ${
                    isActive
                      ? "bg-sidebar-accent text-sidebar-primary border-l-4 border-sidebar-primary"
                      : "hover:bg-sidebar-accent/50"
                  }
                `}
                onClick={onClose}
              >
                <Icon className="w-5 h-5" />
                <span>{item.label}</span>
              </a>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="p-4 border-t border-sidebar-border">
          <div className="text-xs text-sidebar-foreground/60">
            © 2024 NMG Marine Service
          </div>
        </div>
      </aside>
    </>
  );
}
