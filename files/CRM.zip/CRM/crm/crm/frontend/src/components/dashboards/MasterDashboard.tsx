import { useState } from "react";
import { useAuth } from "../../contexts/AuthContext";
import { Card } from "../ui/card";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import {
  Ship,
  Users,
  Wrench,
  AlertTriangle,
  FileText,
  CheckCircle2,
  Clock,
  DollarSign,
  ChevronRight,
  BarChart3,
  ShieldCheck,
  Bell,
} from "lucide-react";

export function MasterDashboard() {
  const { ships, selectedShip, setSelectedShip } = useAuth();
  const [activeTab, setActiveTab] = useState("overview");

  // Mock data - replace with real API data
  const stats = {
    totalShips: 7,
    activeShips: 6,
    totalCrew: 156,
    crewOnboard: 124,
    pendingPMS: 23,
    overdueItems: 5,
    pendingApprovals: 12,
    pendingInvoices: 8,
  };

  const alerts = [
    {
      type: "critical",
      message: "Engine maintenance overdue - MV Pacific Star",
      time: "2 hours ago",
    },
    {
      type: "warning",
      message: "3 crew certificates expiring in 30 days",
      time: "5 hours ago",
    },
    {
      type: "info",
      message: "Daily logs pending approval from 5 crew members",
      time: "1 day ago",
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header with Ship Selector */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-card p-6 rounded-xl border">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">
            Master Control
          </h1>
          <p className="text-muted-foreground">
            Managing {stats.totalShips} ships across the fleet
          </p>
        </div>
        <Select value={selectedShip || ""} onValueChange={setSelectedShip}>
          <SelectTrigger className="w-[300px]">
            <SelectValue placeholder="Select Ship" />
          </SelectTrigger>
          <SelectContent>
            {ships.map((ship) => (
              <SelectItem key={ship.id} value={ship.id}>
                <div className="flex items-center justify-between w-full">
                  <span>{ship.name}</span>
                  <Badge
                    variant={ship.status === "active" ? "default" : "secondary"}
                  >
                    {ship.status}
                  </Badge>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Main Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2 lg:grid-cols-4 mb-4">
          <TabsTrigger value="overview">Fleet Overview</TabsTrigger>
          <TabsTrigger value="maintenance">PMS & Maintenance</TabsTrigger>
          <TabsTrigger value="crew">Crew & Operations</TabsTrigger>
          <TabsTrigger value="compliance">Compliance & Audits</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          {/* KPI Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="p-6">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-sm text-muted-foreground">Active Ships</p>
                  <h3 className="text-2xl font-semibold mt-1">
                    {stats.activeShips}/{stats.totalShips}
                  </h3>
                </div>
                <div className="p-3 bg-primary/10 rounded-xl">
                  <Ship className="w-5 h-5 text-primary" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm text-muted-foreground">
                <Clock className="w-4 h-4 mr-1" />
                <span>Last updated 5m ago</span>
              </div>
            </Card>

            <Card className="p-6">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-sm text-muted-foreground">Crew Onboard</p>
                  <h3 className="text-2xl font-semibold mt-1">
                    {stats.crewOnboard}/{stats.totalCrew}
                  </h3>
                </div>
                <div className="p-3 bg-blue-500/10 rounded-xl">
                  <Users className="w-5 h-5 text-blue-500" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm text-muted-foreground">
                <Clock className="w-4 h-4 mr-1" />
                <span>Updated today</span>
              </div>
            </Card>

            <Card className="p-6">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-sm text-muted-foreground">PMS Tasks</p>
                  <h3 className="text-2xl font-semibold mt-1">
                    {stats.pendingPMS}
                  </h3>
                </div>
                <div className="p-3 bg-yellow-500/10 rounded-xl">
                  <Wrench className="w-5 h-5 text-yellow-500" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm text-destructive">
                <AlertTriangle className="w-4 h-4 mr-1" />
                <span>{stats.overdueItems} overdue items</span>
              </div>
            </Card>

            <Card className="p-6">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-sm text-muted-foreground">
                    Pending Approvals
                  </p>
                  <h3 className="text-2xl font-semibold mt-1">
                    {stats.pendingApprovals}
                  </h3>
                </div>
                <div className="p-3 bg-green-500/10 rounded-xl">
                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm text-muted-foreground">
                <FileText className="w-4 h-4 mr-1" />
                <span>{stats.pendingInvoices} invoices pending</span>
              </div>
            </Card>
          </div>

          {/* Quick Actions & Alerts */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Quick Actions */}
            <Card className="col-span-2 p-6">
              <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Button
                  variant="outline"
                  className="justify-between h-auto py-4 px-4"
                  onClick={() => (window.location.hash = "pms")}
                >
                  <div className="flex items-center">
                    <div className="p-2 bg-yellow-500/10 rounded-lg mr-3">
                      <Wrench className="w-5 h-5 text-yellow-500" />
                    </div>
                    <div className="text-left">
                      <p className="font-medium">PMS Tasks</p>
                      <p className="text-sm text-muted-foreground">
                        Review maintenance status
                      </p>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5" />
                </Button>

                <Button
                  variant="outline"
                  className="justify-between h-auto py-4 px-4"
                  onClick={() => (window.location.hash = "crew-logs")}
                >
                  <div className="flex items-center">
                    <div className="p-2 bg-blue-500/10 rounded-lg mr-3">
                      <FileText className="w-5 h-5 text-blue-500" />
                    </div>
                    <div className="text-left">
                      <p className="font-medium">Daily Logs</p>
                      <p className="text-sm text-muted-foreground">
                        Review crew submissions
                      </p>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5" />
                </Button>

                <Button
                  variant="outline"
                  className="justify-between h-auto py-4 px-4"
                  onClick={() => (window.location.hash = "invoices")}
                >
                  <div className="flex items-center">
                    <div className="p-2 bg-green-500/10 rounded-lg mr-3">
                      <DollarSign className="w-5 h-5 text-green-500" />
                    </div>
                    <div className="text-left">
                      <p className="font-medium">Invoices</p>
                      <p className="text-sm text-muted-foreground">
                        Review & approve payments
                      </p>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5" />
                </Button>

                <Button
                  variant="outline"
                  className="justify-between h-auto py-4 px-4"
                  onClick={() => (window.location.hash = "reports")}
                >
                  <div className="flex items-center">
                    <div className="p-2 bg-purple-500/10 rounded-lg mr-3">
                      <BarChart3 className="w-5 h-5 text-purple-500" />
                    </div>
                    <div className="text-left">
                      <p className="font-medium">Reports</p>
                      <p className="text-sm text-muted-foreground">
                        View fleet analytics
                      </p>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5" />
                </Button>
              </div>
            </Card>

            {/* Alerts */}
            <Card className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Critical Alerts</h3>
                <Bell className="w-5 h-5 text-muted-foreground" />
              </div>
              <div className="space-y-4">
                {alerts.map((alert, index) => (
                  <div
                    key={index}
                    className="flex items-start gap-3 p-3 bg-muted rounded-lg"
                  >
                    <div
                      className={`p-2 rounded-lg shrink-0 ${
                        alert.type === "critical"
                          ? "bg-destructive/10"
                          : alert.type === "warning"
                          ? "bg-yellow-500/10"
                          : "bg-blue-500/10"
                      }`}
                    >
                      {alert.type === "critical" ? (
                        <AlertTriangle className={`w-4 h-4 text-destructive`} />
                      ) : alert.type === "warning" ? (
                        <ShieldCheck className="w-4 h-4 text-yellow-500" />
                      ) : (
                        <Bell className="w-4 h-4 text-blue-500" />
                      )}
                    </div>
                    <div>
                      <p className="text-sm font-medium">{alert.message}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {alert.time}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </TabsContent>

        {/* Other Tabs Content */}
        <TabsContent value="maintenance">Maintenance Content</TabsContent>
        <TabsContent value="crew">Crew Content</TabsContent>
        <TabsContent value="compliance">Compliance Content</TabsContent>
      </Tabs>
    </div>
  );
}
