import { useState } from 'react';
import { Plus, Search, Eye, Edit, Send, FileText } from 'lucide-react';
import { Card, CardContent } from '../ui/card';
import { Input } from '../ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '../ui/dialog';
import { DGCommunicationComposer } from './DGCommunicationComposer';

const outCommunications = [
  {
    id: 1,
    letterId: 'NMG-DG-2024-156',
    subject: 'Pre-Joining Letter - MV Ocean Star',
    sentDate: '2024-12-04',
    sentBy: 'John Doe',
    sentTo: 'DG Mumbai',
    vessel: 'MV Ocean Star',
    crew: 'Robert Johnson',
    status: 'Sent',
    category: 'Pre-Joining',
  },
  {
    id: 2,
    letterId: 'NMG-DG-2024-155',
    subject: 'Manning Request - MT Pacific Wave',
    sentDate: '2024-12-03',
    sentBy: 'Sarah Johnson',
    sentTo: 'DG Delhi',
    vessel: 'MT Pacific Wave',
    crew: '-',
    status: 'Awaiting Reply',
    category: 'Manning',
  },
  {
    id: 3,
    letterId: 'NMG-DG-2024-154',
    subject: 'Incident Report - Minor Injury',
    sentDate: '2024-12-02',
    sentBy: 'Mike Brown',
    sentTo: 'DG Chennai',
    vessel: 'MV Atlantic Trader',
    crew: 'Ahmed Hassan',
    status: 'Closed',
    category: 'Incident',
  },
  {
    id: 4,
    letterId: 'NMG-DG-2024-153',
    subject: 'Crew Dispute Resolution Request',
    sentDate: '2024-12-01',
    sentBy: 'John Doe',
    sentTo: 'DG Kolkata',
    vessel: 'MT Indian Star',
    crew: 'Chen Wei',
    status: 'Awaiting Reply',
    category: 'Dispute',
  },
  {
    id: 5,
    letterId: 'NMG-DG-2024-152',
    subject: 'Medical Fitness Certificate Submission',
    sentDate: '2024-11-30',
    sentBy: 'Sarah Johnson',
    sentTo: 'DG Mumbai',
    vessel: '-',
    crew: 'Maria Garcia',
    status: 'Closed',
    category: 'Medical',
  },
];

const statusColors: Record<string, string> = {
  'Sent': 'bg-accent text-accent-foreground',
  'Awaiting Reply': 'bg-warning text-warning-foreground',
  'Closed': 'bg-muted text-muted-foreground',
};

const categoryColors: Record<string, string> = {
  'Pre-Joining': 'bg-blue-100 text-blue-700 border-blue-200',
  'Manning': 'bg-purple-100 text-purple-700 border-purple-200',
  'Incident': 'bg-red-100 text-red-700 border-red-200',
  'Dispute': 'bg-orange-100 text-orange-700 border-orange-200',
  'Medical': 'bg-green-100 text-green-700 border-green-200',
};

export function DGOutCommunication() {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [showComposer, setShowComposer] = useState(false);

  const filteredComms = outCommunications.filter(comm => {
    const matchesSearch = comm.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         comm.letterId.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || comm.status.toLowerCase().replace(' ', '-') === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Header with Create Button */}
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-foreground">Outbound Communications</h3>
          <p className="text-sm text-muted-foreground">
            Letters and communications sent to DG Shipping
          </p>
        </div>
        <Dialog open={showComposer} onOpenChange={setShowComposer}>
          <DialogTrigger asChild>
            <Button className="bg-accent text-accent-foreground hover:bg-accent/90 gap-2">
              <Plus className="w-4 h-4" />
              Create Letter
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create DG Communication</DialogTitle>
              <DialogDescription>
                Draft a new letter to DG Shipping using templates or custom format
              </DialogDescription>
            </DialogHeader>
            <DGCommunicationComposer onClose={() => setShowComposer(false)} />
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative md:col-span-2">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search by subject or letter ID..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="Sent To" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All DG Offices</SelectItem>
                <SelectItem value="mumbai">DG Mumbai</SelectItem>
                <SelectItem value="delhi">DG Delhi</SelectItem>
                <SelectItem value="chennai">DG Chennai</SelectItem>
                <SelectItem value="kolkata">DG Kolkata</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="sent">Sent</SelectItem>
                <SelectItem value="awaiting-reply">Awaiting Reply</SelectItem>
                <SelectItem value="closed">Closed</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Templates Section */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <FileText className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">Quick Templates:</span>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" size="sm" onClick={() => setShowComposer(true)}>
              Pre-Joining Letter
            </Button>
            <Button variant="outline" size="sm" onClick={() => setShowComposer(true)}>
              Manning Request
            </Button>
            <Button variant="outline" size="sm" onClick={() => setShowComposer(true)}>
              Crew Dispute
            </Button>
            <Button variant="outline" size="sm" onClick={() => setShowComposer(true)}>
              Incident Report
            </Button>
            <Button variant="outline" size="sm" onClick={() => setShowComposer(true)}>
              Medical Certification
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Communications Table */}
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Letter ID</TableHead>
                <TableHead>Subject</TableHead>
                <TableHead>Sent Date</TableHead>
                <TableHead>Sent By</TableHead>
                <TableHead>To (DG Office)</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredComms.map((comm) => (
                <TableRow key={comm.id}>
                  <TableCell className="text-primary">{comm.letterId}</TableCell>
                  <TableCell>{comm.subject}</TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {comm.sentDate}
                  </TableCell>
                  <TableCell>{comm.sentBy}</TableCell>
                  <TableCell>{comm.sentTo}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className={categoryColors[comm.category]}>
                      {comm.category}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge className={statusColors[comm.status]}>
                      {comm.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex justify-end gap-2">
                      <Button variant="ghost" size="sm" title="View">
                        <Eye className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="sm" title="Edit">
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="sm" title="Re-send" className="text-accent">
                        <Send className="w-4 h-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
