import { useState } from 'react';
import { Receipt, Plus, Filter, Download, Upload, CheckCircle2, Clock, XCircle, DollarSign } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '../components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { useAuth } from '../contexts/AuthContext';
import { toast } from 'sonner@2.0.3';

interface Invoice {
  id: string;
  invoiceNumber: string;
  shipName: string;
  category: string;
  vendor: string;
  amount: number;
  currency: string;
  date: string;
  dueDate: string;
  status: 'draft' | 'submitted' | 'approved' | 'paid' | 'rejected';
  description: string;
  uploadedBy: string;
  approvedBy?: string;
  paidDate?: string;
  attachmentUrl?: string;
}

const mockInvoices: Invoice[] = [
  {
    id: 'inv-1',
    invoiceNumber: 'INV-2024-001',
    shipName: 'MV Ocean Star',
    category: 'Fuel',
    vendor: 'Marine Fuel Suppliers Ltd',
    amount: 45000,
    currency: 'USD',
    date: '2024-12-15',
    dueDate: '2025-01-15',
    status: 'approved',
    description: 'Bunker fuel supply - 500 MT',
    uploadedBy: 'Sarah Johnson',
    approvedBy: 'Captain Anderson',
  },
  {
    id: 'inv-2',
    invoiceNumber: 'INV-2024-002',
    shipName: 'MT Pacific Wave',
    category: 'Maintenance',
    vendor: 'Ship Repair Services',
    amount: 12500,
    currency: 'USD',
    date: '2024-12-14',
    dueDate: '2025-01-14',
    status: 'submitted',
    description: 'Main engine overhaul - Parts and labor',
    uploadedBy: 'Sarah Johnson',
  },
  {
    id: 'inv-3',
    invoiceNumber: 'INV-2024-003',
    shipName: 'MV Atlantic Trader',
    category: 'Provisions',
    vendor: 'Global Marine Provisions',
    amount: 8900,
    currency: 'USD',
    date: '2024-12-16',
    dueDate: '2025-01-10',
    status: 'draft',
    description: 'Monthly crew provisions and supplies',
    uploadedBy: 'Sarah Johnson',
  },
  {
    id: 'inv-4',
    invoiceNumber: 'INV-2024-004',
    shipName: 'MT Indian Star',
    category: 'Port Fees',
    vendor: 'Singapore Port Authority',
    amount: 25000,
    currency: 'SGD',
    date: '2024-12-13',
    dueDate: '2024-12-28',
    status: 'paid',
    description: 'Port dues and pilotage charges',
    uploadedBy: 'Sarah Johnson',
    approvedBy: 'Captain Anderson',
    paidDate: '2024-12-20',
  },
  {
    id: 'inv-5',
    invoiceNumber: 'INV-2024-005',
    shipName: 'MV Ocean Star',
    category: 'Safety Equipment',
    vendor: 'Maritime Safety Co.',
    amount: 5600,
    currency: 'USD',
    date: '2024-12-12',
    dueDate: '2025-01-12',
    status: 'submitted',
    description: 'Fire extinguishers and life jackets replacement',
    uploadedBy: 'Sarah Johnson',
  },
];

export function Invoices() {
  const { user, ships } = useAuth();
  const [invoices, setInvoices] = useState<Invoice[]>(mockInvoices);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [filter, setFilter] = useState('all');
  const [newInvoice, setNewInvoice] = useState({
    invoiceNumber: '',
    shipId: '',
    category: '',
    vendor: '',
    amount: '',
    currency: 'USD',
    date: new Date().toISOString().split('T')[0],
    dueDate: '',
    description: '',
    attachment: null as File | null,
  });

  const isMaster = user?.role === 'master';
  const isStaff = user?.role === 'staff';

  // Filter invoices
  const filteredInvoices = filter === 'all' 
    ? invoices 
    : invoices.filter(inv => inv.status === filter);

  // Calculate totals
  const totalAmount = invoices.reduce((sum, inv) => sum + inv.amount, 0);
  const pendingAmount = invoices
    .filter(inv => inv.status === 'submitted' || inv.status === 'approved')
    .reduce((sum, inv) => sum + inv.amount, 0);
  const paidAmount = invoices
    .filter(inv => inv.status === 'paid')
    .reduce((sum, inv) => sum + inv.amount, 0);

  const counts = {
    draft: invoices.filter(inv => inv.status === 'draft').length,
    submitted: invoices.filter(inv => inv.status === 'submitted').length,
    approved: invoices.filter(inv => inv.status === 'approved').length,
    paid: invoices.filter(inv => inv.status === 'paid').length,
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'paid':
        return <Badge className="bg-green-50 text-green-700 border-green-200">Paid</Badge>;
      case 'approved':
        return <Badge className="bg-blue-50 text-blue-700 border-blue-200">Approved</Badge>;
      case 'submitted':
        return <Badge className="bg-yellow-50 text-yellow-700 border-yellow-200">Submitted</Badge>;
      case 'rejected':
        return <Badge className="bg-red-50 text-red-700 border-red-200">Rejected</Badge>;
      default:
        return <Badge className="bg-gray-50 text-gray-700 border-gray-200">Draft</Badge>;
    }
  };

  const handleCreateInvoice = () => {
    if (!newInvoice.invoiceNumber || !newInvoice.shipId || !newInvoice.category || !newInvoice.amount) {
      toast.error('Please fill in all required fields');
      return;
    }

    const ship = ships.find(s => s.id === newInvoice.shipId);
    const invoice: Invoice = {
      id: `inv-${Date.now()}`,
      invoiceNumber: newInvoice.invoiceNumber,
      shipName: ship?.name || 'Unknown Ship',
      category: newInvoice.category,
      vendor: newInvoice.vendor,
      amount: parseFloat(newInvoice.amount),
      currency: newInvoice.currency,
      date: newInvoice.date,
      dueDate: newInvoice.dueDate,
      status: 'draft',
      description: newInvoice.description,
      uploadedBy: user?.name || 'Unknown',
    };

    setInvoices([invoice, ...invoices]);
    setIsCreateDialogOpen(false);
    setNewInvoice({
      invoiceNumber: '',
      shipId: '',
      category: '',
      vendor: '',
      amount: '',
      currency: 'USD',
      date: new Date().toISOString().split('T')[0],
      dueDate: '',
      description: '',
      attachment: null,
    });
    toast.success('Invoice created successfully');
  };

  const handleStatusChange = (invoiceId: string, newStatus: Invoice['status']) => {
    const updatedInvoices = invoices.map(inv => {
      if (inv.id === invoiceId) {
        return {
          ...inv,
          status: newStatus,
          approvedBy: newStatus === 'approved' || newStatus === 'paid' ? user?.name : inv.approvedBy,
          paidDate: newStatus === 'paid' ? new Date().toISOString().split('T')[0] : inv.paidDate,
        };
      }
      return inv;
    });

    setInvoices(updatedInvoices);
    toast.success(`Invoice ${newStatus} successfully`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-foreground text-2xl font-semibold">Invoice Management</h1>
          <p className="text-muted-foreground mt-1">
            {isStaff ? 'Upload and manage invoices across all ships' : 'Review and approve invoices'}
          </p>
        </div>
        {(isStaff || isMaster) && (
          <Button 
            className="bg-accent text-accent-foreground hover:bg-accent/90"
            onClick={() => setIsCreateDialogOpen(true)}
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Invoice
          </Button>
        )}
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="shadow-md">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Amount</p>
                <p className="text-2xl font-semibold text-foreground mt-1">
                  ${(totalAmount / 1000).toFixed(1)}K
                </p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-blue-50 flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-md">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Pending</p>
                <p className="text-2xl font-semibold text-foreground mt-1">
                  ${(pendingAmount / 1000).toFixed(1)}K
                </p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-yellow-50 flex items-center justify-center">
                <Clock className="w-6 h-6 text-yellow-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-md">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Paid</p>
                <p className="text-2xl font-semibold text-foreground mt-1">
                  ${(paidAmount / 1000).toFixed(1)}K
                </p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-green-50 flex items-center justify-center">
                <CheckCircle2 className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-md">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Awaiting Approval</p>
                <p className="text-2xl font-semibold text-foreground mt-1">{counts.submitted}</p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center">
                <Receipt className="w-6 h-6 text-accent" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Invoices Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Invoices</CardTitle>
            <div className="flex items-center gap-2">
              <Select value={filter} onValueChange={setFilter}>
                <SelectTrigger className="w-[160px]">
                  <Filter className="w-4 h-4 mr-2" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Invoices</SelectItem>
                  <SelectItem value="draft">Draft</SelectItem>
                  <SelectItem value="submitted">Submitted</SelectItem>
                  <SelectItem value="approved">Approved</SelectItem>
                  <SelectItem value="paid">Paid</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" size="sm">
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isMaster && invoices.filter(inv => inv.status === 'submitted').length > 0 && (
            <div className="mb-6">
              <h3 className="font-semibold text-foreground mb-3">Pending Approval</h3>
              <div className="space-y-3">
                {invoices.filter(inv => inv.status === 'submitted').map((invoice) => (
                  <div key={invoice.id} className="border border-border rounded-lg p-4 bg-yellow-50/30">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h4 className="font-semibold text-foreground">{invoice.invoiceNumber}</h4>
                        <p className="text-sm text-muted-foreground mt-1">
                          {invoice.shipName} • {invoice.vendor} • {invoice.category}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-foreground">{invoice.currency} {invoice.amount.toLocaleString()}</p>
                        <p className="text-xs text-muted-foreground mt-1">Due: {invoice.dueDate}</p>
                      </div>
                    </div>
                    <p className="text-sm text-foreground mb-3">{invoice.description}</p>
                    <div className="flex items-center gap-2">
                      <Button 
                        size="sm" 
                        className="bg-green-600 hover:bg-green-700"
                        onClick={() => handleStatusChange(invoice.id, 'approved')}
                      >
                        <CheckCircle2 className="w-4 h-4 mr-2" />
                        Approve
                      </Button>
                      <Button 
                        size="sm" 
                        variant="destructive"
                        onClick={() => handleStatusChange(invoice.id, 'rejected')}
                      >
                        <XCircle className="w-4 h-4 mr-2" />
                        Reject
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Invoice #</TableHead>
                <TableHead>Ship</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Vendor</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Due Date</TableHead>
                <TableHead>Status</TableHead>
                {isStaff && <TableHead>Actions</TableHead>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredInvoices.map((invoice) => (
                <TableRow key={invoice.id}>
                  <TableCell className="font-medium">{invoice.invoiceNumber}</TableCell>
                  <TableCell className="text-sm">{invoice.shipName}</TableCell>
                  <TableCell>
                    <Badge variant="outline">{invoice.category}</Badge>
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">{invoice.vendor}</TableCell>
                  <TableCell className="font-medium">
                    {invoice.currency} {invoice.amount.toLocaleString()}
                  </TableCell>
                  <TableCell className="text-sm">{invoice.date}</TableCell>
                  <TableCell className="text-sm">{invoice.dueDate}</TableCell>
                  <TableCell>{getStatusBadge(invoice.status)}</TableCell>
                  {isStaff && (
                    <TableCell>
                      {invoice.status === 'draft' && (
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => handleStatusChange(invoice.id, 'submitted')}
                        >
                          Submit
                        </Button>
                      )}
                      {invoice.status === 'approved' && (
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => handleStatusChange(invoice.id, 'paid')}
                        >
                          Mark Paid
                        </Button>
                      )}
                    </TableCell>
                  )}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Create Invoice Dialog */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Create New Invoice</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 max-h-[60vh] overflow-y-auto">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="invoiceNumber">Invoice Number *</Label>
                <Input
                  id="invoiceNumber"
                  value={newInvoice.invoiceNumber}
                  onChange={(e) => setNewInvoice({ ...newInvoice, invoiceNumber: e.target.value })}
                  placeholder="INV-2024-XXX"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="ship">Ship *</Label>
                <Select value={newInvoice.shipId} onValueChange={(value) => setNewInvoice({ ...newInvoice, shipId: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select ship" />
                  </SelectTrigger>
                  <SelectContent>
                    {ships.map((ship) => (
                      <SelectItem key={ship.id} value={ship.id}>
                        {ship.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="vendor">Vendor Name</Label>
              <Input
                id="vendor"
                value={newInvoice.vendor}
                onChange={(e) => setNewInvoice({ ...newInvoice, vendor: e.target.value })}
                placeholder="Enter vendor name"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="category">Category *</Label>
              <Select value={newInvoice.category} onValueChange={(value) => setNewInvoice({ ...newInvoice, category: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Fuel">Fuel</SelectItem>
                  <SelectItem value="Maintenance">Maintenance</SelectItem>
                  <SelectItem value="Provisions">Provisions</SelectItem>
                  <SelectItem value="Port Fees">Port Fees</SelectItem>
                  <SelectItem value="Safety Equipment">Safety Equipment</SelectItem>
                  <SelectItem value="Spare Parts">Spare Parts</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="amount">Amount *</Label>
                <Input
                  id="amount"
                  type="number"
                  step="0.01"
                  value={newInvoice.amount}
                  onChange={(e) => setNewInvoice({ ...newInvoice, amount: e.target.value })}
                  placeholder="0.00"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="currency">Currency</Label>
                <Select value={newInvoice.currency} onValueChange={(value) => setNewInvoice({ ...newInvoice, currency: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="USD">USD</SelectItem>
                    <SelectItem value="EUR">EUR</SelectItem>
                    <SelectItem value="SGD">SGD</SelectItem>
                    <SelectItem value="GBP">GBP</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="date">Invoice Date</Label>
                <Input
                  id="date"
                  type="date"
                  value={newInvoice.date}
                  onChange={(e) => setNewInvoice({ ...newInvoice, date: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="dueDate">Due Date</Label>
                <Input
                  id="dueDate"
                  type="date"
                  value={newInvoice.dueDate}
                  onChange={(e) => setNewInvoice({ ...newInvoice, dueDate: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={newInvoice.description}
                onChange={(e) => setNewInvoice({ ...newInvoice, description: e.target.value })}
                placeholder="Invoice description..."
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="attachment">Attach Invoice (PDF/Image)</Label>
              <Button variant="outline" size="sm" className="w-full" asChild>
                <label htmlFor="attachment" className="cursor-pointer">
                  <Upload className="w-4 h-4 mr-2" />
                  Upload File
                  <input
                    id="attachment"
                    type="file"
                    accept=".pdf,.jpg,.jpeg,.png"
                    className="hidden"
                    onChange={(e) => setNewInvoice({ ...newInvoice, attachment: e.target.files?.[0] || null })}
                  />
                </label>
              </Button>
              {newInvoice.attachment && (
                <p className="text-xs text-muted-foreground">{newInvoice.attachment.name}</p>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>Cancel</Button>
            <Button className="bg-accent text-accent-foreground hover:bg-accent/90" onClick={handleCreateInvoice}>
              Create Invoice
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
