import { useState, useEffect } from 'react';
import { Users, Database, Mail, Bell, Plus, Loader2 } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../components/ui/table';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Switch } from '../components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { toast } from 'sonner';
import { authApi } from '../services/api';

const masterCategories = [
  { id: 1, name: 'Country', count: 195, lastUpdated: '2024-11-15' },
  { id: 2, name: 'Location', count: 542, lastUpdated: '2024-11-20' },
  { id: 3, name: 'Currency', count: 42, lastUpdated: '2024-10-05' },
  { id: 4, name: 'Rank', count: 28, lastUpdated: '2024-11-10' },
  { id: 5, name: 'Ship Type', count: 15, lastUpdated: '2024-09-25' },
  { id: 6, name: 'Validity Types', count: 35, lastUpdated: '2024-11-01' },
  { id: 7, name: 'Document Types', count: 42, lastUpdated: '2024-10-15' },
];

const templates = [
  { id: 1, name: 'Welcome Email', type: 'Email', lastModified: '2024-11-25' },
  { id: 2, name: 'Pre-Joining Letter', type: 'Document', lastModified: '2024-11-20' },
  { id: 3, name: 'Contract Template - Officer', type: 'Document', lastModified: '2024-11-15' },
  { id: 4, name: 'Contract Template - Rating', type: 'Document', lastModified: '2024-11-15' },
  { id: 5, name: 'Document Expiry Reminder', type: 'Email', lastModified: '2024-11-10' },
];

export function Settings() {
  const [isCreateUserOpen, setIsCreateUserOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [newUser, setNewUser] = useState({
    name: '',
    email: '',
    password: '',
    role: 'STAFF'
  });

  const [users, setUsers] = useState<any[]>([]);
  const [loadingUsers, setLoadingUsers] = useState<boolean>(true);

  const [isEditUserOpen, setIsEditUserOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<any | null>(null);
  const [editUserForm, setEditUserForm] = useState({
    name: '',
    email: '',
    role: 'STAFF',
    status: 'ACTIVE',
  });

  const fetchUsers = async () => {
    try {
      setLoadingUsers(true);
      const data = await authApi.getUsers();
      setUsers(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error('Failed to load users', error);
      toast.error('Failed to load users');
      setUsers([]);
    } finally {
      setLoadingUsers(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      await authApi.signup(newUser);
      toast.success('User created successfully');
      setIsCreateUserOpen(false);
      setNewUser({
        name: '',
        email: '',
        password: '',
        role: 'STAFF'
      });
      await fetchUsers();
    } catch (error: any) {
      toast.error(error.message || 'Failed to create user');
    } finally {
      setIsSubmitting(false);
    }
  };

  const openEditUser = (user: any) => {
    setEditingUser(user);
    setEditUserForm({
      name: user.name || '',
      email: user.email || '',
      role: (user.role || 'STAFF').toUpperCase(),
      status: (user.status || 'ACTIVE').toUpperCase(),
    });
    setIsEditUserOpen(true);
  };

  const handleEditUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    setIsSubmitting(true);
    try {
      await authApi.updateUser(editingUser.id, editUserForm);
      toast.success('User updated successfully');
      setIsEditUserOpen(false);
      setEditingUser(null);
      await fetchUsers();
    } catch (error: any) {
      toast.error(error.message || 'Failed to update user');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-foreground">Settings</h2>
        <p className="text-sm text-muted-foreground">Manage system settings, users, and configurations</p>
      </div>

      {/* Settings Tabs */}
      <Tabs defaultValue="users" className="space-y-6">
        <TabsList className="bg-card border border-border">
          <TabsTrigger value="users" className="gap-2">
            <Users className="w-4 h-4" />
            User Management
          </TabsTrigger>
          <TabsTrigger value="terms" className="gap-2">
            Terms & Conditions
          </TabsTrigger>
          <TabsTrigger value="privacy" className="gap-2">
            Privacy Policy
          </TabsTrigger>
        </TabsList>

        {/* User Management Tab */}
        <TabsContent value="users" className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-foreground">User Management</h3>
              <p className="text-sm text-muted-foreground">Manage user accounts and permissions</p>
            </div>
            <Dialog open={isCreateUserOpen} onOpenChange={setIsCreateUserOpen}>
              <DialogTrigger asChild>
                <Button className="bg-accent text-accent-foreground hover:bg-accent/90">
                  Create User
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>Create New User</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleCreateUser} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name *</Label>
                    <Input
                      id="name"
                      value={newUser.name}
                      onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
                      placeholder="Full name"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={newUser.email}
                      onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                      placeholder="email@example.com"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password">Password *</Label>
                    <Input
                      id="password"
                      type="password"
                      value={newUser.password}
                      onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                      placeholder="Password"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="role">Role *</Label>
                    <Select value={newUser.role} onValueChange={(v) => setNewUser({ ...newUser, role: v })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="MASTER">Master</SelectItem>
                        <SelectItem value="STAFF">Staff</SelectItem>
                        <SelectItem value="CREW">Crew</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex justify-end gap-2 pt-4">
                    <Button type="button" variant="outline" onClick={() => setIsCreateUserOpen(false)}>
                      Cancel
                    </Button>
                    <Button type="submit" disabled={isSubmitting}>
                      {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                      Create User
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell>{user.name}</TableCell>
                      <TableCell className="text-muted-foreground">{user.email}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{user.role}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className={user.status && user.status.toUpperCase() === 'ACTIVE' ? 'bg-accent text-accent-foreground' : 'bg-muted text-muted-foreground'}>
                          {user.status ? user.status.charAt(0) + user.status.slice(1).toLowerCase() : ''}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button variant="outline" size="sm" onClick={() => openEditUser(user)}>Edit</Button>
                          <Button variant="outline" size="sm">Reset Password</Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          {/* Edit User Dialog */}
          <Dialog open={isEditUserOpen} onOpenChange={setIsEditUserOpen}>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Edit User</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleEditUser} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-name">Full Name *</Label>
                  <Input
                    id="edit-name"
                    value={editUserForm.name}
                    onChange={(e) => setEditUserForm({ ...editUserForm, name: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-email">Email *</Label>
                  <Input
                    id="edit-email"
                    type="email"
                    value={editUserForm.email}
                    onChange={(e) => setEditUserForm({ ...editUserForm, email: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-role">Role *</Label>
                  <Select
                    value={editUserForm.role}
                    onValueChange={(v) => setEditUserForm({ ...editUserForm, role: v })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="MASTER">Master</SelectItem>
                      <SelectItem value="STAFF">Staff</SelectItem>
                      <SelectItem value="CREW">Crew</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-status">Status *</Label>
                  <Select
                    value={editUserForm.status}
                    onValueChange={(v) => setEditUserForm({ ...editUserForm, status: v })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ACTIVE">Active</SelectItem>
                      <SelectItem value="INACTIVE">Inactive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex justify-end gap-2 pt-4">
                  <Button type="button" variant="outline" onClick={() => setIsEditUserOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={isSubmitting}>
                    {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                    Save Changes
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </TabsContent>

        {/* Terms & Conditions Tab */}
        <TabsContent value="terms" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Terms & Conditions</CardTitle>
              <CardDescription>NMG Marine Service - Terms of Use</CardDescription>
            </CardHeader>
            <CardContent className="prose prose-sm max-w-none">
              <h3 className="text-lg font-semibold mb-3">1. Acceptance of Terms</h3>
              <p className="text-muted-foreground mb-4">
                By accessing and using the NMG Marine CRM system, you accept and agree to be bound by the terms and provision of this agreement.
              </p>

              <h3 className="text-lg font-semibold mb-3">2. Use License</h3>
              <p className="text-muted-foreground mb-4">
                Permission is granted to temporarily access the materials (information or software) on NMG Marine's CRM system for personal, non-commercial transitory viewing only. This is the grant of a license, not a transfer of title.
              </p>

              <h3 className="text-lg font-semibold mb-3">3. User Obligations</h3>
              <ul className="list-disc pl-6 text-muted-foreground mb-4">
                <li>Maintain the confidentiality of your account credentials</li>
                <li>Notify us immediately of any unauthorized use of your account</li>
                <li>Use the system only for lawful purposes and in accordance with these Terms</li>
                <li>Not attempt to gain unauthorized access to any portion of the system</li>
                <li>Not transmit any malicious code, viruses, or harmful data</li>
              </ul>

              <h3 className="text-lg font-semibold mb-3">4. Data Security</h3>
              <p className="text-muted-foreground mb-4">
                We implement appropriate security measures to protect your data. However, no system is completely secure, and we cannot guarantee absolute security of data transmitted through the system.
              </p>

              <h3 className="text-lg font-semibold mb-3">5. Intellectual Property</h3>
              <p className="text-muted-foreground mb-4">
                All content, features, and functionality of the NMG Marine CRM system are owned by NMG Marine Service and are protected by international copyright, trademark, and other intellectual property laws.
              </p>

              <h3 className="text-lg font-semibold mb-3">6. Limitation of Liability</h3>
              <p className="text-muted-foreground mb-4">
                In no event shall NMG Marine Service be liable for any damages arising out of the use or inability to use the materials on the CRM system, even if NMG Marine or an authorized representative has been notified of the possibility of such damage.
              </p>

              <h3 className="text-lg font-semibold mb-3">7. Modifications</h3>
              <p className="text-muted-foreground mb-4">
                NMG Marine may revise these terms of service at any time without notice. By using this system, you agree to be bound by the current version of these terms and conditions.
              </p>

              <p className="text-sm text-muted-foreground mt-6">
                Last updated: December 2024<br />
                For questions regarding these terms, contact: legal@nmg-marine.com
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Privacy Policy Tab */}
        <TabsContent value="privacy" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Privacy Policy</CardTitle>
              <CardDescription>How we collect, use, and protect your information</CardDescription>
            </CardHeader>
            <CardContent className="prose prose-sm max-w-none">
              <h3 className="text-lg font-semibold mb-3">1. Information We Collect</h3>
              <p className="text-muted-foreground mb-4">
                We collect information that you provide directly to us, including:
              </p>
              <ul className="list-disc pl-6 text-muted-foreground mb-4">
                <li>Personal identification information (name, email address, phone number)</li>
                <li>Professional information (rank, certifications, sea time, nationality)</li>
                <li>Employment records and documents</li>
                <li>Vessel and crew management data</li>
                <li>System usage and activity logs</li>
              </ul>

              <h3 className="text-lg font-semibold mb-3">2. How We Use Your Information</h3>
              <p className="text-muted-foreground mb-4">
                We use the information we collect to:
              </p>
              <ul className="list-disc pl-6 text-muted-foreground mb-4">
                <li>Provide, maintain, and improve our services</li>
                <li>Process crew assignments and manage vessel operations</li>
                <li>Send notifications about certificate expiries and important updates</li>
                <li>Comply with legal and regulatory requirements</li>
                <li>Analyze system usage to enhance user experience</li>
              </ul>

              <h3 className="text-lg font-semibold mb-3">3. Data Security</h3>
              <p className="text-muted-foreground mb-4">
                We implement industry-standard security measures including:
              </p>
              <ul className="list-disc pl-6 text-muted-foreground mb-4">
                <li>Encrypted data transmission (SSL/TLS)</li>
                <li>Secure password hashing</li>
                <li>Role-based access control</li>
                <li>Regular security audits and updates</li>
                <li>Restricted database access</li>
              </ul>

              <h3 className="text-lg font-semibold mb-3">4. Information Sharing</h3>
              <p className="text-muted-foreground mb-4">
                We do not sell your personal information. We may share your information only in the following circumstances:
              </p>
              <ul className="list-disc pl-6 text-muted-foreground mb-4">
                <li>With your explicit consent</li>
                <li>To comply with legal obligations</li>
                <li>To protect the rights and safety of NMG Marine, our users, or others</li>
                <li>With service providers who assist in our operations (under strict confidentiality)</li>
              </ul>

              <h3 className="text-lg font-semibold mb-3">5. Data Retention</h3>
              <p className="text-muted-foreground mb-4">
                We retain your personal information for as long as necessary to fulfill the purposes outlined in this policy, unless a longer retention period is required by law.
              </p>

              <h3 className="text-lg font-semibold mb-3">6. Your Rights</h3>
              <p className="text-muted-foreground mb-4">
                You have the right to:
              </p>
              <ul className="list-disc pl-6 text-muted-foreground mb-4">
                <li>Access your personal information</li>
                <li>Request correction of inaccurate data</li>
                <li>Request deletion of your data (subject to legal obligations)</li>
                <li>Object to processing of your information</li>
                <li>Request data portability</li>
              </ul>

              <h3 className="text-lg font-semibold mb-3">7. Cookies and Tracking</h3>
              <p className="text-muted-foreground mb-4">
                We use local storage and cookies to maintain your session and improve user experience. You can control cookie settings through your browser.
              </p>

              <h3 className="text-lg font-semibold mb-3">8. Changes to This Policy</h3>
              <p className="text-muted-foreground mb-4">
                We may update this privacy policy from time to time. We will notify you of any changes by posting the new policy on this page and updating the "Last updated" date.
              </p>

              <h3 className="text-lg font-semibold mb-3">9. Contact Us</h3>
              <p className="text-muted-foreground mb-4">
                If you have any questions about this privacy policy or our data practices, please contact us at:
              </p>
              <p className="text-muted-foreground">
                Email: privacy@nmg-marine.com<br />
                Phone: +1 (555) 123-4567<br />
                Address: NMG Marine Service, 123 Maritime Plaza, Port City, MC 12345
              </p>

              <p className="text-sm text-muted-foreground mt-6">
                Last updated: December 2024
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
