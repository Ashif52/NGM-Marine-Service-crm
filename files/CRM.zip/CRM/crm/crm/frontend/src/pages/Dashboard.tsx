import { useState, useEffect } from "react";
import {
  Users,
  Ship,
  UsersRound,
  UserPlus,
  TrendingUp,
  TrendingDown,
  Wrench,
  AlertCircle,
  Clock,
  CheckCircle2,
  Loader2,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../components/ui/table";
import {
  LineChart,
  Line,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
} from "recharts";
import { useAuth } from "../contexts/AuthContext";
import { Button } from "../components/ui/button";
import { shipsApi, crewApi, certificatesApi } from "../services/api";
import { toast } from "sonner";

function getDaysRemainingColor(days: number) {
  if (days <= 30) return "bg-destructive text-destructive-foreground";
  if (days <= 60) return "bg-warning text-warning-foreground";
  return "bg-accent text-accent-foreground";
}

export function Dashboard() {
  const { user, selectedShip, ships } = useAuth();
  const currentShip = ships.find((s) => s.id === selectedShip);

  const [loading, setLoading] = useState(true);
  const [dashboardData, setDashboardData] = useState({
    totalShips: 0,
    activeShips: 0,
    totalCrew: 0,
    crewOnboard: 0,
    crewAvailable: 0,
  });
  const [expiringCerts, setExpiringCerts] = useState<any[]>([]);

  const isMaster = user?.role?.toLowerCase() === "master";
  const isCrew = user?.role?.toLowerCase() === "crew";
  const isStaff = user?.role?.toLowerCase() === "staff";

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        setLoading(true);

        // Fetch ships data
        const shipsData = await shipsApi.getAll();
        const activeShips = shipsData.filter(
          (s) => s.status === "ACTIVE"
        ).length;

        // Fetch crew data
        const crewData = await crewApi.getAll();
        const crewOnboard = crewData.filter(
          (c) => c.availability === "ONBOARD"
        ).length;
        const crewAvailable = crewData.filter(
          (c) => c.availability === "AVAILABLE"
        ).length;

        // Fetch expiring certificates (next 60 days)
        const expiring = await certificatesApi.getExpiring(60);

        setDashboardData({
          totalShips: shipsData.length,
          activeShips,
          totalCrew: crewData.length,
          crewOnboard,
          crewAvailable,
        });

        setExpiringCerts(expiring);
      } catch (error: any) {
        console.error("Dashboard data fetch error:", error);
        toast.error("Failed to load dashboard data");
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  // Master sees fleet overview, Crew/Staff see ship-specific data
  const kpiData = isMaster
    ? [
        {
          title: "Total Ships",
          value: dashboardData.totalShips.toString(),
          change: "",
          trend: "up",
          icon: Ship,
          chartData: [0, 0, 0, 0, 0, dashboardData.totalShips],
        },
        {
          title: "Active Vessels",
          value: dashboardData.activeShips.toString(),
          change: "",
          trend: "up",
          icon: Ship,
          chartData: [0, 0, 0, 0, 0, dashboardData.activeShips],
        },
        {
          title: "Total Crew",
          value: dashboardData.totalCrew.toString(),
          change: "",
          trend: "up",
          icon: UsersRound,
          chartData: [0, 0, 0, 0, 0, dashboardData.totalCrew],
        },
        {
          title: "Crew Onboard",
          value: dashboardData.crewOnboard.toString(),
          change: "",
          trend: "up",
          icon: UsersRound,
          chartData: [0, 0, 0, 0, 0, dashboardData.crewOnboard],
        },
        {
          title: "Crew Available",
          value: dashboardData.crewAvailable.toString(),
          change: "",
          trend: "up",
          icon: UserPlus,
          chartData: [0, 0, 0, 0, 0, dashboardData.crewAvailable],
        },
      ]
    : [
        {
          title: "Crew Onboard",
          value: dashboardData.crewOnboard.toString(),
          change: "",
          trend: "up",
          icon: UsersRound,
          chartData: [0, 0, 0, 0, 0, dashboardData.crewOnboard],
        },
        {
          title: "Crew Available",
          value: dashboardData.crewAvailable.toString(),
          change: "",
          trend: "up",
          icon: UserPlus,
          chartData: [0, 0, 0, 0, 0, dashboardData.crewAvailable],
        },
        {
          title: "Total Ships",
          value: dashboardData.totalShips.toString(),
          change: "",
          trend: "up",
          icon: Ship,
          chartData: [0, 0, 0, 0, 0, dashboardData.totalShips],
        },
        {
          title: "Active Vessels",
          value: dashboardData.activeShips.toString(),
          change: "",
          trend: "up",
          icon: Ship,
          chartData: [0, 0, 0, 0, 0, dashboardData.activeShips],
        },
      ];

  return (
    <div className="space-y-6">
      {/* Welcome Header */}
      <div className="bg-gradient-to-r from-primary to-[#02283F] p-6 rounded-2xl shadow-lg">
        <h1 className="text-white text-2xl font-semibold mb-2">
          Welcome back, {user?.name}!
        </h1>
        <p className="text-white/80">
          {isMaster && `Managing ${ships.length} ships across the fleet`}
          {isCrew && `Currently assigned to ${currentShip?.name}`}
          {isStaff && `Managing operations for all vessels`}
        </p>
        {isMaster && (
          <div className="mt-4 flex items-center gap-2">
            <Badge className="bg-white/20 text-white border-white/30">
              Viewing: {currentShip?.name}
            </Badge>
            <Badge className="bg-white/20 text-white border-white/30">
              Status: {currentShip?.status}
            </Badge>
          </div>
        )}
      </div>

      {/* KPI Cards */}
      <div
        className={`grid grid-cols-1 md:grid-cols-2 ${
          isMaster ? "lg:grid-cols-5" : "lg:grid-cols-4"
        } gap-6`}
      >
        {kpiData.map((kpi, index) => {
          const Icon = kpi.icon;
          const TrendIcon = kpi.trend === "up" ? TrendingUp : TrendingDown;

          return (
            <Card key={index} className="shadow-lg">
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <p className="text-sm text-muted-foreground mb-1">
                      {kpi.title}
                    </p>
                    <div className="text-3xl font-semibold text-foreground">
                      {kpi.value}
                    </div>
                    <div
                      className={`flex items-center gap-1 mt-2 text-sm ${
                        kpi.trend === "up" ? "text-accent" : "text-destructive"
                      }`}
                    >
                      <TrendIcon className="w-4 h-4" />
                      <span>{kpi.change}</span>
                    </div>
                  </div>
                  <div className="w-12 h-12 rounded-xl bg-[#E6F3FF] flex items-center justify-center">
                    <Icon className="w-6 h-6 text-primary" />
                  </div>
                </div>
                <div className="h-12">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={kpi.chartData.map((value, i) => ({
                        value,
                        index: i,
                      }))}
                    >
                      <Line
                        type="monotone"
                        dataKey="value"
                        stroke={kpi.trend === "up" ? "#1ABC9C" : "#E74C3C"}
                        strokeWidth={2}
                        dot={false}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Master-specific: Quick Actions */}
      {isMaster && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card
            className="shadow-md hover:shadow-lg transition-shadow cursor-pointer"
            onClick={() => (window.location.hash = "pms")}
          >
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">PMS Approvals</p>
                  <p className="text-xl font-semibold text-foreground mt-1">
                    5 Pending
                  </p>
                </div>
                <Wrench className="w-8 h-8 text-accent" />
              </div>
            </CardContent>
          </Card>

          <Card
            className="shadow-md hover:shadow-lg transition-shadow cursor-pointer"
            onClick={() => (window.location.hash = "crew-logs")}
          >
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">
                    Daily Log Reviews
                  </p>
                  <p className="text-xl font-semibold text-foreground mt-1">
                    4 Pending
                  </p>
                </div>
                <CheckCircle2 className="w-8 h-8 text-accent" />
              </div>
            </CardContent>
          </Card>

          <Card
            className="shadow-md hover:shadow-lg transition-shadow cursor-pointer"
            onClick={() => (window.location.hash = "invoices")}
          >
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">
                    Invoice Approvals
                  </p>
                  <p className="text-xl font-semibold text-foreground mt-1">
                    3 Pending
                  </p>
                </div>
                <AlertCircle className="w-8 h-8 text-accent" />
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Crew-specific: My Tasks */}
      {isCrew && (
        <Card className="shadow-md">
          <CardHeader>
            <CardTitle>My Tasks Today</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                <div>
                  <p className="font-medium text-foreground">
                    Main Engine Oil Check
                  </p>
                  <p className="text-sm text-muted-foreground">
                    PMS Task - Due today
                  </p>
                </div>
                <Button
                  size="sm"
                  className="bg-accent text-accent-foreground hover:bg-accent/90"
                >
                  Start
                </Button>
              </div>
              <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                <div>
                  <p className="font-medium text-foreground">
                    Submit Daily Work Log
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Due: End of shift
                  </p>
                </div>
                <Button size="sm" variant="outline">
                  Add Log
                </Button>
              </div>
              <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                <div>
                  <p className="font-medium text-foreground">Deck Cleaning</p>
                  <p className="text-sm text-muted-foreground">
                    Routine maintenance
                  </p>
                </div>
                <Button size="sm" variant="outline">
                  View
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Two Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upcoming Expiries */}
        <Card>
          <CardHeader>
            <CardTitle>Upcoming Certificate Expiries</CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center py-8">
                <Loader2 className="w-6 h-6 animate-spin mx-auto" />
                <p className="text-muted-foreground mt-2">Loading...</p>
              </div>
            ) : expiringCerts.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-muted-foreground">
                  No expiring certificates in the next 60 days
                </p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Crew Name</TableHead>
                    <TableHead>Certificate</TableHead>
                    <TableHead>Expiry Date</TableHead>
                    <TableHead>Days Left</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {expiringCerts.slice(0, 5).map((cert, index) => (
                    <TableRow key={index}>
                      <TableCell>{cert.crew_name}</TableCell>
                      <TableCell>{cert.certificate_name}</TableCell>
                      <TableCell className="text-sm">
                        {cert.expiry_date}
                      </TableCell>
                      <TableCell>
                        <Badge
                          className={getDaysRemainingColor(cert.days_remaining)}
                        >
                          {cert.days_remaining}d
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {/* Fleet Overview - Only for Master/Staff */}
        {!isCrew && (
          <Card>
            <CardHeader>
              <CardTitle>Fleet Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {ships.slice(0, 5).map((ship) => (
                  <div
                    key={ship.id}
                    className="flex items-center justify-between p-3 bg-muted rounded-lg"
                  >
                    <div>
                      <p className="font-medium text-foreground">{ship.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {ship.type}
                      </p>
                    </div>
                    <Badge
                      className={
                        ship.status === "active"
                          ? "bg-accent text-accent-foreground"
                          : "bg-muted text-muted-foreground"
                      }
                    >
                      {ship.status}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
