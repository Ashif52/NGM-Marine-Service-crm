import { useState } from 'react';
import { Plus, Search, Eye, Edit, FileText } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../components/ui/table';
import { Badge } from '../components/ui/badge';

const clientsData = [
  { 
    id: 1, 
    name: 'Ocean Shipping Ltd', 
    company: 'Ocean Shipping Ltd', 
    contact: 'Michael Chen', 
    email: 'michael@oceanshipping.com', 
    phone: '+1-555-0101', 
    vessels: 12, 
    contractStart: '2022-01-15', 
    contractEnd: '2025-01-14', 
    status: 'Active' 
  },
  { 
    id: 2, 
    name: 'Pacific Marine Services', 
    company: 'Pacific Marine Services', 
    contact: 'Sarah Johnson', 
    email: 'sarah@pacificmarine.com', 
    phone: '+1-555-0102', 
    vessels: 8, 
    contractStart: '2021-06-01', 
    contractEnd: '2024-05-31', 
    status: 'Active' 
  },
  { 
    id: 3, 
    name: 'Atlantic Trade Corp', 
    company: 'Atlantic Trade Corp', 
    contact: 'David Martinez', 
    email: 'david@atlantictrade.com', 
    phone: '+1-555-0103', 
    vessels: 15, 
    contractStart: '2023-03-20', 
    contractEnd: '2026-03-19', 
    status: 'Active' 
  },
  { 
    id: 4, 
    name: 'Indian Ocean Logistics', 
    company: 'Indian Ocean Logistics', 
    contact: 'Priya Sharma', 
    email: 'priya@indianocean.com', 
    phone: '+91-555-0104', 
    vessels: 6, 
    contractStart: '2020-09-15', 
    contractEnd: '2023-09-14', 
    status: 'Inactive' 
  },
  { 
    id: 5, 
    name: 'Mediterranean Shipping', 
    company: 'Mediterranean Shipping', 
    contact: 'Alessandro Rossi', 
    email: 'alessandro@medshipping.com', 
    phone: '+39-555-0105', 
    vessels: 20, 
    contractStart: '2023-07-01', 
    contractEnd: '2026-06-30', 
    status: 'Active' 
  },
];

export function Clients() {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const filteredClients = clientsData.filter(client => {
    const matchesSearch = client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         client.contact.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         client.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || client.status.toLowerCase() === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-foreground">Clients</h2>
          <p className="text-sm text-muted-foreground">Manage your client relationships and contracts</p>
        </div>
        <Button className="bg-accent text-accent-foreground hover:bg-accent/90">
          <Plus className="w-4 h-4 mr-2" />
          Add Client
        </Button>
      </div>

      {/* Filters */}
      <div className="bg-card p-4 rounded-lg border border-border">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search by name, email, company..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="inactive">Inactive</SelectItem>
            </SelectContent>
          </Select>
          <Select>
            <SelectTrigger>
              <SelectValue placeholder="Country" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Countries</SelectItem>
              <SelectItem value="usa">United States</SelectItem>
              <SelectItem value="uk">United Kingdom</SelectItem>
              <SelectItem value="india">India</SelectItem>
              <SelectItem value="italy">Italy</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Client Table */}
      <div className="bg-card rounded-lg border border-border overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Client Name</TableHead>
              <TableHead>Company</TableHead>
              <TableHead>Contact Person</TableHead>
              <TableHead>Email / Phone</TableHead>
              <TableHead className="text-center">Vessels</TableHead>
              <TableHead>Contract Period</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredClients.map((client) => (
              <TableRow key={client.id}>
                <TableCell>{client.name}</TableCell>
                <TableCell className="text-muted-foreground">{client.company}</TableCell>
                <TableCell>{client.contact}</TableCell>
                <TableCell>
                  <div className="text-sm">
                    <div>{client.email}</div>
                    <div className="text-muted-foreground">{client.phone}</div>
                  </div>
                </TableCell>
                <TableCell className="text-center">{client.vessels}</TableCell>
                <TableCell>
                  <div className="text-sm">
                    <div>{client.contractStart}</div>
                    <div className="text-muted-foreground">to {client.contractEnd}</div>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge className={client.status === 'Active' ? 'bg-accent text-accent-foreground' : 'bg-muted text-muted-foreground'}>
                    {client.status}
                  </Badge>
                </TableCell>
                <TableCell>
                  <div className="flex justify-end gap-2">
                    <Button variant="ghost" size="sm" title="View Details">
                      <Eye className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm" title="Edit">
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm" title="Documents">
                      <FileText className="w-4 h-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
