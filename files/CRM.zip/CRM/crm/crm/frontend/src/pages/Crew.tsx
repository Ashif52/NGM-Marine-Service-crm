import { useState, useEffect } from 'react';
import { Plus, Search, Eye, UserCheck, UserX, Loader2 } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../components/ui/table';
import { Badge } from '../components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../components/ui/avatar';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { Label } from '../components/ui/label';
import { toast } from 'sonner';
import { crewApi, shipsApi } from '../services/api';
import { useAuth } from '../contexts/AuthContext';

interface CrewMember {
  id: string;
  name: string;
  email: string;
  role: string;
  ship_id: string | null;
  nationality: string | null;
  availability: string;
  sea_time: string | null;
  status: string;
  rank: string | null;
  department: string | null;
  join_date: string | null;
  created_at: string;
}

export function Crew() {
  const { ships, refreshShips } = useAuth();
  const [crewData, setCrewData] = useState<CrewMember[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [rankFilter, setRankFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // New crew form state
  const [newCrew, setNewCrew] = useState({
    name: '',
    email: '',
    password: '',
    nationality: '',
    sea_time: '',
    rank: '',
    department: 'DECK',
    ship_id: '',
  });

  // Fetch crew data
  const fetchCrew = async () => {
    try {
      setLoading(true);
      const data = await crewApi.getAll();
      setCrewData(data);
    } catch (error: any) {
      toast.error('Failed to load crew data');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCrew();
    refreshShips();
  }, []);

  const handleAddCrew = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      await crewApi.create({
        ...newCrew,
        ship_id: newCrew.ship_id === 'none' ? undefined : newCrew.ship_id,
      });
      toast.success('Crew member added successfully');
      setIsAddDialogOpen(false);
      setNewCrew({
        name: '',
        email: '',
        password: '',
        nationality: '',
        sea_time: '',
        rank: '',
        department: 'DECK',
        ship_id: '',
      });
      fetchCrew();
    } catch (error: any) {
      toast.error(error.message || 'Failed to add crew member');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleAssignToShip = async (crewId: string, shipId: string) => {
    try {
      await crewApi.assignToShip(crewId, shipId);
      toast.success('Crew member assigned to ship');
      fetchCrew();
    } catch (error: any) {
      toast.error(error.message || 'Failed to assign crew');
    }
  };

  const handleUnassign = async (crewId: string) => {
    try {
      await crewApi.unassignFromShip(crewId);
      toast.success('Crew member unassigned from ship');
      fetchCrew();
    } catch (error: any) {
      toast.error(error.message || 'Failed to unassign crew');
    }
  };

  const filteredCrew = crewData.filter(crew => {
    const matchesSearch = (crew.name?.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
                         (crew.nationality?.toLowerCase() || '').includes(searchTerm.toLowerCase());
    const matchesRank = rankFilter === 'all' || crew.rank === rankFilter;
    const matchesStatus = statusFilter === 'all' || crew.availability?.toLowerCase() === statusFilter;
    return matchesSearch && matchesRank && matchesStatus;
  });

  const getInitials = (name: string) => {
    return name?.split(' ').map(n => n[0]).join('').toUpperCase() || '??';
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'available':
        return 'bg-accent text-accent-foreground';
      case 'onboard':
        return 'bg-primary text-primary-foreground';
      case 'standby':
        return 'bg-warning text-warning-foreground';
      case 'blocked':
        return 'bg-destructive text-destructive-foreground';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-foreground">Crew Management</h2>
          <p className="text-sm text-muted-foreground">Manage crew profiles, availability, and assignments</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-accent text-accent-foreground hover:bg-accent/90">
              <Plus className="w-4 h-4 mr-2" />
              Add Crew Member
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add New Crew Member</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleAddCrew} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Full Name *</Label>
                <Input
                  id="name"
                  value={newCrew.name}
                  onChange={(e) => setNewCrew({ ...newCrew, name: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  value={newCrew.email}
                  onChange={(e) => setNewCrew({ ...newCrew, email: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password *</Label>
                <Input
                  id="password"
                  type="password"
                  value={newCrew.password}
                  onChange={(e) => setNewCrew({ ...newCrew, password: e.target.value })}
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="rank">Rank *</Label>
                  <Input
                    id="rank"
                    value={newCrew.rank}
                    onChange={(e) => setNewCrew({ ...newCrew, rank: e.target.value })}
                    placeholder="e.g., Captain"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="department">Department *</Label>
                  <Select value={newCrew.department} onValueChange={(v) => setNewCrew({ ...newCrew, department: v })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="DECK">Deck</SelectItem>
                      <SelectItem value="ENGINE">Engine</SelectItem>
                      <SelectItem value="CATERING">Catering</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="nationality">Nationality</Label>
                  <Input
                    id="nationality"
                    value={newCrew.nationality}
                    onChange={(e) => setNewCrew({ ...newCrew, nationality: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="sea_time">Sea Time</Label>
                  <Input
                    id="sea_time"
                    value={newCrew.sea_time}
                    onChange={(e) => setNewCrew({ ...newCrew, sea_time: e.target.value })}
                    placeholder="e.g., 5 years"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="ship">Assign to Ship (Optional)</Label>
                <Select value={newCrew.ship_id} onValueChange={(v) => setNewCrew({ ...newCrew, ship_id: v })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select ship" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No Assignment</SelectItem>
                    {ships.map((ship) => (
                      <SelectItem key={ship.id} value={ship.id}>{ship.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex justify-end gap-2 pt-4">
                <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                  Add Crew Member
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <div className="bg-card p-4 rounded-lg border border-border">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search by name or nationality..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={rankFilter} onValueChange={setRankFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Rank" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Ranks</SelectItem>
              <SelectItem value="Captain">Captain</SelectItem>
              <SelectItem value="Chief Engineer">Chief Engineer</SelectItem>
              <SelectItem value="Chief Officer">Chief Officer</SelectItem>
              <SelectItem value="Second Engineer">Second Engineer</SelectItem>
              <SelectItem value="AB Seaman">AB Seaman</SelectItem>
              <SelectItem value="Bosun">Bosun</SelectItem>
            </SelectContent>
          </Select>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="available">Available</SelectItem>
              <SelectItem value="onboard">Onboard</SelectItem>
              <SelectItem value="standby">Standby</SelectItem>
              <SelectItem value="blocked">Blocked</SelectItem>
            </SelectContent>
          </Select>
          <Select>
            <SelectTrigger>
              <SelectValue placeholder="Nationality" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Nationalities</SelectItem>
              <SelectItem value="uk">United Kingdom</SelectItem>
              <SelectItem value="ph">Philippines</SelectItem>
              <SelectItem value="eg">Egypt</SelectItem>
              <SelectItem value="kr">South Korea</SelectItem>
              <SelectItem value="cn">China</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Crew Table */}
      <div className="bg-card rounded-lg border border-border overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Rank</TableHead>
              <TableHead>Nationality</TableHead>
              <TableHead>Last Vessel / Company</TableHead>
              <TableHead>Total Sea Time</TableHead>
              <TableHead>Availability</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-8">
                  <Loader2 className="w-6 h-6 animate-spin mx-auto" />
                  <p className="text-muted-foreground mt-2">Loading crew data...</p>
                </TableCell>
              </TableRow>
            ) : filteredCrew.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-8">
                  <p className="text-muted-foreground">No crew members found</p>
                </TableCell>
              </TableRow>
            ) : (
              filteredCrew.map((crew) => (
                <TableRow key={crew.id} className="cursor-pointer hover:bg-muted/50">
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <Avatar className="w-10 h-10">
                        <AvatarImage src="" />
                        <AvatarFallback className="bg-primary text-primary-foreground">
                          {getInitials(crew.name)}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <div>{crew.name}</div>
                        <div className="text-xs text-muted-foreground">{crew.email}</div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>{crew.rank || '-'}</TableCell>
                  <TableCell>{crew.nationality || '-'}</TableCell>
                  <TableCell>
                    <div className="text-sm">
                      <div>{crew.department || '-'}</div>
                      <div className="text-muted-foreground">
                        {ships.find(s => s.id === crew.ship_id)?.name || 'Not assigned'}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>{crew.sea_time || '-'}</TableCell>
                  <TableCell>{crew.availability}</TableCell>
                  <TableCell>
                    <Badge className={getStatusColor(crew.availability)}>
                      {crew.availability}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex justify-end gap-2">
                      <Button variant="ghost" size="sm" title="View Profile">
                        <Eye className="w-4 h-4" />
                      </Button>
                      {crew.availability === 'AVAILABLE' && (
                        <Select onValueChange={(shipId) => handleAssignToShip(crew.id, shipId)}>
                          <SelectTrigger className="w-auto h-8 px-2">
                            <UserCheck className="w-4 h-4 text-accent" />
                          </SelectTrigger>
                          <SelectContent>
                            {ships.map((ship) => (
                              <SelectItem key={ship.id} value={ship.id}>
                                {ship.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      )}
                      {crew.availability === 'ONBOARD' && (
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          title="Unassign from ship" 
                          className="text-destructive"
                          onClick={() => handleUnassign(crew.id)}
                        >
                          <UserX className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
