import { useState } from "react";
import { Ship, Lock, Mail, Loader2 } from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Checkbox } from "../components/ui/checkbox";
import { toast } from "sonner";

interface LoginProps {
  onLogin: (email: string, password: string) => Promise<void>;
}

export function Login({ onLogin }: LoginProps) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      toast.error("Please enter email and password");
      return;
    }

    setIsLoading(true);
    try {
      await onLogin(email, password);
      toast.success("Login successful!");
    } catch (error: any) {
      console.error("Login error:", error);
      toast.error(error.message || "Invalid credentials");
      setPassword(""); // Clear password on error
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex">
      {/* Left Side - Branding */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-[#053B5E] to-[#02283F] p-12 flex-col justify-between relative overflow-hidden">
        {/* Decorative ship illustration */}
        <div className="absolute inset-0 opacity-10">
          <Ship className="w-96 h-96 absolute bottom-0 right-0 transform translate-x-1/4 translate-y-1/4" />
        </div>

        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-8">
            <div className="bg-accent p-3 rounded-lg">
              <Ship className="w-8 h-8 text-white" />
            </div>
            <div>
              <div className="text-white text-2xl font-semibold">
                NMG Marine Service
              </div>
              <div className="text-accent text-sm">
                Crew Management & PMS System
              </div>
            </div>
          </div>

          <h1 className="text-white text-4xl font-semibold mb-4">
            Streamline Your
            <br />
            Marine Operations
          </h1>
          <p className="text-white/80 text-lg">
            Complete crew management and planned maintenance solution for modern
            maritime operations. Manage 7 ships, track crew, handle PMS tasks,
            and ensure compliance - all in one place.
          </p>
        </div>

        <div className="relative z-10 text-white/60 text-sm">
          © 2024 NMG Marine Service. All rights reserved.
        </div>
      </div>

      {/* Right Side - Login Card */}
      <div className="flex-1 flex items-center justify-center p-8 bg-background">
        <div className="w-full max-w-md">
          {/* Mobile Logo */}
          <div className="lg:hidden mb-8 text-center">
            <div className="inline-flex items-center gap-2 mb-2">
              <div className="bg-primary p-2 rounded-lg">
                <Ship className="w-6 h-6 text-white" />
              </div>
              <span className="text-primary text-xl font-semibold">
                NMG Marine
              </span>
            </div>
          </div>

          {/* Login Card */}
          <div className="bg-card p-8 rounded-2xl shadow-lg border border-border">
            <div className="mb-8">
              <h2 className="text-foreground text-2xl font-semibold mb-2">
                Welcome Back
              </h2>
              <p className="text-muted-foreground">
                Sign in to your account to continue
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="you@company.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="pl-10 h-12"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    id="password"
                    type="password"
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10 h-12"
                    required
                  />
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="remember"
                    checked={rememberMe}
                    onCheckedChange={(checked) =>
                      setRememberMe(checked as boolean)
                    }
                  />
                  <label
                    htmlFor="remember"
                    className="text-sm text-foreground cursor-pointer"
                  >
                    Remember me
                  </label>
                </div>
                <a
                  href="#"
                  className="text-sm text-accent hover:text-accent/80 font-medium"
                >
                  Forgot Password?
                </a>
              </div>

              <Button
                type="submit"
                className="w-full h-12 bg-accent text-accent-foreground hover:bg-accent/90 text-base"
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Signing in...
                  </>
                ) : (
                  "Sign In"
                )}
              </Button>

              {/* Demo Credentials Info */}
              <div className="mt-4 p-4 bg-muted rounded-lg">
                <p className="text-xs text-muted-foreground mb-2">
                  Demo Accounts:
                </p>
                <div className="text-xs space-y-1">
                  <p>
                    <span className="font-medium">Master:</span>{" "}
                    master@nmgmarine.com / master123
                  </p>
                  <p>
                    <span className="font-medium">Staff:</span>{" "}
                    staff@nmgmarine.com / staff123
                  </p>
                  <p>
                    <span className="font-medium">Crew:</span>{" "}
                    crew@nmgmarine.com / crew123
                  </p>
                </div>
              </div>
            </form>
          </div>

          <p className="text-center text-sm text-muted-foreground mt-6">
            Don't have an account?{" "}
            <a
              href="#"
              className="text-accent hover:text-accent/80 font-medium"
            >
              Contact Administrator
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}
