import { useState, useEffect } from 'react';
import { Plus, Filter, User, Loader2 } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Card, CardContent } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Avatar, AvatarFallback } from '../components/ui/avatar';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { recruitmentApi } from '../services/api';
import { toast } from 'sonner';

interface Candidate {
  id: number;
  name: string;
  rank: string;
  experience: string;
  vessel?: string;
  source: string;
  initials: string;
}

const candidatesData: Record<string, Candidate[]> = {
  applied: [
    { id: 1, name: 'James Wilson', rank: 'Third Officer', experience: '5 years', vessel: 'MV Ocean Star', source: 'Website', initials: 'JW' },
    { id: 2, name: 'Lisa Anderson', rank: 'Chief Cook', experience: '8 years', vessel: 'MT Pacific Wave', source: 'Agent', initials: 'LA' },
    { id: 3, name: 'Mohammed Ali', rank: 'AB Seaman', experience: '4 years', vessel: 'MV Atlantic Trader', source: 'Referral', initials: 'MA' },
  ],
  shortlisted1: [
    { id: 4, name: 'Sarah Brown', rank: 'Second Officer', experience: '7 years', vessel: 'MV Ocean Star', source: 'Website', initials: 'SB' },
    { id: 5, name: 'David Kumar', rank: 'Electrician', experience: '6 years', vessel: 'MT Indian Star', source: 'Agent', initials: 'DK' },
  ],
  shortlisted2: [
    { id: 6, name: 'Anna Kowalski', rank: 'Chief Officer', experience: '12 years', vessel: 'MV Ocean Star', source: 'Referral', initials: 'AK' },
  ],
  final: [
    { id: 7, name: 'Carlos Rodriguez', rank: 'Second Engineer', experience: '9 years', vessel: 'MT Pacific Wave', source: 'Website', initials: 'CR' },
    { id: 8, name: 'Yuki Tanaka', rank: 'Third Engineer', experience: '5 years', vessel: 'MV Atlantic Trader', source: 'Agent', initials: 'YT' },
  ],
  prejoining: [
    { id: 9, name: 'Thomas Mueller', rank: 'Bosun', experience: '10 years', vessel: 'MV Ocean Star', source: 'Referral', initials: 'TM' },
  ],
  accepted: [
    { id: 10, name: 'Sofia Martinez', rank: 'Oiler', experience: '6 years', vessel: 'MT Indian Star', source: 'Website', initials: 'SM' },
  ],
};

const columns = [
  { id: 'applied', title: 'Applied', color: 'bg-muted' },
  { id: 'shortlisted1', title: 'Shortlisted Round 1', color: 'bg-blue-50' },
  { id: 'shortlisted2', title: 'Shortlisted Round 2', color: 'bg-blue-100' },
  { id: 'final', title: 'Final Selection', color: 'bg-yellow-50' },
  { id: 'prejoining', title: 'Pre-Joining Issued', color: 'bg-green-50' },
  { id: 'accepted', title: 'Accepted', color: 'bg-green-100' },
];

const sourceColors: Record<string, string> = {
  'Website': 'bg-primary text-primary-foreground',
  'Agent': 'bg-accent text-accent-foreground',
  'Referral': 'bg-warning text-warning-foreground',
};

export function Recruitment() {
  const [candidates, setCandidates] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [vesselFilter, setVesselFilter] = useState('all');
  const [rankFilter, setRankFilter] = useState('all');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [newCandidate, setNewCandidate] = useState({
    candidate_name: '',
    candidate_email: '',
    rank: '',
    nationality: '',
    experience: '',
    ship_id: '',
    resume_url: ''
  });

  const fetchCandidates = async () => {
    try {
      setLoading(true);
      const data = await recruitmentApi.getAll();
      setCandidates(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error('Failed to fetch candidates:', error);
      toast.error('Failed to load recruitment data');
      setCandidates([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCandidates();
  }, []);

  const handleAddCandidate = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      await recruitmentApi.create({
        ...newCandidate,
        ship_id: newCandidate.ship_id || undefined
      });
      toast.success('Candidate added successfully');
      setIsAddDialogOpen(false);
      setNewCandidate({
        candidate_name: '',
        candidate_email: '',
        rank: '',
        nationality: '',
        experience: '',
        ship_id: '',
        resume_url: ''
      });
      fetchCandidates();
    } catch (error: any) {
      toast.error(error.message || 'Failed to add candidate');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-foreground">Recruitment Pipeline</h2>
          <p className="text-sm text-muted-foreground">Track candidate applications and hiring progress</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-accent text-accent-foreground hover:bg-accent/90">
              <Plus className="w-4 h-4 mr-2" />
              Add Candidate
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Add New Candidate</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleAddCandidate} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="candidate_name">Name *</Label>
                  <Input
                    id="candidate_name"
                    value={newCandidate.candidate_name}
                    onChange={(e) => setNewCandidate({ ...newCandidate, candidate_name: e.target.value })}
                    placeholder="Full name"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="candidate_email">Email</Label>
                  <Input
                    id="candidate_email"
                    type="email"
                    value={newCandidate.candidate_email}
                    onChange={(e) => setNewCandidate({ ...newCandidate, candidate_email: e.target.value })}
                    placeholder="email@example.com"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="rank">Rank *</Label>
                  <Input
                    id="rank"
                    value={newCandidate.rank}
                    onChange={(e) => setNewCandidate({ ...newCandidate, rank: e.target.value })}
                    placeholder="e.g., Chief Officer"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="nationality">Nationality</Label>
                  <Input
                    id="nationality"
                    value={newCandidate.nationality}
                    onChange={(e) => setNewCandidate({ ...newCandidate, nationality: e.target.value })}
                    placeholder="Country"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="experience">Experience</Label>
                <Input
                  id="experience"
                  value={newCandidate.experience}
                  onChange={(e) => setNewCandidate({ ...newCandidate, experience: e.target.value })}
                  placeholder="e.g., 5 years"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="resume_url">Resume URL</Label>
                <Input
                  id="resume_url"
                  value={newCandidate.resume_url}
                  onChange={(e) => setNewCandidate({ ...newCandidate, resume_url: e.target.value })}
                  placeholder="https://..."
                />
              </div>
              <div className="flex justify-end gap-2 pt-4">
                <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                  Add Candidate
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <div className="bg-card p-4 rounded-lg border border-border">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Select value={vesselFilter} onValueChange={setVesselFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Filter by Vessel" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Vessels</SelectItem>
              <SelectItem value="MV Ocean Star">MV Ocean Star</SelectItem>
              <SelectItem value="MT Pacific Wave">MT Pacific Wave</SelectItem>
              <SelectItem value="MV Atlantic Trader">MV Atlantic Trader</SelectItem>
              <SelectItem value="MT Indian Star">MT Indian Star</SelectItem>
            </SelectContent>
          </Select>
          <Select value={rankFilter} onValueChange={setRankFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Filter by Rank" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Ranks</SelectItem>
              <SelectItem value="Officer">Officers</SelectItem>
              <SelectItem value="Engineer">Engineers</SelectItem>
              <SelectItem value="Ratings">Ratings</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" className="w-full">
            <Filter className="w-4 h-4 mr-2" />
            More Filters
          </Button>
        </div>
      </div>

      {/* Kanban Board */}
      <div className="overflow-x-auto pb-4">
        <div className="flex gap-4 min-w-max">
          {columns.map((column) => {
            // Map column IDs to status values
            const statusMap: Record<string, string> = {
              'applied': 'APPLIED',
              'shortlisted1': 'SHORTLISTED',
              'shortlisted2': 'INTERVIEWED',
              'final': 'FINAL',
              'prejoining': 'PREJOINING',
              'accepted': 'HIRED'
            };
            
            // Filter real candidates by status
            const columnCandidates = candidates.filter(c => 
              c.status?.toUpperCase() === statusMap[column.id]
            );
            
            const getInitials = (name: string) => {
              return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
            };
            
            return (
              <div key={column.id} className="w-80 flex-shrink-0">
                <div className="bg-card rounded-lg border border-border">
                  {/* Column Header */}
                  <div className="p-4 border-b border-border">
                    <div className="flex items-center justify-between">
                      <h3 className="text-foreground">{column.title}</h3>
                      <Badge variant="outline" className="bg-muted">
                        {columnCandidates.length}
                      </Badge>
                    </div>
                  </div>

                  {/* Cards */}
                  <div className="p-4 space-y-3 min-h-[400px] max-h-[600px] overflow-y-auto">
                    {columnCandidates.map((candidate) => (
                      <Card key={candidate.id} className="hover:shadow-md transition-shadow cursor-pointer">
                        <CardContent className="p-4">
                          <div className="flex items-start gap-3">
                            <Avatar className="w-10 h-10">
                              <AvatarFallback className="bg-primary text-primary-foreground text-sm">
                                {getInitials(candidate.candidate_name || 'NA')}
                              </AvatarFallback>
                            </Avatar>
                            <div className="flex-1 min-w-0">
                              <div className="text-sm text-foreground mb-1">
                                {candidate.candidate_name}
                              </div>
                              {candidate.rank && (
                                <div className="text-xs text-muted-foreground mb-2">
                                  {candidate.rank}
                                </div>
                              )}
                              {candidate.nationality && (
                                <div className="text-xs text-muted-foreground mb-2">
                                  {candidate.nationality}
                                </div>
                              )}
                              {candidate.experience && (
                                <div className="text-xs text-muted-foreground mb-2">
                                  Experience: {candidate.experience}
                                </div>
                              )}
                              {candidate.candidate_email && (
                                <div className="text-xs text-muted-foreground">
                                  {candidate.candidate_email}
                                </div>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                    
                    {columnCandidates.length === 0 && (
                      <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                        <User className="w-12 h-12 mb-2 opacity-50" />
                        <p className="text-sm">No candidates</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
