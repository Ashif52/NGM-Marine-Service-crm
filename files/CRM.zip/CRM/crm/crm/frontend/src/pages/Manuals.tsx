import { useState } from "react";
import { ManualList } from "../components/manuals/ManualList";
import { ManualViewer } from "../components/manuals/ManualViewer";

export function Manuals() {
  const [selectedManual, setSelectedManual] = useState<any>(null);

  return (
    <div className="h-full">
      {selectedManual ? (
        <ManualViewer
          {...selectedManual}
          onClose={() => setSelectedManual(null)}
        />
      ) : (
        <ManualList onSelect={setSelectedManual} />
      )}
    </div>
  );
}
