import { useState } from "react";
import { Card } from "../components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "../components/ui/tabs";
import { useAuth } from "../contexts/AuthContext";
import { Button } from "../components/ui/button";
import { AlertTriangle, ClipboardCheck, Search } from "lucide-react";
import { Input } from "../components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../components/ui/table";
import { Badge } from "../components/ui/badge";

const mockIncidents = [
  {
    id: "1",
    ship_name: "MV Pacific",
    incident_type: "Safety",
    description: "Near miss during crane operation",
    reported_by: "John Smith",
    status: "open",
    reported_at: "2024-12-28",
  },
  // Add more mock data
];

const mockAudits = [
  {
    id: "1",
    ship_name: "MV Pacific",
    audit_type: "internal",
    findings: "All safety procedures followed correctly",
    auditor: "James Wilson",
    audit_date: "2024-12-20",
  },
  // Add more mock data
];

export function Incidents() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("incidents");
  const isMaster = user?.role === "MASTER";
  const isCrew = user?.role === "CREW";

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-foreground">Incidents & Audits</h2>
          <p className="text-sm text-muted-foreground">
            {isCrew
              ? "Report and track incidents"
              : "Manage incidents and conduct audits"}
          </p>
        </div>
        {isMaster && (
          <Button>
            <ClipboardCheck className="w-4 h-4 mr-2" />
            New Audit
          </Button>
        )}
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="incidents">
            <AlertTriangle className="w-4 h-4 mr-2" />
            Incidents
          </TabsTrigger>
          <TabsTrigger value="audits" disabled={isCrew}>
            <ClipboardCheck className="w-4 h-4 mr-2" />
            Audits
          </TabsTrigger>
        </TabsList>

        {/* Incidents Tab */}
        <TabsContent value="incidents">
          <Card>
            {/* Filters */}
            <div className="p-4 border-b">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input placeholder="Search incidents..." className="pl-9" />
                </div>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="open">Open</SelectItem>
                    <SelectItem value="closed">Closed</SelectItem>
                  </SelectContent>
                </Select>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="safety">Safety</SelectItem>
                    <SelectItem value="environmental">Environmental</SelectItem>
                    <SelectItem value="operational">Operational</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Incidents Table */}
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Ship</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Reported By</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Date</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {mockIncidents.map((incident) => (
                  <TableRow key={incident.id}>
                    <TableCell>{incident.ship_name}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{incident.incident_type}</Badge>
                    </TableCell>
                    <TableCell>{incident.description}</TableCell>
                    <TableCell>{incident.reported_by}</TableCell>
                    <TableCell>
                      <Badge
                        className={
                          incident.status === "open"
                            ? "bg-warning"
                            : "bg-accent"
                        }
                      >
                        {incident.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm">
                      {incident.reported_at}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
        </TabsContent>

        {/* Audits Tab */}
        <TabsContent value="audits">
          <Card>
            {/* Filters */}
            <div className="p-4 border-b">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input placeholder="Search audits..." className="pl-9" />
                </div>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Audit Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="internal">Internal</SelectItem>
                    <SelectItem value="external">External</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Audits Table */}
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Ship</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Findings</TableHead>
                  <TableHead>Auditor</TableHead>
                  <TableHead>Date</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {mockAudits.map((audit) => (
                  <TableRow key={audit.id}>
                    <TableCell>{audit.ship_name}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{audit.audit_type}</Badge>
                    </TableCell>
                    <TableCell>{audit.findings}</TableCell>
                    <TableCell>{audit.auditor}</TableCell>
                    <TableCell className="text-sm">
                      {audit.audit_date}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
