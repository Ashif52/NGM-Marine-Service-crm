import { useState, useEffect } from 'react';
import { Plus, Search, LayoutGrid, List, Ship, Users, Loader2 } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { Label } from '../components/ui/label';
import { toast } from 'sonner';
import { shipsApi } from '../services/api';

interface Vessel {
  id: string;
  ship_name: string;
  imo_number: string;
  ship_type: string;
  flag: string;
  status: string;
  crew_capacity: number;
}

export function Vessels() {
  const [vesselsData, setVesselsData] = useState<Vessel[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [newVessel, setNewVessel] = useState({
    ship_name: '',
    imo_number: '',
    ship_type: '',
    flag: '',
    status: 'ACTIVE',
    crew_capacity: 25,
  });

  const fetchVessels = async () => {
    try {
      setLoading(true);
      const data = await shipsApi.getAll();
      setVesselsData(data);
    } catch (error: any) {
      toast.error('Failed to load vessels');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchVessels();
  }, []);

  const handleAddVessel = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      await shipsApi.create(newVessel);
      toast.success('Vessel added successfully');
      setIsAddDialogOpen(false);
      setNewVessel({
        ship_name: '',
        imo_number: '',
        ship_type: '',
        flag: '',
        status: 'ACTIVE',
        crew_capacity: 25,
      });
      fetchVessels();
    } catch (error: any) {
      toast.error(error.message || 'Failed to add vessel');
    } finally {
      setIsSubmitting(false);
    }
  };

  const filteredVessels = vesselsData.filter(vessel => {
    const matchesSearch = (vessel.ship_name?.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
                         (vessel.imo_number?.toLowerCase() || '').includes(searchTerm.toLowerCase());
    const matchesType = typeFilter === 'all' || vessel.ship_type === typeFilter;
    return matchesSearch && matchesType;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-foreground">Vessels</h2>
          <p className="text-sm text-muted-foreground">Manage your fleet and vessel information</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-accent text-accent-foreground hover:bg-accent/90">
              <Plus className="w-4 h-4 mr-2" />
              Add Vessel
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Add New Vessel</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleAddVessel} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="ship_name">Vessel Name *</Label>
                <Input
                  id="ship_name"
                  value={newVessel.ship_name}
                  onChange={(e) => setNewVessel({ ...newVessel, ship_name: e.target.value })}
                  placeholder="e.g., MV Ocean Star"
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="imo_number">IMO Number</Label>
                  <Input
                    id="imo_number"
                    value={newVessel.imo_number}
                    onChange={(e) => setNewVessel({ ...newVessel, imo_number: e.target.value })}
                    placeholder="e.g., IMO 9234567"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="flag">Flag</Label>
                  <Input
                    id="flag"
                    value={newVessel.flag}
                    onChange={(e) => setNewVessel({ ...newVessel, flag: e.target.value })}
                    placeholder="e.g., Panama"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="ship_type">Ship Type</Label>
                  <Select value={newVessel.ship_type} onValueChange={(v) => setNewVessel({ ...newVessel, ship_type: v })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Container Ship">Container Ship</SelectItem>
                      <SelectItem value="Oil Tanker">Oil Tanker</SelectItem>
                      <SelectItem value="Bulk Carrier">Bulk Carrier</SelectItem>
                      <SelectItem value="Chemical Tanker">Chemical Tanker</SelectItem>
                      <SelectItem value="LNG Carrier">LNG Carrier</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="crew_capacity">Crew Capacity</Label>
                  <Input
                    id="crew_capacity"
                    type="number"
                    value={newVessel.crew_capacity}
                    onChange={(e) => setNewVessel({ ...newVessel, crew_capacity: parseInt(e.target.value) || 0 })}
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-4">
                <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                  Add Vessel
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters & View Toggle */}
      <div className="bg-card p-4 rounded-lg border border-border">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="relative md:col-span-2">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search by vessel name or IMO..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Ship Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="Container Ship">Container Ship</SelectItem>
              <SelectItem value="Oil Tanker">Oil Tanker</SelectItem>
              <SelectItem value="Bulk Carrier">Bulk Carrier</SelectItem>
              <SelectItem value="Chemical Tanker">Chemical Tanker</SelectItem>
              <SelectItem value="LNG Carrier">LNG Carrier</SelectItem>
            </SelectContent>
          </Select>
          <div className="flex gap-2">
            <div className="flex bg-muted rounded-lg p-1">
              <Button
                variant={viewMode === 'grid' ? 'secondary' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('grid')}
                className="px-2"
              >
                <LayoutGrid className="w-4 h-4" />
              </Button>
              <Button
                variant={viewMode === 'table' ? 'secondary' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('table')}
                className="px-2"
              >
                <List className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Grid View */}
      {viewMode === 'grid' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {loading ? (
            <div className="col-span-full text-center py-12">
              <Loader2 className="w-8 h-8 animate-spin mx-auto text-primary" />
              <p className="text-muted-foreground mt-2">Loading vessels...</p>
            </div>
          ) : filteredVessels.length === 0 ? (
            <div className="col-span-full text-center py-12">
              <Ship className="w-12 h-12 mx-auto text-muted-foreground" />
              <p className="text-muted-foreground mt-2">No vessels found</p>
            </div>
          ) : (
            filteredVessels.map((vessel) => (
              <Card key={vessel.id} className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-foreground">{vessel.ship_name}</CardTitle>
                      <p className="text-sm text-muted-foreground mt-1">{vessel.imo_number || 'No IMO'}</p>
                    </div>
                    <Ship className="w-8 h-8 text-primary" />
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <span className="text-muted-foreground">Flag:</span>
                      <p className="text-foreground">{vessel.flag || '-'}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Type:</span>
                      <p className="text-foreground">{vessel.ship_type || '-'}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Status:</span>
                      <Badge className={vessel.status === 'ACTIVE' ? 'bg-accent text-accent-foreground' : 'bg-muted text-muted-foreground'}>
                        {vessel.status || 'Unknown'}
                      </Badge>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Capacity:</span>
                      <p className="text-foreground">{vessel.crew_capacity || 0} crew</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      )}

      {/* Table View */}
      {viewMode === 'table' && (
        <div className="bg-card rounded-lg border border-border overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Vessel Name</TableHead>
                <TableHead>IMO</TableHead>
                <TableHead>Flag</TableHead>
                <TableHead>Ship Type</TableHead>
                <TableHead className="text-center">Crew Capacity</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8">
                    <Loader2 className="w-6 h-6 animate-spin mx-auto" />
                    <p className="text-muted-foreground mt-2">Loading vessels...</p>
                  </TableCell>
                </TableRow>
              ) : filteredVessels.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8">
                    <p className="text-muted-foreground">No vessels found</p>
                  </TableCell>
                </TableRow>
              ) : (
                filteredVessels.map((vessel) => (
                  <TableRow key={vessel.id} className="cursor-pointer hover:bg-muted/50">
                    <TableCell>{vessel.ship_name}</TableCell>
                    <TableCell className="text-muted-foreground">{vessel.imo_number || '-'}</TableCell>
                    <TableCell>{vessel.flag || '-'}</TableCell>
                    <TableCell>{vessel.ship_type || '-'}</TableCell>
                    <TableCell className="text-center">{vessel.crew_capacity || 0}</TableCell>
                    <TableCell>
                      <Badge className={vessel.status === 'ACTIVE' ? 'bg-accent text-accent-foreground' : 'bg-muted text-muted-foreground'}>
                        {vessel.status || 'Unknown'}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
}
