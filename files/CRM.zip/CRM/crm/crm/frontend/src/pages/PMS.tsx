import { useState, useEffect } from 'react';
import { Wrench, Calendar, CheckCircle2, Clock, AlertCircle, Plus, Filter, Download, Upload, Image as ImageIcon, Loader2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '../components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { useAuth } from '../contexts/AuthContext';
import { toast } from 'sonner';
import { sparePartsApi, equipmentHoursApi, maintenanceReportsApi, pmsTasksApi } from '../services/api';

interface PMSTask {
  id: string;
  equipment: string;
  category: string;
  task: string;
  frequency: string;
  dueDate: string;
  status: 'pending' | 'in-progress' | 'completed' | 'overdue';
  assignedTo?: string;
  completedBy?: string;
  completionDate?: string;
  remarks?: string;
  photoUrl?: string;
  approvalStatus?: 'pending' | 'approved' | 'rejected';
}

const mockPMSTasks: PMSTask[] = [
  { id: 'pms-1', equipment: 'Main Engine', category: 'Engine Room', task: 'Oil Level Check', frequency: 'Daily', dueDate: '2024-12-17', status: 'pending', assignedTo: 'John Smith' },
  { id: 'pms-2', equipment: 'Generator 1', category: 'Engine Room', task: 'Cooling System Inspection', frequency: 'Weekly', dueDate: '2024-12-18', status: 'in-progress', assignedTo: 'John Smith' },
  { id: 'pms-3', equipment: 'Fire Pump', category: 'Safety', task: 'Pressure Test', frequency: 'Monthly', dueDate: '2024-12-20', status: 'completed', assignedTo: 'John Smith', completedBy: 'John Smith', completionDate: '2024-12-16', approvalStatus: 'pending' },
  { id: 'pms-4', equipment: 'Lifeboat Davits', category: 'Safety', task: 'Lubrication & Inspection', frequency: 'Monthly', dueDate: '2024-12-22', status: 'pending', assignedTo: 'Robert Lee' },
  { id: 'pms-5', equipment: 'Steering Gear', category: 'Deck', task: 'Hydraulic Oil Check', frequency: 'Weekly', dueDate: '2024-12-10', status: 'overdue', assignedTo: 'Chen Wei' },
  { id: 'pms-6', equipment: 'Anchor Windlass', category: 'Deck', task: 'Greasing', frequency: 'Monthly', dueDate: '2024-12-25', status: 'pending', assignedTo: 'Chen Wei' },
  { id: 'pms-7', equipment: 'Bilge Pump', category: 'Engine Room', task: 'Functionality Test', frequency: 'Weekly', dueDate: '2024-12-19', status: 'pending', assignedTo: 'John Smith' },
  { id: 'pms-8', equipment: 'Emergency Generator', category: 'Safety', task: 'Load Test', frequency: 'Monthly', dueDate: '2024-12-28', status: 'completed', assignedTo: 'Robert Lee', completedBy: 'Robert Lee', completionDate: '2024-12-15', approvalStatus: 'approved' },
];

export function PMS() {
  const { user, selectedShip, ships } = useAuth();
  const [tasks, setTasks] = useState<PMSTask[]>([]);
  const [loading, setLoading] = useState(true);
  const [spareParts, setSpareParts] = useState<any[]>([]);
  const [equipmentHours, setEquipmentHours] = useState<any[]>([]);
  const [maintenanceReports, setMaintenanceReports] = useState<any[]>([]);
  const [filter, setFilter] = useState('all');
  const [selectedTask, setSelectedTask] = useState<PMSTask | null>(null);
  const [isUpdateDialogOpen, setIsUpdateDialogOpen] = useState(false);
  const [updateForm, setUpdateForm] = useState({
    status: '',
    remarks: '',
    photo: null as File | null
  });

  const currentShip = ships.find(s => s.id === selectedShip);
  const isMaster = user?.role?.toLowerCase() === 'master';
  const isCrew = user?.role?.toLowerCase() === 'crew';

  useEffect(() => {
    const fetchPMSData = async () => {
      try {
        setLoading(true);
        
        // Fetch spare parts
        const sparePartsData = await sparePartsApi.getAll();
        setSpareParts(Array.isArray(sparePartsData) ? sparePartsData : []);
        
        // Fetch equipment hours
        const equipmentData = await equipmentHoursApi.getAll();
        setEquipmentHours(Array.isArray(equipmentData) ? equipmentData : []);
        
        // Fetch maintenance reports
        const reportsData = await maintenanceReportsApi.getAll();
        setMaintenanceReports(Array.isArray(reportsData) ? reportsData : []);
        
        // Fetch PMS tasks from backend
        try {
          const tasksData = await pmsTasksApi.getAll();
          // Convert backend format to frontend format if needed
          const formattedTasks = Array.isArray(tasksData) ? tasksData.map((task: any) => ({
            id: task.id || task.task_id,
            equipment: task.equipment_name || task.task_name || 'Unknown Equipment',
            category: task.category || 'General',
            task: task.job_description || task.task_name || '',
            frequency: task.frequency || 'As Needed',
            dueDate: task.due_date || '',
            status: task.status?.toLowerCase() || 'pending',
            assignedTo: task.assigned_to_name || '',
            completedBy: task.completed_by_name,
            completionDate: task.completion_date,
            remarks: task.remarks,
            photoUrl: task.photo_url,
            approvalStatus: task.approval_status?.toLowerCase()
          })) : [];
          setTasks(formattedTasks.length > 0 ? formattedTasks : mockPMSTasks);
        } catch (taskError) {
          console.log('No PMS tasks found, using mock data');
          setTasks(mockPMSTasks);
        }
      } catch (error: any) {
        console.error('Failed to fetch PMS data:', error);
        toast.error('Failed to load PMS data');
        setTasks(mockPMSTasks);
      } finally {
        setLoading(false);
      }
    };

    fetchPMSData();
  }, []);

  // Filter tasks
  const filteredTasks = tasks.filter(task => {
    if (filter === 'all') return true;
    return task.status === filter;
  });

  // Count tasks by status and real stats
  const taskCounts = {
    pending: tasks.filter(t => t.status === 'pending').length,
    inProgress: tasks.filter(t => t.status === 'in-progress').length,
    completed: tasks.filter(t => t.status === 'completed').length,
    overdue: tasks.filter(t => t.status === 'overdue').length,
    pendingApproval: tasks.filter(t => t.approvalStatus === 'pending').length,
  };
  
  // Real stats from backend data
  const stats = {
    spareParts: spareParts.length,
    lowStockParts: spareParts.filter((part: any) => part.quantity <= (part.min_quantity || 0)).length,
    equipmentTracked: equipmentHours.length,
    maintenanceReports: maintenanceReports.length,
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <Badge className="bg-green-50 text-green-700 border-green-200">Completed</Badge>;
      case 'in-progress':
        return <Badge className="bg-blue-50 text-blue-700 border-blue-200">In Progress</Badge>;
      case 'overdue':
        return <Badge className="bg-red-50 text-red-700 border-red-200">Overdue</Badge>;
      default:
        return <Badge className="bg-yellow-50 text-yellow-700 border-yellow-200">Pending</Badge>;
    }
  };

  const getApprovalBadge = (status?: string) => {
    switch (status) {
      case 'approved':
        return <Badge className="bg-green-50 text-green-700 border-green-200">Approved</Badge>;
      case 'rejected':
        return <Badge className="bg-red-50 text-red-700 border-red-200">Rejected</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-50 text-yellow-700 border-yellow-200">Pending Approval</Badge>;
      default:
        return null;
    }
  };

  const handleUpdateTask = (task: PMSTask) => {
    setSelectedTask(task);
    setUpdateForm({ status: task.status, remarks: task.remarks || '', photo: null });
    setIsUpdateDialogOpen(true);
  };

  const submitTaskUpdate = () => {
    if (!selectedTask) return;

    const updatedTasks = tasks.map(t => {
      if (t.id === selectedTask.id) {
        return {
          ...t,
          status: updateForm.status as PMSTask['status'],
          remarks: updateForm.remarks,
          completedBy: updateForm.status === 'completed' ? user?.name : t.completedBy,
          completionDate: updateForm.status === 'completed' ? new Date().toISOString().split('T')[0] : t.completionDate,
          approvalStatus: updateForm.status === 'completed' ? 'pending' as const : t.approvalStatus,
        };
      }
      return t;
    });

    setTasks(updatedTasks);
    setIsUpdateDialogOpen(false);
    toast.success('Task updated successfully');
  };

  const handleApproval = (taskId: string, approved: boolean) => {
    const updatedTasks = tasks.map(t => {
      if (t.id === taskId) {
        return {
          ...t,
          approvalStatus: approved ? 'approved' as const : 'rejected' as const,
        };
      }
      return t;
    });

    setTasks(updatedTasks);
    toast.success(`Task ${approved ? 'approved' : 'rejected'} successfully`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-foreground text-2xl font-semibold">Planned Maintenance System</h1>
          <p className="text-muted-foreground mt-1">
            {currentShip?.name || 'All Ships'} - Manage equipment maintenance schedules
          </p>
        </div>
        {!isCrew && (
          <Button className="bg-accent text-accent-foreground hover:bg-accent/90">
            <Plus className="w-4 h-4 mr-2" />
            Add Task
          </Button>
        )}
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card className="shadow-md">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Pending</p>
                <p className="text-2xl font-semibold text-foreground mt-1">{taskCounts.pending}</p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-yellow-50 flex items-center justify-center">
                <Clock className="w-6 h-6 text-yellow-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-md">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">In Progress</p>
                <p className="text-2xl font-semibold text-foreground mt-1">{taskCounts.inProgress}</p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-blue-50 flex items-center justify-center">
                <Wrench className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-md">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Completed</p>
                <p className="text-2xl font-semibold text-foreground mt-1">{taskCounts.completed}</p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-green-50 flex items-center justify-center">
                <CheckCircle2 className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-md border-destructive/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Overdue</p>
                <p className="text-2xl font-semibold text-destructive mt-1">{taskCounts.overdue}</p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-red-50 flex items-center justify-center">
                <AlertCircle className="w-6 h-6 text-red-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        {isMaster && (
          <Card className="shadow-md border-accent/30">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Awaiting Approval</p>
                  <p className="text-2xl font-semibold text-accent mt-1">{taskCounts.pendingApproval}</p>
                </div>
                <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-accent" />
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Main Content */}
      <Tabs defaultValue="tasks" className="space-y-4">
        <TabsList className="grid w-full max-w-md grid-cols-2">
          <TabsTrigger value="tasks">Maintenance Tasks</TabsTrigger>
          {isMaster && <TabsTrigger value="approvals">Approvals</TabsTrigger>}
          {!isMaster && <TabsTrigger value="history">History</TabsTrigger>}
        </TabsList>

        <TabsContent value="tasks" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Task List</CardTitle>
                <div className="flex items-center gap-2">
                  <Select value={filter} onValueChange={setFilter}>
                    <SelectTrigger className="w-[160px]">
                      <Filter className="w-4 h-4 mr-2" />
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Tasks</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="in-progress">In Progress</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                      <SelectItem value="overdue">Overdue</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button variant="outline" size="sm">
                    <Download className="w-4 h-4 mr-2" />
                    Export
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Equipment</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Task</TableHead>
                    <TableHead>Frequency</TableHead>
                    <TableHead>Due Date</TableHead>
                    <TableHead>Assigned To</TableHead>
                    <TableHead>Status</TableHead>
                    {isMaster && <TableHead>Approval</TableHead>}
                    <TableHead>Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredTasks.map((task) => (
                    <TableRow key={task.id}>
                      <TableCell className="font-medium">{task.equipment}</TableCell>
                      <TableCell>{task.category}</TableCell>
                      <TableCell>{task.task}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{task.frequency}</Badge>
                      </TableCell>
                      <TableCell className="text-sm">{task.dueDate}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">{task.assignedTo}</TableCell>
                      <TableCell>{getStatusBadge(task.status)}</TableCell>
                      {isMaster && <TableCell>{getApprovalBadge(task.approvalStatus)}</TableCell>}
                      <TableCell>
                        {(isCrew || isMaster) && task.status !== 'completed' && (
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => handleUpdateTask(task)}
                          >
                            Update
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {isMaster && (
          <TabsContent value="approvals" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Pending Approvals</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {tasks.filter(t => t.approvalStatus === 'pending').map((task) => (
                    <div key={task.id} className="border border-border rounded-lg p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h4 className="font-semibold text-foreground">{task.equipment} - {task.task}</h4>
                          <p className="text-sm text-muted-foreground mt-1">
                            Completed by {task.completedBy} on {task.completionDate}
                          </p>
                        </div>
                        {getStatusBadge(task.status)}
                      </div>
                      {task.remarks && (
                        <div className="mb-3 p-3 bg-muted rounded">
                          <p className="text-sm text-foreground"><span className="font-medium">Remarks:</span> {task.remarks}</p>
                        </div>
                      )}
                      <div className="flex items-center gap-2">
                        <Button 
                          size="sm" 
                          className="bg-green-600 hover:bg-green-700"
                          onClick={() => handleApproval(task.id, true)}
                        >
                          <CheckCircle2 className="w-4 h-4 mr-2" />
                          Approve
                        </Button>
                        <Button 
                          size="sm" 
                          variant="destructive"
                          onClick={() => handleApproval(task.id, false)}
                        >
                          <AlertCircle className="w-4 h-4 mr-2" />
                          Reject
                        </Button>
                      </div>
                    </div>
                  ))}
                  {tasks.filter(t => t.approvalStatus === 'pending').length === 0 && (
                    <div className="text-center py-8 text-muted-foreground">
                      <CheckCircle2 className="w-12 h-12 mx-auto mb-2 opacity-50" />
                      <p>No pending approvals</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        )}

        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Maintenance History</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Equipment</TableHead>
                    <TableHead>Task</TableHead>
                    <TableHead>Completed Date</TableHead>
                    <TableHead>Completed By</TableHead>
                    <TableHead>Approval Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {tasks.filter(t => t.status === 'completed').map((task) => (
                    <TableRow key={task.id}>
                      <TableCell className="font-medium">{task.equipment}</TableCell>
                      <TableCell>{task.task}</TableCell>
                      <TableCell>{task.completionDate}</TableCell>
                      <TableCell>{task.completedBy}</TableCell>
                      <TableCell>{getApprovalBadge(task.approvalStatus)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Update Task Dialog */}
      <Dialog open={isUpdateDialogOpen} onOpenChange={setIsUpdateDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Update Task</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Task</Label>
              <p className="text-sm text-muted-foreground mt-1">
                {selectedTask?.equipment} - {selectedTask?.task}
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select value={updateForm.status} onValueChange={(value) => setUpdateForm({ ...updateForm, status: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="in-progress">In Progress</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="remarks">Remarks</Label>
              <Textarea
                id="remarks"
                value={updateForm.remarks}
                onChange={(e) => setUpdateForm({ ...updateForm, remarks: e.target.value })}
                placeholder="Add any notes or observations..."
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="photo">Upload Photo (Optional)</Label>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" className="w-full" asChild>
                  <label htmlFor="photo" className="cursor-pointer">
                    <Upload className="w-4 h-4 mr-2" />
                    Choose File
                    <input
                      id="photo"
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => setUpdateForm({ ...updateForm, photo: e.target.files?.[0] || null })}
                    />
                  </label>
                </Button>
              </div>
              {updateForm.photo && (
                <p className="text-xs text-muted-foreground">{updateForm.photo.name}</p>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsUpdateDialogOpen(false)}>Cancel</Button>
            <Button className="bg-accent text-accent-foreground hover:bg-accent/90" onClick={submitTaskUpdate}>
              Submit Update
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
