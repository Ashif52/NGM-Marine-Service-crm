import {
  createContext,
  useContext,
  useState,
  useEffect,
  ReactNode,
} from "react";
import { authApi, shipsApi, getToken, removeToken } from "../services/api";

export type UserRole = "MASTER" | "CREW" | "STAFF";

export interface Ship {
  id: string;
  name: string;
  type: string;
  status: "active" | "maintenance" | "docked";
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  assignedShip?: string;
  avatar?: string;
}

interface AuthContextType {
  user: User | null;
  loading: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  selectedShip: string | null;
  setSelectedShip: (shipId: string) => void;
  ships: Ship[];
  refreshShips: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedShip, setSelectedShip] = useState<string | null>(null);
  const [ships, setShips] = useState<Ship[]>([]);

  // Check for existing token on mount
  useEffect(() => {
    const initAuth = async () => {
      try {
        const token = getToken();
        if (!token) {
          setLoading(false);
          return;
        }

        const userData = await authApi.getMe();
        setUser({
          id: userData.id,
          name: userData.name || userData.email,
          email: userData.email,
          role: userData.role as UserRole,
          assignedShip: userData.ship_id || undefined,
        });
        if (userData.ship_id) {
          setSelectedShip(userData.ship_id);
        }
        await refreshShips();
      } catch (err) {
        console.error("Auth init error:", err);
        removeToken();
      } finally {
        setLoading(false);
      }
    };
    initAuth();
  }, []);

  const refreshShips = async () => {
    try {
      const shipsData = await shipsApi.getAll();
      setShips(
        shipsData.map((s) => ({
          id: s.id,
          name: s.ship_name,
          type: s.ship_type || "Unknown",
          status: (s.status?.toLowerCase() || "active") as
            | "active"
            | "maintenance"
            | "docked",
        }))
      );
      if (shipsData.length > 0 && !selectedShip) {
        setSelectedShip(shipsData[0].id);
      }
    } catch (err) {
      console.error("Failed to fetch ships:", err);
    }
  };

  const login = async (email: string, password: string) => {
    setLoading(true);
    setError(null);
    try {
      const response = await authApi.login(email, password);
      setUser({
        id: response.user.id,
        name: response.user.name || response.user.email,
        email: response.user.email,
        role: response.user.role as UserRole,
        assignedShip: response.user.ship_id || undefined,
      });
      if (response.user.ship_id) {
        setSelectedShip(response.user.ship_id);
      }
      await refreshShips();
    } catch (err: any) {
      setError(err.message || "Login failed");
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    authApi.logout();
    setUser(null);
    setSelectedShip(null);
    setShips([]);
    setError(null);
    window.location.hash = "login";
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        error,
        login,
        logout,
        selectedShip,
        setSelectedShip,
        ships,
        refreshShips,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
