// API Service Layer for NMG Marine CRM

const API_BASE_URL = 'http://localhost:8000/api/v1';

// Token management
export const getToken = (): string | null => {
  return localStorage.getItem('access_token');
};

export const setToken = (token: string): void => {
  localStorage.setItem('access_token', token);
};

export const removeToken = (): void => {
  localStorage.removeItem('access_token');
};

// API request helper
async function apiRequest<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const token = getToken();
  
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...(token && { Authorization: `Bearer ${token}` }),
    ...options.headers,
  };

  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    ...options,
    headers,
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'An error occurred' }));
    throw new Error(error.detail || `HTTP error! status: ${response.status}`);
  }

  if (response.status === 204) {
    return {} as T;
  }

  return response.json();
}

// Auth API
export const authApi = {
  login: async (email: string, password: string) => {
    const response = await apiRequest<{
      access_token: string;
      token_type: string;
      user: {
        id: string;
        email: string;
        name: string;
        role: string;
        ship_id: string | null;
      };
    }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    setToken(response.access_token);
    return response;
  },

  signup: async (data: {
    email: string;
    password: string;
    name: string;
    role: string;
    ship_id?: string;
  }) => {
    return apiRequest('/auth/signup', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  getMe: async () => {
    return apiRequest<{
      id: string;
      email: string;
      name: string;
      role: string;
      ship_id: string | null;
      nationality: string | null;
      availability: string;
      status: string;
    }>('/auth/me');
  },

  getUsers: async () => {
    return apiRequest<Array<{
      id: string;
      email: string;
      name: string;
      role: string;
      ship_id: string | null;
      nationality: string | null;
      availability: string | null;
      status: string | null;
    }>>('/auth/users');
  },

  updateUser: async (id: string, data: { name?: string; email?: string; role?: string; status?: string }) => {
    return apiRequest(`/auth/users/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  logout: () => {
    removeToken();
  },
};

// Ships API
export const shipsApi = {
  getAll: async () => {
    return apiRequest<Array<{
      id: string;
      ship_name: string;
      imo_number: string;
      ship_type: string;
      flag: string;
      status: string;
      crew_capacity: number;
    }>>('/ships');
  },

  getById: async (id: string) => {
    return apiRequest(`/ships/${id}`);
  },

  create: async (data: {
    ship_name: string;
    imo_number?: string;
    ship_type?: string;
    flag?: string;
    status?: string;
    crew_capacity?: number;
    client_id?: string;
  }) => {
    return apiRequest('/ships', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  update: async (id: string, data: any) => {
    return apiRequest(`/ships/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  delete: async (id: string) => {
    return apiRequest(`/ships/${id}`, {
      method: 'DELETE',
    });
  },
};

// Crew API
export const crewApi = {
  getAll: async (params?: { ship_id?: string; status?: string; availability?: string }) => {
    const queryParams = new URLSearchParams();
    if (params?.ship_id) queryParams.append('ship_id', params.ship_id);
    if (params?.status) queryParams.append('status', params.status);
    if (params?.availability) queryParams.append('availability', params.availability);
    
    const query = queryParams.toString();
    return apiRequest<Array<{
      id: string;
      name: string;
      email: string;
      role: string;
      ship_id: string | null;
      nationality: string | null;
      availability: string;
      sea_time: string | null;
      status: string;
      rank: string | null;
      department: string | null;
      join_date: string | null;
      created_at: string;
    }>>(`/crew/${query ? `?${query}` : ''}`);
  },

  getById: async (id: string) => {
    return apiRequest(`/crew/${id}/`);
  },

  create: async (data: {
    name: string;
    email: string;
    password: string;
    nationality?: string;
    sea_time?: string;
    rank: string;
    department: string;
    join_date?: string;
    job_description?: string;
    contract_duration?: number;
    ship_id?: string;
  }) => {
    return apiRequest('/crew', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  update: async (id: string, data: any) => {
    return apiRequest(`/crew/${id}/`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  assignToShip: async (crewId: string, shipId: string) => {
    return apiRequest(`/crew/${crewId}/assign/?ship_id=${shipId}`, {
      method: 'POST',
    });
  },

  unassignFromShip: async (crewId: string) => {
    return apiRequest(`/crew/${crewId}/unassign/`, {
      method: 'POST',
    });
  },
};

// Certificates API
export const certificatesApi = {
  getByCrewId: async (crewId: string) => {
    return apiRequest<Array<{
      id: string;
      crew_id: string;
      name: string;
      certificate_number: string | null;
      issue_date: string | null;
      expiry_date: string | null;
      issuing_authority: string | null;
      document_url: string | null;
      created_at: string;
    }>>(`/certificates/${crewId}`);
  },

  add: async (crewId: string, data: {
    name: string;
    certificate_number?: string;
    issue_date?: string;
    expiry_date?: string;
    issuing_authority?: string;
    document_url?: string;
  }) => {
    return apiRequest(`/certificates/${crewId}`, {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  update: async (certificateId: string, data: any) => {
    return apiRequest(`/certificates/${certificateId}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  delete: async (certificateId: string) => {
    return apiRequest(`/certificates/${certificateId}`, {
      method: 'DELETE',
    });
  },

  getExpiring: async (days: number) => {
    return apiRequest<Array<{
      certificate_id: string;
      certificate_name: string;
      expiry_date: string;
      days_remaining: number;
      crew_id: string;
      crew_name: string;
      rank: string | null;
      ship_id: string | null;
    }>>(`/certificates/expiring/${days}`);
  },
};

// Spare Parts API
export const sparePartsApi = {
  getAll: async (params?: { ship_id?: string; equipment_id?: string; low_stock?: boolean }) => {
    const queryParams = new URLSearchParams();
    if (params?.ship_id) queryParams.append('ship_id', params.ship_id);
    if (params?.equipment_id) queryParams.append('equipment_id', params.equipment_id);
    if (params?.low_stock) queryParams.append('low_stock', 'true');
    
    const query = queryParams.toString();
    return apiRequest(`/spare-parts${query ? `?${query}` : ''}`);
  },

  getById: async (id: string) => {
    return apiRequest(`/spare-parts/${id}`);
  },

  create: async (data: {
    ship_id: string;
    equipment_id?: string;
    part_number?: string;
    part_name: string;
    manufacturer?: string;
    quantity: number;
    min_quantity?: number;
    unit?: string;
    location_on_ship?: string;
  }) => {
    return apiRequest('/spare-parts', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  update: async (id: string, data: any) => {
    return apiRequest(`/spare-parts/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  delete: async (id: string) => {
    return apiRequest(`/spare-parts/${id}`, {
      method: 'DELETE',
    });
  },

  recordTransaction: async (data: {
    spare_part_id: string;
    transaction_type: 'RECEIPT' | 'USAGE' | 'ADJUSTMENT';
    quantity: number;
    reference_number?: string;
    remarks?: string;
  }) => {
    return apiRequest('/spare-parts/transactions', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  getTransactions: async (sparePartId: string) => {
    return apiRequest(`/spare-parts/transactions/${sparePartId}`);
  },
};

// Equipment Running Hours API
export const equipmentHoursApi = {
  getAll: async (params?: { equipment_id?: string; start_date?: string; end_date?: string }) => {
    const queryParams = new URLSearchParams();
    if (params?.equipment_id) queryParams.append('equipment_id', params.equipment_id);
    if (params?.start_date) queryParams.append('start_date', params.start_date);
    if (params?.end_date) queryParams.append('end_date', params.end_date);
    
    const query = queryParams.toString();
    return apiRequest(`/equipment-hours${query ? `?${query}` : ''}`);
  },

  record: async (data: {
    equipment_id: string;
    date: string;
    running_hours: number;
    total_running_hours?: number;
  }) => {
    return apiRequest('/equipment-hours', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  update: async (id: string, data: any) => {
    return apiRequest(`/equipment-hours/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  getSummary: async (equipmentId: string, period: 'week' | 'month' | 'year' = 'month') => {
    return apiRequest(`/equipment-hours/summary/${equipmentId}?period=${period}`);
  },
};

// Maintenance Reports API
export const maintenanceReportsApi = {
  getTypes: async () => {
    return apiRequest('/maintenance-reports/types');
  },

  getAll: async (params?: { 
    ship_id?: string; 
    equipment_id?: string; 
    report_type_id?: string;
    status?: string;
  }) => {
    const queryParams = new URLSearchParams();
    if (params?.ship_id) queryParams.append('ship_id', params.ship_id);
    if (params?.equipment_id) queryParams.append('equipment_id', params.equipment_id);
    if (params?.report_type_id) queryParams.append('report_type_id', params.report_type_id);
    if (params?.status) queryParams.append('status', params.status);
    
    const query = queryParams.toString();
    return apiRequest(`/maintenance-reports${query ? `?${query}` : ''}`);
  },

  getById: async (id: string) => {
    return apiRequest(`/maintenance-reports/${id}`);
  },

  create: async (data: {
    report_type_id: string;
    ship_id: string;
    equipment_id?: string;
    report_date: string;
    report_data: Record<string, any>;
    remarks?: string;
    status?: string;
  }) => {
    return apiRequest('/maintenance-reports', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  update: async (id: string, data: any) => {
    return apiRequest(`/maintenance-reports/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  delete: async (id: string) => {
    return apiRequest(`/maintenance-reports/${id}`, {
      method: 'DELETE',
    });
  },
};

// Work Logs API
export const workLogsApi = {
  getAll: async (params?: { ship_id?: string; crew_id?: string; status?: string; work_type?: string }) => {
    const queryParams = new URLSearchParams();
    if (params?.ship_id) queryParams.append('ship_id', params.ship_id);
    if (params?.crew_id) queryParams.append('crew_id', params.crew_id);
    if (params?.status) queryParams.append('status', params.status);
    if (params?.work_type) queryParams.append('work_type', params.work_type);
    
    const query = queryParams.toString();
    return apiRequest(`/work-logs/${query ? `?${query}` : ''}`);
  },

  create: async (data: {
    ship_id: string;
    crew_id?: string;
    work_type: string;
    description: string;
    hours: number;
    photo_url?: string;
  }) => {
    return apiRequest('/work-logs/', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  update: async (id: string, data: any) => {
    return apiRequest(`/work-logs/${id}/`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  approve: async (id: string, remarks?: string) => {
    return apiRequest(`/work-logs/${id}/approve/`, {
      method: 'POST',
      body: JSON.stringify({ remarks }),
    });
  },

  delete: async (id: string) => {
    return apiRequest(`/work-logs/${id}/`, {
      method: 'DELETE',
    });
  },
};

// PMS Tasks API
export const pmsTasksApi = {
  getAll: async (params?: { equipment_id?: string; status?: string; assigned_to?: string }) => {
    const queryParams = new URLSearchParams();
    if (params?.equipment_id) queryParams.append('equipment_id', params.equipment_id);
    if (params?.status) queryParams.append('status', params.status);
    if (params?.assigned_to) queryParams.append('assigned_to', params.assigned_to);
    
    const query = queryParams.toString();
    return apiRequest(`/pms/tasks/${query ? `?${query}` : ''}`);
  },

  create: async (data: {
    equipment_id: string;
    task_name: string;
    job_description?: string;
    frequency?: string;
    assigned_to?: string;
    due_date?: string;
    priority?: string;
  }) => {
    return apiRequest('/pms/tasks/', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  update: async (id: string, data: any) => {
    return apiRequest(`/pms/tasks/${id}/`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  delete: async (id: string) => {
    return apiRequest(`/pms/tasks/${id}/`, {
      method: 'DELETE',
    });
  },
};

// Recruitment API
export const recruitmentApi = {
  getAll: async (params?: { status?: string; rank?: string; nationality?: string }) => {
    const queryParams = new URLSearchParams();
    if (params?.status) queryParams.append('status', params.status);
    if (params?.rank) queryParams.append('rank', params.rank);
    if (params?.nationality) queryParams.append('nationality', params.nationality);
    
    const query = queryParams.toString();
    return apiRequest(`/recruitment/${query ? `?${query}` : ''}`);
  },

  getById: async (id: string) => {
    return apiRequest(`/recruitment/${id}/`);
  },

  create: async (data: {
    candidate_name: string;
    candidate_email?: string;
    rank?: string;
    nationality?: string;
    experience?: string;
    ship_id?: string;
    resume_url?: string;
  }) => {
    return apiRequest('/recruitment/', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  update: async (id: string, data: any) => {
    return apiRequest(`/recruitment/${id}/`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  delete: async (id: string) => {
    return apiRequest(`/recruitment/${id}/`, {
      method: 'DELETE',
    });
  },
};

export default {
  auth: authApi,
  ships: shipsApi,
  crew: crewApi,
  certificates: certificatesApi,
  spareParts: sparePartsApi,
  equipmentHours: equipmentHoursApi,
  maintenanceReports: maintenanceReportsApi,
  workLogs: workLogsApi,
  pmsTasks: pmsTasksApi,
  recruitment: recruitmentApi,
};
