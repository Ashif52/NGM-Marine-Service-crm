export type ManualType = "SMM" | "CPM" | "FPM" | "CPMF" | "FPMF";

export type ManualSection = {
  id: string;
  title: string;
  content: string;
  order: number;
  subsections?: ManualSection[];
};

export type ManualVersion = {
  id: string;
  version_number: number;
  revision_date: string;
  change_summary?: string;
  approved_by?: string;
  approved_date?: string;
};

export type Manual = {
  id: string;
  title: string;
  manual_type: ManualType;
  sections: ManualSection[];
  current_version: ManualVersion;
  versions: ManualVersion[];
  ship_id?: string;
  ship_name?: string;
  acknowledgements: ManualAcknowledgement[];
  approved: boolean;
  created_at: string;
  updated_at: string;
};

export type ManualAcknowledgement = {
  id: string;
  manual_id: string;
  user_id: string;
  user_name: string;
  version_id: string;
  version_number: number;
  acknowledged_at: string;
};

export const MANUAL_TYPES = {
  SMM: {
    label: "Safety Management Manual",
    sections: [
      "Company Overview",
      "Safety & Environmental Protection Policy",
      "Roles & Responsibilities",
      "Designated Person Ashore (DPA)",
      "Emergency Preparedness",
      "Maintenance & Defect Reporting",
      "Audits & Reviews"
    ]
  },
  CPM: {
    label: "Company Procedure Manual",
    sections: [
      "Operational Control",
      "Crew Management",
      "Safety Procedures",
      "Incident Reporting"
    ]
  },
  FPM: {
    label: "Fleet Procedure Manual",
    sections: [
      "Navigation Procedures",
      "Engine Room Operations",
      "Planned Maintenance System (PMS)",
      "Cargo Operations",
      "Bunkering Operations"
    ]
  },
  CPMF: {
    label: "Company Forms",
    sections: [
      "Daily Work Log",
      "Risk Assessment",
      "Incident Report",
      "Safety Meeting Record"
    ]
  },
  FPMF: {
    label: "Fleet Forms",
    sections: [
      "PMS Log",
      "Bunkering Checklist",
      "Cargo Checklist",
      "Navigation Checklist"
    ]
  }
} as const;

export type ManualTypeKey = keyof typeof MANUAL_TYPES;

export const FORM_TYPES = {
  DAILY_WORK_LOG: {
    label: "Daily Work Log",
    fields: [
      { name: "work_description", type: "text", required: true },
      { name: "location_onboard", type: "text", required: true },
      { name: "tools_used", type: "text", required: false },
      { name: "hours_worked", type: "number", required: true }
    ]
  },
  RISK_ASSESSMENT: {
    label: "Risk Assessment",
    fields: [
      { name: "hazard_identified", type: "text", required: true },
      { name: "risk_level", type: "select", options: ["Low", "Medium", "High"], required: true },
      { name: "control_measures", type: "text", required: true }
    ]
  },
  SAFETY_MEETING: {
    label: "Safety Meeting Record",
    fields: [
      { name: "topics_discussed", type: "text", required: true },
      { name: "attendees", type: "text", required: true },
      { name: "action_items", type: "text", required: true }
    ]
  },
  PMS_LOG: {
    label: "PMS Log",
    fields: [
      { name: "equipment_name", type: "text", required: true },
      { name: "job_done", type: "text", required: true },
      { name: "spare_used", type: "text", required: false },
      { name: "running_hours", type: "number", required: true }
    ]
  }
} as const;

export type FormTypeKey = keyof typeof FORM_TYPES;
