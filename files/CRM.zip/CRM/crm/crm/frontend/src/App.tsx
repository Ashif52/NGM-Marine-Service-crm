import { useState, useEffect } from "react";
import { AuthProvider, useAuth } from "./contexts/AuthContext";
import { Layout } from "./components/Layout";
import { Login } from "./pages/Login";
import { Dashboard } from "./pages/Dashboard";
import { PMS } from "./pages/PMS";
import { CrewLogs } from "./pages/CrewLogs";
import { Invoices } from "./pages/Invoices";
import { AccessControl } from "./pages/AccessControl";
import { Masters } from "./pages/Masters";
import { Clients } from "./pages/Clients";
import { Vessels } from "./pages/Vessels";
import { Crew } from "./pages/Crew";
import { Recruitment } from "./pages/Recruitment";
import { Manuals } from "./pages/Manuals";
import { Incidents } from "./pages/Incidents";
import { Settings } from "./pages/Settings";
import { Toaster } from "./components/ui/sonner";

function AppContent() {
  const { user, loading, login } = useAuth();
  const [currentPage, setCurrentPage] = useState("dashboard");

  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.slice(1);
      if (hash && hash !== "login") {
        setCurrentPage(hash);
      }
    };

    window.addEventListener("hashchange", handleHashChange);
    handleHashChange();

    return () => window.removeEventListener("hashchange", handleHashChange);
  }, []);

  const handleLogin = async (email: string, password: string) => {
    await login(email, password);
    window.location.hash = "dashboard";
  };

  // Show loading state while checking auth
  if (loading && !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <>
        <Login onLogin={handleLogin} />
        <Toaster />
      </>
    );
  }

  const renderPage = () => {
    switch (currentPage) {
      case "dashboard":
        return <Dashboard />;
      case "pms":
        return <PMS />;
      case "crew-logs":
        return <CrewLogs />;
      case "invoices":
        return <Invoices />;
      case "access-control":
        return <AccessControl />;
      case "masters":
        return <Masters />;
      case "clients":
        return <Clients />;
      case "vessels":
        return <Vessels />;
      case "crew":
        return <Crew />;
      case "recruitment":
        return <Recruitment />;
      case "manuals":
        return <Manuals />;
      case "incidents":
        return <Incidents />;
      case "settings":
        return <Settings />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <>
      <Layout currentPage={currentPage}>{renderPage()}</Layout>
      <Toaster />
    </>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
