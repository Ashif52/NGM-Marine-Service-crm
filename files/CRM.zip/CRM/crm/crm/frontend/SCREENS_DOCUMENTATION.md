# NMG Marine CRM - Complete Screen Documentation

## Overview
This document provides a comprehensive guide to all screens in the NMG Marine CRM system, detailing features, user capabilities, and data sources.

---

## 1. Login Screen (`/src/pages/Login.tsx`)

### Purpose
Authenticate users and grant access to the system based on their role.

### Features
- Email and password authentication
- JWT token-based session management
- Auto-login on page refresh if token is valid
- Loading state during authentication
- Error handling with toast notifications

### User Actions
- Enter email and password
- Click "Login" button to authenticate
- System automatically redirects to Dashboard on successful login

### Data Source
- **API Endpoint**: `POST /api/auth/login`
- **Authentication**: JWT token stored in localStorage
- **Response**: User profile with role (MASTER, CREW, STAFF)

### Role-Based Behavior
- All users use same login screen
- Role determines which pages/features are accessible after login
- Backend returns role with user profile

---

## 2. Dashboard (`/src/pages/Dashboard.tsx`)

### Purpose
Provide overview of key metrics, statistics, and recent activity.

### Features - Master Role
- **KPI Cards** (Real Data):
  - Total Ships count
  - Active Vessels count
  - Total Crew count
  - Crew Onboard count
  - Crew Available count
- **Expiring Certificates Table** (Real Data):
  - Shows certificates expiring in next 60 days
  - Crew name, certificate type, expiry date, days remaining
  - Color-coded badges (red: ≤30 days, yellow: ≤60 days)
- **Fleet Overview** (Real Data):
  - List of ships with status badges
  - Ship name, type, and active status
- **Quick Actions**:
  - PMS Approvals (links to PMS page)
  - Daily Log Reviews (links to Crew Logs)
  - Invoice Approvals (links to Invoices)

### Features - Crew/Staff Role
- **KPI Cards** (Real Data):
  - Crew Onboard count
  - Crew Available count
  - Total Ships count
  - Active Vessels count
- **My Tasks** (Crew only):
  - Assigned PMS tasks
  - Daily work log submission
  - Quick action buttons
- **Expiring Certificates** (Real Data):
  - Same as Master view

### User Actions
- View real-time statistics
- Click Quick Action cards to navigate to specific modules
- Monitor expiring certificates
- View fleet status (Master/Staff only)

### Data Source
- **Ships**: `GET /api/ships/`
- **Crew**: `GET /api/crew/`
- **Certificates**: `GET /api/certificates/expiring?days=60`
- All data refreshes on page load

---

## 3. Crew Management (`/src/pages/Crew.tsx`)

### Purpose
Manage crew members, assignments, and profiles.

### Features (Real Data)
- **Crew List Table**:
  - Name, email, rank, nationality
  - Department, assigned ship
  - Sea time, availability status
  - Action buttons (View, Assign, Unassign)
- **Search & Filters**:
  - Search by name or nationality
  - Filter by rank
  - Filter by availability status (Available, Onboard, Standby, Blocked)
- **Add Crew Member Dialog**:
  - Full form with validation
  - Name, email, password (required)
  - Nationality, sea time, rank, department
  - Optional ship assignment
- **Assign to Ship**:
  - Dropdown selector for available ships
  - Only shown for AVAILABLE crew
- **Unassign from Ship**:
  - Button to unassign ONBOARD crew
  - Changes status back to AVAILABLE

### User Actions
- **View** crew list with real-time data
- **Search** crew by name/nationality
- **Filter** by rank, status
- **Add** new crew member (Master/Staff only)
- **Assign** crew to ships (Master/Staff only)
- **Unassign** crew from ships (Master/Staff only)
- **View** individual crew profile (View button)

### Data Source
- **List Crew**: `GET /api/crew/`
- **Create Crew**: `POST /api/crew`
- **Assign to Ship**: `POST /api/crew/{crew_id}/assign`
- **Unassign from Ship**: `POST /api/crew/{crew_id}/unassign`

### Permissions
- **Master/Staff**: Full access to all features
- **Crew**: Can only view own profile

---

## 4. Vessels Management (`/src/pages/Vessels.tsx`)

### Purpose
Manage fleet of vessels and ship information.

### Features (Real Data)
- **Grid View**:
  - Cards showing ship name, IMO number
  - Flag, ship type, crew capacity
  - Status badge (Active/Inactive)
- **Table View**:
  - Tabular display of all ship data
  - Sortable columns
- **View Toggle**:
  - Switch between Grid and Table views
- **Add Vessel Dialog**:
  - Ship name (required)
  - IMO number
  - Flag, ship type (dropdown)
  - Crew capacity (number)
  - Status (Active by default)
- **Search & Filter**:
  - Search by vessel name or IMO
  - Filter by ship type

### User Actions
- **View** fleet in grid or table layout
- **Search** vessels by name/IMO
- **Filter** by ship type
- **Add** new vessel (Master/Staff only)
- **Toggle** between grid/table views

### Data Source
- **List Ships**: `GET /api/ships/`
- **Create Ship**: `POST /api/ships`

### Permissions
- **Master/Staff**: Full access
- **Crew**: Read-only access to assigned ship

---

## 5. PMS (Planned Maintenance System) (`/src/pages/PMS.tsx`)

### Purpose
Track and manage planned maintenance tasks, spare parts, and equipment.

### Features
- **Task Overview** (Currently Mock Data):
  - Pending, In Progress, Completed, Overdue tasks
  - KPI cards showing task counts
- **Spare Parts** (Real Data - Ready):
  - API connected: `GET /api/spare-parts/`
  - Track inventory, usage, reordering
- **Equipment Hours** (Real Data - Ready):
  - API connected: `GET /api/equipment-hours/`
  - Running hours tracking for equipment
- **Maintenance Reports** (Real Data - Ready):
  - API connected: `GET /api/maintenance-reports/`
  - Historical maintenance records
- **Task Management** (Mock Data):
  - View tasks by status
  - Update task status
  - Add remarks and photos
  - Submit for approval (Crew)
  - Approve/Reject tasks (Master)

### User Actions - Crew
- View assigned tasks
- Update task status
- Add completion remarks
- Upload task photos
- Submit tasks for approval

### User Actions - Master
- View all tasks fleet-wide
- Approve/Reject completed tasks
- Download task reports
- Assign tasks to crew

### Data Source
- **Spare Parts**: `GET /api/spare-parts/` ✅
- **Equipment Hours**: `GET /api/equipment-hours/` ✅
- **Maintenance Reports**: `GET /api/maintenance-reports/` ✅
- **Tasks**: Currently using mock data (backend endpoint exists but not integrated)

### Status
- ✅ API connections ready
- ⚠️ Full integration pending (spare parts, equipment hours, reports need UI updates)
- ⚠️ PMS tasks using mock data

---

## 6. Daily Work Logs (`/src/pages/CrewLogs.tsx`)

### Purpose
Crew members submit daily work reports and activities.

### Features
- **Log Submission Form**:
  - Date selector
  - Work performed (textarea)
  - Hours worked
  - Equipment used
  - Observations/Issues
- **Log History**:
  - View past submissions
  - Filter by date range
- **Approval Status**:
  - Pending, Approved, Rejected badges
  - Master can approve/reject logs

### User Actions - Crew
- Submit daily work log
- View own log history
- Edit pending logs

### User Actions - Master
- View all crew logs
- Approve/Reject logs
- Filter by crew, date, status

### Data Source
- **API Endpoint**: `GET/POST /api/work-logs/` (ready, not fully integrated)
- Currently using mock data

### Status
- ⚠️ API ready, needs UI integration

---

## 7. Settings (`/src/pages/Settings.tsx`)

### Purpose
System configuration, user management, and legal documents.

### Features
- **User Management Tab** (Mock Data):
  - List of system users
  - Create, edit users
  - Reset passwords
  - User roles and status
- **Masters Tab** (Mock Data):
  - System master data
  - Countries, currencies, ranks
  - Ship types, document types
- **Templates Tab** (Mock Data):
  - Email templates
  - Document templates
  - Pre-joining letters, contracts
- **Notifications Tab** (Mock Data):
  - Certificate expiry reminders (60, 30, 15 days)
  - Notification channels (Email, SMS, WhatsApp, Push)
- **Terms & Conditions Tab** ✅:
  - Full terms of service
  - User obligations
  - Liability limitations
  - Intellectual property
- **Privacy Policy Tab** ✅:
  - Data collection practices
  - Security measures
  - User rights (GDPR compliant)
  - Contact information

### User Actions
- **Manage** users (Master only)
- **Configure** master data (Master only)
- **Edit** templates (Master/Staff)
- **Set** notification preferences
- **Read** Terms & Conditions
- **Read** Privacy Policy

### Data Source
- Currently using mock data for management features
- Terms & Privacy: Static content

### Status
- ✅ Terms & Privacy added
- ⚠️ User management needs backend integration
- ⚠️ Master data needs backend integration

---

## 8. Invoices (`/src/pages/Invoices.tsx`)

### Purpose
Manage invoicing and billing.

### Features
- Invoice list
- Create/Edit invoices
- Payment tracking
- Invoice approval workflow

### User Actions
- Create invoices (Staff)
- View invoice history
- Download invoices
- Track payments
- Approve invoices (Master)

### Data Source
- Mock data (backend endpoint not created yet)

### Status
- ⚠️ Needs backend API and integration

---

## 9. Documents (`/src/pages/Documents.tsx`)

### Purpose
Centralized document storage and management.

### Features
- Document upload/download
- Categorization by type
- Search and filter
- Version control
- Expiry tracking

### User Actions
- Upload documents
- Download documents
- Search/Filter
- View document details
- Track expiries

### Data Source
- Mock data (file storage not implemented)

### Status
- ⚠️ Needs file storage backend and integration

---

## 10. Recruitment (`/src/pages/Recruitment.tsx`)

### Purpose
Manage recruitment pipeline and candidate tracking.

### Features
- Candidate applications
- Interview scheduling
- Pipeline stages (Applied, Shortlisted, Final, Pre-joining)
- Document collection
- Offer management

### User Actions
- Add candidates (Staff)
- Move through pipeline stages
- Schedule interviews
- Upload candidate documents
- Generate offers

### Data Source
- Mock data

### Status
- ⚠️ Needs backend API and integration

---

## 11. Reports (`/src/pages/Reports.tsx`)

### Purpose
Generate various operational and compliance reports.

### Features
- Crew reports
- Certificate expiry reports
- PMS compliance reports
- Financial reports
- Custom report builder

### User Actions
- Select report type
- Set date ranges
- Apply filters
- Generate report
- Download/Export (PDF, Excel)

### Data Source
- Mock data

### Status
- ⚠️ Needs backend reporting API

---

## 12. Clients (`/src/pages/Clients.tsx`)

### Purpose
Manage client/shipping company information.

### Features
- Client list
- Contact information
- Active contracts
- Vessel assignments
- Communication history

### User Actions
- Add/Edit clients
- Manage contacts
- View assigned vessels
- Track contracts

### Data Source
- Mock data

### Status
- ⚠️ Needs backend API

---

## 13. Masters (`/src/pages/Masters.tsx`)

### Purpose
Manage system master data and reference tables.

### Features
- Country codes
- Currencies
- Ranks and positions
- Ship types
- Document types
- Validity types

### User Actions
- View master data
- Add/Edit entries (Master only)
- Bulk import
- Export data

### Data Source
- Mock data

### Status
- ⚠️ Needs backend API

---

## 14. DG Communication (`/src/pages/DGCommunication.tsx`)

### Purpose
Track communications with Director General of Shipping and regulatory bodies.

### Features
- Communication log
- Circular tracking
- Compliance deadlines
- Document submission
- Response tracking

### User Actions
- Log communications
- Track circulars
- Set reminders
- Upload documents
- View history

### Data Source
- Mock data

### Status
- ⚠️ Needs backend API

---

## 15. Access Control (`/src/pages/AccessControl.tsx`)

### Purpose
Manage user roles and permissions (Master only).

### Features
- Role management
- Permission assignment
- User access logs
- Security settings

### User Actions (Master Only)
- Create/Edit roles
- Assign permissions
- View access logs
- Configure security policies

### Data Source
- Mock data

### Status
- ⚠️ Needs backend RBAC API

---

## Summary of Data Integration Status

### ✅ Fully Integrated (Real Data)
1. **Login** - JWT authentication
2. **Dashboard** - Ships, crew, certificates statistics
3. **Crew Management** - Full CRUD operations
4. **Vessels Management** - Full CRUD operations
5. **Settings** - Terms & Privacy Policy

### 🔄 Partially Integrated (API Ready)
1. **PMS** - Spare parts, equipment hours, maintenance reports APIs connected but UI needs work

### ⚠️ Not Integrated (Mock Data)
1. Work Logs
2. Invoices
3. Documents
4. Recruitment
5. Reports
6. Clients
7. Masters
8. DG Communication
9. Access Control
10. Finance

---

## Role-Based Access Summary

### MASTER (Super Admin)
- **Full Access** to all modules
- Can create/edit/delete all data
- Approve workflows
- Manage system settings
- View fleet-wide analytics

### STAFF (Shore Office)
- **Access**: Dashboard, Crew, Vessels, PMS, Documents, Invoices, Reports
- Can manage operations
- Cannot access Access Control or delete critical data
- View assigned vessels

### CREW (Seafarer)
- **Access**: Dashboard, PMS (assigned tasks), Work Logs, Documents (own)
- Limited to assigned ship data
- Can submit work logs and PMS updates
- View only access for most data

---

## Next Steps for Full Integration

1. **High Priority**:
   - Complete PMS UI integration (spare parts, equipment, reports)
   - Implement Work Logs full integration
   - Add file upload capability for documents/certificates

2. **Medium Priority**:
   - Invoices backend and integration
   - Reports generation system
   - Clients management backend

3. **Low Priority**:
   - Recruitment pipeline backend
   - DG Communication tracking
   - Access Control/RBAC backend
   - Masters data management backend

---

## Technical Notes

- **Frontend**: React + Vite + TypeScript
- **UI Library**: shadcn/ui (Radix UI components)
- **State Management**: React Context (Auth, Ships)
- **HTTP Client**: Fetch API with custom wrappers
- **Authentication**: JWT tokens in localStorage
- **Notifications**: Sonner toast library
- **Styling**: TailwindCSS

---

**Last Updated**: December 2024  
**Version**: 1.0  
**Documentation Status**: Complete for all existing screens
