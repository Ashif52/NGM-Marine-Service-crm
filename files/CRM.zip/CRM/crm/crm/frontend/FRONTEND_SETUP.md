# NMG Marine CRM - Frontend Setup & Production Guide

## Overview
The frontend is now fully integrated with the backend API. All components fetch real data from the database.

## What Was Implemented

### 1. API Service Layer (`src/services/api.ts`)
- Complete API client with JWT token management
- Endpoints for: Auth, Ships, Crew, Certificates, Spare Parts, Equipment Hours, Maintenance Reports, Work Logs
- Token persists in localStorage for auto-login

### 2. Authentication (`src/contexts/AuthContext.tsx`)
- Real JWT-based authentication
- Auto-login on page refresh if token exists
- Fetches ships list on login
- Role-based access control (MASTER, CREW, STAFF)

### 3. Pages Connected to Backend

#### Dashboard (`src/pages/Dashboard.tsx`)
- **Real Data Loaded:**
  - Total ships count
  - Active ships count
  - Total crew count
  - Crew onboard count
  - Crew available count
  - Expiring certificates (next 60 days)
  - Fleet overview
- **Role-specific views:** Master sees fleet data, Crew/Staff see assigned ship data

#### Crew Management (`src/pages/Crew.tsx`)
- **Features:**
  - List all crew members from database
  - Add new crew member with full form (name, email, password, rank, department, ship assignment)
  - Assign/unassign crew to ships
  - Filter by rank, status, nationality
  - Search by name or nationality
- **API Calls:** GET /crew, POST /crew, POST /crew/{id}/assign, POST /crew/{id}/unassign

#### Vessels Management (`src/pages/Vessels.tsx`)
- **Features:**
  - List all ships from database
  - Add new vessel with form (name, IMO, flag, type, capacity)
  - Grid and table view modes
  - Filter by ship type
  - Search by name or IMO
- **API Calls:** GET /ships, POST /ships

### 4. Components Updated
- **Sidebar:** Fixed role comparison to handle uppercase roles from backend
- **Login:** Async login with error handling and loading states
- **App:** Added loading state for auth check on page load

## Configuration

### Backend URL
Location: `src/services/api.ts`
```typescript
const API_BASE_URL = 'http://localhost:8001/api';
```
**For production:** Update this to your production API URL

### CORS Configuration
Ensure your backend `app/main.py` allows requests from your frontend domain:
```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "https://yourdomain.com"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

## Running the Application

### Development
```bash
# Terminal 1 - Backend (port 8001)
cd backend
C:\projects\demanualai\devenv\Scripts\activate
uvicorn app.main:app --reload --port 8001

# Terminal 2 - Frontend (port 3000)
cd frontend
npm install
npm run dev
```

### Production Build
```bash
cd frontend
npm run build
# Deploy the 'dist' folder to your hosting service
```

## Testing Checklist

### 1. Authentication
- [x] Login with valid credentials
- [x] Token persists on page refresh
- [x] Logout clears token
- [x] Sidebar shows correct menu items based on role

### 2. Dashboard
- [x] Shows real ship count
- [x] Shows real crew statistics
- [x] Displays expiring certificates from database
- [x] Fleet overview shows actual ships

### 3. Crew Management
- [x] Lists all crew from database
- [x] Add new crew member form works
- [x] Search and filters work
- [x] Assign/unassign crew to ships
- [x] Shows loading states

### 4. Vessels Management
- [x] Lists all ships from database
- [x] Add new vessel form works
- [x] Grid and table views work
- [x] Search and filters work
- [x] Shows loading states

## User Roles & Permissions

### MASTER (Super Admin)
- Full access to all modules
- Can manage ships, crew, certificates
- Can view all dashboard statistics

### STAFF (Shore Office)
- Access to operations modules
- Can manage crew and ships
- Can view reports and analytics

### CREW (Seafarer)
- Limited access to assigned ship data
- Can view own profile
- Can submit work logs
- Can view PMS tasks

## Known Limitations

### Not Yet Implemented
- PMS modules (spare parts, equipment hours, maintenance reports) - UI exists but not connected to API
- Documents management
- Invoicing module
- Reports module
- Work logs detailed view

### To Be Added
- File upload for certificates and documents
- Advanced analytics and charts
- Real-time notifications
- Mobile responsive improvements

## Production Deployment Checklist

### Backend
- [ ] Set environment variables (DATABASE_URL, SECRET_KEY, etc.)
- [ ] Update CORS origins to production domain
- [ ] Enable HTTPS
- [ ] Configure proper database connection pooling
- [ ] Set up logging and monitoring

### Frontend
- [ ] Update API_BASE_URL to production backend URL
- [ ] Build production bundle: `npm run build`
- [ ] Deploy to hosting service (Netlify, Vercel, AWS S3, etc.)
- [ ] Configure environment variables if needed
- [ ] Set up SSL certificate
- [ ] Configure CDN for static assets

### Database
- [ ] Run all migration scripts
- [ ] Create initial admin user
- [ ] Backup strategy in place
- [ ] Connection pooling configured

## Troubleshooting

### Issue: Sidebar not showing after login
**Solution:** Backend returns roles in uppercase (MASTER, CREW, STAFF). Sidebar now handles this with `.toLowerCase()` comparison.

### Issue: API calls failing
**Check:**
1. Backend is running on correct port (8001)
2. CORS is configured properly
3. Check browser console for specific error
4. Verify token is being sent in request headers

### Issue: "Failed to load data"
**Check:**
1. Database connection is working
2. Tables exist and have data
3. JWT token is valid and not expired
4. User has correct permissions for the endpoint

## Support
For issues or questions, check:
1. Browser console for errors
2. Backend logs for API errors
3. Network tab in DevTools for failed requests
