-- Spare Parts Inventory Table
CREATE TABLE IF NOT EXISTS public.spare_parts (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  equipment_id uuid,
  ship_id uuid NOT NULL,
  part_number text,
  part_name text NOT NULL,
  manufacturer text,
  quantity integer NOT NULL DEFAULT 0,
  min_quantity integer DEFAULT 1,
  unit text,
  location_on_ship text,
  last_ordered_date date,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now(),
  CONSTRAINT spare_parts_pkey PRIMARY KEY (id),
  CONSTRAINT spare_parts_ship_id_fkey FOREIGN KEY (ship_id) REFERENCES public.ships(id),
  CONSTRAINT spare_parts_equipment_id_fkey FOREIGN KEY (equipment_id) REFERENCES public.equipments(id)
);

-- Spare Parts Transaction History
CREATE TABLE IF NOT EXISTS public.spare_part_transactions (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  spare_part_id uuid NOT NULL,
  transaction_type text NOT NULL CHECK (transaction_type = ANY (ARRAY['RECEIPT'::text, 'USAGE'::text, 'ADJUSTMENT'::text])),
  quantity integer NOT NULL,
  reference_number text,
  remarks text,
  created_by uuid,
  created_at timestamp with time zone DEFAULT now(),
  CONSTRAINT spare_part_transactions_pkey PRIMARY KEY (id),
  CONSTRAINT spare_part_transactions_spare_part_id_fkey FOREIGN KEY (spare_part_id) REFERENCES public.spare_parts(id),
  CONSTRAINT spare_part_transactions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.profiles(id)
);

-- Equipment Running Hours
CREATE TABLE IF NOT EXISTS public.equipment_running_hours (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  equipment_id uuid NOT NULL,
  date date NOT NULL,
  running_hours numeric NOT NULL DEFAULT 0,
  total_running_hours numeric NOT NULL DEFAULT 0,
  reported_by uuid,
  created_at timestamp with time zone DEFAULT now(),
  CONSTRAINT equipment_running_hours_pkey PRIMARY KEY (id),
  CONSTRAINT equipment_running_hours_equipment_id_fkey FOREIGN KEY (equipment_id) REFERENCES public.equipments(id),
  CONSTRAINT equipment_running_hours_reported_by_fkey FOREIGN KEY (reported_by) REFERENCES public.profiles(id)
);

-- Maintenance Report Types
CREATE TABLE IF NOT EXISTS public.maintenance_report_types (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  name text NOT NULL,
  description text,
  created_at timestamp with time zone DEFAULT now(),
  CONSTRAINT maintenance_report_types_pkey PRIMARY KEY (id)
);

-- Maintenance Reports
CREATE TABLE IF NOT EXISTS public.maintenance_reports (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  report_type_id uuid NOT NULL,
  ship_id uuid NOT NULL,
  equipment_id uuid,
  report_date date NOT NULL,
  report_data jsonb NOT NULL,
  remarks text,
  status text NOT NULL DEFAULT 'DRAFT'::text CHECK (status = ANY (ARRAY['DRAFT'::text, 'SUBMITTED'::text, 'APPROVED'::text])),
  created_by uuid NOT NULL,
  approved_by uuid,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now(),
  CONSTRAINT maintenance_reports_pkey PRIMARY KEY (id),
  CONSTRAINT maintenance_reports_report_type_id_fkey FOREIGN KEY (report_type_id) REFERENCES public.maintenance_report_types(id),
  CONSTRAINT maintenance_reports_ship_id_fkey FOREIGN KEY (ship_id) REFERENCES public.ships(id),
  CONSTRAINT maintenance_reports_equipment_id_fkey FOREIGN KEY (equipment_id) REFERENCES public.equipments(id),
  CONSTRAINT maintenance_reports_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.profiles(id),
  CONSTRAINT maintenance_reports_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.profiles(id)
);

-- Add fields to equipments table
ALTER TABLE public.equipments
ADD COLUMN IF NOT EXISTS manufacturer text,
ADD COLUMN IF NOT EXISTS model text,
ADD COLUMN IF NOT EXISTS serial_number text,
ADD COLUMN IF NOT EXISTS installation_date date,
ADD COLUMN IF NOT EXISTS last_maintenance_date date,
ADD COLUMN IF NOT EXISTS next_maintenance_date date,
ADD COLUMN IF NOT EXISTS maintenance_interval_hours numeric,
ADD COLUMN IF NOT EXISTS maintenance_interval_days integer,
ADD COLUMN IF NOT EXISTS total_running_hours numeric DEFAULT 0;

-- Enhance pms_tasks table
ALTER TABLE public.pms_tasks
ADD COLUMN IF NOT EXISTS job_number text,
ADD COLUMN IF NOT EXISTS job_description text,
ADD COLUMN IF NOT EXISTS estimated_hours numeric,
ADD COLUMN IF NOT EXISTS interval_type text CHECK (interval_type = ANY (ARRAY['RUNNING_HOURS'::text, 'CALENDAR'::text, 'CONDITION'::text])),
ADD COLUMN IF NOT EXISTS interval_value numeric,
ADD COLUMN IF NOT EXISTS last_done_date date,
ADD COLUMN IF NOT EXISTS last_done_hours numeric,
ADD COLUMN IF NOT EXISTS priority text CHECK (priority = ANY (ARRAY['LOW'::text, 'MEDIUM'::text, 'HIGH'::text, 'CRITICAL'::text])),
ADD COLUMN IF NOT EXISTS risk_assessment text,
ADD COLUMN IF NOT EXISTS safety_precautions text,
ADD COLUMN IF NOT EXISTS required_parts jsonb,
ADD COLUMN IF NOT EXISTS required_tools text;

-- Insert predefined maintenance report types
INSERT INTO public.maintenance_report_types (code, name, description)
VALUES
  ('MONTHLY_RUNNING_HOURS', 'Monthly Running Hours and Consumption Report', 'Track monthly equipment running hours and consumables'),
  ('ME_CYLINDER_INSPECTION', 'Main Engine Cylinder Inspection Report', 'Main engine cylinder liner calibration and inspection'),
  ('ME_DECARB', 'Main Engine De-carbonization Report', 'Main engine de-carbonization inspection and work'),
  ('AUX_ENGINE_DECARB', 'Auxiliary Engine De-carbonization Report', 'Auxiliary engine de-carbonization inspection and work'),
  ('ME_BEARING_INSPECTION', 'Main Engine Bearing Inspection Report', 'Main engine bearing inspection and measurements'),
  ('MACHINERY_OVERHAUL', 'Machinery Overhaul Report', 'General machinery overhaul documentation'),
  ('CRANKSHAFT_DEFLECTION', 'Crankshaft Deflection Report', 'Crankshaft deflection measurements'),
  ('MEGGER_TEST', 'Megger Test Report', 'Electrical insulation resistance testing'),
  ('WORKDONE_REPORT', 'Work Done Report', 'General work done by deck, engine, and electrical departments'),
  ('LUBE_OIL_SAMPLE', 'Lube Oil and Bunker Sample Report', 'Oil and fuel testing samples')
ON CONFLICT (code) DO NOTHING;
