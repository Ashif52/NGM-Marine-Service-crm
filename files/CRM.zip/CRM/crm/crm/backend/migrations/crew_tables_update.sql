-- Add new fields to crew_profiles table
ALTER TABLE public.crew_profiles
ADD COLUMN IF NOT EXISTS department text,
ADD COLUMN IF NOT EXISTS job_description text,
ADD COLUMN IF NOT EXISTS contract_duration integer,
ADD COLUMN IF NOT EXISTS contract_end_date date,
ADD COLUMN IF NOT EXISTS previous_experience text,
ADD COLUMN IF NOT EXISTS emergency_contact_name text,
ADD COLUMN IF NOT EXISTS emergency_contact_number text;

-- Create crew certificates table
CREATE TABLE IF NOT EXISTS public.crew_certificates (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  crew_id uuid NOT NULL,
  name text NOT NULL,
  certificate_number text,
  issue_date date,
  expiry_date date,
  issuing_authority text,
  document_url text,
  created_at timestamp with time zone DEFAULT now(),
  CONSTRAINT crew_certificates_pkey PRIMARY KEY (id),
  CONSTRAINT crew_certificates_crew_id_fkey FOREIGN KEY (crew_id) REFERENCES public.crew_profiles(id) ON DELETE CASCADE
);

-- Create index on expiry_date for efficient searches
CREATE INDEX IF NOT EXISTS idx_crew_certificates_expiry_date ON public.crew_certificates (expiry_date);

-- Create index on crew_id for efficient lookups
CREATE INDEX IF NOT EXISTS idx_crew_certificates_crew_id ON public.crew_certificates (crew_id);

-- Create certificate types table for standard certificates
CREATE TABLE IF NOT EXISTS public.crew_certificate_types (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  name text NOT NULL,
  description text,
  required_for_roles text[],
  created_at timestamp with time zone DEFAULT now(),
  CONSTRAINT crew_certificate_types_pkey PRIMARY KEY (id)
);

-- Insert standard certificate types based on job descriptions
INSERT INTO public.crew_certificate_types (code, name, description, required_for_roles)
VALUES
  ('STCW_BASIC', 'STCW Basic Safety Training', 'Four basic safety courses required for all seafarers', ARRAY['MASTER', 'DECK', 'ENGINE', 'CATERING']),
  ('COC', 'Certificate of Competency', 'Professional qualification required for officers', ARRAY['MASTER', 'DECK', 'ENGINE']),
  ('MEDICAL', 'Medical Certificate', 'Seafarer medical fitness certificate', ARRAY['MASTER', 'DECK', 'ENGINE', 'CATERING']),
  ('GMDSS', 'GMDSS Operator Certificate', 'Global Maritime Distress Safety System', ARRAY['MASTER', 'DECK']),
  ('SECURITY', 'Ship Security Officer', 'Certification for ship security management', ARRAY['MASTER', 'DECK']),
  ('ENGINE_ROOM', 'Engine Room Resource Management', 'Management of engine room resources', ARRAY['ENGINE']),
  ('COOK_CERT', 'Ship''s Cook Certificate', 'Certification for ship''s cooks', ARRAY['CATERING'])
ON CONFLICT (code) DO NOTHING;
