import psycopg2

conn = psycopg2.connect(
    host="db.iogpqpqoljoqoprbsnes.supabase.co",
    port=5432,
    database="postgres",
    user="postgres",
    password="nmg-marine-crm",
    sslmode="require",
    connect_timeout=10
)

cur = conn.cursor()
cur.execute("""
    SELECT table_schema, table_name
    FROM information_schema.tables
    WHERE table_schema NOT IN ('pg_catalog', 'information_schema')
    ORDER BY table_schema, table_name;
""")

for schema, table in cur.fetchall():
    print(f"{schema}.{table}")

cur.close()
conn.close()
