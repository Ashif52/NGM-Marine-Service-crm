import uvicorn
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import psycopg2
from psycopg2.extras import RealDictCursor
import os
from datetime import datetime
import uuid
import json
from jose import jwt
from fastapi.security import OAuth2PasswordBearer
from passlib.context import CryptContext
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Constants
JWT_SECRET_KEY = os.getenv("JWT_SECRET_KEY", "7cc3a18b-b067-4454-8788-ce874ffd7e30")
JWT_ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")
JWT_EXPIRATION_MINUTES = 60 * 24  # 1 day

# Initialize FastAPI app
app = FastAPI(title="NMG Marine CRM API", docs_url="/api/docs")

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, replace with specific origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Security setup
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/token")
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Database connection
def get_db_connection():
    """Get a PostgreSQL connection to Supabase database"""
    try:
        conn = psycopg2.connect(
            host="db.iogpqpqoljoqoprbsnes.supabase.co",
            port=5432,
            database="postgres",
            user="postgres",
            password="nmg-marine-crm",
            sslmode="require",
            cursor_factory=RealDictCursor
        )
        return conn
    except Exception as e:
        print(f"❌ Error connecting to PostgreSQL: {e}")
        raise RuntimeError(f"Failed to connect to PostgreSQL: {e}")

# Helper functions
def json_serializer(obj):
    """JSON serializer for objects not serializable by default json code"""
    if isinstance(obj, datetime):
        return obj.isoformat()
    raise TypeError(f"Type {type(obj)} not serializable")

def verify_password(plain_password, hashed_password):
    """Verify password"""
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    """Get password hash"""
    return pwd_context.hash(password)

def create_access_token(data: dict):
    """Create JWT token"""
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=JWT_EXPIRATION_MINUTES)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, JWT_SECRET_KEY, algorithm=JWT_ALGORITHM)
    return encoded_jwt

async def get_current_user(token: str = Depends(oauth2_scheme)):
    """Get current user from token"""
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, JWT_SECRET_KEY, algorithms=[JWT_ALGORITHM])
        user_id = payload.get("sub")
        if user_id is None:
            raise credentials_exception
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM profiles WHERE id = %s", (user_id,))
        user = cursor.fetchone()
        cursor.close()
        conn.close()
        
        if user is None:
            raise credentials_exception
        
        return user
    except Exception:
        raise credentials_exception

# Pydantic models
class Token(BaseModel):
    access_token: str
    token_type: str

class LoginRequest(BaseModel):
    email: str
    password: str

class ShipBase(BaseModel):
    ship_name: str
    imo_number: Optional[str] = None
    ship_type: Optional[str] = None
    flag: Optional[str] = None
    client_id: Optional[str] = None
    crew_capacity: Optional[int] = None

class ShipCreate(ShipBase):
    pass

class ShipUpdate(ShipBase):
    ship_name: Optional[str] = None
    status: Optional[str] = None

# Routes
@app.get("/api")
async def root():
    """API root endpoint"""
    return {"message": "NMG Marine CRM API is running"}

@app.get("/api/health")
async def health_check():
    """Health check endpoint"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        cursor.close()
        conn.close()
        return {"status": "healthy", "database": "connected"}
    except Exception as e:
        return {"status": "unhealthy", "database": str(e)}

@app.post("/api/auth/login", response_model=Token)
async def login(login_data: LoginRequest):
    """Authenticate user and return token"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # For testing, we'll just look up the user by email and assume password is correct
        # In a real app, you'd verify the password hash
        cursor.execute("SELECT * FROM profiles WHERE email = %s", (login_data.email,))
        user = cursor.fetchone()
        
        cursor.close()
        conn.close()
        
        if not user:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid credentials",
                headers={"WWW-Authenticate": "Bearer"},
            )
        
        # Create token
        access_token = create_access_token(
            data={"sub": user["id"], "role": user["role"], "name": user["name"]}
        )
        
        return {"access_token": access_token, "token_type": "bearer"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

@app.get("/api/ships")
async def get_ships(
    current_user: dict = Depends(get_current_user),
    status: Optional[str] = None,
    ship_type: Optional[str] = None,
    client_id: Optional[str] = None
):
    """Get all ships"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        query = "SELECT * FROM ships WHERE 1=1"
        params = []
        
        if status:
            query += " AND status = %s"
            params.append(status)
        if ship_type:
            query += " AND ship_type = %s"
            params.append(ship_type)
        if client_id:
            query += " AND client_id = %s"
            params.append(client_id)
        
        # CREW can only see their assigned ship
        if current_user["role"] == "CREW" and current_user.get("ship_id"):
            query += " AND id = %s"
            params.append(current_user["ship_id"])
        
        query += " ORDER BY created_at DESC"
        
        cursor.execute(query, params)
        ships = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        return ships
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/ships/{ship_id}")
async def get_ship(ship_id: str, current_user: dict = Depends(get_current_user)):
    """Get a specific ship"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM ships WHERE id = %s", (ship_id,))
        ship = cursor.fetchone()
        
        cursor.close()
        conn.close()
        
        if not ship:
            raise HTTPException(status_code=404, detail="Ship not found")
        
        # CREW can only see their assigned ship
        if current_user["role"] == "CREW" and current_user.get("ship_id") != ship_id:
            raise HTTPException(status_code=403, detail="Access denied")
        
        return ship
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/ships")
async def create_ship(ship: ShipCreate, current_user: dict = Depends(get_current_user)):
    """Create a new ship (MASTER only)"""
    if current_user["role"] != "MASTER":
        raise HTTPException(status_code=403, detail="Only MASTER can create ships")
    
    try:
        ship_data = ship.dict()
        ship_data["id"] = str(uuid.uuid4())
        ship_data["created_at"] = datetime.now()
        ship_data["status"] = "ACTIVE"
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        columns = ", ".join(ship_data.keys())
        placeholders = ", ".join("%s" for _ in ship_data)
        query = f"INSERT INTO ships ({columns}) VALUES ({placeholders}) RETURNING *"
        
        cursor.execute(query, list(ship_data.values()))
        conn.commit()
        
        new_ship = cursor.fetchone()
        
        cursor.close()
        conn.close()
        
        return new_ship
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.put("/api/ships/{ship_id}")
async def update_ship(ship_id: str, ship: ShipUpdate, current_user: dict = Depends(get_current_user)):
    """Update a ship (MASTER only)"""
    if current_user["role"] != "MASTER":
        raise HTTPException(status_code=403, detail="Only MASTER can update ships")
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if ship exists
        cursor.execute("SELECT * FROM ships WHERE id = %s", (ship_id,))
        existing_ship = cursor.fetchone()
        
        if not existing_ship:
            cursor.close()
            conn.close()
            raise HTTPException(status_code=404, detail="Ship not found")
        
        # Update ship
        update_data = {k: v for k, v in ship.dict().items() if v is not None}
        
        if not update_data:
            cursor.close()
            conn.close()
            return existing_ship
        
        set_clause = ", ".join(f"{k} = %s" for k in update_data.keys())
        values = list(update_data.values())
        values.append(ship_id)
        
        query = f"UPDATE ships SET {set_clause} WHERE id = %s RETURNING *"
        cursor.execute(query, values)
        conn.commit()
        
        updated_ship = cursor.fetchone()
        
        cursor.close()
        conn.close()
        
        return updated_ship
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/api/ships/{ship_id}")
async def delete_ship(ship_id: str, current_user: dict = Depends(get_current_user)):
    """Delete a ship (MASTER only)"""
    if current_user["role"] != "MASTER":
        raise HTTPException(status_code=403, detail="Only MASTER can delete ships")
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if ship exists
        cursor.execute("SELECT * FROM ships WHERE id = %s", (ship_id,))
        existing_ship = cursor.fetchone()
        
        if not existing_ship:
            cursor.close()
            conn.close()
            raise HTTPException(status_code=404, detail="Ship not found")
        
        # Delete ship
        cursor.execute("DELETE FROM ships WHERE id = %s", (ship_id,))
        conn.commit()
        
        cursor.close()
        conn.close()
        
        return {"message": "Ship deleted successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/crew")
async def get_crew_members(current_user: dict = Depends(get_current_user)):
    """Get all crew members"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        query = "SELECT * FROM crew_profiles"
        
        # If CREW, only show their own profile
        if current_user["role"] == "CREW":
            query += " WHERE user_id = %s"
            cursor.execute(query, (current_user["id"],))
        else:
            cursor.execute(query)
        
        crew_members = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        return crew_members
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Run the app
if __name__ == "__main__":
    from datetime import timedelta  # Import timedelta here
    uvicorn.run("direct_api:app", host="0.0.0.0", port=8000, reload=True)
else:
    from datetime import timedelta  # Import timedelta for module import
