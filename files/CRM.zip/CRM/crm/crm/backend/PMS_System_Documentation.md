# PMS System Workflow Documentation

## Overview

The Preventive Maintenance System (PMS) is a comprehensive solution for managing ship maintenance activities, spare parts inventory, equipment running hours, and maintenance reports. This system implements the requirements outlined in the FPM (Fleet and Personnel Management) documentation.

## Table of Contents

1. [Spare Parts Management Workflow](#1-spare-parts-management-workflow)
2. [Equipment Running Hours Workflow](#2-equipment-running-hours-workflow)
3. [Maintenance Reports Workflow](#3-maintenance-reports-workflow)
4. [Complete PMS Task Management](#4-complete-pms-task-management)
5. [API Endpoints Reference](#5-api-endpoints-reference)

---

## 1. Spare Parts Management Workflow

### 1.1 Creating and Tracking Spare Parts

**Description:** This workflow allows maintaining an inventory of spare parts for ships and equipment.

**Steps:**
1. Create spare part with initial quantity and minimum quantity threshold
2. System stores the part with reference to ship and optionally equipment
3. Track inventory levels and location on ship

**Usage Scenario:**
- Ship engineer adds new spare parts to inventory after receiving supplies
- STAFF/MASTER can view inventory levels across all ships

**API Endpoints:**
- `POST /api/spare-parts`: Create spare part with initial quantity
- `GET /api/spare-parts`: List all spare parts with filtering options
- `GET /api/spare-parts/{id}`: Get specific spare part details
- `PUT /api/spare-parts/{id}`: Update spare part information
- `DELETE /api/spare-parts/{id}`: Remove spare part from inventory

**Request/Response Examples:**

Create Spare Part:
```json
POST /api/spare-parts
{
  "ship_id": "uuid",
  "equipment_id": "uuid",
  "part_number": "P-12345",
  "part_name": "Fuel Filter",
  "manufacturer": "Caterpillar",
  "quantity": 10,
  "min_quantity": 2,
  "unit": "pcs",
  "location_on_ship": "Engine Room Store"
}
```

### 1.2 Spare Part Transactions

**Description:** Track the usage and receipt of spare parts over time.

**Steps:**
1. Record transaction (RECEIPT, USAGE, or ADJUSTMENT)
2. System automatically updates the current quantity
3. Transaction history is preserved for auditing

**Usage Scenario:**
- Engineer uses parts for maintenance and records the usage
- Ship receives new supplies and records receipt
- Inventory counts are adjusted after physical verification

**API Endpoints:**
- `POST /api/spare-parts/transactions`: Record usage or receipt
- `GET /api/spare-parts/transactions/{spare_part_id}`: View transaction history

**Transaction Types:**
- **RECEIPT**: Adding parts to inventory (e.g., new delivery)
- **USAGE**: Removing parts from inventory (e.g., used for maintenance)
- **ADJUSTMENT**: Manual adjustment of quantity (e.g., after inventory count)

---

## 2. Equipment Running Hours Workflow

### 2.1 Recording Equipment Usage

**Description:** Track running hours of equipment for maintenance scheduling.

**Steps:**
1. Record daily running hours for equipment
2. System maintains both daily and cumulative totals
3. Running hours inform maintenance scheduling

**Usage Scenario:**
- Engineer records daily engine running hours
- System calculates when maintenance is due based on hours

**API Endpoints:**
- `POST /api/equipment-hours`: Record daily running hours
- `GET /api/equipment-hours`: List recorded hours with filtering
- `GET /api/equipment-hours/{id}`: View specific record
- `PUT /api/equipment-hours/{id}`: Update recorded hours
- `GET /api/equipment-hours/summary/{equipment_id}`: Get usage summary stats

**Request/Response Examples:**

Record Running Hours:
```json
POST /api/equipment-hours
{
  "equipment_id": "uuid",
  "date": "2024-01-15",
  "running_hours": 8.5,
  "total_running_hours": 108.5
}
```

### 2.2 Maintenance Scheduling Based on Running Hours

**Description:** The system uses running hours to trigger maintenance alerts.

**Steps:**
1. Equipment defined with maintenance interval (hours)
2. As running hours accumulate, system calculates time to next maintenance
3. When threshold is reached, maintenance task becomes due

**Usage Scenario:**
- Engine requires maintenance every 250 hours
- System alerts when engine approaches 250 hours since last maintenance

---

## 3. Maintenance Reports Workflow

### 3.1 Creating Maintenance Reports

**Description:** Document maintenance activities using standardized report templates.

**Steps:**
1. Select report type based on maintenance activity
2. Fill report with required data (measurements, observations)
3. Submit for review/approval

**Usage Scenario:**
- Engineer performs engine inspection and records findings
- MASTER reviews and approves the maintenance report

**API Endpoints:**
- `GET /api/maintenance-reports/types`: List available report templates
- `POST /api/maintenance-reports`: Create new maintenance report
- `GET /api/maintenance-reports`: List reports with filtering
- `GET /api/maintenance-reports/{id}`: View specific report
- `PUT /api/maintenance-reports/{id}`: Update report data
- `DELETE /api/maintenance-reports/{id}`: Remove draft report

**Available Report Types:**
- MONTHLY_RUNNING_HOURS: Monthly running hours and consumption
- ME_CYLINDER_INSPECTION: Main engine cylinder inspection
- ME_DECARB: Main engine de-carbonization
- AUX_ENGINE_DECARB: Auxiliary engine de-carbonization
- ME_BEARING_INSPECTION: Main engine bearing inspection
- MACHINERY_OVERHAUL: General machinery overhaul
- CRANKSHAFT_DEFLECTION: Crankshaft deflection measurements
- MEGGER_TEST: Electrical insulation resistance testing
- WORKDONE_REPORT: General work done by departments
- LUBE_OIL_SAMPLE: Oil and fuel testing samples

### 3.2 Report Approval Workflow

**Description:** Multi-step approval process for maintenance reports.

**Steps:**
1. Engineer creates report in DRAFT status
2. When complete, engineer changes status to SUBMITTED
3. MASTER/STAFF reviews and sets status to APPROVED or returns to DRAFT with comments

**Usage Scenario:**
- Engineer completes cylinder inspection report
- MASTER reviews measurements and approves if acceptable

**Report Status Flow:**
```
DRAFT → SUBMITTED → APPROVED
  ↑         ↓
  └───────┘
```

---

## 4. Complete PMS Task Management

### 4.1 Task Scheduling and Execution

**Description:** Comprehensive workflow from task creation to completion.

**Steps:**
1. System creates maintenance tasks based on:
   - Calendar intervals
   - Running hours thresholds
   - Manufacturer recommendations
2. Tasks are assigned to crew members
3. Crew performs maintenance and creates report
4. Parts usage is recorded
5. Task is marked complete and next cycle begins

**Integration Points:**
- Equipment details inform task requirements
- Spare parts inventory verifies availability of required parts
- Running hours determine when maintenance is due
- Maintenance reports document the completed work

### 4.2 PMS Task Fields and Usage

**Enhanced PMS Task Fields:**
- `job_number`: Unique identifier for the maintenance job
- `job_description`: Detailed description of work to be performed
- `interval_type`: RUNNING_HOURS, CALENDAR, or CONDITION
- `interval_value`: Numeric value for the interval
- `priority`: LOW, MEDIUM, HIGH, or CRITICAL
- `risk_assessment`: Assessment of risks involved
- `safety_precautions`: Required safety measures
- `required_parts`: JSON array of parts needed
- `required_tools`: List of tools required

---

## 5. API Endpoints Reference

### Authentication
All endpoints require a valid JWT Bearer token in the Authorization header.

### Role-Based Access Control
- **MASTER**: Full access to all endpoints
- **STAFF**: Can manage spare parts, approve reports, update equipment hours
- **CREW**: Can create reports, record usage, update own reports (DRAFT only)

### Spare Parts Endpoints
```
POST   /api/spare-parts                    Create spare part
GET    /api/spare-parts                    List spare parts
GET    /api/spare-parts/{id}               Get spare part
PUT    /api/spare-parts/{id}               Update spare part
DELETE /api/spare-parts/{id}               Delete spare part
POST   /api/spare-parts/transactions       Record transaction
GET    /api/spare-parts/transactions/{id}  Get transactions
```

### Equipment Running Hours Endpoints
```
POST   /api/equipment-hours                Record hours
GET    /api/equipment-hours                List hours
GET    /api/equipment-hours/{id}           Get specific record
PUT    /api/equipment-hours/{id}           Update record
DELETE /api/equipment-hours/{id}           Delete record
GET    /api/equipment-hours/summary/{id}   Get summary stats
```

### Maintenance Reports Endpoints
```
GET    /api/maintenance-reports/types      Get report types
POST   /api/maintenance-reports            Create report
GET    /api/maintenance-reports            List reports
GET    /api/maintenance-reports/{id}       Get report
PUT    /api/maintenance-reports/{id}       Update report
DELETE /api/maintenance-reports/{id}       Delete report
```

### Query Parameters

**Spare Parts:**
- `ship_id`: Filter by ship UUID
- `equipment_id`: Filter by equipment UUID
- `low_stock`: Boolean to show only low stock items
- `search`: Search by part name or number
- `skip`: Pagination offset
- `limit`: Pagination limit

**Equipment Hours:**
- `equipment_id`: Filter by equipment UUID
- `start_date`: Filter by start date
- `end_date`: Filter by end date
- `skip`: Pagination offset
- `limit`: Pagination limit

**Maintenance Reports:**
- `ship_id`: Filter by ship UUID
- `equipment_id`: Filter by equipment UUID
- `report_type_id`: Filter by report type UUID
- `status`: Filter by status (DRAFT, SUBMITTED, APPROVED)
- `start_date`: Filter by report date
- `end_date`: Filter by report date
- `skip`: Pagination offset
- `limit`: Pagination limit

---

## Testing the System

### Prerequisites
1. Run the database migration script
2. Start the FastAPI server
3. Login with MASTER role credentials

### Running Tests
1. Copy the access token from the login response
2. Update the `ACCESS_TOKEN` variable in `test_pms_system.py`
3. Run the test script: `python test_pms_system.py`

The test script will:
- Create test data (ship, equipment, spare parts)
- Test all CRUD operations
- Verify workflows
- Display results and created resource IDs

### Common Test Scenarios

1. **Spare Parts Inventory Management**
   - Create spare parts with minimum quantities
   - Record usage transactions
   - Verify low stock alerts
   - Record receipt transactions

2. **Equipment Maintenance Tracking**
   - Create equipment with maintenance intervals
   - Record daily running hours
   - Check summary statistics
   - Verify maintenance due calculations

3. **Maintenance Report Workflow**
   - Create draft maintenance report
   - Update with measurement data
   - Submit for approval
   - Approve as MASTER/STAFF

This comprehensive PMS system implements the processes outlined in "FPM 05 Preventive maintenance.md" and supports all the maintenance report types specified in the FPMF documentation.
