-- Add sample crew members to NMG Marine CRM
-- This script creates users and their corresponding crew profiles

-- First, let's add some MASTER users (Super Admins)
INSERT INTO users (id, email, password_hash, role, created_at, updated_at) VALUES
('c01-master-001', 'captain.nmg@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', 'MASTER', NOW(), NOW()),
('c01-master-002', 'admin@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', 'MASTER', NOW(), NOW());

-- Add STAFF users (Shore Office)
INSERT INTO users (id, email, password_hash, role, created_at, updated_at) VALUES
('c01-staff-001', 'hr.manager@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', 'STAFF', NOW(), NOW()),
('c01-staff-002', 'operations@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', 'STAFF', NOW(), NOW()),
('c01-staff-003', 'finance@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', 'STAFF', NOW(), NOW());

-- Add CREW users (Seafarers)
INSERT INTO users (id, email, password_hash, role, created_at, updated_at) VALUES
-- Deck Department Officers
('c01-crew-001', 'john.smith@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', 'CREW', NOW(), NOW()),
('c01-crew-002', 'robert.jones@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', 'CREW', NOW(), NOW()),
('c01-crew-003', 'michael.brown@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', 'CREW', NOW(), NOW()),

-- Engine Department Officers
('c01-crew-004', 'david.wilson@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', 'CREW', NOW(), NOW()),
('c01-crew-005', 'james.taylor@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', 'CREW', NOW(), NOW()),

-- Deck Ratings
('c01-crew-006', 'ahmed.hassan@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', 'CREW', NOW(), NOW()),
('c01-crew-007', 'mohammed.ali@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', 'CREW', NOW(), NOW()),
('c01-crew-008', 'raj.patel@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', 'CREW', NOW(), NOW()),

-- Engine Ratings
('c01-crew-009', 'chen.wei@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', 'CREW', NOW(), NOW()),
('c01-crew-010', 'li.wang@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', 'CREW', NOW(), NOW()),

-- Catering Department
('c01-crew-011', 'maria.garcia@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', 'CREW', NOW(), NOW()),
('c01-crew-012', 'sarah.johnson@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', 'CREW', NOW(), NOW());

-- Now add their crew profiles
INSERT INTO crew_profiles (user_id, ship_id, nationality, availability, sea_time, status, rank, department, join_date, created_at, updated_at) VALUES
-- Master Profiles (Not assigned to ships - Super Admins)
('c01-master-001', NULL, 'British', 'AVAILABLE', '15 years', 'ACTIVE', 'Captain', 'DECK', '2020-01-15', NOW(), NOW()),
('c01-master-002', NULL, 'British', 'AVAILABLE', '20 years', 'ACTIVE', 'Superintendent', 'DECK', '2019-05-01', NOW(), NOW()),

-- Staff Profiles (Shore Office)
('c01-staff-001', NULL, 'British', 'AVAILABLE', '10 years', 'ACTIVE', 'HR Manager', 'DECK', '2021-03-01', NOW(), NOW()),
('c01-staff-002', NULL, 'British', 'AVAILABLE', '12 years', 'ACTIVE', 'Operations Manager', 'DECK', '2020-06-15', NOW(), NOW()),
('c01-staff-003', NULL, 'British', 'AVAILABLE', '8 years', 'ACTIVE', 'Finance Officer', 'DECK', '2022-01-10', NOW(), NOW()),

-- Deck Department - Officers
('c01-crew-001', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', 'British', 'ONBOARD', '10 years', 'ACTIVE', 'Captain', 'DECK', '2020-01-15', NOW(), NOW()),
('c01-crew-002', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', 'American', 'ONBOARD', '8 years', 'ACTIVE', 'Chief Officer', 'DECK', '2021-02-20', NOW(), NOW()),
('c01-crew-003', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', 'British', 'ONBOARD', '6 years', 'ACTIVE', 'Second Officer', 'DECK', '2022-03-10', NOW(), NOW()),

-- Engine Department - Officers
('c01-crew-004', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', 'British', 'ONBOARD', '12 years', 'ACTIVE', 'Chief Engineer', 'ENGINE', '2019-11-01', NOW(), NOW()),
('c01-crew-005', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', 'Scottish', 'ONBOARD', '9 years', 'ACTIVE', 'Second Engineer', 'ENGINE', '2020-07-15', NOW(), NOW()),

-- Deck Department - Ratings
('c01-crew-006', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', 'Egyptian', 'ONBOARD', '5 years', 'ACTIVE', 'Able Seaman', 'DECK', '2023-01-05', NOW(), NOW()),
('c01-crew-007', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', 'Egyptian', 'ONBOARD', '3 years', 'ACTIVE', 'Ordinary Seaman', 'DECK', '2023-06-10', NOW(), NOW()),
('c01-crew-008', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', 'Indian', 'ONBOARD', '4 years', 'ACTIVE', 'Able Seaman', 'DECK', '2022-11-20', NOW(), NOW()),

-- Engine Department - Ratings
('c01-crew-009', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', 'Chinese', 'ONBOARD', '6 years', 'ACTIVE', 'Motorman', 'ENGINE', '2021-09-15', NOW(), NOW()),
('c01-crew-010', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', 'Chinese', 'ONBOARD', '4 years', 'ACTIVE', 'Oiler', 'ENGINE', '2022-08-01', NOW(), NOW()),

-- Catering Department
('c01-crew-011', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', 'Filipino', 'ONBOARD', '7 years', 'ACTIVE', 'Chief Cook', 'CATERING', '2021-04-10', NOW(), NOW()),
('c01-crew-012', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', 'Filipino', 'ONBOARD', '3 years', 'ACTIVE', 'Steward', 'CATERING', '2023-02-15', NOW(), NOW());

-- Add some additional crew members that are AVAILABLE (not assigned to ships)
INSERT INTO users (id, email, password_hash, role, created_at, updated_at) VALUES
('c01-crew-013', 'peter.andersen@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', 'CREW', NOW(), NOW()),
('c01-crew-014', 'hans.schmidt@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', 'CREW', NOW(), NOW()),
('c01-crew-015', 'yuki.tanaka@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', 'CREW', NOW(), NOW()),
('c01-crew-016', 'ivan.petrov@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', 'CREW', NOW(), NOW());

INSERT INTO crew_profiles (user_id, ship_id, nationality, availability, sea_time, status, rank, department, join_date, created_at, updated_at) VALUES
('c01-crew-013', NULL, 'Norwegian', 'AVAILABLE', '15 years', 'ACTIVE', 'Chief Officer', 'DECK', '2020-05-01', NOW(), NOW()),
('c01-crew-014', NULL, 'German', 'AVAILABLE', '11 years', 'ACTIVE', 'Chief Engineer', 'ENGINE', '2021-01-15', NOW(), NOW()),
('c01-crew-015', NULL, 'Japanese', 'AVAILABLE', '8 years', 'ACTIVE', 'Second Officer', 'DECK', '2022-03-20', NOW(), NOW()),
('c01-crew-016', NULL, 'Russian', 'AVAILABLE', '9 years', 'ACTIVE', 'Second Engineer', 'ENGINE', '2021-11-10', NOW(), NOW());

-- Add some crew on STANDBY status
INSERT INTO users (id, email, password_hash, role, created_at, updated_at) VALUES
('c01-crew-017', 'carlo.rossi@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', 'CREW', NOW(), NOW()),
('c01-crew-018', 'jean.dupont@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', 'CREW', NOW(), NOW());

INSERT INTO crew_profiles (user_id, ship_id, nationality, availability, sea_time, status, rank, department, join_date, created_at, updated_at) VALUES
('c01-crew-017', NULL, 'Italian', 'STANDBY', '7 years', 'ACTIVE', 'Chief Officer', 'DECK', '2021-08-15', NOW(), NOW()),
('c01-crew-018', NULL, 'French', 'STANDBY', '5 years', 'ACTIVE', 'Motorman', 'ENGINE', '2022-10-01', NOW(), NOW());

-- Add some crew on BLOCKED status
INSERT INTO users (id, email, password_hash, role, created_at, updated_at) VALUES
('c01-crew-019', 'alex.sanchez@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', 'CREW', NOW(), NOW());

INSERT INTO crew_profiles (user_id, ship_id, nationality, availability, sea_time, status, rank, department, join_date, created_at, updated_at) VALUES
('c01-crew-019', NULL, 'Spanish', 'BLOCKED', '2 years', 'ACTIVE', 'Able Seaman', 'DECK', '2023-04-01', NOW(), NOW());

-- Update user table with personal references to crew profiles
UPDATE users SET crew_profile_id = (
    SELECT id FROM crew_profiles WHERE crew_profiles.user_id = users.id
) WHERE id IN (
    SELECT user_id FROM crew_profiles
);

-- Summary of created crew:
-- 2 Masters (Super Admins)
-- 3 Staff (Shore Office)
-- 16 Crew (Seafarers)
--   - 10 ONBOARD on NMG Vessel 01
--   - 4 AVAILABLE for assignment
--   - 2 on STANDBY
--   - 1 BLOCKED

-- Login credentials (all passwords are: password123):
-- captain.nmg@nmg-marine.com (Master)
-- admin@nmg-marine.com (Master)
-- hr.manager@nmg-marine.com (Staff)
-- john.smith@nmg-marine.com (Crew - Captain)
-- ahmed.hassan@nmg-marine.com (Crew - AB)
-- peter.andersen@nmg-marine.com (Crew - Available)
