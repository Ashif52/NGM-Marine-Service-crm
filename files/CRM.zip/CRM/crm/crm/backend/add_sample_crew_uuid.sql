-- Add sample crew members to NMG Marine CRM
-- Using proper UUIDs for PostgreSQL

-- First, let's add some MASTER users (Super Admins)
INSERT INTO public.users (id, email, password, created_at, last_login, is_active) VALUES
('550e8400-e29b-41d4-a716-446655440001', 'captain.nmg@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
('550e8400-e29b-41d4-a716-446655440002', 'admin@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true);

-- Add STAFF users (Shore Office)
INSERT INTO public.users (id, email, password, created_at, last_login, is_active) VALUES
('550e8400-e29b-41d4-a716-446655440003', 'hr.manager@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
('550e8400-e29b-41d4-a716-446655440004', 'operations@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
('550e8400-e29b-41d4-a716-446655440005', 'finance@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true);

-- Add CREW users (Seafarers)
-- Deck Department Officers
INSERT INTO public.users (id, email, password, created_at, last_login, is_active) VALUES
('550e8400-e29b-41d4-a716-446655440006', 'john.smith@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
('550e8400-e29b-41d4-a716-446655440007', 'robert.jones@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
('550e8400-e29b-41d4-a716-446655440008', 'michael.brown@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),

-- Engine Department Officers
('550e8400-e29b-41d4-a716-446655440009', 'david.wilson@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
('550e8400-e29b-41d4-a716-446655440010', 'james.taylor@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),

-- Deck Ratings
('550e8400-e29b-41d4-a716-446655440011', 'ahmed.hassan@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
('550e8400-e29b-41d4-a716-446655440012', 'mohammed.ali@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
('550e8400-e29b-41d4-a716-446655440013', 'raj.patel@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),

-- Engine Ratings
('550e8400-e29b-41d4-a716-446655440014', 'chen.wei@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
('550e8400-e29b-41d4-a716-446655440015', 'li.wang@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),

-- Catering Department
('550e8400-e29b-41d4-a716-446655440016', 'maria.garcia@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
('550e8400-e29b-41d4-a716-446655440017', 'sarah.johnson@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true);

-- Now add their profiles
INSERT INTO public.profiles (id, name, role, ship_id, created_at, nationality, availability, sea_time, status, user_id) VALUES
-- Master Profiles (Not assigned to ships - Super Admins)
('550e8400-e29b-41d4-a716-446655440101', 'Captain Anderson', 'MASTER', NULL, NOW(), 'British', 'AVAILABLE', '15 years', 'ACTIVE', '550e8400-e29b-41d4-a716-446655440001'),
('550e8400-e29b-41d4-a716-446655440102', 'Admin User', 'MASTER', NULL, NOW(), 'British', 'AVAILABLE', '20 years', 'ACTIVE', '550e8400-e29b-41d4-a716-446655440002'),

-- Staff Profiles (Shore Office)
('550e8400-e29b-41d4-a716-446655440103', 'Sarah Williams', 'STAFF', NULL, NOW(), 'British', 'AVAILABLE', '10 years', 'ACTIVE', '550e8400-e29b-41d4-a716-446655440003'),
('550e8400-e29b-41d4-a716-446655440104', 'Michael Johnson', 'STAFF', NULL, NOW(), 'British', 'AVAILABLE', '12 years', 'ACTIVE', '550e8400-e29b-41d4-a716-446655440004'),
('550e8400-e29b-41d4-a716-446655440105', 'Emma Davis', 'STAFF', NULL, NOW(), 'British', 'AVAILABLE', '8 years', 'ACTIVE', '550e8400-e29b-41d4-a716-446655440005'),

-- Deck Department - Officers
('550e8400-e29b-41d4-a716-446655440106', 'John Smith', 'CREW', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', NOW(), 'British', 'ONBOARD', '10 years', 'ACTIVE', '550e8400-e29b-41d4-a716-446655440006'),
('550e8400-e29b-41d4-a716-446655440107', 'Robert Jones', 'CREW', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', NOW(), 'American', 'ONBOARD', '8 years', 'ACTIVE', '550e8400-e29b-41d4-a716-446655440007'),
('550e8400-e29b-41d4-a716-446655440108', 'Michael Brown', 'CREW', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', NOW(), 'British', 'ONBOARD', '6 years', 'ACTIVE', '550e8400-e29b-41d4-a716-446655440008'),

-- Engine Department - Officers
('550e8400-e29b-41d4-a716-446655440109', 'David Wilson', 'CREW', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', NOW(), 'British', 'ONBOARD', '12 years', 'ACTIVE', '550e8400-e29b-41d4-a716-446655440009'),
('550e8400-e29b-41d4-a716-446655440110', 'James Taylor', 'CREW', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', NOW(), 'Scottish', 'ONBOARD', '9 years', 'ACTIVE', '550e8400-e29b-41d4-a716-446655440010'),

-- Deck Department - Ratings
('550e8400-e29b-41d4-a716-446655440111', 'Ahmed Hassan', 'CREW', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', NOW(), 'Egyptian', 'ONBOARD', '5 years', 'ACTIVE', '550e8400-e29b-41d4-a716-446655440011'),
('550e8400-e29b-41d4-a716-446655440112', 'Mohammed Ali', 'CREW', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', NOW(), 'Egyptian', 'ONBOARD', '3 years', 'ACTIVE', '550e8400-e29b-41d4-a716-446655440012'),
('550e8400-e29b-41d4-a716-446655440113', 'Raj Patel', 'CREW', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', NOW(), 'Indian', 'ONBOARD', '4 years', 'ACTIVE', '550e8400-e29b-41d4-a716-446655440013'),

-- Engine Department - Ratings
('550e8400-e29b-41d4-a716-446655440114', 'Chen Wei', 'CREW', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', NOW(), 'Chinese', 'ONBOARD', '6 years', 'ACTIVE', '550e8400-e29b-41d4-a716-446655440014'),
('550e8400-e29b-41d4-a716-446655440115', 'Li Wang', 'CREW', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', NOW(), 'Chinese', 'ONBOARD', '4 years', 'ACTIVE', '550e8400-e29b-41d4-a716-446655440015'),

-- Catering Department
('550e8400-e29b-41d4-a716-446655440116', 'Maria Garcia', 'CREW', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', NOW(), 'Filipino', 'ONBOARD', '7 years', 'ACTIVE', '550e8400-e29b-41d4-a716-446655440016'),
('550e8400-e29b-41d4-a716-446655440117', 'Sarah Johnson', 'CREW', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', NOW(), 'Filipino', 'ONBOARD', '3 years', 'ACTIVE', '550e8400-e29b-41d4-a716-446655440017');

-- Add some additional crew members that are AVAILABLE (not assigned to ships)
INSERT INTO public.users (id, email, password, created_at, last_login, is_active) VALUES
('550e8400-e29b-41d4-a716-446655440018', 'peter.andersen@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
('550e8400-e29b-41d4-a716-446655440019', 'hans.schmidt@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
('550e8400-e29b-41d4-a716-446655440020', 'yuki.tanaka@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
('550e8400-e29b-41d4-a716-446655440021', 'ivan.petrov@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true);

INSERT INTO public.profiles (id, name, role, ship_id, created_at, nationality, availability, sea_time, status, user_id) VALUES
('550e8400-e29b-41d4-a716-446655440118', 'Peter Andersen', 'CREW', NULL, NOW(), 'Norwegian', 'AVAILABLE', '15 years', 'ACTIVE', '550e8400-e29b-41d4-a716-446655440018'),
('550e8400-e29b-41d4-a716-446655440119', 'Hans Schmidt', 'CREW', NULL, NOW(), 'German', 'AVAILABLE', '11 years', 'ACTIVE', '550e8400-e29b-41d4-a716-446655440019'),
('550e8400-e29b-41d4-a716-446655440120', 'Yuki Tanaka', 'CREW', NULL, NOW(), 'Japanese', 'AVAILABLE', '8 years', 'ACTIVE', '550e8400-e29b-41d4-a716-446655440020'),
('550e8400-e29b-41d4-a716-446655440121', 'Ivan Petrov', 'CREW', NULL, NOW(), 'Russian', 'AVAILABLE', '9 years', 'ACTIVE', '550e8400-e29b-41d4-a716-446655440021');

-- Add some crew on STANDBY status
INSERT INTO public.users (id, email, password, created_at, last_login, is_active) VALUES
('550e8400-e29b-41d4-a716-446655440022', 'carlo.rossi@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
('550e8400-e29b-41d4-a716-446655440023', 'jean.dupont@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true);

INSERT INTO public.profiles (id, name, role, ship_id, created_at, nationality, availability, sea_time, status, user_id) VALUES
('550e8400-e29b-41d4-a716-446655440122', 'Carlo Rossi', 'CREW', NULL, NOW(), 'Italian', 'STANDBY', '7 years', 'ACTIVE', '550e8400-e29b-41d4-a716-446655440022'),
('550e8400-e29b-41d4-a716-446655440123', 'Jean Dupont', 'CREW', NULL, NOW(), 'French', 'STANDBY', '5 years', 'ACTIVE', '550e8400-e29b-41d4-a716-446655440023');

-- Add some crew on BLOCKED status
INSERT INTO public.users (id, email, password, created_at, last_login, is_active) VALUES
('550e8400-e29b-41d4-a716-446655440024', 'alex.sanchez@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true);

INSERT INTO public.profiles (id, name, role, ship_id, created_at, nationality, availability, sea_time, status, user_id) VALUES
('550e8400-e29b-41d4-a716-446655440124', 'Alex Sanchez', 'CREW', NULL, NOW(), 'Spanish', 'BLOCKED', '2 years', 'ACTIVE', '550e8400-e29b-41d4-a716-446655440024');

-- Now add crew profiles with additional details
INSERT INTO public.crew_profiles (user_id, rank, join_date, created_at, department, job_description, contract_duration, contract_end_date, previous_experience, emergency_contact_name, emergency_contact_number) VALUES
-- Deck Officers
('550e8400-e29b-41d4-a716-446655440106', 'Captain', '2020-01-15', NOW(), 'DECK', 'Overall command of vessel', 12, '2025-01-15', '15 years in command', 'Mary Smith', '+44 20 1234 5678'),
('550e8400-e29b-41d4-a716-446655440107', 'Chief Officer', '2021-02-20', NOW(), 'DECK', 'Second in command, cargo operations', 12, '2025-02-20', '10 years as Chief Officer', 'Jennifer Jones', '+1 555 123 4567'),
('550e8400-e29b-41d4-a716-446655440108', 'Second Officer', '2022-03-10', NOW(), 'DECK', 'Navigation officer', 12, '2025-03-10', '6 years navigation', 'Susan Brown', '+44 20 2345 6789'),

-- Engine Officers
('550e8400-e29b-41d4-a716-446655440109', 'Chief Engineer', '2019-11-01', NOW(), 'ENGINE', 'Overall engine maintenance', 12, '2025-11-01', '20 years engineering', 'Linda Wilson', '+44 20 3456 7890'),
('550e8400-e29b-41d4-a716-446655440110', 'Second Engineer', '2020-07-15', NOW(), 'ENGINE', 'Engine room operations', 12, '2025-07-15', '9 years engine room', 'Emma Taylor', '+44 20 4567 8901'),

-- Deck Ratings
('550e8400-e29b-41d4-a716-446655440111', 'Able Seaman', '2023-01-05', NOW(), 'DECK', 'Deck maintenance, mooring operations', 9, '2024-01-05', '5 years deck experience', 'Fatima Hassan', '+20 123 456 7890'),
('550e8400-e29b-41d4-a716-446655440112', 'Ordinary Seaman', '2023-06-10', NOW(), 'DECK', 'General deck duties', 9, '2024-06-10', '3 years at sea', 'Aisha Ali', '+20 234 567 8901'),
('550e8400-e29b-41d4-a716-446655440113', 'Able Seaman', '2022-11-20', NOW(), 'DECK', 'Deck maintenance, watch keeping', 9, '2024-11-20', '4 years as AB', 'Priya Patel', '+91 98765 43210'),

-- Engine Ratings
('550e8400-e29b-41d4-a716-446655440114', 'Motorman', '2021-09-15', NOW(), 'ENGINE', 'Engine room maintenance', 9, '2024-09-15', '8 years engine room', 'Wei Chen', '+86 138 0000 0000'),
('550e8400-e29b-41d4-a716-446655440115', 'Oiler', '2022-08-01', NOW(), 'ENGINE', 'Lubrication, engine monitoring', 9, '2024-08-01', '4 years as Oiler', 'Li Wang', '+86 139 0000 0000'),

-- Catering
('550e8400-e29b-41d4-a716-446655440116', 'Chief Cook', '2021-04-10', NOW(), 'CATERING', 'Meal planning, food preparation', 9, '2024-04-10', '10 years maritime cooking', 'Elena Garcia', '+63 912 345 6789'),
('550e8400-e29b-41d4-a716-446655440117', 'Steward', '2023-02-15', NOW(), 'CATERING', 'Cabin service, mess duties', 9, '2024-02-15', '3 years steward', 'Maria Johnson', '+63 923 456 7890'),

-- Available Crew
('550e8400-e29b-41d4-a716-446655440118', 'Chief Officer', '2020-05-01', NOW(), 'DECK', 'Ready for assignment', 6, '2024-05-01', '15 years as Chief Officer', 'Ingrid Andersen', '+47 123 45678'),
('550e8400-e29b-41d4-a716-446655440119', 'Chief Engineer', '2021-01-15', NOW(), 'ENGINE', 'Ready for assignment', 6, '2024-01-15', '11 years engineering', 'Helga Schmidt', '+49 30 12345678'),
('550e8400-e29b-41d4-a716-446655440120', 'Second Officer', '2022-03-20', NOW(), 'DECK', 'Ready for assignment', 6, '2024-03-20', '8 years navigation', 'Yuki Tanaka', '+81 90 1234 5678'),
('550e8400-e29b-41d4-a716-446655440121', 'Second Engineer', '2021-11-10', NOW(), 'ENGINE', 'Ready for assignment', 6, '2024-11-10', '9 years engine room', 'Ivan Petrov', '+7 495 123 4567'),

-- Standby Crew
('550e8400-e29b-41d4-a716-446655440122', 'Chief Officer', '2021-08-15', NOW(), 'DECK', 'On standby', 6, '2024-08-15', '7 years as Chief Officer', 'Giulia Rossi', '+39 06 123456'),
('550e8400-e29b-41d4-a716-446655440123', 'Motorman', '2022-10-01', NOW(), 'ENGINE', 'On standby', 6, '2024-10-01', '5 years engine room', 'Marie Dupont', '+33 1 23 45 67 89'),

-- Blocked Crew
('550e8400-e29b-41d4-a716-446655440124', 'Able Seaman', '2023-04-01', NOW(), 'DECK', 'Under investigation', 6, '2024-04-01', '2 years deck experience', 'Ana Sanchez', '+34 91 123 45 67');

-- Summary of created crew:
-- 2 Masters (Super Admins)
-- 3 Staff (Shore Office)
-- 16 Crew (Seafarers)
--   - 10 ONBOARD on NMG Vessel 01
--   - 4 AVAILABLE for assignment
--   - 2 on STANDBY
--   - 1 BLOCKED

-- Login credentials (all passwords are: password123):
-- captain.nmg@nmg-marine.com (Master)
-- admin@nmg-marine.com (Master)
-- hr.manager@nmg-marine.com (Staff)
-- john.smith@nmg-marine.com (Crew - Captain)
-- ahmed.hassan@nmg-marine.com (Crew - AB)
-- peter.andersen@nmg-marine.com (Crew - Available)
