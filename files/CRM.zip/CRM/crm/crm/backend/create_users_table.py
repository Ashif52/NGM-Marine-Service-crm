import sqlalchemy as sa
from sqlalchemy import create_engine, text

# Database connection
DATABASE_URL = (
    "postgresql+psycopg2://"
    "postgres:nmg-marine-crm@"
    "db.iogpqpqoljoqoprbsnes.supabase.co:5432/postgres"
    "?sslmode=require"
)

engine = create_engine(DATABASE_URL)

with engine.connect() as conn:
    # Create users table if it doesn't exist
    conn.execute(text("""
        CREATE TABLE IF NOT EXISTS public.users (
            id uuid NOT NULL,
            email character varying NOT NULL,
            password character varying NOT NULL,
            created_at timestamp with time zone DEFAULT now(),
            last_login timestamp with time zone,
            is_active boolean DEFAULT true,
            CONSTRAINT users_pkey PRIMARY KEY (id),
            CONSTRAINT users_email_key UNIQUE (email)
        )
    """))
    
    conn.commit()
    print("Users table created successfully (or already exists)")
