-- Add sample crew members to NMG Marine CRM
-- Using PostgreSQL's gen_random_uuid() function

-- First, let's declare variables for UUIDs
DO $$ 
DECLARE
    master1_id uuid := gen_random_uuid();
    master2_id uuid := gen_random_uuid();
    staff1_id uuid := gen_random_uuid();
    staff2_id uuid := gen_random_uuid();
    staff3_id uuid := gen_random_uuid();
    crew1_id uuid := gen_random_uuid();
    crew2_id uuid := gen_random_uuid();
    crew3_id uuid := gen_random_uuid();
    crew4_id uuid := gen_random_uuid();
    crew5_id uuid := gen_random_uuid();
    crew6_id uuid := gen_random_uuid();
BEGIN

-- First, let's add some MASTER users (Super Admins)
INSERT INTO public.users (id, email, password, created_at, last_login, is_active) VALUES
(master1_id, 'captain.nmg@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
(master2_id, 'admin@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true);

-- Add STAFF users (Shore Office)
INSERT INTO public.users (id, email, password, created_at, last_login, is_active) VALUES
(staff1_id, 'hr.manager@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
(staff2_id, 'operations@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
(staff3_id, 'finance@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true);

-- Add initial CREW users (we'll add more in batches)
INSERT INTO public.users (id, email, password, created_at, last_login, is_active) VALUES
(crew1_id, 'john.smith@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
(crew2_id, 'robert.jones@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
(crew3_id, 'michael.brown@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
(crew4_id, 'david.wilson@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
(crew5_id, 'james.taylor@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
(crew6_id, 'ahmed.hassan@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true);

-- Add their profiles
INSERT INTO public.profiles (id, name, role, ship_id, created_at, nationality, availability, sea_time, status, user_id) VALUES
-- Master Profiles
(gen_random_uuid(), 'Captain Anderson', 'MASTER', NULL, NOW(), 'British', 'AVAILABLE', '15 years', 'ACTIVE', master1_id),
(gen_random_uuid(), 'Admin User', 'MASTER', NULL, NOW(), 'British', 'AVAILABLE', '20 years', 'ACTIVE', master2_id),

-- Staff Profiles
(gen_random_uuid(), 'Sarah Williams', 'STAFF', NULL, NOW(), 'British', 'AVAILABLE', '10 years', 'ACTIVE', staff1_id),
(gen_random_uuid(), 'Michael Johnson', 'STAFF', NULL, NOW(), 'British', 'AVAILABLE', '12 years', 'ACTIVE', staff2_id),
(gen_random_uuid(), 'Emma Davis', 'STAFF', NULL, NOW(), 'British', 'AVAILABLE', '8 years', 'ACTIVE', staff3_id),

-- Initial Crew Profiles
(gen_random_uuid(), 'John Smith', 'CREW', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', NOW(), 'British', 'ONBOARD', '10 years', 'ACTIVE', crew1_id),
(gen_random_uuid(), 'Robert Jones', 'CREW', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', NOW(), 'American', 'ONBOARD', '8 years', 'ACTIVE', crew2_id),
(gen_random_uuid(), 'Michael Brown', 'CREW', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', NOW(), 'British', 'ONBOARD', '6 years', 'ACTIVE', crew3_id),
(gen_random_uuid(), 'David Wilson', 'CREW', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', NOW(), 'British', 'ONBOARD', '12 years', 'ACTIVE', crew4_id),
(gen_random_uuid(), 'James Taylor', 'CREW', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', NOW(), 'Scottish', 'ONBOARD', '9 years', 'ACTIVE', crew5_id),
(gen_random_uuid(), 'Ahmed Hassan', 'CREW', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', NOW(), 'Egyptian', 'ONBOARD', '5 years', 'ACTIVE', crew6_id);

-- Add crew profiles with additional details
INSERT INTO public.crew_profiles (id, user_id, rank, join_date, department, job_description, contract_duration, previous_experience, emergency_contact_name, emergency_contact_number) VALUES
(gen_random_uuid(), crew1_id, 'Captain', '2020-01-15', 'DECK', 'Overall command of vessel', 12, '15 years in command', 'Mary Smith', '+44 20 1234 5678'),
(gen_random_uuid(), crew2_id, 'Chief Officer', '2021-02-20', 'DECK', 'Second in command', 12, '10 years as Chief Officer', 'Jennifer Jones', '+1 555 123 4567'),
(gen_random_uuid(), crew3_id, 'Second Officer', '2022-03-10', 'DECK', 'Navigation officer', 12, '6 years navigation', 'Susan Brown', '+44 20 2345 6789'),
(gen_random_uuid(), crew4_id, 'Chief Engineer', '2019-11-01', 'ENGINE', 'Engine maintenance', 12, '20 years engineering', 'Linda Wilson', '+44 20 3456 7890'),
(gen_random_uuid(), crew5_id, 'Second Engineer', '2020-07-15', 'ENGINE', 'Engine operations', 12, '9 years engine room', 'Emma Taylor', '+44 20 4567 8901'),
(gen_random_uuid(), crew6_id, 'Able Seaman', '2023-01-05', 'DECK', 'Deck maintenance', 9, '5 years deck experience', 'Fatima Hassan', '+20 123 456 7890');

END $$;

-- You can add more crew members in similar batches if needed

-- Login credentials (all passwords are: password123):
-- captain.nmg@nmg-marine.com (Master)
-- admin@nmg-marine.com (Master)
-- hr.manager@nmg-marine.com (Staff)
-- john.smith@nmg-marine.com (Crew - Captain)
-- ahmed.hassan@nmg-marine.com (Crew - AB)
