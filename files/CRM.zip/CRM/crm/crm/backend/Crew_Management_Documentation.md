# Crew Management System Documentation

## Overview

The Crew Management System is a comprehensive solution for managing ship crew members, their profiles, job responsibilities, and certifications. This module implements the requirements outlined in the Fleet and Personnel Management documentation (FPM 01 - Vessel Organisation & Crew Job Responsibilities).

## Table of Contents

1. [Database Schema](#1-database-schema)
2. [API Endpoints](#2-api-endpoints)
3. [Workflows](#3-workflows)
4. [Integration Points](#4-integration-points)
5. [Implementation Notes](#5-implementation-notes)

---

## 1. Database Schema

### 1.1 Core Tables

#### Profile Table (`profiles`)
- Contains basic user information
- Fields:
  - `id` (UUID, Primary Key)
  - `user_id` (UUID, Foreign Key to `users.id`)
  - `name` (String)
  - `role` (String) - Value "CREW" for crew members
  - `ship_id` (UUID, Foreign Key to `ships.id`)
  - `nationality` (String)
  - `availability` (String) - Values: AVAILABLE, ONBOARD, ON_LEAVE
  - `sea_time` (String)
  - `status` (String) - Values: ACTIVE, INACTIVE

#### Crew Profile Table (`crew_profiles`)
- Contains crew-specific information
- Fields:
  - `id` (UUID, Primary Key)
  - `user_id` (UUID, Foreign Key to `profiles.id`)
  - `rank` (String)
  - `department` (String) - Values: DECK, ENGINE, CATERING
  - `job_description` (String)
  - `join_date` (Date)
  - `contract_duration` (Integer) - in months
  - `contract_end_date` (Date)
  - `previous_experience` (String)
  - `emergency_contact_name` (String)
  - `emergency_contact_number` (String)
  - `created_at` (Timestamp)

#### Crew Certificates Table (`crew_certificates`)
- Contains certificates and documents for crew members
- Fields:
  - `id` (UUID, Primary Key)
  - `crew_id` (UUID, Foreign Key to `crew_profiles.id`)
  - `name` (String)
  - `certificate_number` (String)
  - `issue_date` (Date)
  - `expiry_date` (Date)
  - `issuing_authority` (String)
  - `document_url` (String)
  - `created_at` (Timestamp)

### 1.2 Relationships

- A User has one Profile
- A Profile with role "CREW" has one CrewProfile
- A CrewProfile can have many Certificates

### 1.3 Migration Scripts

The database schema updates are provided in:
- `migrations/crew_tables_update.sql` - Adds new fields to crew_profiles and creates the certificates table

---

## 2. API Endpoints

### 2.1 Crew Management Endpoints

#### Create Crew Member
```
POST /api/crew
```
- Creates a new crew member with user, profile, and crew profile
- Requires MASTER or STAFF role
- Request body includes:
  - User data (name, email, password)
  - Profile data (nationality, sea_time)
  - Crew profile data (rank, department, job_description, etc.)
  - Optional certificates array

#### Get All Crew Members
```
GET /api/crew
```
- Returns list of crew members
- Optional filters: ship_id, status, availability
- Requires MASTER or STAFF role

#### Get Specific Crew Member
```
GET /api/crew/{crew_id}
```
- Returns details for a specific crew member
- CREW role can only view their own profile
- Returns complete profile with certificates

#### Update Crew Profile
```
PUT /api/crew/{crew_id}
```
- Updates crew-specific information
- Requires MASTER or STAFF role

#### Assign Crew to Ship
```
POST /api/crew/{crew_id}/assign
```
- Assigns a crew member to a ship
- Sets availability to "ONBOARD"
- Requires MASTER or STAFF role

#### Unassign Crew from Ship
```
POST /api/crew/{crew_id}/unassign
```
- Removes a crew member from a ship
- Sets availability to "AVAILABLE"
- Requires MASTER or STAFF role

### 2.2 Certificate Management Endpoints

#### Add Certificate
```
POST /api/certificates/{crew_id}
```
- Adds a new certificate to a crew member
- Requires MASTER or STAFF role

#### Get Crew Certificates
```
GET /api/certificates/{crew_id}
```
- Returns all certificates for a crew member
- CREW role can only view their own certificates

#### Update Certificate
```
PUT /api/certificates/{certificate_id}
```
- Updates a specific certificate
- Requires MASTER or STAFF role

#### Delete Certificate
```
DELETE /api/certificates/{certificate_id}
```
- Deletes a certificate
- Requires MASTER or STAFF role

#### Get Expiring Certificates
```
GET /api/certificates/expiring/{days}
```
- Returns certificates expiring within the specified number of days
- Requires MASTER or STAFF role

---

## 3. Workflows

### 3.1 Crew Onboarding

1. Create crew member with basic information (POST `/api/crew`)
2. Add required certificates (POST `/api/certificates/{crew_id}`)
3. Assign to a ship if needed (POST `/api/crew/{crew_id}/assign`)

### 3.2 Certificate Management

1. Monitor expiring certificates (GET `/api/certificates/expiring/{days}`)
2. Add new certificates when acquired (POST `/api/certificates/{crew_id}`)
3. Update certificates when renewed (PUT `/api/certificates/{certificate_id}`)

### 3.3 Crew Assignment

1. Assign crew to ship when boarding (POST `/api/crew/{crew_id}/assign`)
2. Unassign crew when disembarking (POST `/api/crew/{crew_id}/unassign`)

---

## 4. Integration Points

### 4.1 Ship Management

- Crew members can be assigned to ships
- Ships maintain a list of current crew

### 4.2 Work Logs

- Crew members can create work logs
- Work logs are linked to crew members

### 4.3 Document Management

- Certificates can include document URLs
- Integration with document upload system for certificate scans

---

## 5. Implementation Notes

### 5.1 Role-Based Access Control

- MASTER and STAFF roles have full access to crew management
- CREW role can only view their own profile and certificates

### 5.2 Compliance with FPM Requirements

The implementation supports all crew types defined in FPM 01:
- MASTER
- CHIEF OFFICER
- SECOND OFFICER
- THIRD OFFICER
- DECK RATINGS
- CHIEF ENGINEER
- SECOND ENGINEER
- THIRD/FOURTH ENGINEER
- ELECTRICAL OFFICER
- ENGINE RATING
- COOK
- GENERAL STEWARD

### 5.3 Certificate Types

The system supports various certificate types including:
- STCW Basic Safety Training
- Certificate of Competency
- Medical Certificate
- GMDSS Operator Certificate
- Ship Security Officer
- Engine Room Resource Management
- Ship's Cook Certificate

### 5.4 Future Enhancements

- Crew schedule/roster management
- Crew performance evaluations
- Automated certificate expiry notifications
- Integration with crew payroll system
