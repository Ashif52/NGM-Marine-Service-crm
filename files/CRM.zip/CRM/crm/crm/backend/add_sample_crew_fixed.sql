-- Add sample crew members to NMG Marine CRM
-- Updated to match the actual database schema

-- First, let's add some MASTER users (Super Admins)
INSERT INTO public.users (id, email, password, created_at, last_login, is_active) VALUES
('c01-master-001', 'captain.nmg@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
('c01-master-002', 'admin@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true);

-- Add STAFF users (Shore Office)
INSERT INTO public.users (id, email, password, created_at, last_login, is_active) VALUES
('c01-staff-001', 'hr.manager@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
('c01-staff-002', 'operations@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
('c01-staff-003', 'finance@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true);

-- Add CREW users (Seafarers)
INSERT INTO public.users (id, email, password, created_at, last_login, is_active) VALUES
-- Deck Department Officers
('c01-crew-001', 'john.smith@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
('c01-crew-002', 'robert.jones@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
('c01-crew-003', 'michael.brown@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),

-- Engine Department Officers
('c01-crew-004', 'david.wilson@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
('c01-crew-005', 'james.taylor@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),

-- Deck Ratings
('c01-crew-006', 'ahmed.hassan@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
('c01-crew-007', 'mohammed.ali@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
('c01-crew-008', 'raj.patel@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),

-- Engine Ratings
('c01-crew-009', 'chen.wei@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
('c01-crew-010', 'li.wang@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),

-- Catering Department
('c01-crew-011', 'maria.garcia@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
('c01-crew-012', 'sarah.johnson@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true);

-- Now add their profiles
INSERT INTO public.profiles (id, name, role, ship_id, created_at, nationality, availability, sea_time, status, user_id) VALUES
-- Master Profiles (Not assigned to ships - Super Admins)
('c01-master-001', 'Captain Anderson', 'MASTER', NULL, NOW(), 'British', 'AVAILABLE', '15 years', 'ACTIVE', 'c01-master-001'),
('c01-master-002', 'Admin User', 'MASTER', NULL, NOW(), 'British', 'AVAILABLE', '20 years', 'ACTIVE', 'c01-master-002'),

-- Staff Profiles (Shore Office)
('c01-staff-001', 'Sarah Williams', 'STAFF', NULL, NOW(), 'British', 'AVAILABLE', '10 years', 'ACTIVE', 'c01-staff-001'),
('c01-staff-002', 'Michael Johnson', 'STAFF', NULL, NOW(), 'British', 'AVAILABLE', '12 years', 'ACTIVE', 'c01-staff-002'),
('c01-staff-003', 'Emma Davis', 'STAFF', NULL, NOW(), 'British', 'AVAILABLE', '8 years', 'ACTIVE', 'c01-staff-003'),

-- Deck Department - Officers
('c01-crew-001', 'John Smith', 'CREW', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', NOW(), 'British', 'ONBOARD', '10 years', 'ACTIVE', 'c01-crew-001'),
('c01-crew-002', 'Robert Jones', 'CREW', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', NOW(), 'American', 'ONBOARD', '8 years', 'ACTIVE', 'c01-crew-002'),
('c01-crew-003', 'Michael Brown', 'CREW', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', NOW(), 'British', 'ONBOARD', '6 years', 'ACTIVE', 'c01-crew-003'),

-- Engine Department - Officers
('c01-crew-004', 'David Wilson', 'CREW', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', NOW(), 'British', 'ONBOARD', '12 years', 'ACTIVE', 'c01-crew-004'),
('c01-crew-005', 'James Taylor', 'CREW', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', NOW(), 'Scottish', 'ONBOARD', '9 years', 'ACTIVE', 'c01-crew-005'),

-- Deck Department - Ratings
('c01-crew-006', 'Ahmed Hassan', 'CREW', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', NOW(), 'Egyptian', 'ONBOARD', '5 years', 'ACTIVE', 'c01-crew-006'),
('c01-crew-007', 'Mohammed Ali', 'CREW', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', NOW(), 'Egyptian', 'ONBOARD', '3 years', 'ACTIVE', 'c01-crew-007'),
('c01-crew-008', 'Raj Patel', 'CREW', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', NOW(), 'Indian', 'ONBOARD', '4 years', 'ACTIVE', 'c01-crew-008'),

-- Engine Department - Ratings
('c01-crew-009', 'Chen Wei', 'CREW', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', NOW(), 'Chinese', 'ONBOARD', '6 years', 'ACTIVE', 'c01-crew-009'),
('c01-crew-010', 'Li Wang', 'CREW', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', NOW(), 'Chinese', 'ONBOARD', '4 years', 'ACTIVE', 'c01-crew-010'),

-- Catering Department
('c01-crew-011', 'Maria Garcia', 'CREW', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', NOW(), 'Filipino', 'ONBOARD', '7 years', 'ACTIVE', 'c01-crew-011'),
('c01-crew-012', 'Sarah Johnson', 'CREW', '41f74c64-e6cf-488b-99e5-1bc3ebce9a05', NOW(), 'Filipino', 'ONBOARD', '3 years', 'ACTIVE', 'c01-crew-012');

-- Add some additional crew members that are AVAILABLE (not assigned to ships)
INSERT INTO public.users (id, email, password, created_at, last_login, is_active) VALUES
('c01-crew-013', 'peter.andersen@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
('c01-crew-014', 'hans.schmidt@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
('c01-crew-015', 'yuki.tanaka@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
('c01-crew-016', 'ivan.petrov@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true);

INSERT INTO public.profiles (id, name, role, ship_id, created_at, nationality, availability, sea_time, status, user_id) VALUES
('c01-crew-013', 'Peter Andersen', 'CREW', NULL, NOW(), 'Norwegian', 'AVAILABLE', '15 years', 'ACTIVE', 'c01-crew-013'),
('c01-crew-014', 'Hans Schmidt', 'CREW', NULL, NOW(), 'German', 'AVAILABLE', '11 years', 'ACTIVE', 'c01-crew-014'),
('c01-crew-015', 'Yuki Tanaka', 'CREW', NULL, NOW(), 'Japanese', 'AVAILABLE', '8 years', 'ACTIVE', 'c01-crew-015'),
('c01-crew-016', 'Ivan Petrov', 'CREW', NULL, NOW(), 'Russian', 'AVAILABLE', '9 years', 'ACTIVE', 'c01-crew-016');

-- Add some crew on STANDBY status
INSERT INTO public.users (id, email, password, created_at, last_login, is_active) VALUES
('c01-crew-017', 'carlo.rossi@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
('c01-crew-018', 'jean.dupont@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true);

INSERT INTO public.profiles (id, name, role, ship_id, created_at, nationality, availability, sea_time, status, user_id) VALUES
('c01-crew-017', 'Carlo Rossi', 'CREW', NULL, NOW(), 'Italian', 'STANDBY', '7 years', 'ACTIVE', 'c01-crew-017'),
('c01-crew-018', 'Jean Dupont', 'CREW', NULL, NOW(), 'French', 'STANDBY', '5 years', 'ACTIVE', 'c01-crew-018');

-- Add some crew on BLOCKED status
INSERT INTO public.users (id, email, password, created_at, last_login, is_active) VALUES
('c01-crew-019', 'alex.sanchez@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true);

INSERT INTO public.profiles (id, name, role, ship_id, created_at, nationality, availability, sea_time, status, user_id) VALUES
('c01-crew-019', 'Alex Sanchez', 'CREW', NULL, NOW(), 'Spanish', 'BLOCKED', '2 years', 'ACTIVE', 'c01-crew-019');

-- Now add crew profiles with additional details
INSERT INTO public.crew_profiles (user_id, rank, join_date, created_at, department, job_description, contract_duration, contract_end_date, previous_experience, emergency_contact_name, emergency_contact_number) VALUES
-- Deck Officers
('c01-crew-001', 'Captain', '2020-01-15', NOW(), 'DECK', 'Overall command of vessel', 12, '2025-01-15', '15 years in command', 'Mary Smith', '+44 20 1234 5678'),
('c01-crew-002', 'Chief Officer', '2021-02-20', NOW(), 'DECK', 'Second in command, cargo operations', 12, '2025-02-20', '10 years as Chief Officer', 'Jennifer Jones', '+1 555 123 4567'),
('c01-crew-003', 'Second Officer', '2022-03-10', NOW(), 'DECK', 'Navigation officer', 12, '2025-03-10', '6 years navigation', 'Susan Brown', '+44 20 2345 6789'),

-- Engine Officers
('c01-crew-004', 'Chief Engineer', '2019-11-01', NOW(), 'ENGINE', 'Overall engine maintenance', 12, '2025-11-01', '20 years engineering', 'Linda Wilson', '+44 20 3456 7890'),
('c01-crew-005', 'Second Engineer', '2020-07-15', NOW(), 'ENGINE', 'Engine room operations', 12, '2025-07-15', '9 years engine room', 'Emma Taylor', '+44 20 4567 8901'),

-- Deck Ratings
('c01-crew-006', 'Able Seaman', '2023-01-05', NOW(), 'DECK', 'Deck maintenance, mooring operations', 9, '2024-01-05', '5 years deck experience', 'Fatima Hassan', '+20 123 456 7890'),
('c01-crew-007', 'Ordinary Seaman', '2023-06-10', NOW(), 'DECK', 'General deck duties', 9, '2024-06-10', '3 years at sea', 'Aisha Ali', '+20 234 567 8901'),
('c01-crew-008', 'Able Seaman', '2022-11-20', NOW(), 'DECK', 'Deck maintenance, watch keeping', 9, '2024-11-20', '4 years as AB', 'Priya Patel', '+91 98765 43210'),

-- Engine Ratings
('c01-crew-009', 'Motorman', '2021-09-15', NOW(), 'ENGINE', 'Engine room maintenance', 9, '2024-09-15', '8 years engine room', 'Wei Chen', '+86 138 0000 0000'),
('c01-crew-010', 'Oiler', '2022-08-01', NOW(), 'ENGINE', 'Lubrication, engine monitoring', 9, '2024-08-01', '4 years as Oiler', 'Li Wang', '+86 139 0000 0000'),

-- Catering
('c01-crew-011', 'Chief Cook', '2021-04-10', NOW(), 'CATERING', 'Meal planning, food preparation', 9, '2024-04-10', '10 years maritime cooking', 'Elena Garcia', '+63 912 345 6789'),
('c01-crew-012', 'Steward', '2023-02-15', NOW(), 'CATERING', 'Cabin service, mess duties', 9, '2024-02-15', '3 years steward', 'Maria Johnson', '+63 923 456 7890'),

-- Available Crew
('c01-crew-013', 'Chief Officer', '2020-05-01', NOW(), 'DECK', 'Ready for assignment', 6, '2024-05-01', '15 years as Chief Officer', 'Ingrid Andersen', '+47 123 45678'),
('c01-crew-014', 'Chief Engineer', '2021-01-15', NOW(), 'ENGINE', 'Ready for assignment', 6, '2024-01-15', '11 years engineering', 'Helga Schmidt', '+49 30 12345678'),
('c01-crew-015', 'Second Officer', '2022-03-20', NOW(), 'DECK', 'Ready for assignment', 6, '2024-03-20', '8 years navigation', 'Yuki Tanaka', '+81 90 1234 5678'),
('c01-crew-016', 'Second Engineer', '2021-11-10', NOW(), 'ENGINE', 'Ready for assignment', 6, '2024-11-10', '9 years engine room', 'Ivan Petrov', '+7 495 123 4567'),

-- Standby Crew
('c01-crew-017', 'Chief Officer', '2021-08-15', NOW(), 'DECK', 'On standby', 6, '2024-08-15', '7 years as Chief Officer', 'Giulia Rossi', '+39 06 123456'),
('c01-crew-018', 'Motorman', '2022-10-01', NOW(), 'ENGINE', 'On standby', 6, '2024-10-01', '5 years engine room', 'Marie Dupont', '+33 1 23 45 67 89'),

-- Blocked Crew
('c01-crew-019', 'Able Seaman', '2023-04-01', NOW(), 'DECK', 'Under investigation', 6, '2024-04-01', '2 years deck experience', 'Ana Sanchez', '+34 91 123 45 67');

-- Summary of created crew:
-- 2 Masters (Super Admins)
-- 3 Staff (Shore Office)
-- 16 Crew (Seafarers)
--   - 10 ONBOARD on NMG Vessel 01
--   - 4 AVAILABLE for assignment
--   - 2 on STANDBY
--   - 1 BLOCKED

-- Login credentials (all passwords are: password123):
-- captain.nmg@nmg-marine.com (Master)
-- admin@nmg-marine.com (Master)
-- hr.manager@nmg-marine.com (Staff)
-- john.smith@nmg-marine.com (Crew - Captain)
-- ahmed.hassan@nmg-marine.com (Crew - AB)
-- peter.andersen@nmg-marine.com (Crew - Available)
