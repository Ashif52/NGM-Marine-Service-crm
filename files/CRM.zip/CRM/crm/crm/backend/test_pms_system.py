import requests
import json
import uuid
from datetime import date, datetime, timedelta

# Base URL for API
BASE_URL = "http://localhost:8000/api"

# Set your access token here after logging in
ACCESS_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIwMTJkNTY0Ni00YTdmLTQ1OTItODI2Yi05OWNmZDA3YWRjYzUiLCJleHAiOjE3NjcwMDY4MTQsInJvbGUiOiJNQVNURVIiLCJzaGlwX2lkIjpudWxsLCJuYW1lIjoiYWRtaW4ifQ.kq6zGY7edruXlpGorUHBYHY0qwL-PkoQ_f0ar1M_gt0"

# Headers for authenticated requests
HEADERS = {
    "Authorization": f"Bearer {ACCESS_TOKEN}",
    "Content-Type": "application/json"
}

# Testing variables to store created IDs
created_ids = {
    "ship_id": None,
    "equipment_id": None,
    "spare_part_id": None,
    "transaction_id": None,
    "running_hours_id": None,
    "report_type_id": None,
    "maintenance_report_id": None
}

# Helper function to make API requests
def api_request(method, endpoint, data=None):
    url = f"{BASE_URL}{endpoint}"
    response = None
    
    if method == "GET":
        response = requests.get(url, headers=HEADERS)
    elif method == "POST":
        response = requests.post(url, headers=HEADERS, json=data)
    elif method == "PUT":
        response = requests.put(url, headers=HEADERS, json=data)
    elif method == "DELETE":
        response = requests.delete(url, headers=HEADERS)
    
    print(f"\n[{method}] {endpoint}")
    print(f"Status: {response.status_code}")
    
    if response.text:
        try:
            response_data = response.json()
            print(json.dumps(response_data, indent=2))
            return response_data
        except:
            print(response.text)
            return response.text
    
    return None

# 1. Get an existing ship ID for testing
def get_ship_id():
    print("\n----- Getting a ship for testing -----")
    response = api_request("GET", "/ships")
    if response and len(response) > 0:
        created_ids["ship_id"] = response[0]["id"]
        return response[0]["id"]
    else:
        # Create a new ship if none exists
        ship_data = {
            "ship_name": "Test Ship",
            "imo_number": "IMO12345678",
            "ship_type": "Cargo"
        }
        response = api_request("POST", "/ships", ship_data)
        if response:
            created_ids["ship_id"] = response["id"]
            return response["id"]
    return None

# 2. Create and test equipment endpoints
def test_equipment():
    print("\n===== EQUIPMENT TESTING =====")
    
    # Create equipment
    print("\n----- Create Equipment -----")
    equipment_data = {
        "ship_id": created_ids["ship_id"],
        "equipment_name": "Main Engine",
        "category": "ENGINE",
        "manufacturer": "Caterpillar",
        "model": "CAT-3516",
        "serial_number": "SN12345678",
        "installation_date": str(date.today() - timedelta(days=365)),
        "maintenance_interval_hours": 250,
        "maintenance_interval_days": 30
    }
    
    response = api_request("POST", "/equipment", equipment_data)
    if response:
        created_ids["equipment_id"] = response["id"]
    
    # Get equipment by ID
    print("\n----- Get Equipment by ID -----")
    api_request("GET", f"/equipment/{created_ids['equipment_id']}")
    
    # Update equipment
    print("\n----- Update Equipment -----")
    update_data = {
        "total_running_hours": 100
    }
    api_request("PUT", f"/equipment/{created_ids['equipment_id']}", update_data)
    
    return created_ids["equipment_id"]

# 3. Test Spare Parts Management
def test_spare_parts():
    print("\n===== SPARE PARTS TESTING =====")
    
    # Create spare part
    print("\n----- Create Spare Part -----")
    spare_part_data = {
        "ship_id": created_ids["ship_id"],
        "equipment_id": created_ids["equipment_id"],
        "part_number": "P-12345",
        "part_name": "Fuel Filter",
        "manufacturer": "Caterpillar",
        "quantity": 10,
        "min_quantity": 2,
        "unit": "pcs",
        "location_on_ship": "Engine Room Store"
    }
    
    response = api_request("POST", "/spare-parts", spare_part_data)
    if response:
        created_ids["spare_part_id"] = response["id"]
    
    # List spare parts
    print("\n----- List All Spare Parts -----")
    api_request("GET", "/spare-parts")
    
    # Filter spare parts by ship
    print("\n----- Filter Spare Parts by Ship -----")
    api_request("GET", f"/spare-parts?ship_id={created_ids['ship_id']}")
    
    # Filter spare parts by equipment
    print("\n----- Filter Spare Parts by Equipment -----")
    api_request("GET", f"/spare-parts?equipment_id={created_ids['equipment_id']}")
    
    # Filter low stock spare parts
    print("\n----- Filter Low Stock Spare Parts -----")
    api_request("GET", "/spare-parts?low_stock=true")
    
    # Get spare part by ID
    print("\n----- Get Spare Part by ID -----")
    api_request("GET", f"/spare-parts/{created_ids['spare_part_id']}")
    
    # Update spare part
    print("\n----- Update Spare Part -----")
    update_data = {
        "quantity": 8,
        "min_quantity": 3
    }
    api_request("PUT", f"/spare-parts/{created_ids['spare_part_id']}", update_data)
    
    # Record spare part transaction (usage)
    print("\n----- Record Spare Part Usage -----")
    transaction_data = {
        "spare_part_id": created_ids["spare_part_id"],
        "transaction_type": "USAGE",
        "quantity": 2,
        "reference_number": "WO-12345",
        "remarks": "Used for engine maintenance"
    }
    
    response = api_request("POST", "/spare-parts/transactions", transaction_data)
    if response:
        created_ids["transaction_id"] = response["id"]
    
    # Record spare part transaction (receipt)
    print("\n----- Record Spare Part Receipt -----")
    receipt_data = {
        "spare_part_id": created_ids["spare_part_id"],
        "transaction_type": "RECEIPT",
        "quantity": 5,
        "reference_number": "PO-67890",
        "remarks": "Restocking"
    }
    api_request("POST", "/spare-parts/transactions", receipt_data)
    
    # Get spare part transactions
    print("\n----- Get Spare Part Transactions -----")
    api_request("GET", f"/spare-parts/transactions/{created_ids['spare_part_id']}")

# 4. Test Equipment Running Hours
def test_running_hours():
    print("\n===== EQUIPMENT RUNNING HOURS TESTING =====")
    
    # Record running hours
    print("\n----- Record Running Hours -----")
    running_hours_data = {
        "equipment_id": created_ids["equipment_id"],
        "date": str(date.today()),
        "running_hours": 8.5,
        "total_running_hours": 108.5
    }
    
    response = api_request("POST", "/equipment-hours", running_hours_data)
    if response:
        created_ids["running_hours_id"] = response["id"]
    
    # List running hours
    print("\n----- List All Running Hours -----")
    api_request("GET", "/equipment-hours")
    
    # Filter running hours by equipment
    print("\n----- Filter Running Hours by Equipment -----")
    api_request("GET", f"/equipment-hours?equipment_id={created_ids['equipment_id']}")
    
    # Get running hours by ID
    print("\n----- Get Running Hours by ID -----")
    api_request("GET", f"/equipment-hours/{created_ids['running_hours_id']}")
    
    # Update running hours
    print("\n----- Update Running Hours -----")
    update_data = {
        "running_hours": 9.0,
        "total_running_hours": 109.0
    }
    api_request("PUT", f"/equipment-hours/{created_ids['running_hours_id']}", update_data)
    
    # Get running hours summary
    print("\n----- Get Running Hours Summary -----")
    api_request("GET", f"/equipment-hours/summary/{created_ids['equipment_id']}?period=month")

# 5. Test Maintenance Reports
def test_maintenance_reports():
    print("\n===== MAINTENANCE REPORTS TESTING =====")
    
    # Create report type if it doesn't exist
    print("\n----- Create Report Type -----")
    report_type_data = {
        "code": "ME_DECARB",
        "name": "Main Engine De-carbonization Report",
        "description": "Main engine de-carbonization inspection and work"
    }
    
    # Get report types
    print("\n----- Get Report Types -----")
    types_response = api_request("GET", "/maintenance-reports/types")
    
    if types_response and len(types_response) > 0:
        created_ids["report_type_id"] = types_response[0]["id"]
    else:
        # Create report type
        type_response = api_request("POST", "/maintenance-report-types", report_type_data)
        if type_response:
            created_ids["report_type_id"] = type_response["id"]
    
    # Create maintenance report
    print("\n----- Create Maintenance Report -----")
    report_data = {
        "report_type_id": created_ids["report_type_id"],
        "ship_id": created_ids["ship_id"],
        "equipment_id": created_ids["equipment_id"],
        "report_date": str(date.today()),
        "report_data": {
            "cylinder_1": {
                "compression_pressure": 150,
                "condition": "Good",
                "remarks": "Normal wear"
            },
            "cylinder_2": {
                "compression_pressure": 148,
                "condition": "Good",
                "remarks": "Normal wear"
            }
        },
        "remarks": "Regular maintenance performed",
        "status": "DRAFT"
    }
    
    response = api_request("POST", "/maintenance-reports", report_data)
    if response:
        created_ids["maintenance_report_id"] = response["id"]
    
    # List maintenance reports
    print("\n----- List All Maintenance Reports -----")
    api_request("GET", "/maintenance-reports")
    
    # Filter maintenance reports
    print("\n----- Filter Maintenance Reports by Ship -----")
    api_request("GET", f"/maintenance-reports?ship_id={created_ids['ship_id']}")
    
    # Get maintenance report by ID
    print("\n----- Get Maintenance Report by ID -----")
    api_request("GET", f"/maintenance-reports/{created_ids['maintenance_report_id']}")
    
    # Update maintenance report
    print("\n----- Update Maintenance Report -----")
    update_data = {
        "report_data": {
            "cylinder_1": {
                "compression_pressure": 152,
                "condition": "Good",
                "remarks": "Normal wear"
            },
            "cylinder_2": {
                "compression_pressure": 149,
                "condition": "Good",
                "remarks": "Normal wear"
            }
        },
        "status": "SUBMITTED"
    }
    api_request("PUT", f"/maintenance-reports/{created_ids['maintenance_report_id']}", update_data)
    
    # Approve maintenance report
    print("\n----- Approve Maintenance Report -----")
    approve_data = {
        "status": "APPROVED"
    }
    api_request("PUT", f"/maintenance-reports/{created_ids['maintenance_report_id']}", approve_data)

# Main test execution
def run_all_tests():
    print("\n***** STARTING PMS SYSTEM TESTS *****\n")
    
    ship_id = get_ship_id()
    if not ship_id:
        print("Failed to get or create a ship. Tests cannot proceed.")
        return
    
    test_equipment()
    test_spare_parts()
    test_running_hours()
    test_maintenance_reports()
    
    print("\n***** ALL TESTS COMPLETED *****")
    print("\nCreated Resources:", json.dumps(created_ids, indent=2))

# Run all tests
if __name__ == "__main__":
    run_all_tests()
