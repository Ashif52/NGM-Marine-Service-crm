import psycopg2
from psycopg2.extras import RealDictCursor
import json
from datetime import datetime, date

def get_db_connection():
    """Get a PostgreSQL connection to Supabase database"""
    try:
        conn = psycopg2.connect(
            host="db.iogpqpqoljoqoprbsnes.supabase.co",
            port=5432,
            database="postgres",
            user="postgres",
            password="nmg-marine-crm",
            sslmode="require",
            cursor_factory=RealDictCursor
        )
        return conn
    except Exception as e:
        print(f"❌ Error connecting to PostgreSQL: {e}")
        raise RuntimeError(f"Failed to connect to PostgreSQL: {e}")

def json_serializer(obj):
    """JSON serializer for objects not serializable by default json code"""
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    raise TypeError(f"Type {type(obj)} not serializable")

def test_connection():
    """Test the database connection"""
    try:
        conn = get_db_connection()
        print("✅ Connected to PostgreSQL successfully!")
        conn.close()
        return True
    except Exception as e:
        print(f"❌ Connection failed: {e}")
        return False

def list_tables():
    """List all tables in the public schema"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        query = """
        SELECT table_name
        FROM information_schema.tables
        WHERE table_schema = 'public'
        ORDER BY table_name;
        """
        
        cursor.execute(query)
        tables = [table["table_name"] for table in cursor.fetchall()]
        
        cursor.close()
        conn.close()
        
        print("📋 Tables in public schema:")
        for table in tables:
            print(f"  - {table}")
        
        return tables
    except Exception as e:
        print(f"❌ Error listing tables: {e}")
        return []

def describe_table(table_name):
    """Describe a table's structure"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        query = """
        SELECT column_name, data_type, is_nullable
        FROM information_schema.columns
        WHERE table_schema = 'public' AND table_name = %s
        ORDER BY ordinal_position;
        """
        
        cursor.execute(query, (table_name,))
        columns = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        if not columns:
            print(f"❌ Table '{table_name}' not found")
            return []
        
        print(f"📋 Structure of table '{table_name}':")
        for col in columns:
            nullable = "NULL" if col["is_nullable"] == "YES" else "NOT NULL"
            print(f"  - {col['column_name']}: {col['data_type']} {nullable}")
        
        return columns
    except Exception as e:
        print(f"❌ Error describing table: {e}")
        return []

def query_table_data(table_name, limit=5):
    """Query sample data from a table"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        query = f"SELECT * FROM {table_name} LIMIT %s"
        
        cursor.execute(query, (limit,))
        rows = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        if not rows:
            print(f"ℹ️ No data found in table '{table_name}'")
            return []
        
        print(f"📊 Sample data from '{table_name}' (up to {limit} rows):")
        for i, row in enumerate(rows):
            print(f"\n[Row {i+1}]")
            print(json.dumps(row, indent=2, default=json_serializer))
        
        return rows
    except Exception as e:
        print(f"❌ Error querying table: {e}")
        return []

def insert_test_ship():
    """Insert a test ship record"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if test ship already exists
        cursor.execute("SELECT COUNT(*) FROM ships WHERE ship_name = 'Test Ship'")
        count = cursor.fetchone()["count"]
        
        if count > 0:
            print("ℹ️ Test ship already exists, skipping insertion")
            conn.close()
            return False
            
        # Insert a new test ship
        ship_data = {
            "id": "test-ship-id-12345",
            "ship_name": "Test Ship",
            "imo_number": "TEST12345678",
            "ship_type": "Test Vessel",
            "flag": "Test Flag",
            "crew_capacity": 10,
            "status": "ACTIVE",
            "created_at": datetime.now(),
            "updated_at": datetime.now()
        }
        
        columns = ", ".join(ship_data.keys())
        placeholders = ", ".join("%s" for _ in ship_data)
        query = f"INSERT INTO ships ({columns}) VALUES ({placeholders}) RETURNING id"
        
        cursor.execute(query, list(ship_data.values()))
        conn.commit()
        
        ship_id = cursor.fetchone()["id"]
        
        cursor.close()
        conn.close()
        
        print(f"✅ Test ship inserted with ID: {ship_id}")
        return True
    except Exception as e:
        print(f"❌ Error inserting test ship: {e}")
        return False

if __name__ == "__main__":
    print("🔍 Testing PostgreSQL connection to Supabase...")
    if test_connection():
        print("\n📊 Database exploration:")
        tables = list_tables()
        
        if tables:
            # Describe a few important tables
            important_tables = ["profiles", "ships", "crew_profiles"]
            for table in important_tables:
                if table in tables:
                    print("\n" + "="*50)
                    describe_table(table)
                    query_table_data(table, 2)
        
        # Try inserting a test ship
        print("\n" + "="*50)
        print("🚢 Testing data insertion (ships table):")
        insert_test_ship()
    
    print("\n✅ Database tests completed.")
