-- Simple script to add crew members - run this step by step

-- STEP 1: Add one master user first
INSERT INTO public.users (id, email, password, created_at, last_login, is_active) 
VALUES (
    gen_random_uuid(), 
    'captain.nmg@nmg-marine.com',
    '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.',
    NOW(),
    NULL,
    true
);

-- STEP 2: Add admin user
INSERT INTO public.users (id, email, password, created_at, last_login, is_active) 
VALUES (
    gen_random_uuid(), 
    'admin@nmg-marine.com',
    '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.',
    NOW(),
    NULL,
    true
);

-- STEP 3: Add staff users
INSERT INTO public.users (id, email, password, created_at, last_login, is_active) VALUES
(gen_random_uuid(), 'hr.manager@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
(gen_random_uuid(), 'operations@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
(gen_random_uuid(), 'finance@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true);

-- STEP 4: Add crew users
INSERT INTO public.users (id, email, password, created_at, last_login, is_active) VALUES
(gen_random_uuid(), 'john.smith@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
(gen_random_uuid(), 'robert.jones@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
(gen_random_uuid(), 'michael.brown@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
(gen_random_uuid(), 'david.wilson@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true),
(gen_random_uuid(), 'james.taylor@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.Lfrom', NOW(), NULL, true),
(gen_random_uuid(), 'ahmed.hassan@nmg-marine.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6ukx.LFvO.', NOW(), NULL, true);

-- STEP 5: Now add profiles for all users
-- First get the user IDs we just created
WITH user_ids AS (
    SELECT id, email FROM public.users WHERE email LIKE '%@nmg-marine.com'
)
-- Add profiles
INSERT INTO public.profiles (id, name, role, ship_id, created_at, nationality, availability, sea_time, status, user_id)
SELECT 
    gen_random_uuid(),
    CASE 
        WHEN email = 'captain.nmg@nmg-marine.com' THEN 'Captain Anderson'
        WHEN email = 'admin@nmg-marine.com' THEN 'Admin User'
        WHEN email = 'hr.manager@nmg-marine.com' THEN 'Sarah Williams'
        WHEN email = 'operations@nmg-marine.com' THEN 'Michael Johnson'
        WHEN email = 'finance@nmg-marine.com' THEN 'Emma Davis'
        WHEN email = 'john.smith@nmg-marine.com' THEN 'John Smith'
        WHEN email = 'robert.jones@nmg-marine.com' THEN 'Robert Jones'
        WHEN email = 'michael.brown@nmg-marine.com' THEN 'Michael Brown'
        WHEN email = 'david.wilson@nmg-marine.com' THEN 'David Wilson'
        WHEN email = 'james.taylor@nmg-marine.com' THEN 'James Taylor'
        WHEN email = 'ahmed.hassan@nmg-marine.com' THEN 'Ahmed Hassan'
    END,
    CASE 
        WHEN email IN ('captain.nmg@nmg-marine.com', 'admin@nmg-marine.com') THEN 'MASTER'
        WHEN email LIKE '%.manager@nmg-marine.com' OR email IN ('operations@nmg-marine.com', 'finance@nmg-marine.com') THEN 'STAFF'
        ELSE 'CREW'
    END,
    CASE 
        WHEN email IN ('john.smith@nmg-marine.com', 'robert.jones@nmg-marine.com', 'michael.brown@nmg-marine.com', 'david.wilson@nmg-marine.com', 'james.taylor@nmg-marine.com', 'ahmed.hassan@nmg-marine.com') THEN '41f74c64-e6cf-488b-99e5-1bc3ebce9a05'
        ELSE NULL
    END,
    NOW(),
    CASE 
        WHEN email LIKE '%@nmg-marine.com' AND email NOT LIKE '%ahmed%' AND email NOT LIKE '%john%' THEN 'British'
        WHEN email = 'robert.jones@nmg-marine.com' THEN 'American'
        WHEN email = 'james.taylor@nmg-marine.com' THEN 'Scottish'
        WHEN email = 'ahmed.hassan@nmg-marine.com' THEN 'Egyptian'
        ELSE 'Unknown'
    END,
    CASE 
        WHEN email IN ('john.smith@nmg-marine.com', 'robert.jones@nmg-marine.com', 'michael.brown@nmg-marine.com', 'david.wilson@nmg-marine.com', 'james.taylor@nmg-marine.com', 'ahmed.hassan@nmg-marine.com') THEN 'ONBOARD'
        ELSE 'AVAILABLE'
    END,
    CASE 
        WHEN email = 'captain.nmg@nmg-marine.com' THEN '15 years'
        WHEN email = 'admin@nmg-marine.com' THEN '20 years'
        WHEN email LIKE '%.manager@nmg-marine.com' OR email IN ('operations@nmg-marine.com', 'finance@nmg-marine.com') THEN '10 years'
        WHEN email = 'john.smith@nmg-marine.com' THEN '10 years'
        WHEN email = 'robert.jones@nmg-marine.com' THEN '8 years'
        WHEN email = 'michael.brown@nmg-marine.com' THEN '6 years'
        WHEN email = 'david.wilson@nmg-marine.com' THEN '12 years'
        WHEN email = 'james.taylor@nmg-marine.com' THEN '9 years'
        WHEN email = 'ahmed.hassan@nmg-marine.com' THEN '5 years'
    END,
    'ACTIVE',
    user_ids.id
FROM user_ids;

-- STEP 6: Add crew profiles for crew members
WITH crew_profiles AS (
    SELECT p.id as profile_id, u.email
    FROM public.profiles p
    JOIN public.users u ON p.user_id = u.id
    WHERE p.role = 'CREW'
)
INSERT INTO public.crew_profiles (id, user_id, rank, join_date, department, job_description, contract_duration, previous_experience, emergency_contact_name, emergency_contact_number)
SELECT 
    gen_random_uuid(),
    cp.profile_id,
    CASE 
        WHEN email = 'john.smith@nmg-marine.com' THEN 'Captain'
        WHEN email = 'robert.jones@nmg-marine.com' THEN 'Chief Officer'
        WHEN email = 'michael.brown@nmg-marine.com' THEN 'Second Officer'
        WHEN email = 'david.wilson@nmg-marine.com' THEN 'Chief Engineer'
        WHEN email = 'james.taylor@nmg-marine.com' THEN 'Second Engineer'
        WHEN email = 'ahmed.hassan@nmg-marine.com' THEN 'Able Seaman'
    END,
    CASE 
        WHEN email = 'john.smith@nmg-marine.com' THEN '2020-01-15'
        WHEN email = 'robert.jones@nmg-marine.com' THEN '2021-02-20'
        WHEN email = 'michael.brown@nmg-marine.com' THEN '2022-03-10'
        WHEN email = 'david.wilson@nmg-marine.com' THEN '2019-11-01'
        WHEN email = 'james.taylor@nmg-marine.com' THEN '2020-07-15'
        WHEN email = 'ahmed.hassan@nmg-marine.com' THEN '2023-01-05'
    END,
    CASE 
        WHEN email IN ('john.smith@nmg-marine.com', 'robert.jones@nmg-marine.com', 'michael.brown@nmg-marine.com', 'ahmed.hassan@nmg-marine.com') THEN 'DECK'
        WHEN email IN ('david.wilson@nmg-marine.com', 'james.taylor@nmg-marine.com') THEN 'ENGINE'
        ELSE 'DECK'
    END,
    CASE 
        WHEN email = 'john.smith@nmg-marine.com' THEN 'Overall command of vessel'
        WHEN email = 'robert.jones@nmg-marine.com' THEN 'Second in command'
        WHEN email = 'michael.brown@nmg-marine.com' THEN 'Navigation officer'
        WHEN email = 'david.wilson@nmg-marine.com' THEN 'Engine maintenance'
        WHEN email = 'james.taylor@nmg-marine.com' THEN 'Engine operations'
        WHEN email = 'ahmed.hassan@nmg-marine.com' THEN 'Deck maintenance'
    END,
    12,
    CASE 
        WHEN email = 'john.smith@nmg-marine.com' THEN '15 years in command'
        WHEN email = 'robert.jones@nmg-marine.com' THEN '10 years as Chief Officer'
        WHEN email = 'michael.brown@nmg-marine.com' THEN '6 years navigation'
        WHEN email = 'david.wilson@nmg-marine.com' THEN '20 years engineering'
        WHEN email = 'james.taylor@nmg-marine.com' THEN '9 years engine room'
        WHEN email = 'ahmed.hassan@nmg-marine.com' THEN '5 years deck experience'
    END,
    CASE 
        WHEN email = 'john.smith@nmg-marine.com' THEN 'Mary Smith'
        WHEN email = 'robert.jones@nmg-marine.com' THEN 'Jennifer Jones'
        WHEN email = 'michael.brown@nmg-marine.com' THEN 'Susan Brown'
        WHEN email = 'david.wilson@nmg-marine.com' THEN 'Linda Wilson'
        WHEN email = 'james.taylor@nmg-marine.com' THEN 'Emma Taylor'
        WHEN email = 'ahmed.hassan@nmg-marine.com' THEN 'Fatima Hassan'
    END,
    CASE 
        WHEN email = 'john.smith@nmg-marine.com' THEN '+44 20 1234 5678'
        WHEN email = 'robert.jones@nmg-marine.com' THEN '+1 555 123 4567'
        WHEN email = 'michael.brown@nmg-marine.com' THEN '+44 20 2345 6789'
        WHEN email = 'david.wilson@nmg-marine.com' THEN '+44 20 3456 7890'
        WHEN email = 'james.taylor@nmg-marine.com' THEN '+44 20 4567 8901'
        WHEN email = 'ahmed.hassan@nmg-marine.com' THEN '+20 123 456 7890'
    END
FROM crew_profiles cp;

-- All done! You now have:
-- 2 Masters: captain.nmg@nmg-marine.com, admin@nmg-marine.com
-- 3 Staff: hr.manager@nmg-marine.com, operations@nmg-marine.com, finance@nmg-marine.com
-- 6 Crew: john.smith@nmg-marine.com (Captain), robert.jones@nmg-marine.com (Chief Officer), michael.brown@nmg-marine.com (Second Officer), david.wilson@nmg-marine.com (Chief Engineer), james.taylor@nmg-marine.com (Second Engineer), ahmed.hassan@nmg-marine.com (Able Seaman)
-- All passwords: password123
