from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
import logging

from .database import engine, Base, get_db
from .config import settings
from .routers import auth, ships, crew, work_logs, spare_parts, equipment_running_hours, maintenance_reports, certificates, recruitment, manuals, incidents, demo

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)

app = FastAPI(
    title=settings.PROJECT_NAME,
    description="API for NMG Marine CRM System - Fleet Management, PMS, Crew Management",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Configure CORS for frontend integration
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",  # Vite dev server
        "http://localhost:3000",
        "http://127.0.0.1:5173",
        "http://127.0.0.1:3000",
        "*"  # Allow all in development - restrict in production
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Create database tables at startup
@app.on_event("startup")
async def create_tables():
    """Create all database tables if they don't exist."""
    try:
        logging.info("Creating database tables if they don't exist...")
        Base.metadata.create_all(bind=engine)
        logging.info("Database tables created successfully.")
    except Exception as e:
        logging.error(f"Error creating database tables: {e}")

# Include routers
app.include_router(auth.router, prefix=settings.API_V1_PREFIX)
app.include_router(ships.router, prefix=settings.API_V1_PREFIX)
app.include_router(crew.router, prefix=settings.API_V1_PREFIX)
app.include_router(work_logs.router, prefix=settings.API_V1_PREFIX)
# PMS System Routers
app.include_router(spare_parts.router, prefix=settings.API_V1_PREFIX)
app.include_router(equipment_running_hours.router, prefix=settings.API_V1_PREFIX)
app.include_router(maintenance_reports.router, prefix=settings.API_V1_PREFIX)
app.include_router(certificates.router, prefix=settings.API_V1_PREFIX)
app.include_router(recruitment.router, prefix=settings.API_V1_PREFIX)
# Document Control & Incidents
app.include_router(manuals.router, prefix=settings.API_V1_PREFIX)
app.include_router(incidents.router, prefix=settings.API_V1_PREFIX)

# Demo data setup
app.include_router(demo.router, prefix=settings.API_V1_PREFIX)


@app.get("/", tags=["Root"])
async def root():
    """Root endpoint - API health check."""
    return {
        "message": "Welcome to NMG Marine CRM API",
        "version": "1.0.0",
        "docs": "/docs",
        "status": "running",
        "database": "SQLAlchemy ORM"
    }


@app.get("/health", tags=["Health"])
async def health_check(db: Session = Depends(get_db)):
    """Health check endpoint with database connection verification."""
    try:
        # Test database connection
        db.execute("SELECT 1")
        db_status = "connected"
    except Exception as e:
        db_status = f"error: {str(e)}"
    
    return {
        "status": "healthy",
        "database": db_status
    }
