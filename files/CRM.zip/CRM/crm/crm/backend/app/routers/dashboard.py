from fastapi import APIRouter, HTTPException, Depends
from ..database import supabase
from ..utils.security import get_current_user, require_roles

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])


@router.get("/master")
async def get_master_dashboard(current_user: dict = Depends(require_roles(["MASTER"]))):
    """Get master dashboard KPIs. MASTER only."""
    try:
        # Get ship counts
        ships_res = supabase.table("ships").select("id, status").execute()
        ships = ships_res.data
        total_ships = len(ships)
        active_ships = len([s for s in ships if s.get("status") == "ACTIVE"])
        
        # Get crew counts
        crew_res = supabase.table("profiles").select("id, role, availability").eq("role", "CREW").execute()
        crew = crew_res.data
        total_crew = len(crew)
        onboard_crew = len([c for c in crew if c.get("availability") == "ONBOARD"])
        
        # Get pending PMS tasks
        pms_res = supabase.table("pms_tasks").select("id, status").execute()
        pms_tasks = pms_res.data
        pending_pms = len([t for t in pms_tasks if t.get("status") == "PENDING"])
        overdue_pms = len([t for t in pms_tasks if t.get("status") == "OVERDUE"])
        
        # Get pending work log approvals
        work_logs_res = supabase.table("daily_work_logs").select("id, status").eq("status", "PENDING").execute()
        pending_work_logs = len(work_logs_res.data)
        
        # Get pending invoice approvals
        invoices_res = supabase.table("invoices").select("id, status, amount").execute()
        invoices = invoices_res.data
        pending_invoices = len([i for i in invoices if i.get("status") == "SUBMITTED"])
        total_invoice_amount = sum([float(i.get("amount", 0)) for i in invoices])
        
        # Get pending PMS log approvals
        pms_logs_res = supabase.table("pms_logs").select("id, status").eq("status", "PENDING").execute()
        pending_pms_logs = len(pms_logs_res.data)
        
        return {
            "ships": {
                "total": total_ships,
                "active": active_ships,
                "maintenance": total_ships - active_ships
            },
            "crew": {
                "total": total_crew,
                "onboard": onboard_crew,
                "available": total_crew - onboard_crew
            },
            "pms": {
                "pending": pending_pms,
                "overdue": overdue_pms,
                "pending_approval": pending_pms_logs
            },
            "work_logs": {
                "pending_approval": pending_work_logs
            },
            "invoices": {
                "pending_approval": pending_invoices,
                "total_amount": total_invoice_amount
            },
            "total_pending_approvals": pending_work_logs + pending_invoices + pending_pms_logs
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/crew")
async def get_crew_dashboard(current_user: dict = Depends(get_current_user)):
    """Get crew dashboard KPIs."""
    try:
        user_id = current_user["id"]
        
        # Get assigned tasks
        tasks_res = supabase.table("pms_tasks").select("id, status").eq("assigned_to", user_id).execute()
        tasks = tasks_res.data
        total_tasks = len(tasks)
        pending_tasks = len([t for t in tasks if t.get("status") == "PENDING"])
        completed_tasks = len([t for t in tasks if t.get("status") == "COMPLETED"])
        
        # Get work logs
        logs_res = supabase.table("daily_work_logs").select("id, status").eq("crew_id", user_id).execute()
        logs = logs_res.data
        total_logs = len(logs)
        pending_logs = len([l for l in logs if l.get("status") == "PENDING"])
        approved_logs = len([l for l in logs if l.get("status") == "APPROVED"])
        
        return {
            "tasks": {
                "total": total_tasks,
                "pending": pending_tasks,
                "completed": completed_tasks,
                "in_progress": total_tasks - pending_tasks - completed_tasks
            },
            "work_logs": {
                "total": total_logs,
                "pending": pending_logs,
                "approved": approved_logs
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/staff")
async def get_staff_dashboard(current_user: dict = Depends(require_roles(["MASTER", "STAFF"]))):
    """Get staff dashboard KPIs. MASTER and STAFF only."""
    try:
        # Get ship counts
        ships_res = supabase.table("ships").select("id, status").execute()
        ships = ships_res.data
        total_ships = len(ships)
        active_ships = len([s for s in ships if s.get("status") == "ACTIVE"])
        
        # Get crew counts
        crew_res = supabase.table("profiles").select("id, role, availability").eq("role", "CREW").execute()
        crew = crew_res.data
        total_crew = len(crew)
        available_crew = len([c for c in crew if c.get("availability") == "AVAILABLE"])
        
        # Get invoice stats
        invoices_res = supabase.table("invoices").select("id, status, amount").execute()
        invoices = invoices_res.data
        draft_invoices = len([i for i in invoices if i.get("status") == "DRAFT"])
        submitted_invoices = len([i for i in invoices if i.get("status") == "SUBMITTED"])
        
        # Get recruitment stats
        recruitment_res = supabase.table("recruitment").select("id, status").execute()
        candidates = recruitment_res.data
        total_candidates = len(candidates)
        pending_candidates = len([c for c in candidates if c.get("status") == "APPLIED"])
        
        # Get client stats
        clients_res = supabase.table("clients").select("id, status").execute()
        clients = clients_res.data
        total_clients = len(clients)
        active_clients = len([c for c in clients if c.get("status") == "ACTIVE"])
        
        return {
            "ships": {
                "total": total_ships,
                "active": active_ships
            },
            "crew": {
                "total": total_crew,
                "available": available_crew
            },
            "invoices": {
                "draft": draft_invoices,
                "submitted": submitted_invoices
            },
            "recruitment": {
                "total": total_candidates,
                "pending": pending_candidates
            },
            "clients": {
                "total": total_clients,
                "active": active_clients
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/activity-logs")
async def get_activity_logs(
    current_user: dict = Depends(require_roles(["MASTER"])),
    limit: int = 50
):
    """Get recent activity logs. MASTER only."""
    try:
        res = supabase.table("activity_logs").select(
            "*, profiles(name)"
        ).order("created_at", desc=True).limit(limit).execute()
        
        return res.data
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
