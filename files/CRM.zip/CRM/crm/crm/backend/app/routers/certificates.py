from fastapi import APIRouter, HTTPException, Depends, Query
from typing import List, Optional
from sqlalchemy.orm import Session
import uuid
from datetime import datetime

from ..database import get_db
from ..models.crew_profile import CrewCertificate as CrewCertificateModel, CrewProfile
from ..models.profile import Profile
from ..utils.security import get_current_user, require_roles
from ..utils.helpers import log_activity
from ..schemas.crew import CrewCertificate as CrewCertificateSchema, CrewCertificateResponse

router = APIRouter(prefix="/certificates", tags=["Crew Certificates"])


@router.post("/{crew_id}", response_model=CrewCertificateResponse)
async def add_crew_certificate(
    crew_id: str,
    certificate: CrewCertificateSchema,
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"])),
    db: Session = Depends(get_db)
):
    """Add a certificate to a crew member."""
    try:
        # Get crew profile
        crew_profile = db.query(CrewProfile).filter(CrewProfile.user_id == uuid.UUID(crew_id)).first()
        
        if not crew_profile:
            raise HTTPException(status_code=404, detail="Crew profile not found")
        
        # Create certificate
        new_cert = CrewCertificateModel(
            id=uuid.uuid4(),
            crew_id=crew_profile.id,
            name=certificate.name,
            certificate_number=certificate.certificate_number,
            issue_date=certificate.issue_date,
            expiry_date=certificate.expiry_date,
            issuing_authority=certificate.issuing_authority,
            document_url=certificate.document_url
        )
        
        db.add(new_cert)
        db.commit()
        db.refresh(new_cert)
        
        # Log activity
        await log_activity(current_user["id"], "ADD_CERTIFICATE", "CREW", db=db)
        
        # Prepare response
        result = {
            "id": str(new_cert.id),
            "crew_id": str(new_cert.crew_id),
            "name": new_cert.name,
            "certificate_number": new_cert.certificate_number,
            "issue_date": new_cert.issue_date,
            "expiry_date": new_cert.expiry_date,
            "issuing_authority": new_cert.issuing_authority,
            "document_url": new_cert.document_url,
            "created_at": new_cert.created_at
        }
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{crew_id}", response_model=List[CrewCertificateResponse])
async def get_crew_certificates(
    crew_id: str,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get all certificates for a specific crew member."""
    try:
        # CREW can only view their own certificates
        if current_user["role"] == "CREW" and current_user["id"] != crew_id:
            raise HTTPException(status_code=403, detail="Access denied")
        
        # Get crew profile
        crew_profile = db.query(CrewProfile).filter(CrewProfile.user_id == uuid.UUID(crew_id)).first()
        
        if not crew_profile:
            raise HTTPException(status_code=404, detail="Crew profile not found")
        
        # Get certificates
        certificates = db.query(CrewCertificateModel).filter(CrewCertificateModel.crew_id == crew_profile.id).all()
        
        # Prepare response
        result = []
        for cert in certificates:
            result.append({
                "id": str(cert.id),
                "crew_id": str(cert.crew_id),
                "name": cert.name,
                "certificate_number": cert.certificate_number,
                "issue_date": cert.issue_date,
                "expiry_date": cert.expiry_date,
                "issuing_authority": cert.issuing_authority,
                "document_url": cert.document_url,
                "created_at": cert.created_at
            })
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/{certificate_id}", response_model=CrewCertificateResponse)
async def update_certificate(
    certificate_id: str,
    certificate_data: CrewCertificateSchema,
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"])),
    db: Session = Depends(get_db)
):
    """Update a specific certificate."""
    try:
        # Get certificate
        certificate = db.query(CrewCertificateModel).filter(CrewCertificateModel.id == uuid.UUID(certificate_id)).first()
        
        if not certificate:
            raise HTTPException(status_code=404, detail="Certificate not found")
        
        # Update certificate fields
        certificate.name = certificate_data.name
        certificate.certificate_number = certificate_data.certificate_number
        certificate.issue_date = certificate_data.issue_date
        certificate.expiry_date = certificate_data.expiry_date
        certificate.issuing_authority = certificate_data.issuing_authority
        certificate.document_url = certificate_data.document_url
        
        db.commit()
        db.refresh(certificate)
        
        # Log activity
        await log_activity(current_user["id"], "UPDATE_CERTIFICATE", "CREW", db=db)
        
        # Prepare response
        result = {
            "id": str(certificate.id),
            "crew_id": str(certificate.crew_id),
            "name": certificate.name,
            "certificate_number": certificate.certificate_number,
            "issue_date": certificate.issue_date,
            "expiry_date": certificate.expiry_date,
            "issuing_authority": certificate.issuing_authority,
            "document_url": certificate.document_url,
            "created_at": certificate.created_at
        }
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/{certificate_id}")
async def delete_certificate(
    certificate_id: str,
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"])),
    db: Session = Depends(get_db)
):
    """Delete a specific certificate."""
    try:
        # Get certificate
        certificate = db.query(CrewCertificateModel).filter(CrewCertificateModel.id == uuid.UUID(certificate_id)).first()
        
        if not certificate:
            raise HTTPException(status_code=404, detail="Certificate not found")
        
        # Delete certificate
        db.delete(certificate)
        db.commit()
        
        # Log activity
        await log_activity(current_user["id"], "DELETE_CERTIFICATE", "CREW", db=db)
        
        return {"message": "Certificate deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/expiring/{days}", response_model=List[dict])
async def get_expiring_certificates(
    days: int,
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"])),
    db: Session = Depends(get_db)
):
    """Get certificates expiring within the specified number of days."""
    try:
        # Calculate expiry date range
        import datetime as dt
        today = dt.date.today()
        expiry_date = today + dt.timedelta(days=days)
        
        # Query certificates
        certificates = db.query(CrewCertificateModel).filter(
            CrewCertificateModel.expiry_date >= today,
            CrewCertificateModel.expiry_date <= expiry_date
        ).all()
        
        # Get crew information for each certificate
        result = []
        for cert in certificates:
            # Get crew profile
            crew_profile = db.query(CrewProfile).filter(CrewProfile.id == cert.crew_id).first()
            if crew_profile:
                # Get user profile
                profile = db.query(Profile).filter(Profile.id == crew_profile.user_id).first()
                if profile:
                    result.append({
                        "certificate_id": str(cert.id),
                        "certificate_name": cert.name,
                        "expiry_date": cert.expiry_date,
                        "days_remaining": (cert.expiry_date - today).days if cert.expiry_date else None,
                        "crew_id": str(crew_profile.user_id),
                        "crew_name": profile.name,
                        "rank": crew_profile.rank,
                        "ship_id": str(profile.ship_id) if profile.ship_id else None
                    })
        
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
