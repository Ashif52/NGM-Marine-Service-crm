from fastapi import APIRouter, HTTPException, Depends, Query
from typing import List, Optional
from sqlalchemy.orm import Session
from sqlalchemy import desc
import uuid
from ..database import get_db
from ..models.recruitment import Recruitment
from ..utils.security import get_current_user, require_roles
from ..utils.helpers import log_activity
from ..schemas.recruitment import RecruitmentCreate, RecruitmentUpdate, RecruitmentResponse

router = APIRouter(prefix="/recruitment", tags=["Recruitment"])


@router.get("/", response_model=List[RecruitmentResponse])
async def get_candidates(
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"])),
    status: Optional[str] = Query(None),
    rank: Optional[str] = Query(None),
    nationality: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """Get all recruitment candidates. MASTER and STAFF only."""
    try:
        query = db.query(Recruitment)
        
        if status:
            query = query.filter(Recruitment.status == status)
        if rank:
            query = query.filter(Recruitment.rank == rank)
        if nationality:
            query = query.filter(Recruitment.nationality == nationality)
        
        candidates = query.order_by(desc(Recruitment.created_at)).all()
        return candidates
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{candidate_id}", response_model=RecruitmentResponse)
async def get_candidate(
    candidate_id: str,
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"])),
    db: Session = Depends(get_db)
):
    """Get a specific candidate."""
    try:
        candidate = db.query(Recruitment).filter(Recruitment.id == candidate_id).first()
        
        if not candidate:
            raise HTTPException(status_code=404, detail="Candidate not found")
        
        return candidate
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/", response_model=RecruitmentResponse)
async def create_candidate(
    candidate: RecruitmentCreate,
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"])),
    db: Session = Depends(get_db)
):
    """Create a new recruitment candidate. MASTER and STAFF only."""
    try:
        new_candidate = Recruitment(
            id=uuid.uuid4(),
            **candidate.dict()
        )
        
        db.add(new_candidate)
        db.commit()
        db.refresh(new_candidate)
        
        await log_activity(current_user["id"], "CREATE_CANDIDATE", "RECRUITMENT")
        return new_candidate
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/{candidate_id}", response_model=RecruitmentResponse)
async def update_candidate(
    candidate_id: str,
    candidate: RecruitmentUpdate,
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"])),
    db: Session = Depends(get_db)
):
    """Update a candidate."""
    try:
        db_candidate = db.query(Recruitment).filter(Recruitment.id == candidate_id).first()
        
        if not db_candidate:
            raise HTTPException(status_code=404, detail="Candidate not found")
        
        update_data = candidate.dict(exclude_unset=True)
        for key, value in update_data.items():
            setattr(db_candidate, key, value)
        
        db.commit()
        db.refresh(db_candidate)
        
        await log_activity(current_user["id"], "UPDATE_CANDIDATE", "RECRUITMENT")
        return db_candidate
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/{candidate_id}")
async def delete_candidate(
    candidate_id: str,
    current_user: dict = Depends(require_roles(["MASTER"])),
    db: Session = Depends(get_db)
):
    """Delete a candidate. MASTER only."""
    try:
        candidate = db.query(Recruitment).filter(Recruitment.id == candidate_id).first()
        
        if not candidate:
            raise HTTPException(status_code=404, detail="Candidate not found")
        
        db.delete(candidate)
        db.commit()
        
        await log_activity(current_user["id"], "DELETE_CANDIDATE", "RECRUITMENT")
        return {"message": "Candidate deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/{candidate_id}/status", response_model=RecruitmentResponse)
async def update_candidate_status(
    candidate_id: str,
    status: str,
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"])),
    db: Session = Depends(get_db)
):
    """Update candidate status (APPLIED, SHORTLISTED, INTERVIEWED, HIRED, REJECTED)."""
    try:
        valid_statuses = ["APPLIED", "SHORTLISTED", "INTERVIEWED", "HIRED", "REJECTED"]
        if status not in valid_statuses:
            raise HTTPException(status_code=400, detail=f"Invalid status. Must be one of: {valid_statuses}")
        
        candidate = db.query(Recruitment).filter(Recruitment.id == candidate_id).first()
        
        if not candidate:
            raise HTTPException(status_code=404, detail="Candidate not found")
        
        candidate.status = status
        db.commit()
        db.refresh(candidate)
        
        await log_activity(current_user["id"], f"UPDATE_CANDIDATE_STATUS_{status}", "RECRUITMENT")
        return candidate
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))
