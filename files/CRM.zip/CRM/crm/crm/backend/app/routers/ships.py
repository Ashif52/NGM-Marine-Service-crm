from fastapi import APIRouter, HTTPException, Depends, Query
from typing import List, Optional
from sqlalchemy.orm import Session
from sqlalchemy import desc
from ..database import get_db
from ..models.ship import Ship
from ..models.profile import Profile
from ..utils.security import get_current_user, require_roles
from ..utils.helpers import log_activity
from ..schemas.ship import ShipCreate, ShipUpdate, ShipResponse
import uuid
from datetime import datetime

router = APIRouter(prefix="/ships", tags=["Ships"])


@router.get("/", response_model=List[ShipResponse])
async def get_ships(
    current_user: dict = Depends(get_current_user),
    status: Optional[str] = Query(None),
    ship_type: Optional[str] = Query(None),
    client_id: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """Get all ships. CREW can only see their assigned ship."""
    try:
        # Start with base query
        query = db.query(Ship)
        
        # Add filters
        if status:
            query = query.filter(Ship.status == status)
        if ship_type:
            query = query.filter(Ship.ship_type == ship_type)
        if client_id:
            query = query.filter(Ship.client_id == uuid.UUID(client_id))
        
        # CREW can only see their assigned ship
        if current_user["role"] == "CREW" and current_user.get("ship_id"):
            query = query.filter(Ship.id == uuid.UUID(current_user["ship_id"]))
        
        # Add ordering
        ships = query.order_by(desc(Ship.created_at)).all()
        
        # Convert to response format
        return [{
            "id": str(ship.id),
            "ship_name": ship.ship_name,
            "imo_number": ship.imo_number,
            "ship_type": ship.ship_type,
            "flag": ship.flag,
            "client_id": str(ship.client_id) if ship.client_id else None,
            "crew_capacity": ship.crew_capacity,
            "status": ship.status,
            "created_at": ship.created_at
        } for ship in ships]
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{ship_id}", response_model=ShipResponse)
async def get_ship(ship_id: str, current_user: dict = Depends(get_current_user), db: Session = Depends(get_db)):
    """Get a specific ship."""
    try:
        # CREW can only access their assigned ship
        if current_user["role"] == "CREW" and current_user.get("ship_id") != ship_id:
            raise HTTPException(status_code=403, detail="Access denied")
        
        # Get ship by id
        ship = db.query(Ship).filter(Ship.id == uuid.UUID(ship_id)).first()
        
        if not ship:
            raise HTTPException(status_code=404, detail="Ship not found")
        
        # Convert to response format
        return {
            "id": str(ship.id),
            "ship_name": ship.ship_name,
            "imo_number": ship.imo_number,
            "ship_type": ship.ship_type,
            "flag": ship.flag,
            "client_id": str(ship.client_id) if ship.client_id else None,
            "crew_capacity": ship.crew_capacity,
            "status": ship.status,
            "created_at": ship.created_at
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/", response_model=ShipResponse)
async def create_ship(
    ship: ShipCreate,
    current_user: dict = Depends(require_roles(["MASTER"])),
    db: Session = Depends(get_db)
):
    """Create a new ship. MASTER only."""
    try:
        ship_data = ship.dict()
        ship_id = uuid.uuid4()
        
        # Convert client_id to UUID if provided
        if ship_data.get("client_id"):
            ship_data["client_id"] = uuid.UUID(ship_data["client_id"])
        
        # Create new ship
        new_ship = Ship(
            id=ship_id,
            ship_name=ship_data["ship_name"],
            imo_number=ship_data.get("imo_number"),
            ship_type=ship_data.get("ship_type"),
            flag=ship_data.get("flag"),
            client_id=ship_data.get("client_id"),
            crew_capacity=ship_data.get("crew_capacity"),
            status="ACTIVE",
            created_at=datetime.now()
        )
        
        # Add to database and commit
        db.add(new_ship)
        db.commit()
        db.refresh(new_ship)
        
        # Log activity
        await log_activity(current_user["id"], "CREATE_SHIP", "SHIPS", db=db)
        
        # Convert to response format
        return {
            "id": str(new_ship.id),
            "ship_name": new_ship.ship_name,
            "imo_number": new_ship.imo_number,
            "ship_type": new_ship.ship_type,
            "flag": new_ship.flag,
            "client_id": str(new_ship.client_id) if new_ship.client_id else None,
            "crew_capacity": new_ship.crew_capacity,
            "status": new_ship.status,
            "created_at": new_ship.created_at
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/{ship_id}", response_model=ShipResponse)
async def update_ship(
    ship_id: str,
    ship: ShipUpdate,
    current_user: dict = Depends(require_roles(["MASTER"])),
    db: Session = Depends(get_db)
):
    """Update a ship. MASTER only."""
    try:
        # Get data that is not None
        update_data = {k: v for k, v in ship.dict().items() if v is not None}
        
        if not update_data:
            raise HTTPException(status_code=400, detail="No data to update")
        
        # Convert client_id to UUID if provided
        if update_data.get("client_id"):
            update_data["client_id"] = uuid.UUID(update_data["client_id"])
        
        # Get ship by id
        existing_ship = db.query(Ship).filter(Ship.id == uuid.UUID(ship_id)).first()
        
        if not existing_ship:
            raise HTTPException(status_code=404, detail="Ship not found")
        
        # Update ship attributes
        for key, value in update_data.items():
            setattr(existing_ship, key, value)
        
        # Commit changes
        db.commit()
        db.refresh(existing_ship)
        
        # Log activity
        await log_activity(current_user["id"], "UPDATE_SHIP", "SHIPS", db=db)
        
        # Convert to response format
        return {
            "id": str(existing_ship.id),
            "ship_name": existing_ship.ship_name,
            "imo_number": existing_ship.imo_number,
            "ship_type": existing_ship.ship_type,
            "flag": existing_ship.flag,
            "client_id": str(existing_ship.client_id) if existing_ship.client_id else None,
            "crew_capacity": existing_ship.crew_capacity,
            "status": existing_ship.status,
            "created_at": existing_ship.created_at
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/{ship_id}")
async def delete_ship(
    ship_id: str,
    current_user: dict = Depends(require_roles(["MASTER"])),
    db: Session = Depends(get_db)
):
    """Delete a ship. MASTER only."""
    try:
        # Get ship by id
        existing_ship = db.query(Ship).filter(Ship.id == uuid.UUID(ship_id)).first()
        
        if not existing_ship:
            raise HTTPException(status_code=404, detail="Ship not found")
        
        # Delete ship
        db.delete(existing_ship)
        db.commit()
        
        # Log activity
        await log_activity(current_user["id"], "DELETE_SHIP", "SHIPS", db=db)
        
        return {"message": "Ship deleted successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{ship_id}/crew")
async def get_ship_crew(
    ship_id: str,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get all crew members assigned to a ship."""
    try:
        # CREW can only view their own ship
        if current_user["role"] == "CREW" and current_user.get("ship_id") != ship_id:
            raise HTTPException(status_code=403, detail="Access denied")
        
        # Get crew profiles for the ship
        crew_profiles = db.query(Profile).filter(Profile.ship_id == uuid.UUID(ship_id)).all()
        
        # Convert to response format
        crew = [{
            "id": str(profile.id),
            "name": profile.name,
            "role": profile.role,
            "nationality": profile.nationality,
            "availability": profile.availability,
            "status": profile.status
        } for profile in crew_profiles]
        
        return crew
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
