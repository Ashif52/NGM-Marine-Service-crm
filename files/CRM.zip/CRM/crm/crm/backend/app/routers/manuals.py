from fastapi import APIRouter, Depends, Query, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
from ..database import get_db
from ..utils.security import get_current_user, require_roles
from ..services.manuals import ManualService
from ..schemas.manuals import (
    ManualCreate,
    ManualUpdate,
    ManualVersionCreate,
    ManualVersionUpdate,
    ManualAcknowledgementCreate,
    ManualResponse,
    ManualListResponse,
)

router = APIRouter(prefix="/manuals", tags=["Manuals"])

@router.get("/", response_model=ManualListResponse)
async def list_manuals(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=100),
    manual_type: Optional[str] = None,
    ship_id: Optional[str] = None,
    search: Optional[str] = None,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """List all manuals with optional filters"""
    service = ManualService(db)

    # CREW can only see manuals for their ship
    if current_user["role"] == "CREW":
        if not current_user.get("ship_id"):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="No ship assigned"
            )
        ship_id = current_user["ship_id"]

    manuals = service.get_manuals(
        skip=skip,
        limit=limit,
        manual_type=manual_type,
        ship_id=ship_id,
        search=search,
    )

    total = len(manuals)  # TODO: Add count query
    return {
        "manuals": manuals,
        "total": total,
        "page": skip // limit + 1,
        "size": limit
    }

@router.post("/", response_model=ManualResponse)
async def create_manual(
    manual: ManualCreate,
    current_user: dict = Depends(require_roles(["MASTER"])),
    db: Session = Depends(get_db)
):
    """Create a new manual (MASTER only)"""
    service = ManualService(db)
    return service.create_manual(manual, current_user["id"])

@router.post("/{manual_id}/versions", response_model=ManualResponse)
async def create_version(
    manual_id: str,
    version: ManualVersionCreate,
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"])),
    db: Session = Depends(get_db)
):
    """Create a new version of a manual"""
    service = ManualService(db)
    
    # Validate manual ownership for STAFF
    if current_user["role"] == "STAFF":
        manual = service.get_manual(manual_id)
        if manual.ship_id != current_user.get("ship_id"):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Not authorized to modify this manual"
            )

    version.manual_id = manual_id
    service.create_version(version, current_user["id"])
    return service.get_manual(manual_id)

@router.get("/{manual_id}", response_model=ManualResponse)
async def get_manual(
    manual_id: str,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get a specific manual by ID"""
    service = ManualService(db)
    manual = service.get_manual(manual_id)

    # Check access
    if current_user["role"] == "CREW" and manual.ship_id != current_user.get("ship_id"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to access this manual"
        )

    return manual

@router.put("/{manual_id}", response_model=ManualResponse)
async def update_manual(
    manual_id: str,
    manual: ManualUpdate,
    current_user: dict = Depends(require_roles(["MASTER"])),
    db: Session = Depends(get_db)
):
    """Update a manual (MASTER only)"""
    service = ManualService(db)
    return service.update_manual(manual_id, manual, current_user["id"])

@router.put("/versions/{version_id}", response_model=ManualResponse)
async def update_version(
    version_id: str,
    version: ManualVersionUpdate,
    current_user: dict = Depends(require_roles(["MASTER"])),
    db: Session = Depends(get_db)
):
    """Update a manual version (MASTER only)"""
    service = ManualService(db)
    updated = service.update_version(version_id, version, current_user["id"])
    return service.get_manual(updated.manual_id)

@router.post("/acknowledge", response_model=ManualResponse)
async def acknowledge_manual(
    ack: ManualAcknowledgementCreate,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Acknowledge a manual version"""
    service = ManualService(db)
    
    # Validate access
    manual = service.get_manual(ack.manual_id)
    if current_user["role"] == "CREW" and manual.ship_id != current_user.get("ship_id"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to acknowledge this manual"
        )

    service.acknowledge_manual(ack, current_user["id"])
    return manual

@router.get("/acknowledgements/me", response_model=List[ManualResponse])
async def get_my_acknowledgements(
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get all manuals acknowledged by the current user"""
    service = ManualService(db)
    acks = service.get_user_acknowledgements(current_user["id"])
    return [ack.manual for ack in acks]
