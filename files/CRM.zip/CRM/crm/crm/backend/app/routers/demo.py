from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..database import get_db
from ..utils.demo_data import create_demo_users

router = APIRouter(prefix="/demo", tags=["Demo"])

@router.post("/setup")
async def setup_demo(db: Session = Depends(get_db)):
    """Create demo users and data"""
    return create_demo_users(db)
