from fastapi import APIRouter, Depends, HTTPException, status, Query
from typing import List, Optional
from sqlalchemy.orm import Session
from ...db.database import get_db
from ...db.models.ship import Ship
from ...schemas.sql.ship import ShipCreate, ShipUpdate, ShipResponse
from ...db.repositories.ship_repository import ShipRepository

router = APIRouter(
    prefix="/api/ships",
    tags=["Ships"],
    responses={404: {"description": "Not found"}},
)

@router.get("/", response_model=List[ShipResponse])
async def get_ships(
    skip: int = Query(0, description="Skip records"),
    limit: int = Query(100, description="Limit records"),
    client_id: Optional[str] = Query(None, description="Filter by client ID"),
    ship_type: Optional[str] = Query(None, description="Filter by ship type"),
    status: Optional[str] = Query(None, description="Filter by status"),
    db: Session = Depends(get_db)
):
    """
    Get all ships with optional filtering.
    """
    repository = ShipRepository(db)
    
    if client_id:
        return repository.get_ships_by_client(client_id)
    elif ship_type:
        return repository.get_ships_by_type(ship_type)
    elif status == "ACTIVE":
        return repository.get_active_ships()
    else:
        return repository.get_all(skip=skip, limit=limit)

@router.post("/", response_model=ShipResponse, status_code=status.HTTP_201_CREATED)
async def create_ship(ship: ShipCreate, db: Session = Depends(get_db)):
    """
    Create a new ship.
    """
    repository = ShipRepository(db)
    
    # Check if ship with the same IMO number already exists
    if ship.imo_number:
        existing_ship = repository.get_ship_by_imo(ship.imo_number)
        if existing_ship:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Ship with IMO number {ship.imo_number} already exists"
            )
    
    return repository.create(ship)

@router.get("/{ship_id}", response_model=ShipResponse)
async def get_ship(ship_id: str, db: Session = Depends(get_db)):
    """
    Get a specific ship by ID.
    """
    repository = ShipRepository(db)
    ship = repository.get_by_id(ship_id)
    
    if ship is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Ship with ID {ship_id} not found"
        )
    
    return ship

@router.put("/{ship_id}", response_model=ShipResponse)
async def update_ship(ship_id: str, ship: ShipUpdate, db: Session = Depends(get_db)):
    """
    Update a ship.
    """
    repository = ShipRepository(db)
    return repository.update(ship_id, ship)

@router.delete("/{ship_id}", response_model=ShipResponse)
async def delete_ship(ship_id: str, db: Session = Depends(get_db)):
    """
    Delete a ship.
    """
    repository = ShipRepository(db)
    return repository.delete(ship_id)

@router.patch("/{ship_id}/status", response_model=ShipResponse)
async def update_ship_status(ship_id: str, status: str, db: Session = Depends(get_db)):
    """
    Update a ship's status.
    """
    repository = ShipRepository(db)
    return repository.update_ship_status(ship_id, status)
