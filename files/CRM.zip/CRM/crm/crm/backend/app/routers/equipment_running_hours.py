from fastapi import APIRouter, HTTPException, status, Depends, Query
from sqlalchemy.orm import Session
from typing import List, Optional
import uuid
from datetime import date, datetime, timedelta

from ..database import get_db
from ..models.equipment_running_hours import EquipmentRunningHours
from ..models.equipment import Equipment
from ..schemas.equipment_running_hours import (
    EquipmentRunningHoursCreate, EquipmentRunningHoursUpdate, 
    EquipmentRunningHours as EquipmentRunningHoursSchema
)
from ..utils.security import get_current_user, require_roles

router = APIRouter(prefix="/equipment-hours", tags=["Equipment Running Hours"])


@router.post("", response_model=EquipmentRunningHoursSchema)
async def record_equipment_hours(
    hours_data: EquipmentRunningHoursCreate,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Record running hours for a piece of equipment"""
    # Verify user has appropriate role
    if current_user["role"] not in ["MASTER", "STAFF", "CREW"]:
        raise HTTPException(status_code=403, detail="Not authorized to record equipment hours")
    
    # Check if equipment exists
    equipment = db.query(Equipment).filter(Equipment.id == hours_data.equipment_id).first()
    if not equipment:
        raise HTTPException(status_code=404, detail="Equipment not found")
    
    # Check if an entry already exists for this equipment and date
    existing_entry = db.query(EquipmentRunningHours).filter(
        EquipmentRunningHours.equipment_id == hours_data.equipment_id,
        EquipmentRunningHours.date == hours_data.date
    ).first()
    
    if existing_entry:
        raise HTTPException(
            status_code=400, 
            detail=f"An entry for this equipment on {hours_data.date} already exists. Use update endpoint instead."
        )
    
    # Create new running hours record
    db_hours = EquipmentRunningHours(
        equipment_id=hours_data.equipment_id,
        date=hours_data.date,
        running_hours=hours_data.running_hours,
        total_running_hours=hours_data.total_running_hours,
        reported_by=uuid.UUID(current_user["id"])
    )
    
    # Update equipment's total running hours
    equipment.total_running_hours = hours_data.total_running_hours
    
    db.add(db_hours)
    db.commit()
    db.refresh(db_hours)
    
    return db_hours


@router.get("", response_model=List[EquipmentRunningHoursSchema])
async def get_equipment_hours(
    equipment_id: Optional[uuid.UUID] = None,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    skip: int = 0,
    limit: int = 100,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get equipment running hours with optional filtering
    - equipment_id: Filter by specific equipment
    - start_date: Filter by start date (inclusive)
    - end_date: Filter by end date (inclusive)
    """
    query = db.query(EquipmentRunningHours)
    
    # Apply filters
    if equipment_id:
        query = query.filter(EquipmentRunningHours.equipment_id == equipment_id)
    
    if start_date:
        query = query.filter(EquipmentRunningHours.date >= start_date)
    
    if end_date:
        query = query.filter(EquipmentRunningHours.date <= end_date)
    
    # Order by date, then by equipment
    query = query.order_by(EquipmentRunningHours.date.desc(), EquipmentRunningHours.equipment_id)
    
    # Apply pagination
    hours_records = query.offset(skip).limit(limit).all()
    
    return hours_records


@router.get("/{entry_id}", response_model=EquipmentRunningHoursSchema)
async def get_equipment_hours_entry(
    entry_id: uuid.UUID,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get a specific equipment running hours entry by ID"""
    hours_entry = db.query(EquipmentRunningHours).filter(
        EquipmentRunningHours.id == entry_id
    ).first()
    
    if not hours_entry:
        raise HTTPException(status_code=404, detail="Equipment running hours entry not found")
    
    return hours_entry


@router.put("/{entry_id}", response_model=EquipmentRunningHoursSchema)
async def update_equipment_hours(
    entry_id: uuid.UUID,
    hours_update: EquipmentRunningHoursUpdate,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Update a specific equipment running hours entry"""
    # Verify user has appropriate role
    if current_user["role"] not in ["MASTER", "STAFF"]:
        raise HTTPException(status_code=403, detail="Not authorized to update equipment hours")
    
    # Get existing entry
    db_hours = db.query(EquipmentRunningHours).filter(
        EquipmentRunningHours.id == entry_id
    ).first()
    
    if not db_hours:
        raise HTTPException(status_code=404, detail="Equipment running hours entry not found")
    
    # Update entry
    update_data = hours_update.dict(exclude_unset=True)
    for key, value in update_data.items():
        setattr(db_hours, key, value)
    
    # If total_running_hours was updated, update the equipment as well
    if "total_running_hours" in update_data:
        equipment = db.query(Equipment).filter(Equipment.id == db_hours.equipment_id).first()
        if equipment:
            equipment.total_running_hours = update_data["total_running_hours"]
    
    db.commit()
    db.refresh(db_hours)
    
    return db_hours


@router.delete("/{entry_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_equipment_hours_entry(
    entry_id: uuid.UUID,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Delete a specific equipment running hours entry"""
    # Verify user has appropriate role
    if current_user["role"] not in ["MASTER", "STAFF"]:
        raise HTTPException(status_code=403, detail="Not authorized to delete equipment hours")
    
    # Get existing entry
    db_hours = db.query(EquipmentRunningHours).filter(
        EquipmentRunningHours.id == entry_id
    ).first()
    
    if not db_hours:
        raise HTTPException(status_code=404, detail="Equipment running hours entry not found")
    
    # Delete entry
    db.delete(db_hours)
    db.commit()
    
    return None


@router.get("/summary/{equipment_id}", response_model=dict)
async def get_equipment_hours_summary(
    equipment_id: uuid.UUID,
    period: str = Query("month", enum=["week", "month", "year"]),
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get a summary of equipment running hours
    - period: Summary period (week, month, year)
    """
    # Check if equipment exists
    equipment = db.query(Equipment).filter(Equipment.id == equipment_id).first()
    if not equipment:
        raise HTTPException(status_code=404, detail="Equipment not found")
    
    # Calculate date range based on period
    today = date.today()
    if period == "week":
        start_date = today - timedelta(days=today.weekday())
    elif period == "month":
        start_date = date(today.year, today.month, 1)
    else:  # year
        start_date = date(today.year, 1, 1)
    
    # Get total hours for the period
    hours_entries = db.query(EquipmentRunningHours).filter(
        EquipmentRunningHours.equipment_id == equipment_id,
        EquipmentRunningHours.date >= start_date,
        EquipmentRunningHours.date <= today
    ).all()
    
    # Calculate summary
    total_period_hours = sum(entry.running_hours for entry in hours_entries)
    daily_average = total_period_hours / len(hours_entries) if hours_entries else 0
    
    return {
        "equipment_id": str(equipment_id),
        "equipment_name": equipment.equipment_name,
        "period": period,
        "start_date": start_date,
        "end_date": today,
        "total_period_hours": float(total_period_hours),
        "daily_average": float(daily_average),
        "total_running_hours": float(equipment.total_running_hours) if equipment.total_running_hours else 0,
        "entry_count": len(hours_entries)
    }
