from fastapi import APIRouter, HTTPException, Depends, Query
from typing import List, Optional
from ..database import supabase
from ..utils.security import get_current_user, require_roles
from ..utils.helpers import log_activity
from ..schemas.client import ClientCreate, ClientUpdate, ClientResponse

router = APIRouter(prefix="/clients", tags=["Clients"])


@router.get("/", response_model=List[ClientResponse])
async def get_clients(
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"])),
    status: Optional[str] = Query(None)
):
    """Get all clients. MASTER and STAFF only."""
    try:
        query = supabase.table("clients").select("*")
        
        if status:
            query = query.eq("status", status)
        
        res = query.order("created_at", desc=True).execute()
        return res.data
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{client_id}", response_model=ClientResponse)
async def get_client(
    client_id: str,
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"]))
):
    """Get a specific client."""
    try:
        res = supabase.table("clients").select("*").eq("id", client_id).execute()
        
        if not res.data:
            raise HTTPException(status_code=404, detail="Client not found")
        
        return res.data[0]
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/", response_model=ClientResponse)
async def create_client(
    client: ClientCreate,
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"]))
):
    """Create a new client. MASTER and STAFF only."""
    try:
        res = supabase.table("clients").insert(client.dict()).execute()
        
        if not res.data:
            raise HTTPException(status_code=400, detail="Failed to create client")
        
        await log_activity(current_user["id"], "CREATE_CLIENT", "CLIENTS")
        return res.data[0]
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/{client_id}", response_model=ClientResponse)
async def update_client(
    client_id: str,
    client: ClientUpdate,
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"]))
):
    """Update a client."""
    try:
        update_data = {k: v for k, v in client.dict().items() if v is not None}
        
        if not update_data:
            raise HTTPException(status_code=400, detail="No data to update")
        
        res = supabase.table("clients").update(update_data).eq("id", client_id).execute()
        
        if not res.data:
            raise HTTPException(status_code=404, detail="Client not found")
        
        await log_activity(current_user["id"], "UPDATE_CLIENT", "CLIENTS")
        return res.data[0]
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/{client_id}")
async def delete_client(
    client_id: str,
    current_user: dict = Depends(require_roles(["MASTER"]))
):
    """Delete a client. MASTER only."""
    try:
        supabase.table("clients").delete().eq("id", client_id).execute()
        await log_activity(current_user["id"], "DELETE_CLIENT", "CLIENTS")
        return {"message": "Client deleted successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{client_id}/ships", response_model=List[dict])
async def get_client_ships(
    client_id: str,
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"]))
):
    """Get all ships for a client."""
    try:
        res = supabase.table("ships").select("*").eq("client_id", client_id).execute()
        return res.data
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
