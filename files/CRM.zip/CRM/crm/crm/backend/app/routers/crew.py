from fastapi import APIRouter, HTTPException, Depends, Query
from typing import List, Optional
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import desc
import uuid
from datetime import datetime, timedelta

from ..database import get_db
from ..models.profile import Profile
from ..models.users import User
from ..models.crew_profile import CrewProfile, CrewCertificate
from ..models.ship import Ship
from ..utils.security import get_current_user, require_roles, get_password_hash
from ..utils.helpers import log_activity
from ..schemas.crew import (
    CrewProfileCreate, CrewProfileUpdate, CrewMemberResponse,
    CrewCreateRequest, CrewCertificateResponse
)

router = APIRouter(prefix="/crew", tags=["Crew"])


@router.post("", response_model=CrewMemberResponse)
async def create_crew_member(
    crew_data: CrewCreateRequest,
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"])),
    db: Session = Depends(get_db)
):
    """Create a new crew member. MASTER and STAFF only."""
    try:
        # Check if email already exists
        existing_user = db.query(User).filter(User.email == crew_data.email).first()
        if existing_user:
            raise HTTPException(status_code=400, detail="Email already registered")
        
        # Create new user
        new_user = User(
            id=uuid.uuid4(),
            email=crew_data.email,
            password=get_password_hash(crew_data.password),
            is_active=True
        )
        db.add(new_user)
        db.flush()  # Get the user ID without committing
        
        # Create profile with CREW role
        new_profile = Profile(
            id=new_user.id,  # Same ID as user
            user_id=new_user.id,
            name=crew_data.name,
            role="CREW",
            ship_id=crew_data.ship_id,
            nationality=crew_data.nationality,
            sea_time=crew_data.sea_time,
            availability="AVAILABLE" if not crew_data.ship_id else "ONBOARD",
            status="ACTIVE"
        )
        db.add(new_profile)
        db.flush()
        
        # Create crew profile with additional details
        new_crew_profile = CrewProfile(
            id=uuid.uuid4(),
            user_id=new_profile.id,  # Changed from new_user.id to new_profile.id (references profiles table)
            rank=crew_data.rank,
            department=crew_data.department,
            job_description=crew_data.job_description,
            join_date=crew_data.join_date or datetime.now().date(),
            contract_duration=crew_data.contract_duration,
            contract_end_date=(datetime.now() + timedelta(days=30*crew_data.contract_duration)).date() if crew_data.contract_duration else None,
            previous_experience=crew_data.previous_experience,
            emergency_contact_name=crew_data.emergency_contact_name,
            emergency_contact_number=crew_data.emergency_contact_number
        )
        db.add(new_crew_profile)
        db.flush()
        
        # Add certificates if provided
        if crew_data.certificates:
            for cert_data in crew_data.certificates:
                new_cert = CrewCertificate(
                    id=uuid.uuid4(),
                    crew_id=new_crew_profile.id,
                    name=cert_data.name,
                    certificate_number=cert_data.certificate_number,
                    issue_date=cert_data.issue_date,
                    expiry_date=cert_data.expiry_date,
                    issuing_authority=cert_data.issuing_authority,
                    document_url=cert_data.document_url
                )
                db.add(new_cert)
        
        # Commit all changes
        db.commit()
        
        # Log activity
        await log_activity(current_user["id"], "CREATE_CREW", "CREW", db=db)
        
        # Return new crew member details
        return await get_crew_member(str(new_user.id), current_user, db)
    except HTTPException:
        db.rollback()
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/", response_model=List[CrewMemberResponse])
async def get_crew_members(
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"])),
    ship_id: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    availability: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """Get all crew members. MASTER and STAFF only."""
    try:
        # Start query for profiles with CREW role
        query = db.query(Profile).filter(Profile.role == "CREW")
        
        # Apply filters
        if ship_id:
            query = query.filter(Profile.ship_id == uuid.UUID(ship_id))
        if status:
            query = query.filter(Profile.status == status)
        if availability:
            query = query.filter(Profile.availability == availability)
        
        # Order by created_at desc
        profiles = query.order_by(desc(Profile.created_at)).all()
        
        # Get crew profiles for these users
        crew_profiles = {}
        profile_ids = [str(p.id) for p in profiles]
        
        if profile_ids:
            crew_data = db.query(CrewProfile).filter(CrewProfile.user_id.in_([uuid.UUID(pid) for pid in profile_ids])).all()
            for crew in crew_data:
                crew_profiles[str(crew.user_id)] = crew
        
        # Construct response
        crew_list = []
        for profile in profiles:
            crew_profile = crew_profiles.get(str(profile.id))
            crew_data = {
                "id": str(profile.id),
                "name": profile.name,
                "role": profile.role,
                "ship_id": str(profile.ship_id) if profile.ship_id else None,
                "nationality": profile.nationality,
                "availability": profile.availability,
                "sea_time": profile.sea_time,
                "status": profile.status,
                "created_at": profile.created_at,
                "rank": crew_profile.rank if crew_profile else None,
                "join_date": crew_profile.join_date if crew_profile else None
            }
            crew_list.append(crew_data)
        
        return crew_list
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{crew_id}", response_model=CrewMemberResponse)
async def get_crew_member(
    crew_id: str,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get a specific crew member."""
    try:
        # CREW can only view their own profile
        if current_user["role"] == "CREW" and current_user["id"] != crew_id:
            raise HTTPException(status_code=403, detail="Access denied")
        
        # Get profile with user email
        profile = db.query(Profile).join(User, User.id == Profile.id).add_columns(
            Profile.id, Profile.name, Profile.role, Profile.ship_id, 
            Profile.nationality, Profile.availability, Profile.sea_time, 
            Profile.status, Profile.created_at, User.email
        ).filter(Profile.id == uuid.UUID(crew_id)).first()
        
        if not profile:
            raise HTTPException(status_code=404, detail="Crew member not found")
        
        # Get crew profile
        crew_profile = db.query(CrewProfile).filter(CrewProfile.user_id == uuid.UUID(crew_id)).first()
        
        # Get certificates if crew profile exists
        certificates = []
        if crew_profile:
            cert_records = db.query(CrewCertificate).filter(CrewCertificate.crew_id == crew_profile.id).all()
            certificates = [
                {
                    "id": str(cert.id),
                    "crew_id": str(cert.crew_id),
                    "name": cert.name,
                    "certificate_number": cert.certificate_number,
                    "issue_date": cert.issue_date,
                    "expiry_date": cert.expiry_date,
                    "issuing_authority": cert.issuing_authority,
                    "document_url": cert.document_url,
                    "created_at": cert.created_at
                } for cert in cert_records
            ]
        
        # Construct response
        crew_data = {
            "id": str(profile.id),
            "name": profile.name,
            "email": profile.email,
            "role": profile.role,
            "ship_id": str(profile.ship_id) if profile.ship_id else None,
            "nationality": profile.nationality,
            "availability": profile.availability,
            "sea_time": profile.sea_time,
            "status": profile.status,
            "created_at": profile.created_at,
            "rank": crew_profile.rank if crew_profile else None,
            "join_date": crew_profile.join_date if crew_profile else None,
            "department": crew_profile.department if crew_profile else None,
            "job_description": crew_profile.job_description if crew_profile else None,
            "contract_duration": crew_profile.contract_duration if crew_profile else None,
            "previous_experience": crew_profile.previous_experience if crew_profile else None,
            "emergency_contact_name": crew_profile.emergency_contact_name if crew_profile else None,
            "emergency_contact_number": crew_profile.emergency_contact_number if crew_profile else None,
            "certificates": certificates
        }
        
        return crew_data
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/{crew_id}", response_model=CrewMemberResponse)
async def update_crew_member(
    crew_id: str,
    update_data: CrewProfileUpdate,
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"])),
    db: Session = Depends(get_db)
):
    """Update crew member profile. MASTER and STAFF only."""
    try:
        data = {k: v for k, v in update_data.dict().items() if v is not None}
        
        if not data:
            raise HTTPException(status_code=400, detail="No data to update")
        
        # Get crew profile
        crew_profile = db.query(CrewProfile).filter(CrewProfile.user_id == uuid.UUID(crew_id)).first()
        
        if not crew_profile:
            # Create crew profile if it doesn't exist
            crew_profile = CrewProfile(
                user_id=uuid.UUID(crew_id),
                **data
            )
            db.add(crew_profile)
        else:
            # Update crew profile
            for key, value in data.items():
                setattr(crew_profile, key, value)
        
        # Commit changes
        db.commit()
        
        # Log activity
        await log_activity(current_user["id"], "UPDATE_CREW", "CREW", db=db)
        
        # Return updated crew member
        return await get_crew_member(crew_id, current_user, db)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/{crew_id}/assign")
async def assign_crew_to_ship(
    crew_id: str,
    ship_id: str,
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"])),
    db: Session = Depends(get_db)
):
    """Assign a crew member to a ship."""
    try:
        # Verify ship exists
        ship = db.query(Ship).filter(Ship.id == uuid.UUID(ship_id)).first()
        if not ship:
            raise HTTPException(status_code=404, detail="Ship not found")
        
        # Get crew profile
        profile = db.query(Profile).filter(Profile.id == uuid.UUID(crew_id)).first()
        if not profile:
            raise HTTPException(status_code=404, detail="Crew member not found")
        
        # Update profile with ship assignment
        profile.ship_id = uuid.UUID(ship_id)
        profile.availability = "ONBOARD"
        
        # Commit changes
        db.commit()
        
        # Log activity
        await log_activity(current_user["id"], "ASSIGN_CREW", "CREW", db=db)
        
        return {"message": "Crew member assigned successfully"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/{crew_id}/unassign")
async def unassign_crew_from_ship(
    crew_id: str,
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"])),
    db: Session = Depends(get_db)
):
    """Remove a crew member from their assigned ship."""
    try:
        # Get crew profile
        profile = db.query(Profile).filter(Profile.id == uuid.UUID(crew_id)).first()
        if not profile:
            raise HTTPException(status_code=404, detail="Crew member not found")
        
        # Update profile
        profile.ship_id = None
        profile.availability = "AVAILABLE"
        
        # Commit changes
        db.commit()
        
        # Log activity
        await log_activity(current_user["id"], "UNASSIGN_CREW", "CREW", db=db)
        
        return {"message": "Crew member unassigned successfully"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
