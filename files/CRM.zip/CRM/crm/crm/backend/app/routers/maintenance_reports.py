from fastapi import APIRouter, HTTPException, status, Depends, Query
from sqlalchemy.orm import Session
from typing import List, Optional, Dict, Any
import uuid
from datetime import date, datetime

from ..database import get_db
from ..models.maintenance_report import MaintenanceReport, MaintenanceReportType
from ..models.equipment import Equipment
from ..models.ship import Ship
from ..schemas.maintenance_report import (
    MaintenanceReportCreate, MaintenanceReportUpdate, MaintenanceReport as MaintenanceReportSchema,
    MaintenanceReportWithType, MaintenanceReportType as MaintenanceReportTypeSchema
)
from ..utils.security import get_current_user, require_roles

router = APIRouter(prefix="/maintenance-reports", tags=["Maintenance Reports"])


@router.get("/types", response_model=List[MaintenanceReportTypeSchema])
async def get_report_types(
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get all available maintenance report types"""
    report_types = db.query(MaintenanceReportType).all()
    return report_types


@router.post("", response_model=MaintenanceReportSchema)
async def create_maintenance_report(
    report: MaintenanceReportCreate,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Create a new maintenance report"""
    # Verify user has appropriate role
    if current_user["role"] not in ["MASTER", "STAFF", "CREW"]:
        raise HTTPException(status_code=403, detail="Not authorized to create maintenance reports")
    
    # Check if ship exists
    ship = db.query(Ship).filter(Ship.id == report.ship_id).first()
    if not ship:
        raise HTTPException(status_code=404, detail="Ship not found")
    
    # Check if report type exists
    report_type = db.query(MaintenanceReportType).filter(
        MaintenanceReportType.id == report.report_type_id
    ).first()
    if not report_type:
        raise HTTPException(status_code=404, detail="Report type not found")
    
    # Check if equipment exists if provided
    if report.equipment_id:
        equipment = db.query(Equipment).filter(Equipment.id == report.equipment_id).first()
        if not equipment:
            raise HTTPException(status_code=404, detail="Equipment not found")
    
    # Create maintenance report
    db_report = MaintenanceReport(
        report_type_id=report.report_type_id,
        ship_id=report.ship_id,
        equipment_id=report.equipment_id,
        report_date=report.report_date,
        report_data=report.report_data,
        remarks=report.remarks,
        status=report.status,
        created_by=uuid.UUID(current_user["id"])
    )
    
    db.add(db_report)
    db.commit()
    db.refresh(db_report)
    
    return db_report


@router.get("", response_model=List[MaintenanceReportSchema])
async def get_maintenance_reports(
    ship_id: Optional[uuid.UUID] = None,
    equipment_id: Optional[uuid.UUID] = None,
    report_type_id: Optional[uuid.UUID] = None,
    status: Optional[str] = None,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    skip: int = 0,
    limit: int = 100,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get maintenance reports with optional filtering
    - ship_id: Filter by ship
    - equipment_id: Filter by equipment
    - report_type_id: Filter by report type
    - status: Filter by status (DRAFT, SUBMITTED, APPROVED)
    - start_date: Filter by start date (inclusive)
    - end_date: Filter by end date (inclusive)
    """
    query = db.query(MaintenanceReport)
    
    # Apply filters
    if ship_id:
        query = query.filter(MaintenanceReport.ship_id == ship_id)
    
    if equipment_id:
        query = query.filter(MaintenanceReport.equipment_id == equipment_id)
    
    if report_type_id:
        query = query.filter(MaintenanceReport.report_type_id == report_type_id)
    
    if status:
        query = query.filter(MaintenanceReport.status == status)
    
    if start_date:
        query = query.filter(MaintenanceReport.report_date >= start_date)
    
    if end_date:
        query = query.filter(MaintenanceReport.report_date <= end_date)
    
    # Order by date desc
    query = query.order_by(MaintenanceReport.report_date.desc())
    
    # Apply pagination
    reports = query.offset(skip).limit(limit).all()
    
    return reports


@router.get("/{report_id}", response_model=MaintenanceReportWithType)
async def get_maintenance_report(
    report_id: uuid.UUID,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get a specific maintenance report by ID, including its report type"""
    report = db.query(MaintenanceReport).filter(MaintenanceReport.id == report_id).first()
    
    if not report:
        raise HTTPException(status_code=404, detail="Maintenance report not found")
    
    return report


@router.put("/{report_id}", response_model=MaintenanceReportSchema)
async def update_maintenance_report(
    report_id: uuid.UUID,
    report_update: MaintenanceReportUpdate,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Update a maintenance report"""
    # Get existing report
    db_report = db.query(MaintenanceReport).filter(MaintenanceReport.id == report_id).first()
    
    if not db_report:
        raise HTTPException(status_code=404, detail="Maintenance report not found")
    
    # Check authorization based on roles and report status
    if current_user["role"] not in ["MASTER", "STAFF"]:
        # Crew can only update their own DRAFT reports
        if db_report.created_by != uuid.UUID(current_user["id"]) or db_report.status != "DRAFT":
            raise HTTPException(
                status_code=403, 
                detail="Not authorized to update this maintenance report"
            )
    
    # Check if report type exists if provided
    if report_update.report_type_id:
        report_type = db.query(MaintenanceReportType).filter(
            MaintenanceReportType.id == report_update.report_type_id
        ).first()
        if not report_type:
            raise HTTPException(status_code=404, detail="Report type not found")
    
    # Check if equipment exists if provided
    if report_update.equipment_id:
        equipment = db.query(Equipment).filter(Equipment.id == report_update.equipment_id).first()
        if not equipment:
            raise HTTPException(status_code=404, detail="Equipment not found")
    
    # If status is being updated to APPROVED, only MASTER/STAFF can approve
    if (report_update.status == "APPROVED" and current_user["role"] not in ["MASTER", "STAFF"]):
        raise HTTPException(
            status_code=403, 
            detail="Only MASTER or STAFF can approve reports"
        )
    
    # Update report
    update_data = report_update.dict(exclude_unset=True)
    for key, value in update_data.items():
        setattr(db_report, key, value)
    
    # If status is being updated to APPROVED, set approved_by
    if report_update.status == "APPROVED" and db_report.approved_by is None:
        db_report.approved_by = uuid.UUID(current_user["id"])
    
    # Update the updated_at timestamp
    db_report.updated_at = datetime.now()
    
    db.commit()
    db.refresh(db_report)
    
    return db_report


@router.delete("/{report_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_maintenance_report(
    report_id: uuid.UUID,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Delete a maintenance report"""
    # Get existing report
    db_report = db.query(MaintenanceReport).filter(MaintenanceReport.id == report_id).first()
    
    if not db_report:
        raise HTTPException(status_code=404, detail="Maintenance report not found")
    
    # Check authorization based on roles and report status
    if current_user["role"] not in ["MASTER", "STAFF"]:
        # Crew can only delete their own DRAFT reports
        if db_report.created_by != uuid.UUID(current_user["id"]) or db_report.status != "DRAFT":
            raise HTTPException(
                status_code=403, 
                detail="Not authorized to delete this maintenance report"
            )
    
    # Delete report
    db.delete(db_report)
    db.commit()
    
    return None
