from fastapi import APIRouter, HTTPException, Depends, Query
from typing import List, Optional
from ..database import supabase
from ..utils.security import get_current_user, require_roles
from ..utils.helpers import log_activity
from ..schemas.pms import (
    EquipmentCreate, EquipmentUpdate, EquipmentResponse,
    PMSTaskCreate, PMSTaskUpdate, PMSTaskResponse,
    PMSLogCreate, PMSLogApproval, PMSLogResponse
)

router = APIRouter(prefix="/pms", tags=["PMS"])


# Equipment endpoints
@router.get("/equipment", response_model=List[EquipmentResponse])
async def get_equipment(
    current_user: dict = Depends(get_current_user),
    ship_id: Optional[str] = Query(None)
):
    """Get all equipment."""
    try:
        query = supabase.table("equipments").select("*")
        
        if ship_id:
            query = query.eq("ship_id", ship_id)
        elif current_user["role"] == "CREW" and current_user.get("ship_id"):
            query = query.eq("ship_id", current_user["ship_id"])
        
        res = query.order("created_at", desc=True).execute()
        return res.data
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/equipment", response_model=EquipmentResponse)
async def create_equipment(
    equipment: EquipmentCreate,
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"]))
):
    """Create new equipment. MASTER and STAFF only."""
    try:
        res = supabase.table("equipments").insert(equipment.dict()).execute()
        
        if not res.data:
            raise HTTPException(status_code=400, detail="Failed to create equipment")
        
        await log_activity(current_user["id"], "CREATE_EQUIPMENT", "PMS")
        return res.data[0]
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/equipment/{equipment_id}", response_model=EquipmentResponse)
async def update_equipment(
    equipment_id: str,
    equipment: EquipmentUpdate,
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"]))
):
    """Update equipment. MASTER and STAFF only."""
    try:
        update_data = {k: v for k, v in equipment.dict().items() if v is not None}
        res = supabase.table("equipments").update(update_data).eq("id", equipment_id).execute()
        
        if not res.data:
            raise HTTPException(status_code=404, detail="Equipment not found")
        
        return res.data[0]
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/equipment/{equipment_id}")
async def delete_equipment(
    equipment_id: str,
    current_user: dict = Depends(require_roles(["MASTER"]))
):
    """Delete equipment. MASTER only."""
    try:
        supabase.table("equipments").delete().eq("id", equipment_id).execute()
        return {"message": "Equipment deleted successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# PMS Task endpoints
@router.get("/tasks", response_model=List[PMSTaskResponse])
async def get_tasks(
    current_user: dict = Depends(get_current_user),
    equipment_id: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    assigned_to: Optional[str] = Query(None),
    frequency: Optional[str] = Query(None)
):
    """Get all PMS tasks."""
    try:
        query = supabase.table("pms_tasks").select("*")
        
        if equipment_id:
            query = query.eq("equipment_id", equipment_id)
        if status:
            query = query.eq("status", status)
        if assigned_to:
            query = query.eq("assigned_to", assigned_to)
        if frequency:
            query = query.eq("frequency", frequency)
        
        # CREW can only see tasks assigned to them
        if current_user["role"] == "CREW":
            query = query.eq("assigned_to", current_user["id"])
        
        res = query.order("due_date", desc=False).execute()
        return res.data
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/tasks/{task_id}", response_model=PMSTaskResponse)
async def get_task(task_id: str, current_user: dict = Depends(get_current_user)):
    """Get a specific PMS task."""
    try:
        res = supabase.table("pms_tasks").select("*").eq("id", task_id).execute()
        
        if not res.data:
            raise HTTPException(status_code=404, detail="Task not found")
        
        task = res.data[0]
        
        # CREW can only view their assigned tasks
        if current_user["role"] == "CREW" and task.get("assigned_to") != current_user["id"]:
            raise HTTPException(status_code=403, detail="Access denied")
        
        return task
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/tasks", response_model=PMSTaskResponse)
async def create_task(
    task: PMSTaskCreate,
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"]))
):
    """Create new PMS task. MASTER and STAFF only."""
    try:
        task_data = task.dict()
        task_data["due_date"] = str(task_data["due_date"])
        
        res = supabase.table("pms_tasks").insert(task_data).execute()
        
        if not res.data:
            raise HTTPException(status_code=400, detail="Failed to create task")
        
        await log_activity(current_user["id"], "CREATE_PMS_TASK", "PMS")
        return res.data[0]
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/tasks/{task_id}", response_model=PMSTaskResponse)
async def update_task(
    task_id: str,
    task: PMSTaskUpdate,
    current_user: dict = Depends(get_current_user)
):
    """Update a PMS task. CREW can only update status."""
    try:
        # Get existing task
        existing = supabase.table("pms_tasks").select("*").eq("id", task_id).execute()
        if not existing.data:
            raise HTTPException(status_code=404, detail="Task not found")
        
        existing_task = existing.data[0]
        
        # CREW can only update status of their assigned tasks
        if current_user["role"] == "CREW":
            if existing_task.get("assigned_to") != current_user["id"]:
                raise HTTPException(status_code=403, detail="Access denied")
            update_data = {"status": task.status} if task.status else {}
        else:
            update_data = {k: v for k, v in task.dict().items() if v is not None}
            if "due_date" in update_data and update_data["due_date"]:
                update_data["due_date"] = str(update_data["due_date"])
        
        if not update_data:
            raise HTTPException(status_code=400, detail="No data to update")
        
        res = supabase.table("pms_tasks").update(update_data).eq("id", task_id).execute()
        return res.data[0]
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/tasks/{task_id}")
async def delete_task(
    task_id: str,
    current_user: dict = Depends(require_roles(["MASTER"]))
):
    """Delete a PMS task. MASTER only."""
    try:
        supabase.table("pms_tasks").delete().eq("id", task_id).execute()
        return {"message": "Task deleted successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# PMS Log endpoints
@router.get("/logs", response_model=List[PMSLogResponse])
async def get_logs(
    current_user: dict = Depends(get_current_user),
    pms_task_id: Optional[str] = Query(None),
    crew_id: Optional[str] = Query(None),
    status: Optional[str] = Query(None)
):
    """Get all PMS logs."""
    try:
        query = supabase.table("pms_logs").select("*")
        
        if pms_task_id:
            query = query.eq("pms_task_id", pms_task_id)
        if crew_id:
            query = query.eq("crew_id", crew_id)
        if status:
            query = query.eq("status", status)
        
        # CREW can only see their own logs
        if current_user["role"] == "CREW":
            query = query.eq("crew_id", current_user["id"])
        
        res = query.order("created_at", desc=True).execute()
        return res.data
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/logs", response_model=PMSLogResponse)
async def create_log(
    log: PMSLogCreate,
    current_user: dict = Depends(get_current_user)
):
    """Submit a PMS completion log."""
    try:
        log_data = log.dict()
        log_data["crew_id"] = current_user["id"]
        
        res = supabase.table("pms_logs").insert(log_data).execute()
        
        if not res.data:
            raise HTTPException(status_code=400, detail="Failed to create log")
        
        await log_activity(current_user["id"], "CREATE_PMS_LOG", "PMS")
        return res.data[0]
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/logs/{log_id}/approve", response_model=PMSLogResponse)
async def approve_log(
    log_id: str,
    approval: PMSLogApproval,
    current_user: dict = Depends(require_roles(["MASTER"]))
):
    """Approve or reject a PMS log. MASTER only."""
    try:
        update_data = {
            "status": approval.status,
            "approved_by": current_user["id"]
        }
        
        res = supabase.table("pms_logs").update(update_data).eq("id", log_id).execute()
        
        if not res.data:
            raise HTTPException(status_code=404, detail="Log not found")
        
        await log_activity(current_user["id"], f"APPROVE_PMS_LOG_{approval.status}", "PMS")
        return res.data[0]
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
