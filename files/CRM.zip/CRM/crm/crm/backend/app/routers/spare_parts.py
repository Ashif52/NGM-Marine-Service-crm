from fastapi import APIRouter, HTTPException, status, Depends, Query
from sqlalchemy.orm import Session
from typing import List, Optional
import uuid
from datetime import datetime

from ..database import get_db
from ..models.spare_part import SparePart, SparePartTransaction
from ..schemas.spare_part import (
    SparePartCreate, SparePartUpdate, SparePart as SparePartSchema,
    SparePartTransactionCreate, SparePartTransaction as SparePartTransactionSchema
)
from ..utils.security import get_current_user, require_roles

router = APIRouter(prefix="/spare-parts", tags=["Spare Parts Management"])


@router.post("", response_model=SparePartSchema)
async def create_spare_part(
    spare_part: SparePartCreate,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Create a new spare part in inventory"""
    # Verify user has appropriate role
    if current_user["role"] not in ["MASTER", "STAFF"]:
        raise HTTPException(status_code=403, detail="Not authorized to manage spare parts")
    
    # Check if ship exists
    from ..models.ship import Ship
    ship = db.query(Ship).filter(Ship.id == spare_part.ship_id).first()
    if not ship:
        raise HTTPException(status_code=404, detail="Ship not found")
    
    # Check if equipment exists if equipment_id is provided
    if spare_part.equipment_id:
        from ..models.equipment import Equipment
        equipment = db.query(Equipment).filter(Equipment.id == spare_part.equipment_id).first()
        if not equipment:
            raise HTTPException(status_code=404, detail="Equipment not found")
    
    # Create new spare part
    db_spare_part = SparePart(
        **spare_part.dict()
    )
    
    db.add(db_spare_part)
    db.commit()
    db.refresh(db_spare_part)
    
    return db_spare_part


@router.get("", response_model=List[SparePartSchema])
async def get_spare_parts(
    ship_id: Optional[uuid.UUID] = None,
    equipment_id: Optional[uuid.UUID] = None,
    low_stock: bool = False,
    search: Optional[str] = None,
    skip: int = 0,
    limit: int = 100,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get spare parts with optional filtering
    - ship_id: Filter by ship
    - equipment_id: Filter by equipment
    - low_stock: Filter parts where quantity <= min_quantity
    - search: Search by part name or part number
    """
    query = db.query(SparePart)
    
    # Apply filters
    if ship_id:
        query = query.filter(SparePart.ship_id == ship_id)
    
    if equipment_id:
        query = query.filter(SparePart.equipment_id == equipment_id)
    
    if low_stock:
        query = query.filter(SparePart.quantity <= SparePart.min_quantity)
    
    if search:
        search_term = f"%{search}%"
        query = query.filter(
            (SparePart.part_name.ilike(search_term)) | 
            (SparePart.part_number.ilike(search_term))
        )
    
    # Apply pagination
    spare_parts = query.offset(skip).limit(limit).all()
    
    return spare_parts


@router.get("/{spare_part_id}", response_model=SparePartSchema)
async def get_spare_part(
    spare_part_id: uuid.UUID,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get a specific spare part by ID"""
    spare_part = db.query(SparePart).filter(SparePart.id == spare_part_id).first()
    
    if not spare_part:
        raise HTTPException(status_code=404, detail="Spare part not found")
    
    return spare_part


@router.put("/{spare_part_id}", response_model=SparePartSchema)
async def update_spare_part(
    spare_part_id: uuid.UUID,
    spare_part_update: SparePartUpdate,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Update a spare part"""
    # Verify user has appropriate role
    if current_user["role"] not in ["MASTER", "STAFF"]:
        raise HTTPException(status_code=403, detail="Not authorized to manage spare parts")
    
    # Get existing spare part
    db_spare_part = db.query(SparePart).filter(SparePart.id == spare_part_id).first()
    
    if not db_spare_part:
        raise HTTPException(status_code=404, detail="Spare part not found")
    
    # Check if equipment exists if equipment_id is provided
    if spare_part_update.equipment_id:
        from ..models.equipment import Equipment
        equipment = db.query(Equipment).filter(Equipment.id == spare_part_update.equipment_id).first()
        if not equipment:
            raise HTTPException(status_code=404, detail="Equipment not found")
    
    # Update spare part
    update_data = spare_part_update.dict(exclude_unset=True)
    for key, value in update_data.items():
        setattr(db_spare_part, key, value)
    
    # Update the updated_at timestamp
    db_spare_part.updated_at = datetime.now()
    
    db.commit()
    db.refresh(db_spare_part)
    
    return db_spare_part


@router.delete("/{spare_part_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_spare_part(
    spare_part_id: uuid.UUID,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Delete a spare part"""
    # Verify user has appropriate role
    if current_user["role"] not in ["MASTER", "STAFF"]:
        raise HTTPException(status_code=403, detail="Not authorized to manage spare parts")
    
    # Get existing spare part
    db_spare_part = db.query(SparePart).filter(SparePart.id == spare_part_id).first()
    
    if not db_spare_part:
        raise HTTPException(status_code=404, detail="Spare part not found")
    
    # Check if there are any transactions for this spare part
    transactions = db.query(SparePartTransaction).filter(
        SparePartTransaction.spare_part_id == spare_part_id
    ).count()
    
    if transactions > 0:
        raise HTTPException(
            status_code=400, 
            detail="Cannot delete spare part with transaction history. Consider updating quantity to zero instead."
        )
    
    db.delete(db_spare_part)
    db.commit()
    
    return None


@router.post("/transactions", response_model=SparePartTransactionSchema)
async def create_spare_part_transaction(
    transaction: SparePartTransactionCreate,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Record a spare part transaction (receipt, usage, or adjustment)"""
    # Verify user has appropriate role
    if current_user["role"] not in ["MASTER", "STAFF", "CREW"]:
        raise HTTPException(status_code=403, detail="Not authorized to record spare part transactions")
    
    # Validate transaction type
    valid_types = ["RECEIPT", "USAGE", "ADJUSTMENT"]
    if transaction.transaction_type not in valid_types:
        raise HTTPException(
            status_code=400, 
            detail=f"Invalid transaction type. Must be one of: {', '.join(valid_types)}"
        )
    
    # Get spare part
    spare_part = db.query(SparePart).filter(SparePart.id == transaction.spare_part_id).first()
    
    if not spare_part:
        raise HTTPException(status_code=404, detail="Spare part not found")
    
    # Create transaction
    db_transaction = SparePartTransaction(
        spare_part_id=transaction.spare_part_id,
        transaction_type=transaction.transaction_type,
        quantity=transaction.quantity,
        reference_number=transaction.reference_number,
        remarks=transaction.remarks,
        created_by=uuid.UUID(current_user["id"])
    )
    
    # Update spare part quantity
    if transaction.transaction_type == "RECEIPT":
        spare_part.quantity += transaction.quantity
        spare_part.last_ordered_date = datetime.now().date()
    elif transaction.transaction_type == "USAGE":
        if spare_part.quantity < transaction.quantity:
            raise HTTPException(status_code=400, detail="Insufficient quantity in inventory")
        spare_part.quantity -= transaction.quantity
    else:  # ADJUSTMENT
        spare_part.quantity = transaction.quantity
    
    # Update the spare part's updated_at timestamp
    spare_part.updated_at = datetime.now()
    
    db.add(db_transaction)
    db.commit()
    db.refresh(db_transaction)
    
    return db_transaction


@router.get("/transactions/{spare_part_id}", response_model=List[SparePartTransactionSchema])
async def get_spare_part_transactions(
    spare_part_id: uuid.UUID,
    skip: int = 0,
    limit: int = 100,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get transaction history for a specific spare part"""
    # Check if spare part exists
    spare_part = db.query(SparePart).filter(SparePart.id == spare_part_id).first()
    
    if not spare_part:
        raise HTTPException(status_code=404, detail="Spare part not found")
    
    # Get transactions
    transactions = db.query(SparePartTransaction).filter(
        SparePartTransaction.spare_part_id == spare_part_id
    ).order_by(
        SparePartTransaction.created_at.desc()
    ).offset(skip).limit(limit).all()
    
    return transactions
