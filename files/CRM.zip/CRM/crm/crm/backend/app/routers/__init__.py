from . import auth, ships, crew, work_logs  # pms, invoices, documents, clients, recruitment, dashboard
