from fastapi import APIRouter, HTTPException, status, Depends
from sqlalchemy.orm import Session
from typing import List
import uuid
from datetime import datetime

from ..database import get_db
from ..models.users import User
from ..models.profile import Profile
from ..models.crew_profile import CrewProfile
from ..utils.security import create_access_token, get_current_user, get_password_hash, verify_password, require_roles
from ..utils.helpers import log_activity
from ..schemas.auth import UserLogin, UserCreate, UserResponse, Token, ProfileUpdate, UserAdminUpdate
from ..config import settings

router = APIRouter(prefix="/auth", tags=["Authentication"])


@router.post("/signup", response_model=Token)
async def signup(user_data: UserCreate, db: Session = Depends(get_db)):
    """Register a new user and create profile."""
    try:
        # Validate role
        allowed_roles = ["MASTER", "STAFF", "CREW"]
        if user_data.role.upper() not in allowed_roles:
            raise HTTPException(status_code=400, detail=f"Invalid role. Must be one of: {', '.join(allowed_roles)}")
        
        # Ensure role is uppercase to match constraint
        user_data.role = user_data.role.upper()
        
        # Check if user already exists
        existing_user = db.query(User).filter(User.email == user_data.email).first()
        if existing_user:
            raise HTTPException(status_code=400, detail="Email already registered")
        
        # Generate UUID for user
        user_id = uuid.uuid4()
        
        # Create password hash
        hashed_password = get_password_hash(user_data.password)
        
        # Create new user
        user = User(
            id=user_id,
            email=user_data.email,
            password=hashed_password,
            is_active=True,
            created_at=datetime.now()
        )
        db.add(user)
        
        # Create profile
        profile = Profile(
            id=user_id,
            user_id=user_id,
            name=user_data.name,
            role=user_data.role,
            ship_id=uuid.UUID(user_data.ship_id) if user_data.ship_id else None,
            nationality=user_data.nationality,
            status="ACTIVE"
        )
        db.add(profile)
        
        # Create crew profile if CREW role
        if user_data.role == "CREW" and (user_data.rank or user_data.join_date):
            crew_profile = CrewProfile(
                user_id=user_id,
                rank=user_data.rank,
                join_date=user_data.join_date,
                created_at=datetime.now()
            )
            db.add(crew_profile)
        
        # Commit changes to database
        db.commit()
        
        # Create access token
        access_token = create_access_token(
            subject=str(user_id),
            additional_data={
                "role": user_data.role,
                "ship_id": user_data.ship_id,
                "name": user_data.name
            }
        )
        
        return {
            "access_token": access_token,
            "token_type": "bearer",
            "user": {
                "id": str(user_id),
                "email": user_data.email,
                "name": user_data.name,
                "role": user_data.role,
                "ship_id": user_data.ship_id,
                "nationality": user_data.nationality,
                "status": "ACTIVE",
                "availability": "AVAILABLE"
            }
        }
    except Exception as e:
        db.rollback()
        # Provide more detailed error message
        error_detail = str(e)
        # Log the error for debugging
        print(f"Signup error: {error_detail}")
        raise HTTPException(status_code=400, detail=error_detail)


@router.post("/login", response_model=Token)
async def login(credentials: UserLogin, db: Session = Depends(get_db)):
    """Login and get access token."""
    try:
        # Find user by email
        user = db.query(User).filter(User.email == credentials.email).first()
        
        if not user or not verify_password(credentials.password, user.password):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Incorrect email or password",
                headers={"WWW-Authenticate": "Bearer"},
            )
        
        # Get profile
        profile = db.query(Profile).filter(Profile.id == user.id).first()
        
        if not profile or profile.status != "ACTIVE":
            raise HTTPException(status_code=401, detail="User account is inactive")
        
        # Update last login
        user.last_login = datetime.now()
        db.commit()
        
        # Log activity
        await log_activity(str(user.id), "LOGIN", "AUTH")
        
        # Create access token
        access_token = create_access_token(
            subject=str(user.id),
            additional_data={
                "role": profile.role,
                "ship_id": str(profile.ship_id) if profile.ship_id else None,
                "name": profile.name
            }
        )
        
        return {
            "access_token": access_token,
            "token_type": "bearer",
            "user": {
                "id": str(user.id),
                "email": user.email,
                "name": profile.name,
                "role": profile.role,
                "ship_id": str(profile.ship_id) if profile.ship_id else None,
                "nationality": profile.nationality,
                "availability": profile.availability,
                "status": profile.status
            }
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=401, detail="Invalid credentials")


@router.get("/me", response_model=UserResponse)
async def get_me(current_user: dict = Depends(get_current_user), db: Session = Depends(get_db)):
    """Get current user profile."""
    try:
        # Get user and profile from database
        user_id = current_user["id"]
        user = db.query(User).filter(User.id == user_id).first()
        profile = db.query(Profile).filter(Profile.id == user_id).first()
        
        if not profile:
            raise HTTPException(status_code=404, detail="Profile not found")
        
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        return {
            "id": str(user_id),
            "email": user.email,
            "name": profile.name,
            "role": profile.role,
            "ship_id": str(profile.ship_id) if profile.ship_id else None,
            "nationality": profile.nationality,
            "availability": profile.availability,
            "status": profile.status
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/users", response_model=List[UserResponse])
async def list_users(
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"])),
    db: Session = Depends(get_db)
):
    """List all users with their profiles. MASTER and STAFF only."""
    try:
        profiles = db.query(Profile).all()
        if not profiles:
            return []

        user_ids = [p.user_id for p in profiles]
        users = db.query(User).filter(User.id.in_(user_ids)).all()
        users_map = {u.id: u for u in users}

        results = []
        for profile in profiles:
            user = users_map.get(profile.user_id)
            if not user:
                continue

            results.append(
                {
                    "id": str(profile.id),
                    "email": user.email,
                    "name": profile.name,
                    "role": profile.role,
                    "ship_id": str(profile.ship_id) if profile.ship_id else None,
                    "nationality": profile.nationality,
                    "availability": profile.availability,
                    "status": profile.status,
                }
            )

        return results
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/users/{user_id}", response_model=UserResponse)
async def update_user_admin(
    user_id: str,
    update: UserAdminUpdate,
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"])),
    db: Session = Depends(get_db)
):
    """Update a user and profile by ID. MASTER and STAFF only."""
    try:
        try:
            uid = uuid.UUID(user_id)
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid user id")

        user = db.query(User).filter(User.id == uid).first()
        profile = db.query(Profile).filter(Profile.id == uid).first()

        if not user or not profile:
            raise HTTPException(status_code=404, detail="User not found")

        data = {k: v for k, v in update.dict().items() if v is not None}

        if "role" in data:
            role = data["role"].upper()
            allowed_roles = ["MASTER", "STAFF", "CREW"]
            if role not in allowed_roles:
                raise HTTPException(status_code=400, detail=f"Invalid role. Must be one of: {', '.join(allowed_roles)}")
            profile.role = role

        if "status" in data:
            profile.status = data["status"].upper()

        if "name" in data:
            profile.name = data["name"]

        if "email" in data:
            user.email = data["email"]

        db.commit()
        db.refresh(profile)
        db.refresh(user)

        return {
            "id": str(profile.id),
            "email": user.email,
            "name": profile.name,
            "role": profile.role,
            "ship_id": str(profile.ship_id) if profile.ship_id else None,
            "nationality": profile.nationality,
            "availability": profile.availability,
            "status": profile.status,
        }
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/profile", response_model=UserResponse)
async def update_profile(
    profile_update: ProfileUpdate,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Update current user profile."""
    try:
        # Filter out None values
        update_data = {k: v for k, v in profile_update.dict().items() if v is not None}
        
        if not update_data:
            raise HTTPException(status_code=400, detail="No data to update")
        
        # Convert ship_id to UUID if provided
        if "ship_id" in update_data and update_data["ship_id"]:
            update_data["ship_id"] = uuid.UUID(update_data["ship_id"])
        
        # Get user and profile from database
        user_id = current_user["id"]
        user = db.query(User).filter(User.id == user_id).first()
        profile = db.query(Profile).filter(Profile.id == user_id).first()
        
        if not profile:
            raise HTTPException(status_code=404, detail="Profile not found")
            
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        # Update profile
        for key, value in update_data.items():
            setattr(profile, key, value)
        
        # If email is being updated, update it in the User model too
        if "email" in update_data:
            user.email = update_data["email"]
        
        db.commit()
        
        return {
            "id": str(profile.id),
            "email": user.email,
            "name": profile.name,
            "role": profile.role,
            "ship_id": str(profile.ship_id) if profile.ship_id else None,
            "nationality": profile.nationality,
            "availability": profile.availability,
            "status": profile.status
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
