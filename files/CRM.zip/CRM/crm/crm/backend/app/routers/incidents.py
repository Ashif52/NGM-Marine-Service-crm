from fastapi import APIRouter, HTTPException, Depends, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime
from ..database import get_db
from ..models.incident import IncidentReport, AuditLog, IncidentStatus, AuditType
from ..utils.security import get_current_user, require_roles
from ..schemas.incidents import (
    IncidentCreate,
    IncidentResponse,
    IncidentUpdate,
    AuditCreate,
    AuditResponse
)

router = APIRouter(prefix="/incidents", tags=["Incidents"])

@router.get("/reports", response_model=List[IncidentResponse])
async def list_incidents(
    ship_id: Optional[str] = Query(None),
    status: Optional[IncidentStatus] = Query(None),
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """List all incident reports"""
    query = db.query(IncidentReport)
    
    if ship_id:
        query = query.filter(IncidentReport.ship_id == ship_id)
    if status:
        query = query.filter(IncidentReport.status == status)
    
    # CREW can only see incidents from their ship
    if current_user["role"] == "CREW":
        if not current_user.get("ship_id"):
            raise HTTPException(status_code=403, detail="No ship assigned")
        query = query.filter(IncidentReport.ship_id == current_user["ship_id"])
    
    return query.order_by(IncidentReport.created_at.desc()).all()

@router.post("/reports", response_model=IncidentResponse)
async def create_incident(
    incident: IncidentCreate,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Create a new incident report"""
    # CREW can only report for their ship
    if current_user["role"] == "CREW":
        if not current_user.get("ship_id"):
            raise HTTPException(status_code=403, detail="No ship assigned")
        if incident.ship_id != current_user["ship_id"]:
            raise HTTPException(status_code=403, detail="Can only report for assigned ship")
    
    db_incident = IncidentReport(
        **incident.dict(),
        reported_by=current_user["id"]
    )
    db.add(db_incident)
    db.commit()
    db.refresh(db_incident)
    return db_incident

@router.put("/reports/{incident_id}/close", response_model=IncidentResponse)
async def close_incident(
    incident_id: str,
    incident: IncidentUpdate,
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"])),
    db: Session = Depends(get_db)
):
    """Close an incident report (MASTER/STAFF only)"""
    db_incident = db.query(IncidentReport).filter(IncidentReport.id == incident_id).first()
    if not db_incident:
        raise HTTPException(status_code=404, detail="Incident not found")
    
    db_incident.status = IncidentStatus.CLOSED
    db_incident.corrective_action = incident.corrective_action
    db_incident.closed_by = current_user["id"]
    db_incident.closed_at = datetime.now()
    
    db.commit()
    db.refresh(db_incident)
    return db_incident

@router.get("/audits", response_model=List[AuditResponse])
async def list_audits(
    ship_id: Optional[str] = Query(None),
    audit_type: Optional[AuditType] = Query(None),
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"])),
    db: Session = Depends(get_db)
):
    """List all audit logs (MASTER/STAFF only)"""
    query = db.query(AuditLog)
    
    if ship_id:
        query = query.filter(AuditLog.ship_id == ship_id)
    if audit_type:
        query = query.filter(AuditLog.audit_type == audit_type)
    
    return query.order_by(AuditLog.audit_date.desc()).all()

@router.post("/audits", response_model=AuditResponse)
async def create_audit(
    audit: AuditCreate,
    current_user: dict = Depends(require_roles(["MASTER"])),
    db: Session = Depends(get_db)
):
    """Create a new audit log (MASTER only)"""
    db_audit = AuditLog(
        **audit.dict(),
        auditor=current_user["id"]
    )
    db.add(db_audit)
    db.commit()
    db.refresh(db_audit)
    return db_audit
