from fastapi import APIRouter, HTTPException, Depends, Query
from typing import List, Optional
from sqlalchemy.orm import Session
from sqlalchemy import desc
import uuid

from ..database import get_db
from ..models.daily_work_log import DailyWorkLog
from ..models.ship import Ship
from ..models.profile import Profile
from ..utils.security import get_current_user, require_roles
from ..utils.helpers import log_activity
from ..schemas.work_log import WorkLogCreate, WorkLogUpdate, WorkLogApproval, WorkLogResponse

router = APIRouter(prefix="/work-logs", tags=["Work Logs"])


@router.get("/", response_model=List[WorkLogResponse])
async def get_work_logs(
    current_user: dict = Depends(get_current_user),
    ship_id: Optional[str] = Query(None),
    crew_id: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    work_type: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """Get all daily work logs."""
    try:
        # Start with base query
        query = db.query(DailyWorkLog)
        
        # Apply filters
        if ship_id:
            query = query.filter(DailyWorkLog.ship_id == uuid.UUID(ship_id))
        if crew_id:
            query = query.filter(DailyWorkLog.crew_id == uuid.UUID(crew_id))
        if status:
            query = query.filter(DailyWorkLog.status == status)
        if work_type:
            query = query.filter(DailyWorkLog.work_type == work_type)
        
        # CREW can only see their own logs
        if current_user["role"] == "CREW":
            query = query.filter(DailyWorkLog.crew_id == uuid.UUID(current_user["id"]))
        
        # Order by created_at desc
        work_logs = query.order_by(desc(DailyWorkLog.created_at)).all()
        
        # Convert to response format
        return [{
            "id": str(log.id),
            "ship_id": str(log.ship_id) if log.ship_id else None,
            "crew_id": str(log.crew_id) if log.crew_id else None,
            "work_type": log.work_type,
            "description": log.description,
            "hours": float(log.hours) if log.hours else None,
            "photo_url": log.photo_url,
            "status": log.status,
            "approved_by": str(log.approved_by) if log.approved_by else None,
            "created_at": log.created_at
        } for log in work_logs]
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{log_id}", response_model=WorkLogResponse)
async def get_work_log(log_id: str, current_user: dict = Depends(get_current_user), db: Session = Depends(get_db)):
    """Get a specific work log."""
    try:
        # Get work log by id
        log = db.query(DailyWorkLog).filter(DailyWorkLog.id == uuid.UUID(log_id)).first()
        
        if not log:
            raise HTTPException(status_code=404, detail="Work log not found")
        
        # CREW can only view their own logs
        if current_user["role"] == "CREW" and str(log.crew_id) != current_user["id"]:
            raise HTTPException(status_code=403, detail="Access denied")
        
        # Convert to response format
        return {
            "id": str(log.id),
            "ship_id": str(log.ship_id) if log.ship_id else None,
            "crew_id": str(log.crew_id) if log.crew_id else None,
            "work_type": log.work_type,
            "description": log.description,
            "hours": float(log.hours) if log.hours else None,
            "photo_url": log.photo_url,
            "status": log.status,
            "approved_by": str(log.approved_by) if log.approved_by else None,
            "created_at": log.created_at
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/", response_model=WorkLogResponse)
async def create_work_log(
    log: WorkLogCreate,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Create a new daily work log."""
    try:
        log_data = log.dict()
        
        # Set crew_id to current user
        crew_id = uuid.UUID(current_user["id"])
        
        # If CREW, use their assigned ship
        if current_user["role"] == "CREW" and current_user.get("ship_id"):
            ship_id = uuid.UUID(current_user["ship_id"])
        else:
            ship_id = uuid.UUID(log_data["ship_id"])
        
        # Create new work log
        new_log = DailyWorkLog(
            id=uuid.uuid4(),
            crew_id=crew_id,
            ship_id=ship_id,
            work_type=log_data.get("work_type"),
            description=log_data.get("description"),
            hours=log_data.get("hours"),
            photo_url=log_data.get("photo_url"),
            status="PENDING"
        )
        
        # Add to database and commit
        db.add(new_log)
        db.commit()
        db.refresh(new_log)
        
        # Log activity
        await log_activity(current_user["id"], "CREATE_WORK_LOG", "WORK_LOGS", db=db)
        
        # Convert to response format
        return {
            "id": str(new_log.id),
            "ship_id": str(new_log.ship_id) if new_log.ship_id else None,
            "crew_id": str(new_log.crew_id) if new_log.crew_id else None,
            "work_type": new_log.work_type,
            "description": new_log.description,
            "hours": float(new_log.hours) if new_log.hours else None,
            "photo_url": new_log.photo_url,
            "status": new_log.status,
            "approved_by": str(new_log.approved_by) if new_log.approved_by else None,
            "created_at": new_log.created_at
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/{log_id}", response_model=WorkLogResponse)
async def update_work_log(
    log_id: str,
    log: WorkLogUpdate,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Update a work log. Only pending logs can be updated."""
    try:
        # Get existing log
        existing_log = db.query(DailyWorkLog).filter(DailyWorkLog.id == uuid.UUID(log_id)).first()
        if not existing_log:
            raise HTTPException(status_code=404, detail="Work log not found")
        
        # Check ownership for CREW
        if current_user["role"] == "CREW" and str(existing_log.crew_id) != current_user["id"]:
            raise HTTPException(status_code=403, detail="Access denied")
        
        # Can only update pending logs
        if existing_log.status != "PENDING":
            raise HTTPException(status_code=400, detail="Can only update pending logs")
        
        # Get data that is not None
        update_data = {k: v for k, v in log.dict().items() if v is not None}
        
        if not update_data:
            raise HTTPException(status_code=400, detail="No data to update")
        
        # Update log attributes
        for key, value in update_data.items():
            setattr(existing_log, key, value)
        
        # Commit changes
        db.commit()
        db.refresh(existing_log)
        
        # Log activity
        await log_activity(current_user["id"], "UPDATE_WORK_LOG", "WORK_LOGS", db=db)
        
        # Convert to response format
        return {
            "id": str(existing_log.id),
            "ship_id": str(existing_log.ship_id) if existing_log.ship_id else None,
            "crew_id": str(existing_log.crew_id) if existing_log.crew_id else None,
            "work_type": existing_log.work_type,
            "description": existing_log.description,
            "hours": float(existing_log.hours) if existing_log.hours else None,
            "photo_url": existing_log.photo_url,
            "status": existing_log.status,
            "approved_by": str(existing_log.approved_by) if existing_log.approved_by else None,
            "created_at": existing_log.created_at
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/{log_id}/approve", response_model=WorkLogResponse)
async def approve_work_log(
    log_id: str,
    approval: WorkLogApproval,
    current_user: dict = Depends(require_roles(["MASTER"])),
    db: Session = Depends(get_db)
):
    """Approve or reject a work log. MASTER only."""
    try:
        # Get existing log
        log = db.query(DailyWorkLog).filter(DailyWorkLog.id == uuid.UUID(log_id)).first()
        if not log:
            raise HTTPException(status_code=404, detail="Work log not found")
        
        # Update approval status
        log.status = approval.status
        log.approved_by = uuid.UUID(current_user["id"])
        
        # Commit changes
        db.commit()
        db.refresh(log)
        
        # Log activity
        await log_activity(current_user["id"], f"APPROVE_WORK_LOG_{approval.status}", "WORK_LOGS", db=db)
        
        # Convert to response format
        return {
            "id": str(log.id),
            "ship_id": str(log.ship_id) if log.ship_id else None,
            "crew_id": str(log.crew_id) if log.crew_id else None,
            "work_type": log.work_type,
            "description": log.description,
            "hours": float(log.hours) if log.hours else None,
            "photo_url": log.photo_url,
            "status": log.status,
            "approved_by": str(log.approved_by) if log.approved_by else None,
            "created_at": log.created_at
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/{log_id}")
async def delete_work_log(
    log_id: str,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Delete a work log. Only pending logs can be deleted."""
    try:
        # Get existing log
        log = db.query(DailyWorkLog).filter(DailyWorkLog.id == uuid.UUID(log_id)).first()
        if not log:
            raise HTTPException(status_code=404, detail="Work log not found")
        
        # Check ownership for CREW
        if current_user["role"] == "CREW" and str(log.crew_id) != current_user["id"]:
            raise HTTPException(status_code=403, detail="Access denied")
        
        # Can only delete pending logs (unless MASTER)
        if log.status != "PENDING" and current_user["role"] != "MASTER":
            raise HTTPException(status_code=400, detail="Can only delete pending logs")
        
        # Delete log
        db.delete(log)
        db.commit()
        
        # Log activity
        await log_activity(current_user["id"], "DELETE_WORK_LOG", "WORK_LOGS", db=db)
        
        return {"message": "Work log deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
