from fastapi import APIRouter, HTTPException, Depends, Query
from typing import List, Optional
from ..database import supabase
from ..utils.security import get_current_user, require_roles
from ..utils.helpers import log_activity
from ..schemas.invoice import InvoiceCreate, InvoiceUpdate, InvoiceApproval, InvoiceResponse

router = APIRouter(prefix="/invoices", tags=["Invoices"])


@router.get("/", response_model=List[InvoiceResponse])
async def get_invoices(
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"])),
    ship_id: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    category: Optional[str] = Query(None)
):
    """Get all invoices. MASTER and STAFF only."""
    try:
        query = supabase.table("invoices").select("*")
        
        if ship_id:
            query = query.eq("ship_id", ship_id)
        if status:
            query = query.eq("status", status)
        if category:
            query = query.eq("category", category)
        
        res = query.order("created_at", desc=True).execute()
        return res.data
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{invoice_id}", response_model=InvoiceResponse)
async def get_invoice(
    invoice_id: str,
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"]))
):
    """Get a specific invoice."""
    try:
        res = supabase.table("invoices").select("*").eq("id", invoice_id).execute()
        
        if not res.data:
            raise HTTPException(status_code=404, detail="Invoice not found")
        
        return res.data[0]
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/", response_model=InvoiceResponse)
async def create_invoice(
    invoice: InvoiceCreate,
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"]))
):
    """Create a new invoice. MASTER and STAFF only."""
    try:
        invoice_data = invoice.dict()
        invoice_data["uploaded_by"] = current_user["id"]
        if invoice_data.get("due_date"):
            invoice_data["due_date"] = str(invoice_data["due_date"])
        
        res = supabase.table("invoices").insert(invoice_data).execute()
        
        if not res.data:
            raise HTTPException(status_code=400, detail="Failed to create invoice")
        
        await log_activity(current_user["id"], "CREATE_INVOICE", "INVOICES")
        return res.data[0]
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/{invoice_id}", response_model=InvoiceResponse)
async def update_invoice(
    invoice_id: str,
    invoice: InvoiceUpdate,
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"]))
):
    """Update an invoice."""
    try:
        # Get existing invoice
        existing = supabase.table("invoices").select("*").eq("id", invoice_id).execute()
        if not existing.data:
            raise HTTPException(status_code=404, detail="Invoice not found")
        
        # STAFF can only update DRAFT invoices
        if current_user["role"] == "STAFF" and existing.data[0].get("status") != "DRAFT":
            raise HTTPException(status_code=403, detail="Can only update draft invoices")
        
        update_data = {k: v for k, v in invoice.dict().items() if v is not None}
        if "due_date" in update_data and update_data["due_date"]:
            update_data["due_date"] = str(update_data["due_date"])
        
        if not update_data:
            raise HTTPException(status_code=400, detail="No data to update")
        
        res = supabase.table("invoices").update(update_data).eq("id", invoice_id).execute()
        return res.data[0]
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/{invoice_id}/submit", response_model=InvoiceResponse)
async def submit_invoice(
    invoice_id: str,
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"]))
):
    """Submit an invoice for approval."""
    try:
        # Check if invoice is in DRAFT status
        existing = supabase.table("invoices").select("*").eq("id", invoice_id).execute()
        if not existing.data:
            raise HTTPException(status_code=404, detail="Invoice not found")
        
        if existing.data[0].get("status") != "DRAFT":
            raise HTTPException(status_code=400, detail="Only draft invoices can be submitted")
        
        res = supabase.table("invoices").update({"status": "SUBMITTED"}).eq("id", invoice_id).execute()
        
        await log_activity(current_user["id"], "SUBMIT_INVOICE", "INVOICES")
        return res.data[0]
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/{invoice_id}/approve", response_model=InvoiceResponse)
async def approve_invoice(
    invoice_id: str,
    approval: InvoiceApproval,
    current_user: dict = Depends(require_roles(["MASTER"]))
):
    """Approve, reject, or mark invoice as paid. MASTER only."""
    try:
        update_data = {
            "status": approval.status,
            "approved_by": current_user["id"]
        }
        
        res = supabase.table("invoices").update(update_data).eq("id", invoice_id).execute()
        
        if not res.data:
            raise HTTPException(status_code=404, detail="Invoice not found")
        
        await log_activity(current_user["id"], f"APPROVE_INVOICE_{approval.status}", "INVOICES")
        return res.data[0]
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/{invoice_id}")
async def delete_invoice(
    invoice_id: str,
    current_user: dict = Depends(require_roles(["MASTER"]))
):
    """Delete an invoice. MASTER only."""
    try:
        supabase.table("invoices").delete().eq("id", invoice_id).execute()
        await log_activity(current_user["id"], "DELETE_INVOICE", "INVOICES")
        return {"message": "Invoice deleted successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
