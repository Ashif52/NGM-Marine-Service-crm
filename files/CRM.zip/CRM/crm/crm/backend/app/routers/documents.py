from fastapi import APIRouter, HTTPException, Depends, Query
from typing import List, Optional
from ..database import supabase
from ..utils.security import get_current_user, require_roles
from ..utils.helpers import log_activity
from ..schemas.document import DocumentCreate, DocumentUpdate, DocumentResponse

router = APIRouter(prefix="/documents", tags=["Documents"])


@router.get("/", response_model=List[DocumentResponse])
async def get_documents(
    current_user: dict = Depends(get_current_user),
    ship_id: Optional[str] = Query(None),
    crew_id: Optional[str] = Query(None),
    document_type: Optional[str] = Query(None),
    status: Optional[str] = Query(None)
):
    """Get all documents."""
    try:
        query = supabase.table("documents").select("*")
        
        if ship_id:
            query = query.eq("ship_id", ship_id)
        if crew_id:
            query = query.eq("crew_id", crew_id)
        if document_type:
            query = query.eq("document_type", document_type)
        if status:
            query = query.eq("status", status)
        
        # CREW can only see documents for their ship or themselves
        if current_user["role"] == "CREW":
            if current_user.get("ship_id"):
                query = query.or_(f"ship_id.eq.{current_user['ship_id']},crew_id.eq.{current_user['id']}")
            else:
                query = query.eq("crew_id", current_user["id"])
        
        res = query.order("created_at", desc=True).execute()
        return res.data
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{document_id}", response_model=DocumentResponse)
async def get_document(document_id: str, current_user: dict = Depends(get_current_user)):
    """Get a specific document."""
    try:
        res = supabase.table("documents").select("*").eq("id", document_id).execute()
        
        if not res.data:
            raise HTTPException(status_code=404, detail="Document not found")
        
        return res.data[0]
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/", response_model=DocumentResponse)
async def create_document(
    document: DocumentCreate,
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"]))
):
    """Create a new document. MASTER and STAFF only."""
    try:
        doc_data = document.dict()
        doc_data["uploaded_by"] = current_user["id"]
        if doc_data.get("expiry_date"):
            doc_data["expiry_date"] = str(doc_data["expiry_date"])
        
        res = supabase.table("documents").insert(doc_data).execute()
        
        if not res.data:
            raise HTTPException(status_code=400, detail="Failed to create document")
        
        await log_activity(current_user["id"], "CREATE_DOCUMENT", "DOCUMENTS")
        return res.data[0]
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/{document_id}", response_model=DocumentResponse)
async def update_document(
    document_id: str,
    document: DocumentUpdate,
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"]))
):
    """Update a document."""
    try:
        update_data = {k: v for k, v in document.dict().items() if v is not None}
        if "expiry_date" in update_data and update_data["expiry_date"]:
            update_data["expiry_date"] = str(update_data["expiry_date"])
        
        if not update_data:
            raise HTTPException(status_code=400, detail="No data to update")
        
        res = supabase.table("documents").update(update_data).eq("id", document_id).execute()
        
        if not res.data:
            raise HTTPException(status_code=404, detail="Document not found")
        
        return res.data[0]
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/{document_id}")
async def delete_document(
    document_id: str,
    current_user: dict = Depends(require_roles(["MASTER"]))
):
    """Delete a document. MASTER only."""
    try:
        supabase.table("documents").delete().eq("id", document_id).execute()
        await log_activity(current_user["id"], "DELETE_DOCUMENT", "DOCUMENTS")
        return {"message": "Document deleted successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/expiring/soon", response_model=List[DocumentResponse])
async def get_expiring_documents(
    current_user: dict = Depends(require_roles(["MASTER", "STAFF"])),
    days: int = Query(30, description="Days until expiry")
):
    """Get documents expiring within specified days."""
    try:
        from datetime import datetime, timedelta
        expiry_date = (datetime.now() + timedelta(days=days)).strftime("%Y-%m-%d")
        
        res = supabase.table("documents").select("*").lte("expiry_date", expiry_date).eq("status", "VALID").execute()
        return res.data
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
