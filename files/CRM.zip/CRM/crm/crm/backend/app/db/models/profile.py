from sqlalchemy import Column, String, Integer, ForeignKey, DateTime, Text, Boolean
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid
from ..database import Base

class Profile(Base):
    __tablename__ = "profiles"
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String)
    email = Column(String, unique=True, nullable=False)
    role = Column(String, default="STAFF")  # MASTER, STAFF, CREW
    auth_id = Column(String, unique=True)  # ID from authentication provider
    ship_id = Column(String)  # Not a foreign key because crew can be unassigned
    contact_number = Column(String)
    avatar_url = Column(String)
    status = Column(String, default="ACTIVE")
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
