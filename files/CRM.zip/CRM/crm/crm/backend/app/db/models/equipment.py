from sqlalchemy import Column, String, Integer, ForeignKey, DateTime, Text, Boolean, Date
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid
from ..database import Base

class Equipment(Base):
    __tablename__ = "equipments"
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    ship_id = Column(String, ForeignKey("ships.id"), nullable=False)
    equipment_name = Column(String, nullable=False)
    equipment_code = Column(String)
    category = Column(String)
    make = Column(String)
    model = Column(String)
    installation_date = Column(Date)
    specifications = Column(Text)  # JSON formatted specifications
    maintenance_instructions = Column(Text)
    status = Column(String, default="ACTIVE")  # ACTIVE, UNDER_REPAIR, INACTIVE
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    ship = relationship("Ship", back_populates="equipments")
    pms_tasks = relationship("PMSTask", back_populates="equipment")
    pms_logs = relationship("PMSLog", back_populates="equipment")
