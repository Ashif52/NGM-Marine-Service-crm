from sqlalchemy import Column, String, Integer, ForeignKey, DateTime, Text, Boolean
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid
from ..database import Base

class Ship(Base):
    __tablename__ = "ships"
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    ship_name = Column(String, nullable=False)
    imo_number = Column(String)
    ship_type = Column(String)
    flag = Column(String)
    client_id = Column(String, ForeignKey("clients.id"))
    crew_capacity = Column(Integer)
    status = Column(String, default="ACTIVE")
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    client = relationship("Client", back_populates="ships")
    crew_profiles = relationship("CrewProfile", back_populates="ship")
    equipments = relationship("Equipment", back_populates="ship")
    pms_tasks = relationship("PMSTask", back_populates="ship")
    pms_logs = relationship("PMSLog", back_populates="ship")
    work_logs = relationship("DailyWorkLog", back_populates="ship")
    documents = relationship("Document", back_populates="ship")
    invoices = relationship("Invoice", back_populates="ship")
