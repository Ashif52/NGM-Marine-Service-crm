from sqlalchemy import Column, String, Integer, ForeignKey, DateTime, Text, Boolean, Float
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid
from ..database import Base

class RecruitmentCandidate(Base):
    __tablename__ = "recruitment"
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String, nullable=False)
    rank = Column(String)
    nationality = Column(String)
    passport_number = Column(String)
    cdc_number = Column(String)  # Continuous Discharge Certificate
    sea_time = Column(Float)  # In years
    availability_date = Column(DateTime(timezone=True))
    contact_number = Column(String)
    email = Column(String)
    experience = Column(Text)
    certifications = Column(Text)  # JSON formatted certification details
    last_vessel = Column(String)
    last_company = Column(String)
    references = Column(Text)  # JSON formatted references
    interview_notes = Column(Text)
    status = Column(String, default="APPLIED")  # APPLIED, INTERVIEWED, SELECTED, REJECTED, WAITLISTED
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
