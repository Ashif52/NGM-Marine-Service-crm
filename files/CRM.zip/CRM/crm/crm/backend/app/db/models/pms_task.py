from sqlalchemy import Column, String, Integer, ForeignKey, DateTime, Text, Boolean, Date, Interval
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid
from ..database import Base

class PMSTask(Base):
    __tablename__ = "pms_tasks"
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    ship_id = Column(String, ForeignKey("ships.id"), nullable=False)
    equipment_id = Column(String, ForeignKey("equipments.id"))
    task_name = Column(String, nullable=False)
    description = Column(Text)
    frequency = Column(Interval)  # Time interval for recurring tasks
    last_done = Column(DateTime(timezone=True))
    next_due = Column(DateTime(timezone=True))
    priority = Column(String, default="MEDIUM")  # HIGH, MEDIUM, LOW
    estimated_time = Column(Integer)  # In minutes
    instructions = Column(Text)
    status = Column(String, default="PENDING")  # PENDING, IN_PROGRESS, COMPLETED, OVERDUE
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    ship = relationship("Ship", back_populates="pms_tasks")
    equipment = relationship("Equipment", back_populates="pms_tasks")
    pms_logs = relationship("PMSLog", back_populates="pms_task")
