from sqlalchemy import Column, String, Integer, ForeignKey, DateTime, Text, Boolean
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid
from ..database import Base

class PMSLog(Base):
    __tablename__ = "pms_logs"
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    ship_id = Column(String, ForeignKey("ships.id"), nullable=False)
    equipment_id = Column(String, ForeignKey("equipments.id"))
    pms_task_id = Column(String, ForeignKey("pms_tasks.id"))
    assigned_to_id = Column(String, ForeignKey("crew_profiles.id"))
    log_date = Column(DateTime(timezone=True), server_default=func.now())
    work_done = Column(Text)
    parts_used = Column(Text)  # JSON formatted parts list
    time_taken = Column(Integer)  # In minutes
    remarks = Column(Text)
    issues_found = Column(Text)
    action_taken = Column(Text)
    status = Column(String, default="PENDING")  # PENDING, COMPLETED, APPROVED, REJECTED
    approved_by = Column(String)
    approval_date = Column(DateTime(timezone=True))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    ship = relationship("Ship", back_populates="pms_logs")
    equipment = relationship("Equipment", back_populates="pms_logs")
    pms_task = relationship("PMSTask", back_populates="pms_logs")
    assigned_to = relationship("CrewProfile", back_populates="pms_logs")
