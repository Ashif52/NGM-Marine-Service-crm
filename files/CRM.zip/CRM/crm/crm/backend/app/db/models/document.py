from sqlalchemy import Column, String, Integer, ForeignKey, DateTime, Text, Boolean, Date
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid
from ..database import Base

class Document(Base):
    __tablename__ = "documents"
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    ship_id = Column(String, ForeignKey("ships.id"))
    document_type = Column(String, nullable=False)  # CERTIFICATE, MANUAL, LICENSE, OTHER
    document_name = Column(String, nullable=False)
    document_number = Column(String)
    issue_date = Column(Date)
    expiry_date = Column(Date)
    issuing_authority = Column(String)
    file_path = Column(String)  # URL to the stored document
    notes = Column(Text)
    status = Column(String, default="ACTIVE")  # ACTIVE, EXPIRED, RENEWED
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    ship = relationship("Ship", back_populates="documents")
