from sqlalchemy import Column, String, Integer, ForeignKey, DateTime, Text, Boolean, Float
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid
from ..database import Base

class Invoice(Base):
    __tablename__ = "invoices"
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    invoice_number = Column(String, nullable=False)
    ship_id = Column(String, ForeignKey("ships.id"))
    client_id = Column(String, ForeignKey("clients.id"), nullable=False)
    issue_date = Column(DateTime(timezone=True), server_default=func.now())
    due_date = Column(DateTime(timezone=True))
    amount = Column(Float, nullable=False)
    tax_amount = Column(Float, default=0)
    total_amount = Column(Float, nullable=False)
    items = Column(Text)  # JSON formatted invoice items
    notes = Column(Text)
    status = Column(String, default="DRAFT")  # DRAFT, SUBMITTED, APPROVED, PAID, REJECTED
    submitted_by = Column(String)
    approved_by = Column(String)
    approval_date = Column(DateTime(timezone=True))
    payment_date = Column(DateTime(timezone=True))
    payment_reference = Column(String)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    ship = relationship("Ship", back_populates="invoices")
    client = relationship("Client", back_populates="invoices")
