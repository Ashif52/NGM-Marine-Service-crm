from sqlalchemy.orm import Session
from typing import List, Optional
from ..models.ship import Ship
from ...schemas.ship import ShipCreate, ShipUpdate
from .base_repository import BaseRepository

class ShipRepository(BaseRepository[Ship, ShipCreate, ShipUpdate]):
    def __init__(self, db: Session):
        super().__init__(Ship, db)
    
    def get_ships_by_client(self, client_id: str) -> List[Ship]:
        """Get all ships for a specific client."""
        return self.db.query(Ship).filter(Ship.client_id == client_id).all()
    
    def get_active_ships(self) -> List[Ship]:
        """Get all active ships."""
        return self.db.query(Ship).filter(Ship.status == "ACTIVE").all()
    
    def get_ship_by_imo(self, imo_number: str) -> Optional[Ship]:
        """Get ship by IMO number."""
        return self.db.query(Ship).filter(Ship.imo_number == imo_number).first()
    
    def get_ships_by_type(self, ship_type: str) -> List[Ship]:
        """Get ships by type."""
        return self.db.query(Ship).filter(Ship.ship_type == ship_type).all()
    
    def update_ship_status(self, id: str, status: str) -> Ship:
        """Update ship status."""
        db_ship = self.get_by_id(id)
        if db_ship:
            db_ship.status = status
            self.db.add(db_ship)
            self.db.commit()
            self.db.refresh(db_ship)
        return db_ship
