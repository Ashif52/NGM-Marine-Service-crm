from sqlalchemy import Column, String, Integer, ForeignKey, DateTime, Text, Boolean, Float
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid
from ..database import Base

class CrewProfile(Base):
    __tablename__ = "crew_profiles"
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String, nullable=False)
    rank = Column(String)
    nationality = Column(String)
    passport_number = Column(String)
    cdc_number = Column(String)  # Continuous Discharge Certificate
    sea_time = Column(Float)  # In years
    ship_id = Column(String, ForeignKey("ships.id"), nullable=True)
    availability = Column(String, default="AVAILABLE")  # AVAILABLE, ON_SHIP, ON_LEAVE
    contact_number = Column(String)
    email = Column(String)
    experience_details = Column(Text)
    certificates = Column(Text)  # JSON formatted text containing certificate details
    status = Column(String, default="ACTIVE")
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    ship = relationship("Ship", back_populates="crew_profiles")
    work_logs = relationship("DailyWorkLog", back_populates="crew")
    pms_logs = relationship("PMSLog", back_populates="assigned_to")
