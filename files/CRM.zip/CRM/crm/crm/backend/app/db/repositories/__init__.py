# Import repositories for easier access
from .ship_repository import ShipRepository
# Add other repositories as they are implemented
