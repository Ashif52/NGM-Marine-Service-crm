from sqlalchemy import Column, String, Integer, ForeignKey, DateTime, Text, Boolean
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid
from ..database import Base

class DailyWorkLog(Base):
    __tablename__ = "daily_work_logs"
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    ship_id = Column(String, ForeignKey("ships.id"), nullable=False)
    crew_id = Column(String, ForeignKey("crew_profiles.id"), nullable=False)
    log_date = Column(DateTime(timezone=True), server_default=func.now())
    work_done = Column(Text, nullable=False)
    hours_worked = Column(Integer)
    location = Column(String)  # Location on the ship
    remarks = Column(Text)
    status = Column(String, default="PENDING")  # PENDING, APPROVED, REJECTED
    approved_by = Column(String)
    approval_date = Column(DateTime(timezone=True))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    ship = relationship("Ship", back_populates="work_logs")
    crew = relationship("CrewProfile", back_populates="work_logs")
