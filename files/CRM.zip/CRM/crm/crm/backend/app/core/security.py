from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from typing import List, Optional
from datetime import datetime, timedelta
from ..config import settings

oauth2_scheme = OAuth2PasswordBearer(tokenUrl=f"{settings.API_V1_PREFIX}/auth/login")

def create_access_token(subject: str, additional_data: dict = None) -> str:
    """Create JWT access token"""
    expire = datetime.utcnow() + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode = {"exp": expire, "sub": str(subject)}
    if additional_data:
        to_encode.update(additional_data)
    return jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)

async def get_current_user(token: str = Depends(oauth2_scheme)) -> dict:
    """Get current authenticated user from JWT token"""
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        user_id: str = payload.get("sub")
        if user_id is None:
            raise credentials_exception
        return {
            "id": user_id,
            "role": payload.get("role"),
            "ship_id": payload.get("ship_id"),
            "name": payload.get("name")
        }
    except JWTError:
        raise credentials_exception

def require_roles(allowed_roles: List[str]):
    """Role-based access control dependency"""
    async def role_checker(current_user: dict = Depends(get_current_user)):
        if current_user["role"] not in allowed_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Operation not permitted for this role"
            )
        return current_user
    return role_checker

def verify_ship_access(ship_id: str, current_user: dict):
    """Verify user has access to specified ship"""
    # CREW can only access their assigned ship
    if current_user["role"] == "CREW":
        if not current_user.get("ship_id"):
            raise HTTPException(
                status_code=403,
                detail="No ship assigned"
            )
        if current_user["ship_id"] != ship_id:
            raise HTTPException(
                status_code=403,
                detail="Access restricted to assigned ship only"
            )
    return True

def verify_document_access(document_type: str, ship_id: Optional[str], current_user: dict):
    """Verify user has access to document based on type and ship"""
    # CREW can only access CPM/SMM or documents for their ship
    if current_user["role"] == "CREW":
        if document_type not in ["CPM", "SMM"]:
            if not current_user.get("ship_id"):
                raise HTTPException(
                    status_code=403,
                    detail="No ship assigned"
                )
            if current_user["ship_id"] != ship_id:
                raise HTTPException(
                    status_code=403,
                    detail="Access restricted to assigned ship only"
                )
    return True
