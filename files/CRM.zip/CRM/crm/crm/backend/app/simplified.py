from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import psycopg2
from psycopg2.extras import RealDictCursor
import os
from dotenv import load_dotenv
import jwt
from datetime import datetime, timedelta
from passlib.context import CryptContext
import uuid

# Load environment variables
load_dotenv()

app = FastAPI(title="NMG Marine CRM API")

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Replace with your frontend URL in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# JWT Settings
JWT_SECRET_KEY = os.getenv("JWT_SECRET_KEY", "7cc3a18b-b067-4454-8788-ce874ffd7e30")
JWT_ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")
JWT_EXPIRATION_MINUTES = int(os.getenv("JWT_EXPIRATION_MINUTES", "1440"))

# Password hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# OAuth2 setup
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")

# Database connection
def get_db_connection():
    """Get a PostgreSQL connection to Supabase database"""
    try:
        conn = psycopg2.connect(
            host="db.iogpqpqoljoqoprbsnes.supabase.co",
            port=5432,
            database="postgres",
            user="postgres",
            password="nmg-marine-crm",
            sslmode="require",
            cursor_factory=RealDictCursor
        )
        conn.autocommit = False
        return conn
    except Exception as e:
        print(f"❌ Error connecting to PostgreSQL: {e}")
        raise RuntimeError(f"Failed to connect to PostgreSQL: {e}")

# Security utility functions
def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

def create_access_token(subject: str, additional_data: Dict[str, Any] = {}, expires_delta: Optional[timedelta] = None):
    if expires_delta is None:
        expires_delta = timedelta(minutes=JWT_EXPIRATION_MINUTES)
    
    expiry = datetime.utcnow() + expires_delta
    to_encode = {"sub": str(subject), "exp": expiry}
    to_encode.update(additional_data)
    
    return jwt.encode(to_encode, JWT_SECRET_KEY, JWT_ALGORITHM)

async def get_current_user(token: str = Depends(oauth2_scheme)):
    try:
        payload = jwt.decode(token, JWT_SECRET_KEY, algorithms=[JWT_ALGORITHM])
        user_id = payload.get("sub")
        
        if not user_id:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED, 
                detail="Invalid authentication token"
            )
        
        # Get user from database
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM profiles WHERE id = %s", (user_id,))
        user_data = cursor.fetchone()
        
        cursor.close()
        conn.close()
        
        if not user_data or user_data["status"] != "ACTIVE":
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED, 
                detail="User not found or inactive"
            )
        
        # Add token claims to user data
        for key, value in payload.items():
            if key not in ["sub", "exp"] and key not in user_data:
                user_data[key] = value
        
        return user_data
    except jwt.PyJWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, 
            detail=f"Authentication error: {str(e)}"
        )

def require_roles(allowed_roles: List[str]):
    async def role_checker(current_user: dict = Depends(get_current_user)):
        if current_user["role"] not in allowed_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Access denied. Required roles: {allowed_roles}"
            )
        return current_user
    return role_checker

# Pydantic Models
class UserLogin(BaseModel):
    email: str
    password: str

class Token(BaseModel):
    access_token: str
    token_type: str

class ShipBase(BaseModel):
    ship_name: str
    imo_number: Optional[str] = None
    ship_type: Optional[str] = None
    flag: Optional[str] = None
    client_id: Optional[str] = None
    crew_capacity: Optional[int] = None

class ShipCreate(ShipBase):
    pass

class ShipUpdate(BaseModel):
    ship_name: Optional[str] = None
    imo_number: Optional[str] = None
    ship_type: Optional[str] = None
    flag: Optional[str] = None
    client_id: Optional[str] = None
    crew_capacity: Optional[int] = None
    status: Optional[str] = None

# API Routes
@app.get("/api")
async def root():
    return {"message": "NMG Marine CRM API is running"}

@app.post("/api/auth/login", response_model=Token)
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get user by email
        cursor.execute(
            "SELECT id, email, password, role, ship_id, name FROM users WHERE email = %s", 
            (form_data.username,)
        )
        user = cursor.fetchone()
        
        cursor.close()
        conn.close()
        
        if not user or not verify_password(form_data.password, user["password"]):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Incorrect email or password",
                headers={"WWW-Authenticate": "Bearer"},
            )
        
        # Create JWT token
        access_token = create_access_token(
            subject=user["id"],
            additional_data={
                "role": user["role"],
                "ship_id": user["ship_id"],
                "name": user["name"]
            }
        )
        
        return {"access_token": access_token, "token_type": "bearer"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

@app.get("/api/ships")
async def get_ships(
    current_user: dict = Depends(get_current_user),
    status: Optional[str] = None,
    ship_type: Optional[str] = None,
    client_id: Optional[str] = None
):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Start with base query
        query = "SELECT * FROM ships WHERE 1=1"
        params = []
        
        # Add filters
        if status:
            query += " AND status = %s"
            params.append(status)
        if ship_type:
            query += " AND ship_type = %s"
            params.append(ship_type)
        if client_id:
            query += " AND client_id = %s"
            params.append(client_id)
        
        # CREW can only see their assigned ship
        if current_user["role"] == "CREW" and current_user.get("ship_id"):
            query += " AND id = %s"
            params.append(current_user["ship_id"])
        
        # Add ordering
        query += " ORDER BY created_at DESC"
        
        # Execute query
        cursor.execute(query, params)
        ships = cursor.fetchall()
        
        cursor.close()
        conn.close()
        return ships
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/ships/{ship_id}")
async def get_ship(ship_id: str, current_user: dict = Depends(get_current_user)):
    try:
        # CREW can only access their assigned ship
        if current_user["role"] == "CREW" and current_user.get("ship_id") != ship_id:
            raise HTTPException(status_code=403, detail="Access denied")
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM ships WHERE id = %s", (ship_id,))
        ship = cursor.fetchone()
        
        cursor.close()
        conn.close()
        
        if not ship:
            raise HTTPException(status_code=404, detail="Ship not found")
        
        return ship
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/ships")
async def create_ship(
    ship: ShipCreate,
    current_user: dict = Depends(require_roles(["MASTER"]))
):
    try:
        ship_data = ship.dict()
        ship_id = str(uuid.uuid4())
        now = datetime.now()
        
        # Add system fields
        ship_data["id"] = ship_id
        ship_data["created_at"] = now
        ship_data["updated_at"] = now
        ship_data["status"] = "ACTIVE"
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Build the query dynamically based on the provided fields
        columns = ", ".join(ship_data.keys())
        placeholders = ", ".join("%s" for _ in ship_data)
        query = f"INSERT INTO ships ({columns}) VALUES ({placeholders}) RETURNING *"
        
        cursor.execute(query, list(ship_data.values()))
        conn.commit()
        
        new_ship = cursor.fetchone()
        
        cursor.close()
        conn.close()
        
        if not new_ship:
            raise HTTPException(status_code=400, detail="Failed to create ship")
        
        return new_ship
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Run the application
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
