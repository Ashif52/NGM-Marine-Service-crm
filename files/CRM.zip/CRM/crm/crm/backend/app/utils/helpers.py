from sqlalchemy.orm import Session
from ..database import get_db
from ..models.activity_log import ActivityLog
import uuid
from datetime import datetime

async def log_activity(user_id, action, entity_type, entity_id=None, description=None, db: Session = None):
    """Log user activity in the activity_logs table."""
    try:
        # Create session if not provided
        close_session = False
        if db is None:
            db = next(get_db())
            close_session = True
        
        # Create new activity log
        activity_log = ActivityLog(
            id=uuid.uuid4(),
            user_id=uuid.UUID(user_id) if isinstance(user_id, str) else user_id,
            action=action,
            module=entity_type,
            created_at=datetime.now()
        )
        
        # Add to database and commit
        db.add(activity_log)
        db.commit()
        
        # Close session if we created it
        if close_session:
            db.close()
    except Exception as e:
        # Log error but don't fail the main operation
        print(f"Error logging activity: {e}")
        # Rollback if there was an error
        if db is not None and close_session:
            db.rollback()

def serialize_uuid(obj):
    """Convert UUID objects to strings for JSON serialization."""
    if hasattr(obj, 'hex'):
        return str(obj)
    return obj
