from sqlalchemy.orm import Session
from app.models.auth import User, UserRole
from app.models.ships import Ship, ShipType, ShipStatus
from app.utils.security import get_password_hash
import uuid

def create_demo_users(db: Session):
    """Create demo users for testing"""
    
    # Create a demo ship first
    demo_ship = Ship(
        id=uuid.uuid4(),
        name="MV PACIFIC STAR",
        imo_number="9876543",
        flag="Panama",
        ship_type=ShipType.BULK_CARRIER,
        status=ShipStatus.ACTIVE,
        call_sign="3EXX4",
        port_of_registry="Panama",
        classification_society="DNV",
        gross_tonnage="45000",
        year_built="2015"
    )
    db.add(demo_ship)
    db.commit()
    
    # Demo users with fixed credentials
    demo_users = [
        {
            "email": "master@nmgmarine.com",
            "password": "master123",  # In production, use strong passwords
            "name": "John Smith",
            "role": UserRole.MASTER,
            "ship_id": None  # Master has access to all ships
        },
        {
            "email": "staff@nmgmarine.com",
            "password": "staff123",
            "name": "Sarah Wilson",
            "role": UserRole.STAFF,
            "ship_id": None  # Staff can access all ships
        },
        {
            "email": "crew@nmgmarine.com",
            "password": "crew123",
            "name": "Mike Chen",
            "role": UserRole.CREW,
            "ship_id": demo_ship.id  # Crew is assigned to specific ship
        }
    ]
    
    for user_data in demo_users:
        # Check if user already exists
        existing_user = db.query(User).filter(User.email == user_data["email"]).first()
        if existing_user:
            continue
            
        # Create user
        user = User(
            id=uuid.uuid4(),
            email=user_data["email"],
            name=user_data["name"],
            password_hash=get_password_hash(user_data["password"]),
            role=user_data["role"],
            ship_id=user_data["ship_id"],
            is_active=True
        )
        db.add(user)
    
    db.commit()
    
    return {
        "message": "Demo users created successfully",
        "credentials": [
            {
                "role": "MASTER",
                "email": "master@nmgmarine.com",
                "password": "master123",
                "access": "Full system access"
            },
            {
                "role": "STAFF",
                "email": "staff@nmgmarine.com",
                "password": "staff123",
                "access": "Operations & invoices"
            },
            {
                "role": "CREW",
                "email": "crew@nmgmarine.com",
                "password": "crew123",
                "access": "Daily logs & PMS tasks"
            }
        ]
    }
