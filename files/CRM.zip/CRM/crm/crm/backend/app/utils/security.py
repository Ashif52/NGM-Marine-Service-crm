from datetime import datetime, timedelta
from typing import Any, Dict, Optional, List
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import JWTError, jwt
from passlib.context import CryptContext
from sqlalchemy.orm import Session
from ..config import settings
from ..database import get_db
from ..models.profile import Profile

# Use HTTPBearer for simple Bearer token authentication
security = HTTPBearer()
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def verify_password(plain_password, hashed_password):
    """Verify a password against a hash"""
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    """Get password hash"""
    # bcrypt has a 72-byte limit on passwords
    # Truncate the password if it exceeds the limit
    if len(password.encode('utf-8')) > 72:
        password = password[:72]
    try:
        return pwd_context.hash(password)
    except ValueError as e:
        # Handle bcrypt version compatibility issues
        if "password cannot be longer than 72 bytes" in str(e):
            # Force truncation and try again
            password = password[:72]
            return pwd_context.hash(password)
        raise

def create_access_token(subject: str, additional_data: Dict[str, Any] = {}, expires_delta: Optional[timedelta] = None) -> str:
    """Create a JWT access token"""
    if expires_delta is None:
        expires_delta = timedelta(minutes=settings.JWT_EXPIRATION_MINUTES)
        
    expiry = datetime.utcnow() + expires_delta
    to_encode = {"sub": str(subject), "exp": expiry}
    to_encode.update(additional_data)
    
    return jwt.encode(
        to_encode, 
        settings.JWT_SECRET_KEY, 
        settings.JWT_ALGORITHM
    )


async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security), db: Session = Depends(get_db)):
    """Decode the JWT token to get the current user"""
    try:
        token = credentials.credentials
        payload = jwt.decode(
            token, 
            settings.JWT_SECRET_KEY, 
            algorithms=[settings.JWT_ALGORITHM]
        )
        user_id = payload.get("sub")
        
        if not user_id:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED, 
                detail="Invalid authentication token"
            )
        
        # Check if user profile exists and is active
        profile = db.query(Profile).filter(Profile.id == user_id).first()
        
        if not profile or profile.status != "ACTIVE":
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED, 
                detail="User not found or inactive"
            )
        
        # Convert SQLAlchemy model to dict
        user_data = {
            "id": str(profile.id),
            "name": profile.name,
            "role": profile.role,
            "ship_id": str(profile.ship_id) if profile.ship_id else None,
            "status": profile.status
        }
        
        # Include token data with profile
        for key, value in payload.items():
            if key not in ["sub", "exp"] and key not in user_data:
                user_data[key] = value
        
        return user_data
    except HTTPException:
        raise
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, 
            detail=f"Invalid authentication token: {str(e)}"
        )


def require_roles(allowed_roles: List[str]):
    """Dependency to check if user has required role."""
    async def role_checker(current_user: dict = Depends(get_current_user)):
        if current_user["role"] not in allowed_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Access denied. Required roles: {allowed_roles}"
            )
        return current_user
    return role_checker
