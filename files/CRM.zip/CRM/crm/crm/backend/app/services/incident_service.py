from sqlalchemy.orm import Session
from typing import List, Optional
from fastapi import HTTPException
from ..models.incident import IncidentReport, AuditLog, IncidentStatus, AuditType
from datetime import datetime

class IncidentService:
    def __init__(self, db: Session):
        self.db = db
    
    async def get_incidents(
        self,
        user_id: str,
        user_role: str,
        ship_id: Optional[str] = None,
        status: Optional[IncidentStatus] = None
    ) -> List[IncidentReport]:
        """Get incident reports based on user role and filters"""
        query = self.db.query(IncidentReport)
        
        if ship_id:
            query = query.filter(IncidentReport.ship_id == ship_id)
        if status:
            query = query.filter(IncidentReport.status == status)
        
        # CREW can only see incidents from their ship
        if user_role == "CREW":
            if not ship_id:
                raise HTTPException(status_code=403, detail="No ship assigned")
            query = query.filter(IncidentReport.ship_id == ship_id)
        
        return query.order_by(IncidentReport.created_at.desc()).all()
    
    async def create_incident(
        self,
        ship_id: str,
        incident_type: str,
        description: str,
        reported_by: str,
        corrective_action: Optional[str] = None
    ) -> IncidentReport:
        """Create a new incident report"""
        incident = IncidentReport(
            ship_id=ship_id,
            incident_type=incident_type,
            description=description,
            reported_by=reported_by,
            corrective_action=corrective_action,
            status=IncidentStatus.OPEN
        )
        self.db.add(incident)
        await self.db.commit()
        await self.db.refresh(incident)
        return incident
    
    async def close_incident(
        self,
        incident_id: str,
        closed_by: str,
        corrective_action: str
    ) -> IncidentReport:
        """Close an incident report"""
        incident = self.db.query(IncidentReport).filter(
            IncidentReport.id == incident_id
        ).first()
        
        if not incident:
            raise HTTPException(status_code=404, detail="Incident not found")
        
        if incident.status == IncidentStatus.CLOSED:
            raise HTTPException(status_code=400, detail="Incident already closed")
        
        incident.status = IncidentStatus.CLOSED
        incident.corrective_action = corrective_action
        incident.closed_by = closed_by
        incident.closed_at = datetime.now()
        
        await self.db.commit()
        await self.db.refresh(incident)
        return incident
    
    async def create_audit(
        self,
        ship_id: str,
        audit_type: AuditType,
        findings: str,
        auditor: str,
        audit_date: datetime,
        corrective_action: Optional[str] = None
    ) -> AuditLog:
        """Create a new audit log"""
        audit = AuditLog(
            ship_id=ship_id,
            audit_type=audit_type,
            findings=findings,
            auditor=auditor,
            audit_date=audit_date,
            corrective_action=corrective_action
        )
        self.db.add(audit)
        await self.db.commit()
        await self.db.refresh(audit)
        return audit
    
    async def get_audits(
        self,
        ship_id: Optional[str] = None,
        audit_type: Optional[AuditType] = None
    ) -> List[AuditLog]:
        """Get audit logs with optional filters"""
        query = self.db.query(AuditLog)
        
        if ship_id:
            query = query.filter(AuditLog.ship_id == ship_id)
        if audit_type:
            query = query.filter(AuditLog.audit_type == audit_type)
        
        return query.order_by(AuditLog.audit_date.desc()).all()
