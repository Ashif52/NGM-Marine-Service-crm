from sqlalchemy.orm import Session
from sqlalchemy import desc
from datetime import datetime
from typing import List, Optional
from fastapi import HTTPException, status

from ..models.manuals import Manual, ManualVersion, ManualAcknowledgement
from ..models.auth import User
from ..schemas.manuals import (
    ManualCreate,
    ManualUpdate,
    ManualVersionCreate,
    ManualVersionUpdate,
    ManualAcknowledgementCreate,
)

class ManualService:
    def __init__(self, db: Session):
        self.db = db

    def get_manuals(
        self,
        skip: int = 0,
        limit: int = 100,
        manual_type: Optional[str] = None,
        ship_id: Optional[str] = None,
        search: Optional[str] = None,
    ) -> List[Manual]:
        query = self.db.query(Manual)

        if manual_type:
            query = query.filter(Manual.manual_type == manual_type)
        if ship_id:
            query = query.filter(Manual.ship_id == ship_id)
        if search:
            query = query.filter(Manual.title.ilike(f"%{search}%"))

        return query.offset(skip).limit(limit).all()

    def get_manual(self, manual_id: str) -> Manual:
        manual = self.db.query(Manual).filter(Manual.id == manual_id).first()
        if not manual:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Manual not found"
            )
        return manual

    def create_manual(self, data: ManualCreate, user_id: str) -> Manual:
        # Create manual
        manual = Manual(
            title=data.title,
            manual_type=data.manual_type,
            ship_id=data.ship_id,
            sections=data.sections,
            created_by=user_id,
        )
        self.db.add(manual)
        self.db.flush()

        # Create initial version
        version = ManualVersion(
            manual_id=manual.id,
            version_number=1,
            content=data.content,
            created_by=user_id,
        )
        self.db.add(version)
        self.db.flush()

        # Set as current version
        manual.current_version_id = version.id
        self.db.commit()
        self.db.refresh(manual)

        return manual

    def update_manual(self, manual_id: str, data: ManualUpdate, user_id: str) -> Manual:
        manual = self.get_manual(manual_id)

        # Update basic info
        if data.title is not None:
            manual.title = data.title
        if data.manual_type is not None:
            manual.manual_type = data.manual_type
        if data.ship_id is not None:
            manual.ship_id = data.ship_id
        if data.sections is not None:
            manual.sections = data.sections
        if data.approved is not None:
            manual.approved = data.approved

        manual.updated_by = user_id
        manual.updated_at = datetime.utcnow()

        self.db.commit()
        self.db.refresh(manual)
        return manual

    def create_version(self, data: ManualVersionCreate, user_id: str) -> ManualVersion:
        manual = self.get_manual(data.manual_id)

        # Get latest version number
        latest_version = (
            self.db.query(ManualVersion)
            .filter(ManualVersion.manual_id == manual.id)
            .order_by(desc(ManualVersion.version_number))
            .first()
        )
        new_version_number = (latest_version.version_number + 1) if latest_version else 1

        # Create new version
        version = ManualVersion(
            manual_id=manual.id,
            version_number=new_version_number,
            content=data.content,
            change_summary=data.change_summary,
            created_by=user_id,
        )
        self.db.add(version)
        self.db.flush()

        # Update manual's current version
        manual.current_version_id = version.id
        manual.updated_by = user_id
        manual.updated_at = datetime.utcnow()

        self.db.commit()
        self.db.refresh(version)
        return version

    def update_version(
        self, version_id: str, data: ManualVersionUpdate, user_id: str
    ) -> ManualVersion:
        version = (
            self.db.query(ManualVersion).filter(ManualVersion.id == version_id).first()
        )
        if not version:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Manual version not found"
            )

        if data.content is not None:
            version.content = data.content
        if data.change_summary is not None:
            version.change_summary = data.change_summary
        if data.approved is not None:
            version.approved_by = user_id if data.approved else None
            version.approved_date = datetime.utcnow() if data.approved else None

        version.updated_by = user_id
        version.updated_at = datetime.utcnow()

        self.db.commit()
        self.db.refresh(version)
        return version

    def acknowledge_manual(
        self, data: ManualAcknowledgementCreate, user_id: str
    ) -> ManualAcknowledgement:
        # Check if already acknowledged
        existing = (
            self.db.query(ManualAcknowledgement)
            .filter(
                ManualAcknowledgement.manual_id == data.manual_id,
                ManualAcknowledgement.user_id == user_id,
                ManualAcknowledgement.version_id == data.version_id,
            )
            .first()
        )
        if existing:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Manual version already acknowledged"
            )

        # Create acknowledgement
        ack = ManualAcknowledgement(
            manual_id=data.manual_id,
            version_id=data.version_id,
            user_id=user_id,
            created_by=user_id,
        )
        self.db.add(ack)
        self.db.commit()
        self.db.refresh(ack)
        return ack

    def get_user_acknowledgements(self, user_id: str) -> List[ManualAcknowledgement]:
        return (
            self.db.query(ManualAcknowledgement)
            .filter(ManualAcknowledgement.user_id == user_id)
            .all()
        )
