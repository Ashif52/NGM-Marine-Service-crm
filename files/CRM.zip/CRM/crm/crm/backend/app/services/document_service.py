from sqlalchemy.orm import Session
from typing import List, Optional
from fastapi import HTTPException
from ..models.document_control import Document, DocumentVersion, DocumentAcknowledgement, ManualType
from datetime import datetime

class DocumentService:
    def __init__(self, db: Session):
        self.db = db
    
    async def get_documents(
        self,
        user_id: str,
        user_role: str,
        ship_id: Optional[str] = None,
        manual_type: Optional[ManualType] = None
    ) -> List[Document]:
        """Get documents based on user role and filters"""
        query = self.db.query(Document).filter(Document.is_active == True)
        
        if manual_type:
            query = query.filter(Document.manual_type == manual_type)
        
        # Role-based filtering
        if user_role == "CREW":
            if not ship_id:
                raise HTTPException(status_code=403, detail="No ship assigned")
            query = query.filter(
                (Document.ship_id == ship_id) |
                (Document.manual_type.in_([ManualType.CPM, ManualType.SMM]))
            )
        elif ship_id:
            query = query.filter(Document.ship_id == ship_id)
        
        return query.all()
    
    async def create_document(
        self,
        title: str,
        manual_type: ManualType,
        created_by: str,
        ship_id: Optional[str] = None
    ) -> Document:
        """Create a new document"""
        if manual_type in [ManualType.FPM, ManualType.FPMF] and not ship_id:
            raise HTTPException(status_code=400, detail="ship_id required for FPM/FPMF")
        
        document = Document(
            title=title,
            manual_type=manual_type,
            ship_id=ship_id,
            created_by=created_by
        )
        self.db.add(document)
        await self.db.commit()
        await self.db.refresh(document)
        return document
    
    async def create_version(
        self,
        document_id: str,
        version_number: int,
        file_path: str,
        change_summary: Optional[str] = None,
        approved_by: Optional[str] = None
    ) -> DocumentVersion:
        """Create a new document version"""
        version = DocumentVersion(
            document_id=document_id,
            version_number=version_number,
            file_path=file_path,
            change_summary=change_summary,
            approved_by=approved_by,
            revision_date=datetime.now()
        )
        self.db.add(version)
        await self.db.commit()
        await self.db.refresh(version)
        return version
    
    async def acknowledge_document(
        self,
        version_id: str,
        user_id: str
    ) -> DocumentAcknowledgement:
        """Create document acknowledgement"""
        # Check if already acknowledged
        existing = self.db.query(DocumentAcknowledgement).filter(
            DocumentAcknowledgement.document_version_id == version_id,
            DocumentAcknowledgement.user_id == user_id
        ).first()
        
        if existing:
            raise HTTPException(status_code=400, detail="Already acknowledged")
        
        ack = DocumentAcknowledgement(
            document_version_id=version_id,
            user_id=user_id
        )
        self.db.add(ack)
        await self.db.commit()
        await self.db.refresh(ack)
        return ack
    
    async def get_pending_acknowledgements(
        self,
        user_id: str,
        ship_id: Optional[str] = None
    ) -> List[DocumentVersion]:
        """Get documents pending acknowledgement for a user"""
        # Get latest versions of active documents
        latest_versions = (
            self.db.query(DocumentVersion)
            .join(Document)
            .filter(Document.is_active == True)
        )
        
        if ship_id:
            latest_versions = latest_versions.filter(
                (Document.ship_id == ship_id) |
                (Document.manual_type.in_([ManualType.CPM, ManualType.SMM]))
            )
        
        # Exclude already acknowledged versions
        acknowledged = (
            self.db.query(DocumentAcknowledgement.document_version_id)
            .filter(DocumentAcknowledgement.user_id == user_id)
        )
        
        return latest_versions.filter(
            ~DocumentVersion.id.in_(acknowledged)
        ).all()
