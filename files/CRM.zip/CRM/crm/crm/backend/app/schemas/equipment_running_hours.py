from pydantic import BaseModel, UUID4
from typing import Optional
from datetime import date, datetime

class EquipmentRunningHoursBase(BaseModel):
    """Base schema for equipment running hours"""
    equipment_id: UUID4
    date: date
    running_hours: float
    total_running_hours: float

class EquipmentRunningHoursCreate(EquipmentRunningHoursBase):
    """Schema for creating equipment running hours entry"""
    pass

class EquipmentRunningHoursUpdate(BaseModel):
    """Schema for updating equipment running hours"""
    running_hours: Optional[float] = None
    total_running_hours: Optional[float] = None

class EquipmentRunningHours(EquipmentRunningHoursBase):
    """Schema for returning equipment running hours"""
    id: UUID4
    reported_by: Optional[UUID4] = None
    created_at: datetime
    
    class Config:
        orm_mode = True
