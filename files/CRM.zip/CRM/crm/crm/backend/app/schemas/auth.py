from pydantic import BaseModel, EmailStr
from typing import Optional
from datetime import date


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserCreate(BaseModel):
    email: EmailStr
    password: str
    name: str
    role: str  # MASTER, CREW, STAFF
    ship_id: Optional[str] = None
    nationality: Optional[str] = None
    rank: Optional[str] = None
    join_date: Optional[date] = None


class UserResponse(BaseModel):
    id: str
    email: str
    name: str
    role: str
    ship_id: Optional[str] = None
    nationality: Optional[str] = None
    availability: Optional[str] = None
    status: Optional[str] = None


class UserAdminUpdate(BaseModel):
    name: Optional[str] = None
    email: Optional[EmailStr] = None
    role: Optional[str] = None
    status: Optional[str] = None


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserResponse


class ProfileUpdate(BaseModel):
    name: Optional[str] = None
    nationality: Optional[str] = None
    availability: Optional[str] = None
    sea_time: Optional[str] = None
    ship_id: Optional[str] = None
