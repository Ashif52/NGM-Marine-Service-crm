from pydantic import BaseModel, UUID4, EmailStr
from typing import Optional, List
from datetime import date, datetime


class CrewCertificate(BaseModel):
    name: str
    certificate_number: Optional[str] = None
    issue_date: Optional[date] = None
    expiry_date: Optional[date] = None
    issuing_authority: Optional[str] = None
    document_url: Optional[str] = None

class CrewProfileBase(BaseModel):
    rank: Optional[str] = None
    join_date: Optional[date] = None
    department: Optional[str] = None  # DECK, ENGINE, CATERING
    job_description: Optional[str] = None
    contract_duration: Optional[int] = None  # in months
    previous_experience: Optional[str] = None
    emergency_contact_name: Optional[str] = None
    emergency_contact_number: Optional[str] = None


class CrewProfileCreate(CrewProfileBase):
    user_id: str


class CrewProfileUpdate(BaseModel):
    rank: Optional[str] = None
    join_date: Optional[date] = None
    department: Optional[str] = None
    job_description: Optional[str] = None
    contract_duration: Optional[int] = None
    previous_experience: Optional[str] = None
    emergency_contact_name: Optional[str] = None
    emergency_contact_number: Optional[str] = None


class CrewCreateRequest(BaseModel):
    # User profile data
    name: str
    email: EmailStr
    password: str
    nationality: Optional[str] = None
    sea_time: Optional[str] = None
    
    # Crew specific data
    rank: str
    department: str  # DECK, ENGINE, CATERING
    join_date: Optional[date] = None
    job_description: Optional[str] = None
    contract_duration: Optional[int] = None
    previous_experience: Optional[str] = None
    emergency_contact_name: Optional[str] = None
    emergency_contact_number: Optional[str] = None
    
    # Optional ship assignment
    ship_id: Optional[UUID4] = None
    
    # Certificates
    certificates: Optional[List[CrewCertificate]] = []


class CrewProfileResponse(CrewProfileBase):
    id: str
    user_id: str
    created_at: datetime
    
    class Config:
        from_attributes = True


class CrewCertificateResponse(CrewCertificate):
    id: str
    crew_id: str
    created_at: datetime
    
    class Config:
        from_attributes = True


class CrewMemberResponse(BaseModel):
    id: str
    name: Optional[str] = None
    email: Optional[str] = None
    role: str
    ship_id: Optional[str] = None
    nationality: Optional[str] = None
    availability: Optional[str] = None
    sea_time: Optional[str] = None
    status: Optional[str] = None
    
    # Crew specific fields
    rank: Optional[str] = None
    join_date: Optional[date] = None
    department: Optional[str] = None
    job_description: Optional[str] = None
    contract_duration: Optional[int] = None
    previous_experience: Optional[str] = None
    emergency_contact_name: Optional[str] = None
    emergency_contact_number: Optional[str] = None
    created_at: datetime
    
    # Optional certificates
    certificates: Optional[List[CrewCertificateResponse]] = []
    
    class Config:
        from_attributes = True
