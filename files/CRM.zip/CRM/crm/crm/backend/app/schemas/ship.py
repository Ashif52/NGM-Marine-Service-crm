from pydantic import BaseModel
from typing import Optional
from datetime import datetime


class ShipBase(BaseModel):
    ship_name: str
    imo_number: Optional[str] = None
    ship_type: Optional[str] = None
    flag: Optional[str] = None
    client_id: Optional[str] = None
    crew_capacity: Optional[int] = None


class ShipCreate(ShipBase):
    pass


class ShipUpdate(BaseModel):
    ship_name: Optional[str] = None
    imo_number: Optional[str] = None
    ship_type: Optional[str] = None
    flag: Optional[str] = None
    client_id: Optional[str] = None
    crew_capacity: Optional[int] = None
    status: Optional[str] = None


class ShipResponse(ShipBase):
    id: str
    status: str
    created_at: datetime
    
    class Config:
        from_attributes = True
