from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime

# Base Ship schema (shared properties)
class ShipBase(BaseModel):
    ship_name: str
    imo_number: Optional[str] = None
    ship_type: Optional[str] = None
    flag: Optional[str] = None
    client_id: Optional[str] = None
    crew_capacity: Optional[int] = None

# Create Ship schema (properties required during creation)
class ShipCreate(ShipBase):
    pass

# Update Ship schema (all properties optional during update)
class ShipUpdate(BaseModel):
    ship_name: Optional[str] = None
    imo_number: Optional[str] = None
    ship_type: Optional[str] = None
    flag: Optional[str] = None
    client_id: Optional[str] = None
    crew_capacity: Optional[int] = None
    status: Optional[str] = None

# Ship response schema (returned from API)
class ShipResponse(ShipBase):
    id: str
    status: str = "ACTIVE"
    created_at: datetime
    updated_at: Optional[datetime] = None
    
    class Config:
        orm_mode = True
