from pydantic import BaseModel, UUID4
from typing import Optional, List
from datetime import date, datetime

class SparePartBase(BaseModel):
    """Base schema for spare part"""
    equipment_id: Optional[UUID4] = None
    ship_id: UUID4
    part_number: Optional[str] = None
    part_name: str
    manufacturer: Optional[str] = None
    quantity: int = 0
    min_quantity: Optional[int] = 1
    unit: Optional[str] = None
    location_on_ship: Optional[str] = None
    last_ordered_date: Optional[date] = None

class SparePartCreate(SparePartBase):
    """Schema for creating a spare part"""
    pass

class SparePartUpdate(BaseModel):
    """Schema for updating a spare part"""
    equipment_id: Optional[UUID4] = None
    part_number: Optional[str] = None
    part_name: Optional[str] = None
    manufacturer: Optional[str] = None
    quantity: Optional[int] = None
    min_quantity: Optional[int] = None
    unit: Optional[str] = None
    location_on_ship: Optional[str] = None
    last_ordered_date: Optional[date] = None

class SparePart(SparePartBase):
    """Schema for returning a spare part"""
    id: UUID4
    created_at: datetime
    updated_at: datetime
    
    class Config:
        orm_mode = True

class SparePartTransactionBase(BaseModel):
    """Base schema for spare part transaction"""
    spare_part_id: UUID4
    transaction_type: str  # RECEIPT, USAGE, ADJUSTMENT
    quantity: int
    reference_number: Optional[str] = None
    remarks: Optional[str] = None

class SparePartTransactionCreate(SparePartTransactionBase):
    """Schema for creating a spare part transaction"""
    pass

class SparePartTransaction(SparePartTransactionBase):
    """Schema for returning a spare part transaction"""
    id: UUID4
    created_by: Optional[UUID4] = None
    created_at: datetime
    
    class Config:
        orm_mode = True
