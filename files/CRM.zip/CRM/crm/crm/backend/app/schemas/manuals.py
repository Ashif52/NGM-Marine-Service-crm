from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime
from enum import Enum
from uuid import UUID

class ManualType(str, Enum):
    SMM = "SMM"
    CPM = "CPM"
    FPM = "FPM"
    CPMF = "CPMF"
    FPMF = "FPMF"

class ManualSectionBase(BaseModel):
    id: str
    title: str
    content: str
    order: int
    subsections: Optional[List['ManualSectionBase']] = None

class ManualVersionBase(BaseModel):
    id: str
    version_number: int
    revision_date: datetime
    change_summary: Optional[str] = None
    approved_by: Optional[str] = None
    approved_date: Optional[datetime] = None

class ManualAcknowledgementBase(BaseModel):
    id: str
    manual_id: str
    user_id: str
    user_name: str
    version_id: str
    version_number: int
    acknowledged_at: datetime

class ManualBase(BaseModel):
    title: str
    manual_type: ManualType
    ship_id: Optional[str] = None
    sections: List[ManualSectionBase]
    approved: bool = False

class ManualCreate(ManualBase):
    content: Dict[str, Any]  # Initial version content

class ManualUpdate(BaseModel):
    title: Optional[str] = None
    manual_type: Optional[ManualType] = None
    ship_id: Optional[str] = None
    sections: Optional[List[ManualSectionBase]] = None
    approved: Optional[bool] = None

class ManualVersionCreate(BaseModel):
    manual_id: str
    content: Dict[str, Any]
    change_summary: Optional[str] = None

class ManualVersionUpdate(BaseModel):
    content: Optional[Dict[str, Any]] = None
    change_summary: Optional[str] = None
    approved: Optional[bool] = None

class ManualAcknowledgementCreate(BaseModel):
    manual_id: str
    version_id: str

class ManualResponse(ManualBase):
    id: str
    ship_name: Optional[str] = None
    current_version: ManualVersionBase
    versions: List[ManualVersionBase]
    acknowledgements: List[ManualAcknowledgementBase]
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

class ManualListResponse(BaseModel):
    manuals: List[ManualResponse]
    total: int
    page: int
    size: int
