from pydantic import BaseModel
from typing import Optional
from datetime import datetime


class WorkLogBase(BaseModel):
    ship_id: str
    work_type: str
    description: Optional[str] = None
    hours: Optional[float] = None
    photo_url: Optional[str] = None


class WorkLogCreate(WorkLogBase):
    pass


class WorkLogUpdate(BaseModel):
    work_type: Optional[str] = None
    description: Optional[str] = None
    hours: Optional[float] = None
    photo_url: Optional[str] = None


class WorkLogApproval(BaseModel):
    status: str  # APPROVED, REJECTED


class WorkLogResponse(WorkLogBase):
    id: str
    crew_id: str
    status: str
    approved_by: Optional[str] = None
    created_at: datetime
    
    class Config:
        from_attributes = True
