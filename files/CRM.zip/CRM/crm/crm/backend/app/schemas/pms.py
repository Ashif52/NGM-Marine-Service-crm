from pydantic import BaseModel
from typing import Optional
from datetime import date, datetime


# Equipment schemas
class EquipmentBase(BaseModel):
    equipment_name: str
    category: Optional[str] = None
    ship_id: str


class EquipmentCreate(EquipmentBase):
    pass


class EquipmentUpdate(BaseModel):
    equipment_name: Optional[str] = None
    category: Optional[str] = None


class EquipmentResponse(EquipmentBase):
    id: str
    created_at: datetime
    
    class Config:
        from_attributes = True


# PMS Task schemas
class PMSTaskBase(BaseModel):
    equipment_id: str
    task_name: str
    frequency: str  # DAILY, WEEKLY, MONTHLY
    due_date: date
    assigned_to: Optional[str] = None


class PMSTaskCreate(PMSTaskBase):
    pass


class PMSTaskUpdate(BaseModel):
    task_name: Optional[str] = None
    frequency: Optional[str] = None
    due_date: Optional[date] = None
    assigned_to: Optional[str] = None
    status: Optional[str] = None


class PMSTaskResponse(PMSTaskBase):
    id: str
    status: str
    created_at: datetime
    
    class Config:
        from_attributes = True


# PMS Log schemas
class PMSLogBase(BaseModel):
    pms_task_id: str
    crew_id: str
    remarks: Optional[str] = None
    photo_url: Optional[str] = None


class PMSLogCreate(PMSLogBase):
    pass


class PMSLogApproval(BaseModel):
    status: str  # APPROVED, REJECTED


class PMSLogResponse(PMSLogBase):
    id: str
    status: str
    approved_by: Optional[str] = None
    created_at: datetime
    
    class Config:
        from_attributes = True
