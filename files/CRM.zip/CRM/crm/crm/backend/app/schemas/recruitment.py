from pydantic import BaseModel, EmailStr, field_serializer
from typing import Optional
from datetime import date, datetime
from uuid import UUID


class RecruitmentBase(BaseModel):
    candidate_name: str
    candidate_email: Optional[str] = None
    rank: Optional[str] = None
    nationality: Optional[str] = None
    experience: Optional[str] = None
    ship_id: Optional[str] = None
    resume_url: Optional[str] = None


class RecruitmentCreate(RecruitmentBase):
    pass


class RecruitmentUpdate(BaseModel):
    candidate_name: Optional[str] = None
    candidate_email: Optional[str] = None
    rank: Optional[str] = None
    nationality: Optional[str] = None
    experience: Optional[str] = None
    ship_id: Optional[str] = None
    resume_url: Optional[str] = None
    status: Optional[str] = None


class RecruitmentResponse(RecruitmentBase):
    id: UUID
    status: str
    applied_date: date
    created_at: datetime
    
    @field_serializer('id')
    def serialize_id(self, value: UUID, _info):
        return str(value)
    
    class Config:
        from_attributes = True
