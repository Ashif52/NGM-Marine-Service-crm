from pydantic import BaseModel
from typing import Optional
from datetime import date, datetime


class InvoiceBase(BaseModel):
    ship_id: str
    invoice_number: str
    amount: float
    vendor: Optional[str] = None
    category: Optional[str] = None
    currency: str = "USD"
    due_date: Optional[date] = None
    description: Optional[str] = None
    file_url: Optional[str] = None


class InvoiceCreate(InvoiceBase):
    pass


class InvoiceUpdate(BaseModel):
    invoice_number: Optional[str] = None
    amount: Optional[float] = None
    vendor: Optional[str] = None
    category: Optional[str] = None
    currency: Optional[str] = None
    due_date: Optional[date] = None
    description: Optional[str] = None
    file_url: Optional[str] = None
    status: Optional[str] = None


class InvoiceApproval(BaseModel):
    status: str  # APPROVED, REJECTED, PAID


class InvoiceResponse(InvoiceBase):
    id: str
    uploaded_by: Optional[str] = None
    status: str
    approved_by: Optional[str] = None
    created_at: datetime
    
    class Config:
        from_attributes = True
