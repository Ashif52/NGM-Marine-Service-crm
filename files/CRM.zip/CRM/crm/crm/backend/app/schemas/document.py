from pydantic import BaseModel
from typing import Optional
from datetime import date, datetime


class DocumentBase(BaseModel):
    document_type: str
    document_name: str
    ship_id: Optional[str] = None
    crew_id: Optional[str] = None
    file_url: Optional[str] = None
    expiry_date: Optional[date] = None


class DocumentCreate(DocumentBase):
    pass


class DocumentUpdate(BaseModel):
    document_type: Optional[str] = None
    document_name: Optional[str] = None
    file_url: Optional[str] = None
    expiry_date: Optional[date] = None
    status: Optional[str] = None


class DocumentResponse(DocumentBase):
    id: str
    status: str
    uploaded_by: Optional[str] = None
    created_at: datetime
    
    class Config:
        from_attributes = True
