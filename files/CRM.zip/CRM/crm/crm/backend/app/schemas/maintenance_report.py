from pydantic import BaseModel, UUID4, Field
from typing import Optional, Dict, Any
from datetime import date, datetime

class MaintenanceReportTypeBase(BaseModel):
    """Base schema for maintenance report type"""
    code: str
    name: str
    description: Optional[str] = None

class MaintenanceReportTypeCreate(MaintenanceReportTypeBase):
    """Schema for creating a maintenance report type"""
    pass

class MaintenanceReportType(MaintenanceReportTypeBase):
    """Schema for returning a maintenance report type"""
    id: UUID4
    created_at: datetime
    
    class Config:
        orm_mode = True

class MaintenanceReportBase(BaseModel):
    """Base schema for maintenance report"""
    report_type_id: UUID4
    ship_id: UUID4
    equipment_id: Optional[UUID4] = None
    report_date: date
    report_data: Dict[str, Any] = Field(..., description="JSON data for the report fields")
    remarks: Optional[str] = None
    status: str = "DRAFT"  # DRAFT, SUBMITTED, APPROVED

class MaintenanceReportCreate(MaintenanceReportBase):
    """Schema for creating a maintenance report"""
    pass

class MaintenanceReportUpdate(BaseModel):
    """Schema for updating a maintenance report"""
    report_type_id: Optional[UUID4] = None
    equipment_id: Optional[UUID4] = None
    report_date: Optional[date] = None
    report_data: Optional[Dict[str, Any]] = None
    remarks: Optional[str] = None
    status: Optional[str] = None

class MaintenanceReport(MaintenanceReportBase):
    """Schema for returning a maintenance report"""
    id: UUID4
    created_by: UUID4
    approved_by: Optional[UUID4] = None
    created_at: datetime
    updated_at: datetime
    
    class Config:
        orm_mode = True

class MaintenanceReportWithType(MaintenanceReport):
    """Schema for returning a maintenance report with its type"""
    report_type: MaintenanceReportType
    
    class Config:
        orm_mode = True
