from sqlalchemy import Column, String, UUID, DateTime, ForeignKey, func
from sqlalchemy.orm import relationship
from app.database import Base
import uuid

class ActivityLog(Base):
    """Activity log model for tracking user actions"""
    __tablename__ = "activity_logs"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("profiles.id"), nullable=True)
    action = Column(String, nullable=True)
    module = Column(String, nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    
    # Relationships
    user = relationship("Profile")
    
    def __repr__(self):
        return f"ActivityLog(id={self.id}, action={self.action}, module={self.module})"
