from sqlalchemy import Column, String, UUID, DateTime, ForeignKey, Integer, Date, func, Numeric
from sqlalchemy.orm import relationship
from app.database import Base
import uuid

class EquipmentRunningHours(Base):
    """Equipment running hours tracking model"""
    __tablename__ = "equipment_running_hours"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    equipment_id = Column(UUID(as_uuid=True), ForeignKey("equipments.id"), nullable=False)
    date = Column(Date, nullable=False)
    running_hours = Column(Numeric, nullable=False, default=0)  # Hours run on this date
    total_running_hours = Column(Numeric, nullable=False, default=0)  # Cumulative total
    reported_by = Column(UUID(as_uuid=True), ForeignKey("profiles.id"), nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    
    # Relationships
    equipment = relationship("Equipment", back_populates="running_hours")
    reporter = relationship("Profile", foreign_keys=[reported_by])
    
    def __repr__(self):
        return f"EquipmentRunningHours(id={self.id}, date={self.date}, hours={self.running_hours})"
