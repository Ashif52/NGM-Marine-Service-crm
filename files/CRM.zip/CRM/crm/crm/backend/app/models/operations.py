from sqlalchemy import Column, String, ForeignKey, Enum as SQLEnum, DateTime, Text
from sqlalchemy.orm import relationship
from enum import Enum
from app.models.marine_base import MarineBaseModel

class LogStatus(str, Enum):
    """Work log approval status"""
    SUBMITTED = "submitted"
    APPROVED = "approved"
    REJECTED = "rejected"

class DailyWorkLog(MarineBaseModel):
    """Daily work logs for crew operations"""
    __tablename__ = "daily_work_logs"

    ship_id = Column(ForeignKey("ships.id"), nullable=False)
    crew_id = Column(ForeignKey("users.id"), nullable=False)
    work_description = Column(Text, nullable=False)
    log_date = Column(DateTime, nullable=False)
    attachment_path = Column(String)  # Optional attachment
    status = Column(SQLEnum(LogStatus), default=LogStatus.SUBMITTED)
    reviewed_by = Column(ForeignKey("users.id"), nullable=True)
    reviewed_at = Column(DateTime, nullable=True)
    
    # Additional fields for detailed reporting
    department = Column(String)      # Engine/Deck/Other
    work_type = Column(String)      # Maintenance/Operation/Safety
    hours_worked = Column(String)   # Duration of work
    location = Column(String)       # Location on ship
    weather_conditions = Column(String)  # If relevant
    
    # Relationships
    ship = relationship("Ship", back_populates="daily_logs")
    crew = relationship("User", foreign_keys=[crew_id])
    reviewer = relationship("User", foreign_keys=[reviewed_by])

    def __repr__(self):
        return f"DailyWorkLog(id={self.id}, crew={self.crew_id}, date={self.log_date})"

class IncidentType(str, Enum):
    """Types of incidents as per ISM Code"""
    SAFETY = "safety"           # Safety-related incidents
    ENVIRONMENTAL = "environmental"  # Environmental incidents
    OPERATIONAL = "operational"     # Operational incidents
    SECURITY = "security"         # Security incidents
    NEAR_MISS = "near_miss"       # Near miss reports
    NON_CONFORMITY = "non_conformity"  # ISM non-conformities

class IncidentStatus(str, Enum):
    """Incident report status"""
    OPEN = "open"
    INVESTIGATING = "investigating"
    CORRECTIVE_ACTION = "corrective_action"
    CLOSED = "closed"

class IncidentReport(MarineBaseModel):
    """Incident and non-conformity reports"""
    __tablename__ = "incident_reports"

    ship_id = Column(ForeignKey("ships.id"), nullable=False)
    reported_by = Column(ForeignKey("users.id"), nullable=False)
    incident_type = Column(SQLEnum(IncidentType), nullable=False)
    description = Column(Text, nullable=False)
    immediate_actions = Column(Text)  # Immediate actions taken
    root_cause = Column(Text)        # Root cause analysis
    corrective_action = Column(Text)  # Corrective actions
    preventive_action = Column(Text)  # Preventive actions
    status = Column(SQLEnum(IncidentStatus), default=IncidentStatus.OPEN)
    closed_by = Column(ForeignKey("users.id"), nullable=True)
    closed_at = Column(DateTime, nullable=True)
    
    # Relationships
    ship = relationship("Ship", back_populates="incidents")
    reporter = relationship("User", foreign_keys=[reported_by])
    closer = relationship("User", foreign_keys=[closed_by])

    def __repr__(self):
        return f"IncidentReport(id={self.id}, type={self.incident_type}, status={self.status})"

class AuditType(str, Enum):
    """Types of audits"""
    INTERNAL = "internal"  # Company internal audits
    EXTERNAL = "external"  # Third-party/flag state audits

class AuditLog(MarineBaseModel):
    """Audit records"""
    __tablename__ = "audit_logs"

    ship_id = Column(ForeignKey("ships.id"), nullable=False)
    audit_type = Column(SQLEnum(AuditType), nullable=False)
    findings = Column(Text, nullable=False)
    corrective_action = Column(Text)
    auditor = Column(ForeignKey("users.id"), nullable=False)
    audit_date = Column(DateTime, nullable=False)
    next_audit_date = Column(DateTime)  # For scheduling follow-ups
    
    # Additional audit details
    audit_scope = Column(Text)       # Scope of audit
    reference_documents = Column(Text)  # Referenced procedures
    recommendations = Column(Text)    # Recommendations
    follow_up_notes = Column(Text)   # Follow-up actions
    
    # Relationships
    ship = relationship("Ship", back_populates="audits")
    auditor_profile = relationship("User", foreign_keys=[auditor])

    def __repr__(self):
        return f"AuditLog(id={self.id}, type={self.audit_type}, ship={self.ship_id})"
