from sqlalchemy import Column, String, ForeignKey, Enum as SQLEnum
from sqlalchemy.orm import relationship
from enum import Enum
from app.models.marine_base import MarineBaseModel

class UserRole(str, Enum):
    """User roles as per ISM Code requirements"""
    MASTER = "MASTER"  # DPA/Owner level access
    STAFF = "STAFF"   # Office/Technical staff
    CREW = "CREW"     # Ship-specific users

class User(MarineBaseModel):
    """User model with strict role-based access control"""
    __tablename__ = "users"

    name = Column(String, nullable=False)
    email = Column(String, unique=True, nullable=False)
    password_hash = Column(String, nullable=False)
    role = Column(SQLEnum(UserRole), nullable=False)
    ship_id = Column(ForeignKey("ships.id"), nullable=True)
    
    # Relationships
    ship = relationship("Ship", back_populates="crew")
    created_documents = relationship("Document", foreign_keys="Document.created_by")
    approved_documents = relationship("DocumentVersion", foreign_keys="DocumentVersion.approved_by")
    document_acknowledgements = relationship("DocumentAcknowledgement", back_populates="user")
    performed_pms = relationship("PMSLog", foreign_keys="PMSLog.performed_by")
    reviewed_pms = relationship("PMSLog", foreign_keys="PMSLog.reviewed_by")
    daily_logs = relationship("DailyWorkLog", foreign_keys="DailyWorkLog.crew_id")
    reviewed_logs = relationship("DailyWorkLog", foreign_keys="DailyWorkLog.reviewed_by")
    reported_incidents = relationship("IncidentReport", foreign_keys="IncidentReport.reported_by")
    closed_incidents = relationship("IncidentReport", foreign_keys="IncidentReport.closed_by")
    conducted_audits = relationship("AuditLog", foreign_keys="AuditLog.auditor")

    def __repr__(self):
        return f"User(id={self.id}, name={self.name}, role={self.role})"

    @property
    def is_master(self) -> bool:
        return self.role == UserRole.MASTER

    @property
    def is_staff(self) -> bool:
        return self.role == UserRole.STAFF

    @property
    def is_crew(self) -> bool:
        return self.role == UserRole.CREW
