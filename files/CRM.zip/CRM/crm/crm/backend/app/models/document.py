from sqlalchemy import Column, String, UUID, DateTime, Date, ForeignKey, func
from sqlalchemy.orm import relationship
from app.database import Base
import uuid

class Document(Base):
    """Document model"""
    __tablename__ = "documents"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    ship_id = Column(UUID(as_uuid=True), ForeignKey("ships.id"), nullable=True)
    crew_id = Column(UUID(as_uuid=True), ForeignKey("profiles.id"), nullable=True)
    document_type = Column(String, nullable=False)
    document_name = Column(String, nullable=False)
    file_url = Column(String, nullable=True)
    expiry_date = Column(Date, nullable=True)
    status = Column(String, default="VALID")
    uploaded_by = Column(UUID(as_uuid=True), ForeignKey("profiles.id"), nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    
    # Relationships
    ship = relationship("Ship", back_populates="documents")
    crew = relationship("Profile", foreign_keys=[crew_id], back_populates="documents")
    uploader = relationship("Profile", foreign_keys=[uploaded_by], back_populates="uploaded_documents")
    
    def __repr__(self):
        return f"Document(id={self.id}, name={self.document_name}, type={self.document_type})"
