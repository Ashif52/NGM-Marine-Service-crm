from sqlalchemy import Column, String, UUID, DateTime, ForeignKey, func
from sqlalchemy.orm import relationship
from app.database import Base
import uuid

class Profile(Base):
    """User profile model"""
    __tablename__ = "profiles"
    
    id = Column(UUID(as_uuid=True), primary_key=True)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    name = Column(String)
    role = Column(String, nullable=False)
    ship_id = Column(UUID(as_uuid=True), ForeignKey("ships.id"), nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    nationality = Column(String, nullable=True)
    availability = Column(String, default="AVAILABLE")
    sea_time = Column(String, nullable=True)
    status = Column(String, default="ACTIVE")
    
    # Relationships
    user = relationship("User", back_populates="profile", foreign_keys=[user_id])
    ship = relationship("Ship", back_populates="crew")
    crew_profile = relationship("CrewProfile", back_populates="profile", uselist=False)
    work_logs = relationship("DailyWorkLog", back_populates="crew", foreign_keys="DailyWorkLog.crew_id")
    approved_logs = relationship("DailyWorkLog", foreign_keys="DailyWorkLog.approved_by", back_populates="approver")
    documents = relationship("Document", foreign_keys="Document.crew_id", back_populates="crew")
    uploaded_documents = relationship("Document", foreign_keys="Document.uploaded_by", back_populates="uploader")
    invoices = relationship("Invoice", foreign_keys="Invoice.uploaded_by", back_populates="uploader")
    approved_invoices = relationship("Invoice", foreign_keys="Invoice.approved_by", back_populates="approver")
    pms_assignments = relationship("PMSTask", back_populates="assigned_to_crew")
    pms_logs = relationship("PMSLog", foreign_keys="PMSLog.crew_id", back_populates="crew")
    approved_pms_logs = relationship("PMSLog", foreign_keys="PMSLog.approved_by", back_populates="approver")
    
    def __repr__(self):
        return f"Profile(id={self.id}, name={self.name}, role={self.role})"
