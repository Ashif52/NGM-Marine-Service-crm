from sqlalchemy import Column, String, UUID, DateTime, Numeric, Date, ForeignKey, func
from sqlalchemy.orm import relationship
from app.database import Base
import uuid

class Invoice(Base):
    """Invoice model"""
    __tablename__ = "invoices"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    ship_id = Column(UUID(as_uuid=True), ForeignKey("ships.id"), nullable=True)
    uploaded_by = Column(UUID(as_uuid=True), ForeignKey("profiles.id"), nullable=True)
    invoice_number = Column(String, nullable=True)
    amount = Column(Numeric, nullable=True)
    file_url = Column(String, nullable=True)
    status = Column(String, default="DRAFT")
    approved_by = Column(UUID(as_uuid=True), ForeignKey("profiles.id"), nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    vendor = Column(String, nullable=True)
    category = Column(String, nullable=True)
    currency = Column(String, default="USD")
    due_date = Column(Date, nullable=True)
    description = Column(String, nullable=True)
    
    # Relationships
    ship = relationship("Ship", back_populates="invoices")
    uploader = relationship("Profile", foreign_keys=[uploaded_by], back_populates="invoices")
    approver = relationship("Profile", foreign_keys=[approved_by], back_populates="approved_invoices")
    
    def __repr__(self):
        return f"Invoice(id={self.id}, invoice_number={self.invoice_number})"
