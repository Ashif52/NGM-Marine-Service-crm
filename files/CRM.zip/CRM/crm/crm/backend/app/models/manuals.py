from sqlalchemy import Column, String, Integer, ForeignKey, DateTime, Enum as SQLEnum, JSON, Boolean
from sqlalchemy.orm import relationship
from datetime import datetime
import enum
from .marine_base import MarineBaseModel
from uuid import uuid4

class ManualType(str, enum.Enum):
    SMM = "SMM"  # Safety Management Manual
    CPM = "CPM"  # Company Procedure Manual
    FPM = "FPM"  # Fleet Procedure Manual
    CPMF = "CPMF"  # Company Forms
    FPMF = "FPMF"  # Fleet Forms

class Manual(MarineBaseModel):
    __tablename__ = "manuals"

    title = Column(String, nullable=False)
    manual_type = Column(SQLEnum(ManualType), nullable=False)
    ship_id = Column(String, ForeignKey("ships.id"), nullable=True)
    sections = Column(JSON, nullable=False, default=list)  # List of sections with nested structure
    approved = Column(Boolean, default=False)

    # Relationships
    ship = relationship("Ship", back_populates="manuals")
    versions = relationship("ManualVersion", back_populates="manual", order_by="ManualVersion.version_number")
    acknowledgements = relationship("ManualAcknowledgement", back_populates="manual")
    current_version_id = Column(String, ForeignKey("manual_versions.id"), nullable=True)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        if not self.id:
            self.id = str(uuid4())

class ManualVersion(MarineBaseModel):
    __tablename__ = "manual_versions"

    manual_id = Column(String, ForeignKey("manuals.id"), nullable=False)
    version_number = Column(Integer, nullable=False)
    content = Column(JSON, nullable=False)  # Full manual content including sections
    change_summary = Column(String, nullable=True)
    approved_by = Column(String, ForeignKey("users.id"), nullable=True)
    approved_date = Column(DateTime, nullable=True)

    # Relationships
    manual = relationship("Manual", foreign_keys=[manual_id], back_populates="versions")
    approver = relationship("User", foreign_keys=[approved_by])

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        if not self.id:
            self.id = str(uuid4())

class ManualAcknowledgement(MarineBaseModel):
    __tablename__ = "manual_acknowledgements"

    manual_id = Column(String, ForeignKey("manuals.id"), nullable=False)
    user_id = Column(String, ForeignKey("users.id"), nullable=False)
    version_id = Column(String, ForeignKey("manual_versions.id"), nullable=False)
    acknowledged_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    # Relationships
    manual = relationship("Manual", back_populates="acknowledgements")
    user = relationship("User")
    version = relationship("ManualVersion")

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        if not self.id:
            self.id = str(uuid4())
