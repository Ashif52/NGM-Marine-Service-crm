from sqlalchemy import Column, DateTime, Boolean, func
from app.models.base import BaseModel

class MarineBaseModel(BaseModel):
    """Base model for marine-specific models with audit trail requirements"""
    
    is_active = Column(Boolean, default=True, nullable=False)
    updated_at = Column(DateTime, onupdate=func.now())
    deleted_at = Column(DateTime, nullable=True)  # Soft delete timestamp
    
    # Audit trail columns
    created_by = Column(String, nullable=False)  # User ID who created the record
    updated_by = Column(String, nullable=True)   # User ID who last updated the record
    deleted_by = Column(String, nullable=True)   # User ID who soft-deleted the record
