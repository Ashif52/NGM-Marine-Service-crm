from sqlalchemy import Column, String, UUID, DateTime, ForeignKey, Enum as SQLEnum, func
from sqlalchemy.orm import relationship
from app.database import Base
import uuid
from enum import Enum

class IncidentStatus(str, Enum):
    OPEN = "open"
    IN_PROGRESS = "in_progress"
    CLOSED = "closed"

class AuditType(str, Enum):
    INTERNAL = "internal"
    EXTERNAL = "external"

class IncidentReport(Base):
    """Incident Report model"""
    __tablename__ = "incident_reports"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    ship_id = Column(UUID(as_uuid=True), ForeignKey("ships.id"), nullable=False)
    reported_by = Column(UUID(as_uuid=True), ForeignKey("profiles.id"), nullable=False)
    incident_type = Column(String, nullable=False)
    description = Column(String, nullable=False)
    corrective_action = Column(String, nullable=True)
    status = Column(SQLEnum(IncidentStatus), default=IncidentStatus.OPEN)
    closed_by = Column(UUID(as_uuid=True), ForeignKey("profiles.id"), nullable=True)
    closed_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    
    # Relationships
    ship = relationship("Ship", back_populates="incidents")
    reporter = relationship("Profile", foreign_keys=[reported_by], back_populates="reported_incidents")
    closer = relationship("Profile", foreign_keys=[closed_by], back_populates="closed_incidents")
    
    def __repr__(self):
        return f"IncidentReport(id={self.id}, type={self.incident_type})"

class AuditLog(Base):
    """Audit Log model"""
    __tablename__ = "audit_logs"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    audit_type = Column(SQLEnum(AuditType), nullable=False)
    ship_id = Column(UUID(as_uuid=True), ForeignKey("ships.id"), nullable=False)
    findings = Column(String, nullable=False)
    corrective_action = Column(String, nullable=True)
    auditor = Column(UUID(as_uuid=True), ForeignKey("profiles.id"), nullable=False)
    audit_date = Column(DateTime, nullable=False)
    created_at = Column(DateTime, server_default=func.now())
    
    # Relationships
    ship = relationship("Ship", back_populates="audits")
    auditor_profile = relationship("Profile", back_populates="conducted_audits")
    
    def __repr__(self):
        return f"AuditLog(id={self.id}, type={self.audit_type})"
