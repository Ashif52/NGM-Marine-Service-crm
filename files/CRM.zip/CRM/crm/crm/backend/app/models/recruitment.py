from sqlalchemy import Column, String, UUID, DateTime, Date, ForeignKey, func
from sqlalchemy.orm import relationship
from app.database import Base
import uuid

class Recruitment(Base):
    """Recruitment model for job applicants"""
    __tablename__ = "recruitment"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    candidate_name = Column(String, nullable=False)
    candidate_email = Column(String, nullable=True)
    rank = Column(String, nullable=True)
    nationality = Column(String, nullable=True)
    experience = Column(String, nullable=True)
    status = Column(String, default="APPLIED")
    applied_date = Column(Date, server_default=func.current_date())
    ship_id = Column(UUID(as_uuid=True), ForeignKey("ships.id"), nullable=True)
    resume_url = Column(String, nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    
    # Relationships
    ship = relationship("Ship", back_populates="recruitment_positions")
    
    def __repr__(self):
        return f"Recruitment(id={self.id}, candidate_name={self.candidate_name})"
