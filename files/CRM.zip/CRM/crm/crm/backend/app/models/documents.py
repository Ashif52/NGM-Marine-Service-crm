from sqlalchemy import Column, String, ForeignKey, Enum as SQLEnum, Integer, DateTime
from sqlalchemy.orm import relationship
from enum import Enum
from app.models.marine_base import MarineBaseModel

class ManualType(str, Enum):
    """Document types as per ISM Code requirements"""
    CPM = "CPM"    # Company Procedures Manual
    CPMF = "CPMF"  # Company Procedures Manual Forms
    FPM = "FPM"    # Fleet Procedures Manual
    FPMF = "FPMF"  # Fleet Procedures Manual Forms
    SMM = "SMM"    # Safety Management Manual

class Document(MarineBaseModel):
    """Document model for marine manuals and procedures"""
    __tablename__ = "documents"

    title = Column(String, nullable=False)
    manual_type = Column(SQLEnum(ManualType), nullable=False)
    ship_id = Column(ForeignKey("ships.id"), nullable=True)  # NULL for company-wide docs
    created_by = Column(ForeignKey("users.id"), nullable=False)
    
    # Relationships
    ship = relationship("Ship", back_populates="documents")
    creator = relationship("User", foreign_keys=[created_by])
    versions = relationship("DocumentVersion", back_populates="document")

    def __repr__(self):
        return f"Document(id={self.id}, title={self.title}, type={self.manual_type})"

    @property
    def latest_version(self):
        """Get the latest approved version"""
        return max(self.versions, key=lambda v: v.version_number, default=None)

    @property
    def is_ship_specific(self) -> bool:
        """Check if document requires ship assignment"""
        return self.manual_type in [ManualType.FPM, ManualType.FPMF]

class DocumentVersion(MarineBaseModel):
    """Version control for marine documents"""
    __tablename__ = "document_versions"

    document_id = Column(ForeignKey("documents.id"), nullable=False)
    version_number = Column(Integer, nullable=False)
    revision_date = Column(DateTime, nullable=False)
    file_path = Column(String, nullable=False)
    change_summary = Column(String)
    approved_by = Column(ForeignKey("users.id"), nullable=True)  # Only MASTER can approve
    approved_at = Column(DateTime, nullable=True)
    
    # Relationships
    document = relationship("Document", back_populates="versions")
    approver = relationship("User", foreign_keys=[approved_by])
    acknowledgements = relationship("DocumentAcknowledgement", back_populates="version")

    def __repr__(self):
        return f"DocumentVersion(id={self.id}, doc={self.document_id}, ver={self.version_number})"

class DocumentAcknowledgement(MarineBaseModel):
    """Track document acknowledgements by crew"""
    __tablename__ = "document_acknowledgements"

    document_version_id = Column(ForeignKey("document_versions.id"), nullable=False)
    user_id = Column(ForeignKey("users.id"), nullable=False)
    
    # Relationships
    version = relationship("DocumentVersion", back_populates="acknowledgements")
    user = relationship("User", back_populates="document_acknowledgements")

    def __repr__(self):
        return f"DocumentAcknowledgement(id={self.id}, user={self.user_id}, version={self.document_version_id})"
