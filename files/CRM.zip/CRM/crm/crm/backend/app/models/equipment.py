from sqlalchemy import Column, String, UUID, DateTime, ForeignKey, func, Date, Numeric, Integer
from sqlalchemy.orm import relationship
from app.database import Base
import uuid

class Equipment(Base):
    """Equipment model"""
    __tablename__ = "equipments"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    ship_id = Column(UUID(as_uuid=True), ForeignKey("ships.id"), nullable=True)
    equipment_name = Column(String, nullable=False)
    category = Column(String, nullable=True)
    manufacturer = Column(String, nullable=True)
    model = Column(String, nullable=True)
    serial_number = Column(String, nullable=True)
    installation_date = Column(Date, nullable=True)
    last_maintenance_date = Column(Date, nullable=True)
    next_maintenance_date = Column(Date, nullable=True)
    maintenance_interval_hours = Column(Numeric, nullable=True)
    maintenance_interval_days = Column(Integer, nullable=True)
    total_running_hours = Column(Numeric, default=0)
    created_at = Column(DateTime, server_default=func.now())
    
    # Relationships
    ship = relationship("Ship", back_populates="equipment")
    pms_tasks = relationship("PMSTask", back_populates="equipment")
    spare_parts = relationship("SparePart", back_populates="equipment")
    running_hours = relationship("EquipmentRunningHours", back_populates="equipment")
    maintenance_reports = relationship("MaintenanceReport", back_populates="equipment")
    
    def __repr__(self):
        return f"Equipment(id={self.id}, name={self.equipment_name})"
