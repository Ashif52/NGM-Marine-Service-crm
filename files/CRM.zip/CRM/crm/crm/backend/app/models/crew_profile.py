from sqlalchemy import Column, String, UUID, DateTime, Date, ForeignKey, func, Integer
from sqlalchemy.orm import relationship
from app.database import Base
import uuid

class CrewProfile(Base):
    """Crew profile model extending Profile for crew-specific data"""
    __tablename__ = "crew_profiles"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("profiles.id"), nullable=True)
    rank = Column(String, nullable=True)
    department = Column(String, nullable=True)  # DECK, ENGINE, CATERING
    job_description = Column(String, nullable=True)
    join_date = Column(Date, nullable=True)
    contract_duration = Column(Integer, nullable=True)  # in months
    contract_end_date = Column(Date, nullable=True)
    previous_experience = Column(String, nullable=True)
    emergency_contact_name = Column(String, nullable=True)
    emergency_contact_number = Column(String, nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    
    # Relationships
    profile = relationship("Profile", back_populates="crew_profile")
    certificates = relationship("CrewCertificate", back_populates="crew", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"CrewProfile(id={self.id}, rank={self.rank})"


class CrewCertificate(Base):
    """Crew certificates and documents model"""
    __tablename__ = "crew_certificates"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    crew_id = Column(UUID(as_uuid=True), ForeignKey("crew_profiles.id"), nullable=False)
    name = Column(String, nullable=False)
    certificate_number = Column(String, nullable=True)
    issue_date = Column(Date, nullable=True)
    expiry_date = Column(Date, nullable=True)
    issuing_authority = Column(String, nullable=True)
    document_url = Column(String, nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    
    # Relationships
    crew = relationship("CrewProfile", back_populates="certificates")
    
    def __repr__(self):
        return f"CrewCertificate(id={self.id}, name={self.name})"

