from sqlalchemy import Column, String, UUID, DateTime, ForeignKey, Integer, func, Enum as SQLEnum
from sqlalchemy.orm import relationship
from app.database import Base
import uuid
from enum import Enum

class ManualType(str, Enum):
    CPM = "CPM"
    CPMF = "CPMF"
    FPM = "FPM"
    FPMF = "FPMF"
    SMM = "SMM"

class Document(Base):
    """Document model for CPM/FPM/SMM manuals"""
    __tablename__ = "documents"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    title = Column(String, nullable=False)
    manual_type = Column(SQLEnum(ManualType), nullable=False)
    ship_id = Column(UUID(as_uuid=True), ForeignKey("ships.id"), nullable=True)
    created_by = Column(UUID(as_uuid=True), ForeignKey("profiles.id"), nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, server_default=func.now())
    
    # Relationships
    ship = relationship("Ship", back_populates="documents")
    creator = relationship("Profile", foreign_keys=[created_by], back_populates="created_documents")
    versions = relationship("DocumentVersion", back_populates="document")
    
    def __repr__(self):
        return f"Document(id={self.id}, title={self.title}, type={self.manual_type})"

class DocumentVersion(Base):
    """Document version model"""
    __tablename__ = "document_versions"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    document_id = Column(UUID(as_uuid=True), ForeignKey("documents.id"), nullable=False)
    version_number = Column(Integer, nullable=False)
    revision_date = Column(DateTime, nullable=False)
    file_path = Column(String, nullable=False)
    change_summary = Column(String, nullable=True)
    approved_by = Column(UUID(as_uuid=True), ForeignKey("profiles.id"), nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    
    # Relationships
    document = relationship("Document", back_populates="versions")
    approver = relationship("Profile", foreign_keys=[approved_by], back_populates="approved_documents")
    acknowledgements = relationship("DocumentAcknowledgement", back_populates="document_version")
    
    def __repr__(self):
        return f"DocumentVersion(id={self.id}, version={self.version_number})"

class DocumentAcknowledgement(Base):
    """Document acknowledgement model"""
    __tablename__ = "document_acknowledgements"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    document_version_id = Column(UUID(as_uuid=True), ForeignKey("document_versions.id"), nullable=False)
    user_id = Column(UUID(as_uuid=True), ForeignKey("profiles.id"), nullable=False)
    acknowledged_at = Column(DateTime, server_default=func.now())
    
    # Relationships
    document_version = relationship("DocumentVersion", back_populates="acknowledgements")
    user = relationship("Profile", back_populates="document_acknowledgements")
    
    def __repr__(self):
        return f"DocumentAcknowledgement(id={self.id}, user_id={self.user_id})"
