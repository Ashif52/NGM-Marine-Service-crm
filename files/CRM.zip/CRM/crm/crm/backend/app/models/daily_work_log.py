from sqlalchemy import Column, String, UUID, DateTime, Numeric, ForeignKey, func
from sqlalchemy.orm import relationship
from app.database import Base
import uuid

class DailyWorkLog(Base):
    """Daily work log model"""
    __tablename__ = "daily_work_logs"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    ship_id = Column(UUID(as_uuid=True), ForeignKey("ships.id"), nullable=True)
    crew_id = Column(UUID(as_uuid=True), ForeignKey("profiles.id"), nullable=True)
    work_type = Column(String, nullable=True)
    description = Column(String, nullable=True)
    hours = Column(Numeric, nullable=True)
    photo_url = Column(String, nullable=True)
    status = Column(String, default="PENDING")
    approved_by = Column(UUID(as_uuid=True), ForeignKey("profiles.id"), nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    
    # Relationships
    ship = relationship("Ship", back_populates="work_logs")
    crew = relationship("Profile", foreign_keys=[crew_id], back_populates="work_logs")
    approver = relationship("Profile", foreign_keys=[approved_by], back_populates="approved_logs")
    
    def __repr__(self):
        return f"DailyWorkLog(id={self.id}, work_type={self.work_type})"
