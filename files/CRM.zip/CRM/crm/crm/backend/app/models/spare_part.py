from sqlalchemy import Column, String, UUID, DateTime, ForeignKey, Integer, Date, func, Numeric
from sqlalchemy.orm import relationship
from app.database import Base
import uuid

class SparePart(Base):
    """Spare parts inventory model"""
    __tablename__ = "spare_parts"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    equipment_id = Column(UUID(as_uuid=True), ForeignKey("equipments.id"), nullable=True)
    ship_id = Column(UUID(as_uuid=True), ForeignKey("ships.id"), nullable=False)
    part_number = Column(String, nullable=True)
    part_name = Column(String, nullable=False)
    manufacturer = Column(String, nullable=True)
    quantity = Column(Integer, nullable=False, default=0)
    min_quantity = Column(Integer, default=1)
    unit = Column(String, nullable=True)
    location_on_ship = Column(String, nullable=True)
    last_ordered_date = Column(Date, nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())
    
    # Relationships
    equipment = relationship("Equipment", back_populates="spare_parts")
    ship = relationship("Ship", back_populates="spare_parts")
    transactions = relationship("SparePartTransaction", back_populates="spare_part")
    
    def __repr__(self):
        return f"SparePart(id={self.id}, part_name={self.part_name}, quantity={self.quantity})"


class SparePartTransaction(Base):
    """Spare parts transaction history model"""
    __tablename__ = "spare_part_transactions"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    spare_part_id = Column(UUID(as_uuid=True), ForeignKey("spare_parts.id"), nullable=False)
    transaction_type = Column(String, nullable=False)  # RECEIPT, USAGE, ADJUSTMENT
    quantity = Column(Integer, nullable=False)
    reference_number = Column(String, nullable=True)
    remarks = Column(String, nullable=True)
    created_by = Column(UUID(as_uuid=True), ForeignKey("profiles.id"), nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    
    # Relationships
    spare_part = relationship("SparePart", back_populates="transactions")
    creator = relationship("Profile", foreign_keys=[created_by])
    
    def __repr__(self):
        return f"SparePartTransaction(id={self.id}, type={self.transaction_type}, quantity={self.quantity})"
