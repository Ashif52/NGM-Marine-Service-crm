from sqlalchemy import Column, String, UUID, DateTime, ForeignKey, Enum as SQLEnum, Boolean, func
from sqlalchemy.orm import relationship
from app.database import Base
import uuid
from enum import Enum

class IntervalType(str, Enum):
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"

class ManualReference(str, Enum):
    CPM = "CPM"
    FPM = "FPM"

class PMSStatus(str, Enum):
    COMPLETED = "completed"
    PENDING = "pending"

class PMSTask(Base):
    """Planned Maintenance System Task model"""
    __tablename__ = "pms_tasks"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    ship_id = Column(UUID(as_uuid=True), ForeignKey("ships.id"), nullable=False)
    equipment_name = Column(String, nullable=False)
    task_description = Column(String, nullable=False)
    interval_type = Column(SQLEnum(IntervalType), nullable=False)
    reference_manual = Column(SQLEnum(ManualReference), nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, server_default=func.now())
    
    # Relationships
    ship = relationship("Ship", back_populates="pms_tasks")
    logs = relationship("PMSLog", back_populates="task")
    
    def __repr__(self):
        return f"PMSTask(id={self.id}, equipment={self.equipment_name})"

class PMSLog(Base):
    """PMS Log model"""
    __tablename__ = "pms_logs"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    pms_task_id = Column(UUID(as_uuid=True), ForeignKey("pms_tasks.id"), nullable=False)
    performed_by = Column(UUID(as_uuid=True), ForeignKey("profiles.id"), nullable=False)
    performed_date = Column(DateTime, nullable=False)
    remarks = Column(String, nullable=True)
    status = Column(SQLEnum(PMSStatus), default=PMSStatus.PENDING)
    reviewed_by = Column(UUID(as_uuid=True), ForeignKey("profiles.id"), nullable=True)
    reviewed_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    
    # Relationships
    task = relationship("PMSTask", back_populates="logs")
    performer = relationship("Profile", foreign_keys=[performed_by], back_populates="performed_pms_logs")
    reviewer = relationship("Profile", foreign_keys=[reviewed_by], back_populates="reviewed_pms_logs")
    
    def __repr__(self):
        return f"PMSLog(id={self.id}, task_id={self.pms_task_id})"
