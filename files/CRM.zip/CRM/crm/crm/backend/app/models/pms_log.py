from sqlalchemy import Column, String, UUID, DateTime, ForeignKey, func
from sqlalchemy.orm import relationship
from app.database import Base
import uuid

class PMSLog(Base):
    """Planned Maintenance System Log model"""
    __tablename__ = "pms_logs"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    pms_task_id = Column(UUID(as_uuid=True), ForeignKey("pms_tasks.id"), nullable=True)
    crew_id = Column(UUID(as_uuid=True), ForeignKey("profiles.id"), nullable=True)
    remarks = Column(String, nullable=True)
    photo_url = Column(String, nullable=True)
    status = Column(String, default="PENDING")
    approved_by = Column(UUID(as_uuid=True), ForeignKey("profiles.id"), nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    
    # Relationships
    pms_task = relationship("PMSTask", back_populates="pms_logs")
    crew = relationship("Profile", foreign_keys=[crew_id], back_populates="pms_logs")
    approver = relationship("Profile", foreign_keys=[approved_by], back_populates="approved_pms_logs")
    
    def __repr__(self):
        return f"PMSLog(id={self.id})"
