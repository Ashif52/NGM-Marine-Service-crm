from sqlalchemy import Column, String, UUID, DateTime, Integer, ForeignKey, func
from sqlalchemy.orm import relationship
from app.database import Base
import uuid

class Ship(Base):
    """Ship model"""
    __tablename__ = "ships"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    ship_name = Column(String, nullable=False)
    imo_number = Column(String, nullable=True)
    ship_type = Column(String, nullable=True)
    status = Column(String, default="ACTIVE")
    created_at = Column(DateTime, server_default=func.now())
    flag = Column(String, nullable=True)
    client_id = Column(UUID(as_uuid=True), ForeignKey("clients.id"), nullable=True)
    crew_capacity = Column(Integer, nullable=True)
    
    # Relationships
    client = relationship("Client", back_populates="ships")
    crew = relationship("Profile", back_populates="ship")
    equipment = relationship("Equipment", back_populates="ship")
    work_logs = relationship("DailyWorkLog", back_populates="ship")
    documents = relationship("Document", back_populates="ship")
    invoices = relationship("Invoice", back_populates="ship")
    recruitment_positions = relationship("Recruitment", back_populates="ship")
    spare_parts = relationship("SparePart", back_populates="ship")
    maintenance_reports = relationship("MaintenanceReport", back_populates="ship")
    
    def __repr__(self):
        return f"Ship(id={self.id}, name={self.ship_name})"
