from sqlalchemy import Column, String, UUID, DateTime, ForeignKey, Integer, Date, func, Numeric, JSON
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import relationship
from app.database import Base
import uuid

class MaintenanceReportType(Base):
    """Maintenance report type model"""
    __tablename__ = "maintenance_report_types"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    code = Column(String, unique=True, nullable=False)
    name = Column(String, nullable=False)
    description = Column(String, nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    
    # Relationships
    reports = relationship("MaintenanceReport", back_populates="report_type")
    
    def __repr__(self):
        return f"MaintenanceReportType(id={self.id}, code={self.code}, name={self.name})"


class MaintenanceReport(Base):
    """Maintenance report model"""
    __tablename__ = "maintenance_reports"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    report_type_id = Column(UUID(as_uuid=True), ForeignKey("maintenance_report_types.id"), nullable=False)
    ship_id = Column(UUID(as_uuid=True), ForeignKey("ships.id"), nullable=False)
    equipment_id = Column(UUID(as_uuid=True), ForeignKey("equipments.id"), nullable=True)
    report_date = Column(Date, nullable=False)
    report_data = Column(JSONB, nullable=False)
    remarks = Column(String, nullable=True)
    status = Column(String, nullable=False, default="DRAFT")  # DRAFT, SUBMITTED, APPROVED
    created_by = Column(UUID(as_uuid=True), ForeignKey("profiles.id"), nullable=False)
    approved_by = Column(UUID(as_uuid=True), ForeignKey("profiles.id"), nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())
    
    # Relationships
    report_type = relationship("MaintenanceReportType", back_populates="reports")
    ship = relationship("Ship", back_populates="maintenance_reports")
    equipment = relationship("Equipment", back_populates="maintenance_reports")
    creator = relationship("Profile", foreign_keys=[created_by])
    approver = relationship("Profile", foreign_keys=[approved_by])
    
    def __repr__(self):
        return f"MaintenanceReport(id={self.id}, type={self.report_type.code}, date={self.report_date}, status={self.status})"
