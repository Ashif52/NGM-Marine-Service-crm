from sqlalchemy import Column, String, UUID, DateTime, Boolean, func
from sqlalchemy.orm import relationship
from app.database import Base
import uuid

class User(Base):
    """User model for authentication"""
    __tablename__ = "users"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email = Column(String, unique=True, nullable=False)
    password = Column(String, nullable=False)
    created_at = Column(DateTime, server_default=func.now())
    last_login = Column(DateTime, nullable=True)
    is_active = Column(Boolean, default=True)
    
    # Relationships
    profile = relationship("Profile", back_populates="user", uselist=False)
    
    def __repr__(self):
        return f"User(id={self.id}, email={self.email})"
