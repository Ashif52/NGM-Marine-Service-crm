from sqlalchemy import Column, DateTime, String, UUID, func
from sqlalchemy.ext.declarative import declared_attr
from sqlalchemy.sql import expression
import uuid

class BaseModel:
    """Base class for all models"""
    
    @declared_attr
    def __tablename__(cls):
        return cls.__name__.lower()
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    created_at = Column(DateTime, server_default=func.now())
