from sqlalchemy import Column, String, ForeignKey, Enum as SQLEnum, DateTime, Text
from sqlalchemy.orm import relationship
from enum import Enum
from app.models.marine_base import MarineBaseModel
from app.models.documents import ManualType

class IntervalType(str, Enum):
    """PMS task intervals"""
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"

class PMSStatus(str, Enum):
    """PMS task status"""
    PENDING = "pending"      # Not yet started
    COMPLETED = "completed"  # Completed by crew
    REVIEWED = "reviewed"    # Reviewed by staff
    APPROVED = "approved"    # Approved by master
    OVERDUE = "overdue"     # Past due date

class PMSTask(MarineBaseModel):
    """Planned Maintenance System tasks"""
    __tablename__ = "pms_tasks"

    ship_id = Column(ForeignKey("ships.id"), nullable=False)
    equipment_name = Column(String, nullable=False)
    task_description = Column(Text, nullable=False)
    interval = Column(SQLEnum(IntervalType), nullable=False)
    reference_manual = Column(SQLEnum(ManualType), nullable=False)  # CPM or FPM reference
    next_due_date = Column(DateTime, nullable=False)
    
    # Relationships
    ship = relationship("Ship", back_populates="pms_tasks")
    logs = relationship("PMSLog", back_populates="task")

    def __repr__(self):
        return f"PMSTask(id={self.id}, equipment={self.equipment_name}, interval={self.interval})"

    @property
    def status(self) -> PMSStatus:
        """Calculate current task status"""
        if not self.logs:
            return PMSStatus.PENDING
        latest_log = max(self.logs, key=lambda l: l.performed_date)
        return latest_log.status

class PMSLog(MarineBaseModel):
    """PMS task completion logs"""
    __tablename__ = "pms_logs"

    pms_task_id = Column(ForeignKey("pms_tasks.id"), nullable=False)
    performed_by = Column(ForeignKey("users.id"), nullable=False)  # CREW only
    performed_date = Column(DateTime, nullable=False)
    remarks = Column(Text)
    status = Column(SQLEnum(PMSStatus), default=PMSStatus.PENDING)
    reviewed_by = Column(ForeignKey("users.id"), nullable=True)  # STAFF/MASTER
    reviewed_at = Column(DateTime, nullable=True)
    
    # Optional fields for detailed reporting
    running_hours = Column(String)  # Equipment running hours if applicable
    parts_used = Column(Text)       # Parts used in maintenance
    tools_used = Column(Text)       # Tools used in maintenance
    safety_checks = Column(Text)    # Safety checks performed
    
    # Relationships
    task = relationship("PMSTask", back_populates="logs")
    performer = relationship("User", foreign_keys=[performed_by])
    reviewer = relationship("User", foreign_keys=[reviewed_by])

    def __repr__(self):
        return f"PMSLog(id={self.id}, task={self.pms_task_id}, status={self.status})"
