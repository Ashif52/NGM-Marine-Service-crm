from sqlalchemy import Column, String, UUID, DateTime, func
from sqlalchemy.orm import relationship
from app.database import Base
import uuid

class Client(Base):
    """Client model"""
    __tablename__ = "clients"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    company_name = Column(String, nullable=False)
    contact_person = Column(String, nullable=True)
    email = Column(String, nullable=True)
    phone = Column(String, nullable=True)
    address = Column(String, nullable=True)
    status = Column(String, default="ACTIVE")
    created_at = Column(DateTime, server_default=func.now())
    
    # Relationships
    ships = relationship("Ship", back_populates="client")
    
    def __repr__(self):
        return f"Client(id={self.id}, name={self.company_name})"
