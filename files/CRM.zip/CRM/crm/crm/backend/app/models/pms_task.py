from sqlalchemy import Column, String, UUID, DateTime, Date, ForeignKey, func, Numeric
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import relationship
from app.database import Base
import uuid

class PMSTask(Base):
    """Planned Maintenance System Task model"""
    __tablename__ = "pms_tasks"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    equipment_id = Column(UUID(as_uuid=True), ForeignKey("equipments.id"), nullable=True)
    task_name = Column(String, nullable=False)
    job_number = Column(String, nullable=True)
    job_description = Column(String, nullable=True)
    frequency = Column(String, nullable=True)  # DAILY, WEEKLY, MONTHLY
    interval_type = Column(String, nullable=True)  # RUNNING_HOURS, CALENDAR, CONDITION
    interval_value = Column(Numeric, nullable=True)
    estimated_hours = Column(Numeric, nullable=True)
    assigned_to = Column(UUID(as_uuid=True), ForeignKey("profiles.id"), nullable=True)
    due_date = Column(Date, nullable=True)
    last_done_date = Column(Date, nullable=True)
    last_done_hours = Column(Numeric, nullable=True)
    status = Column(String, default="PENDING")
    priority = Column(String, nullable=True)  # LOW, MEDIUM, HIGH, CRITICAL
    risk_assessment = Column(String, nullable=True)
    safety_precautions = Column(String, nullable=True)
    required_parts = Column(JSONB, nullable=True)
    required_tools = Column(String, nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    
    # Relationships
    equipment = relationship("Equipment", back_populates="pms_tasks")
    assigned_to_crew = relationship("Profile", back_populates="pms_assignments")
    pms_logs = relationship("PMSLog", back_populates="pms_task")
    
    def __repr__(self):
        return f"PMSTask(id={self.id}, task_name={self.task_name})"
