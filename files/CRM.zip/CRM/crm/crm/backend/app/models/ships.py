from sqlalchemy import Column, String, Enum as SQLEnum
from sqlalchemy.orm import relationship
from enum import Enum
from app.models.marine_base import MarineBaseModel

class ShipType(str, Enum):
    """Ship types as per IMO classification"""
    BULK_CARRIER = "BULK_CARRIER"
    TANKER = "TANKER"
    CONTAINER = "CONTAINER"
    GENERAL_CARGO = "GENERAL_CARGO"
    RORO = "RORO"
    PASSENGER = "PASSENGER"
    OFFSHORE = "OFFSHORE"

class ShipStatus(str, Enum):
    """Ship operational status"""
    ACTIVE = "ACTIVE"           # In normal operation
    MAINTENANCE = "MAINTENANCE" # Under repair/maintenance
    DOCKED = "DOCKED"          # In port/docked
    LAID_UP = "LAID_UP"        # Long-term storage
    SUSPENDED = "SUSPENDED"     # Operations suspended

class Ship(MarineBaseModel):
    """Ship model with IMO-compliant fields"""
    __tablename__ = "ships"

    name = Column(String, nullable=False)
    imo_number = Column(String, unique=True, nullable=False)
    flag = Column(String, nullable=False)  # Flag state
    ship_type = Column(SQLEnum(ShipType), nullable=False)
    status = Column(SQLEnum(ShipStatus), default=ShipStatus.ACTIVE)
    
    # Optional fields
    call_sign = Column(String)
    port_of_registry = Column(String)
    classification_society = Column(String)
    gross_tonnage = Column(String)
    net_tonnage = Column(String)
    year_built = Column(String)
    
    # Relationships
    crew = relationship("User", back_populates="ship")
    equipment = relationship("Equipment", back_populates="ship")
    documents = relationship("Document", back_populates="ship")
    pms_tasks = relationship("PMSTask", back_populates="ship")
    daily_logs = relationship("DailyWorkLog", back_populates="ship")
    incidents = relationship("IncidentReport", back_populates="ship")
    audits = relationship("AuditLog", back_populates="ship")

    def __repr__(self):
        return f"Ship(id={self.id}, name={self.name}, imo={self.imo_number})"
