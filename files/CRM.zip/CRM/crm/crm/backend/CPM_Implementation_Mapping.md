# Company Procedures Manual (CPM) Coverage and Backend Implementation Mapping

This document explains what each file in `resources/mds/cpm` covers and how our backend at `backend/` supports it today. It highlights implemented items, partial support, and gaps with suggested next steps.

## Folder Contents Summary (resources/mds/cpm)
- CPM 01 Personnel management.md
- CPM 02 Controls & records.md
- CPM 03 Document & data control.md
- CPM 04 Competence Awarence & Training.md
- CPM 05 Purchasing (1).md
- CPM 06 Control of NCs Accidents.md
- CPM 07 Corrective & Preventive action.md
- CPM 08 Internal Audit (1).md
- CPM 09 Management Review.md
- CPM 10 General Operations.md
- CPM 11 Company Emergency Response (1).md
- CPM 12 Insurance & claims.md
- CPM 13 Surveys & Inspections.md
- CPM 14 Lay ups & dry docking.md
- CPM 15 Resources to DPA.md
- CPM A–G: Cover page, ToC, addresses, controlled copies, issue/revision logs, master list of documents

---

## Mapping: CPM Requirements → Backend Status

### 1) CPM 01 Personnel management
- Scope: Organization, roles, responsibilities, manning, crew records.
- Implemented:
  - Crew master data, role `CREW` under profiles
  - Crew creation and onboarding
  - Ship assignment/unassignment
  - Crew certifications tracking with expiry views
- Backend:
  - Models: `Profile`, `CrewProfile`, `CrewCertificate`, `User`, `Ship`
  - Routers:
    - `POST/GET/PUT /api/crew`, `POST /api/crew/{id}/assign`, `POST /api/crew/{id}/unassign`
    - `POST/GET/PUT/DELETE /api/certificates/*`, `GET /api/certificates/expiring/{days}`
  - Security: Role-based access (MASTER/STAFF/CREW)
- Gaps / Next:
  - Performance appraisal records, rest/work hours logs (referenced in FPMF forms) – partial via work logs but needs dedicated module.

### 2) CPM 02 Controls & records
- Scope: Controlled records, retention, audit trails.
- Implemented (partial):
  - PMS entities keep timestamps and histories (spare part transactions, running hours, maintenance reports)
  - Basic work logs module
- Backend:
  - Routers: `/api/spare-parts`, `/api/spare-parts/transactions`, `/api/equipment-hours`, `/api/maintenance-reports`, `/api/work-logs`
- Gaps / Next:
  - Centralized records registry, retention policies, and export.

### 3) CPM 03 Document & data control
- Scope: Controlled documents, revisions, access.
- Implemented (partial):
  - Document model exists in DB; endpoints currently commented out in app include.
- Backend:
  - Models: `Document` (referenced by `Profile`)
  - Routers: documents router planned, not enabled
- Gaps / Next:
  - Enable documents router, upload/storage, versioning, approval workflow, access control.

### 4) CPM 04 Competence Awareness & Training
- Scope: Competency tracking, training plans, awareness.
- Implemented (partial):
  - Certifications tracked with expiry
- Gaps / Next:
  - Dedicated training records, courses, assessments, CPD hours.

### 5) CPM 05 Purchasing
- Scope: Purchasing process, requisitions, POs, receipts.
- Implemented (partial):
  - Inventory via spare parts; transactions include RECEIPT with `reference_number` (can hold PO#)
- Backend:
  - Routers: `/api/spare-parts`, `/api/spare-parts/transactions`
- Gaps / Next:
  - Requisitions, approvals, suppliers, POs, GRN, 3-way match.

### 6) CPM 06 Control of NCs & Accidents
- Scope: Non-conformities, incidents, investigations.
- Implemented: Not yet.
- Next:
  - NCR/Incident models and endpoints, root cause, actions, lessons learned.

### 7) CPM 07 Corrective & Preventive Action (CAPA)
- Scope: CAPA lifecycle linked to audits/incidents.
- Implemented: Not yet.
- Next:
  - CAPA entity with assignments, due dates, effectiveness checks.

### 8) CPM 08 Internal Audit
- Scope: Internal audit planning, execution, findings, follow-up.
- Implemented: Not yet.
- Next:
  - Audit plans, checklists, findings, link to CAPA.

### 9) CPM 09 Management Review
- Scope: MR meetings, inputs/outputs, actions.
- Implemented: Not yet.
- Next:
  - MR records, agendas, decisions, action tracking.

### 10) CPM 10 General Operations
- Scope: Operational controls, checklists.
- Implemented (partial):
  - Operational data via ships, work logs, PMS tasks, maintenance reports
- Gaps / Next:
  - Broader ops checklists and procedure-specific records.

### 11) CPM 11 Company Emergency Response
- Scope: ERP structure, drills, logs.
- Implemented: Not yet.
- Next:
  - ERP incident logs, drills, muster lists, communication records.

### 12) CPM 12 Insurance & claims
- Scope: Policies, claims lifecycle.
- Implemented: Not yet.
- Next:
  - Policy registry, claims module, attachments, status.

### 13) CPM 13 Surveys & Inspections
- Scope: Class/flag/client surveys, findings, closures.
- Implemented (partial):
  - Can log outcomes via maintenance reports; not dedicated
- Next:
  - Surveys/inspection entities, schedules, deficiencies, link to CAPA.

### 14) CPM 14 Lay ups & dry docking
- Scope: Dry-dock planning, work packs, costs, reports.
- Implemented: Not yet.
- Next:
  - Dry-dock projects, jobs, budgets, vendor work, post-dock reports.

### 15) CPM 15 Resources to DPA
- Scope: DPA resources, reporting lines, responsibilities.
- Implemented: Not specifically.
- Next:
  - DPA dashboard and reporting endpoints.

### CPM A–G (meta-docs)
- Scope: Controlled distribution, issue/revisions, address lists, master lists.
- Backend: Not applicable; can be supported by document control module.

---

## Implemented Core Modules (Backend)
- Authentication/Users: `auth` router, `User`, JWT with HTTP Bearer
- Profiles & Crew Management: `Profile`, `CrewProfile`, `CrewCertificate`, `crew` and `certificates` routers
- Fleet/Ships: `Ship` model, `ships` router
- PMS:
  - Inventory: `SparePart`, `SparePartTransaction`, `spare_parts` router
  - Equipment Hours: `EquipmentRunningHours`, `equipment_running_hours` router
  - Maintenance Reports: `MaintenanceReport`, `MaintenanceReportType`, `maintenance_reports` router
- Work Logs: `work_logs` router

## Partially Implemented / Planned
- Documents: model present; router to enable and extend
- Purchasing: basic via spare parts receipts; full procurement pending
- Records governance: central registry/retention to design

## Not Yet Implemented (High-Level)
- Incidents/NCR + CAPA
- Internal Audits
- Management Reviews
- Insurance & Claims
- Surveys/Inspections (dedicated)
- Dry-docking projects
- ERP/Drills

---

## Recommended Next Steps (Prioritized)
1) Enable Document Control module (upload/versions/ACL) – supports CPM 03 and multiple others
2) Procurement workflow (requisitions→PO→GRN) – CPM 05
3) Incidents/NCR + CAPA – CPM 06–07
4) Internal Audit + linkage to CAPA – CPM 08
5) Surveys/Inspections + linkage to CAPA – CPM 13
6) Dry-docking project module – CPM 14

This mapping should help align development with CPM compliance and clarify what is already operational in the backend.
