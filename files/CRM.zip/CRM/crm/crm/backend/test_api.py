import requests
import json

# Base URL for the API
BASE_URL = "http://localhost:8000"

def test_endpoints():
    print("Testing API endpoints...")
    
    # Test root endpoint
    try:
        response = requests.get(f"{BASE_URL}/")
        print(f"Root endpoint: {response.status_code} - {response.json()}")
    except Exception as e:
        print(f"Root endpoint error: {e}")
    
    # Test health endpoint
    try:
        response = requests.get(f"{BASE_URL}/health")
        print(f"Health endpoint: {response.status_code} - {response.json()}")
    except Exception as e:
        print(f"Health endpoint error: {e}")
    
    # Test docs endpoint
    try:
        response = requests.get(f"{BASE_URL}/docs")
        print(f"Docs endpoint: {response.status_code}")
    except Exception as e:
        print(f"Docs endpoint error: {e}")
    
    # Test auth signup endpoint
    try:
        signup_data = {
            "email": "test@example.com",
            "password": "testpassword123",
            "name": "Test User",
            "role": "STAFF"
        }
        response = requests.post(f"{BASE_URL}/api/auth/signup", json=signup_data)
        print(f"Auth signup: {response.status_code}")
        if response.status_code != 200:
            print(f"  Error: {response.text}")
    except Exception as e:
        print(f"Auth signup error: {e}")

if __name__ == "__main__":
    test_endpoints()
