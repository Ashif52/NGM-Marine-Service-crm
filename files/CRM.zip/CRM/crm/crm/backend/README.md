# NMG Marine CRM - Backend API

FastAPI backend for NMG Marine CRM System.

## Setup

1. Create virtual environment:
```bash
python -m venv venv
venv\Scripts\activate  # Windows
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Configure environment variables in `.env` file

4. Run the server:

   a. With Supabase integration:
   ```bash
   # This runs the original version with Supabase client
   uvicorn app.main:app --reload --port 8000
   ```

   b. With SQLAlchemy integration:
   ```bash
   # This runs the SQLAlchemy version for direct PostgreSQL access
   python sql_app.py
   ```

## API Documentation

Once running, visit:
- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

## Project Structure

```
backend/
├── app/
│   ├── __init__.py
│   ├── main.py              # FastAPI application
│   ├── config.py            # Configuration settings
│   ├── database.py          # Supabase client
│   ├── db/                  # SQLAlchemy implementation
│   │   ├── database.py      # SQLAlchemy connection setup
│   │   ├── models/          # SQLAlchemy ORM models
│   │   └── repositories/    # Repository pattern implementations
│   ├── schemas/
│   │   ├── __init__.py      # Pydantic schemas for Supabase
│   │   └── sql/             # Pydantic schemas for SQLAlchemy
│   ├── routers/
│   │   ├── __init__.py      # API endpoints for Supabase
│   │   └── sql/             # API endpoints for SQLAlchemy
│   └── utils/               # Utilities
├── requirements.txt
├── .env
├── run.py                   # Script to run the Supabase version
├── sql_app.py               # Script to run the SQLAlchemy version
├── simple_app.py            # Simplified test app
└── README.md
```

## Roles

- **MASTER**: Full access to all features
- **STAFF**: Operations access (no approvals)
- **CREW**: Limited access to assigned ship tasks

## Implementation Options

### Supabase Implementation

The original implementation uses the Supabase client to interact with the PostgreSQL database. This approach leverages Supabase's built-in authentication and real-time features.

### SQLAlchemy Implementation

The alternative implementation uses SQLAlchemy for direct PostgreSQL access. This approach:

- Eliminates dependency conflicts with the Supabase client
- Provides more flexibility with database operations
- Uses the repository pattern for clean separation of concerns
- Makes it easier to test with mock database connections

## Dependency Compatibility Issues

When using the Supabase client, we encountered the following compatibility issues:

1. The `supabase==2.3.0` package requires `httpx<0.25.0` while other packages might require newer versions.
2. Supabase libraries have specific Pydantic version requirements:
   - `gotrue 0.5.4` requires `pydantic<2.0.0` (specifically works with `pydantic==1.10.8`)
   - Newer versions of FastAPI work better with `pydantic>=2.0.0`
3. The Supabase client requires the API key to be in the correct format (service role key JWT format).

To resolve these issues, you can:

1. Use the SQLAlchemy implementation for direct database access
2. Create a dedicated virtual environment with specific versions:
   ```
   fastapi==0.104.1
   pydantic==1.10.8
   supabase==0.7.1
   httpx==0.23.0
   ```
